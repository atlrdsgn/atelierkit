/** @format */

export * from './paragraph'
