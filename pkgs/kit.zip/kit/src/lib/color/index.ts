/** @format */

export {kitColorPalette} from './color.index'
export {darkKitColorPalette} from './color.index'
