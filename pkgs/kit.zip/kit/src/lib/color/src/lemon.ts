/** @format */

export const lemon = {
  lemon0: `#fcfff5`,
  lemon1: `#faffec`,
  lemon2: `#f7ffe2`,
  lemon3: `#f3ffd9`,
  lemon4: `#edffc4`,
  lemon5: `#e6ffb3`,
  lemon6: `#e0ff9e`,
  lemon7: `#b6cc7f`,
  lemon8: `#899c5f`,
  lemon9: `#5c6a3f`,
  lemon10: `#465131`,
  lemon11: `#2f3920`,
  lemon12: `#1b1f10`,
  lemon13: `#050600`,
} as const
