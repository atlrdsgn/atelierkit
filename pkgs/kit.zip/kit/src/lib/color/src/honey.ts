/** @format */

export const honey = {
  honeyA: `rgba(226, 255, 115, 1)`,
}
