/** @format */

export const volt = {
  volt0: `#eeffec`,
  volt1: `#ddffdb`,
  volt2: `#cdffcb`,
  volt3: `#bdffb7`,
  volt4: `#9aff93`,
  volt5: `#7bff71`,
  volt6: `#56ff4d`,
  volt7: `#46cf3f`,
  volt8: `#359f2d`,
  volt9: `#247020`,
  volt10: `#1b5816`,
  volt11: `#124010`,
  volt12: `#0a2908`,
  volt13: `#011000`,
} as const
