/** @format */

export const slate = {
  slate0: `#f4f4f5`,
  slate1: `#e7e9eb`,
  slate2: `#dcdee1`,
  slate3: `#d1d3d9`,
  slate4: `#bbbdc5`,
  slate5: `#a3a7b1`,
  slate6: `#8b919e`,
  slate7: `#727680`,
  slate8: `#585a62`,
  slate9: `#3d3f45`,
  slate10: `#2f3137`,
  slate11: `#212327`,
  slate12: `#141618`,
  slate13: `#080809`,
} as const
