/** @format */

export const sapphire = {
  sapphire0: `#f4f1f9`,
  sapphire1: `#e7e1f4`,
  sapphire2: `#dcd3ed`,
  sapphire3: `#d1c4e9`,
  sapphire4: `#b9a6de`,
  sapphire5: `#a289d2`,
  sapphire6: `#8b6bc7`,
  sapphire7: `#7056a2`,
  sapphire8: `#54427a`,
  sapphire9: `#3a2d54`,
  sapphire10: `#2d2241`,
  sapphire11: `#20182d`,
  sapphire12: `#120d1a`,
  sapphire13: `#040307`,
} as const
