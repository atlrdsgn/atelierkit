/*! 
    atelierkit© v0.3.3. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
     */
import * as A from "react";
import H, { createContext as mr, useContext as Mr, useState as G, forwardRef as q, createElement as w, Children as Xe, useMemo as lr, useRef as te, useEffect as ie, useCallback as ae, useLayoutEffect as Tt, isValidElement as Or, cloneElement as yo, Fragment as Co, useReducer as vn } from "react";
import * as wo from "@radix-ui/react-avatar";
import * as kn from "react-dom";
import bn, { flushSync as At, createPortal as zt } from "react-dom";
import * as Ie from "@radix-ui/react-menubar";
import * as Be from "@radix-ui/react-popover";
import { Thumb as xn, Root as yn } from "@radix-ui/react-switch";
import * as Nr from "@radix-ui/react-tooltip";
var po = { exports: {} }, pr = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Uo;
function Cn() {
  if (Uo)
    return pr;
  Uo = 1;
  var e = H, r = Symbol.for("react.element"), o = Symbol.for("react.fragment"), t = Object.prototype.hasOwnProperty, i = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, n = { key: !0, ref: !0, __self: !0, __source: !0 };
  function s(l, a, c) {
    var p, d = {}, h = null, u = null;
    c !== void 0 && (h = "" + c), a.key !== void 0 && (h = "" + a.key), a.ref !== void 0 && (u = a.ref);
    for (p in a)
      t.call(a, p) && !n.hasOwnProperty(p) && (d[p] = a[p]);
    if (l && l.defaultProps)
      for (p in a = l.defaultProps, a)
        d[p] === void 0 && (d[p] = a[p]);
    return { $$typeof: r, type: l, key: h, ref: u, props: d, _owner: i.current };
  }
  return pr.Fragment = o, pr.jsx = s, pr.jsxs = s, pr;
}
var gr = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ko;
function wn() {
  return Ko || (Ko = 1, process.env.NODE_ENV !== "production" && function() {
    var e = H, r = Symbol.for("react.element"), o = Symbol.for("react.portal"), t = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), n = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), l = Symbol.for("react.context"), a = Symbol.for("react.forward_ref"), c = Symbol.for("react.suspense"), p = Symbol.for("react.suspense_list"), d = Symbol.for("react.memo"), h = Symbol.for("react.lazy"), u = Symbol.for("react.offscreen"), f = Symbol.iterator, g = "@@iterator";
    function m(_) {
      if (_ === null || typeof _ != "object")
        return null;
      var x = f && _[f] || _[g];
      return typeof x == "function" ? x : null;
    }
    var k = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function v(_) {
      {
        for (var x = arguments.length, $ = new Array(x > 1 ? x - 1 : 0), O = 1; O < x; O++)
          $[O - 1] = arguments[O];
        b("error", _, $);
      }
    }
    function b(_, x, $) {
      {
        var O = k.ReactDebugCurrentFrame, Y = O.getStackAddendum();
        Y !== "" && (x += "%s", $ = $.concat([Y]));
        var re = $.map(function(V) {
          return String(V);
        });
        re.unshift("Warning: " + x), Function.prototype.apply.call(console[_], console, re);
      }
    }
    var C = !1, S = !1, E = !1, P = !1, T = !1, F;
    F = Symbol.for("react.module.reference");
    function U(_) {
      return !!(typeof _ == "string" || typeof _ == "function" || _ === t || _ === n || T || _ === i || _ === c || _ === p || P || _ === u || C || S || E || typeof _ == "object" && _ !== null && (_.$$typeof === h || _.$$typeof === d || _.$$typeof === s || _.$$typeof === l || _.$$typeof === a || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      _.$$typeof === F || _.getModuleId !== void 0));
    }
    function N(_, x, $) {
      var O = _.displayName;
      if (O)
        return O;
      var Y = x.displayName || x.name || "";
      return Y !== "" ? $ + "(" + Y + ")" : $;
    }
    function W(_) {
      return _.displayName || "Context";
    }
    function j(_) {
      if (_ == null)
        return null;
      if (typeof _.tag == "number" && v("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof _ == "function")
        return _.displayName || _.name || null;
      if (typeof _ == "string")
        return _;
      switch (_) {
        case t:
          return "Fragment";
        case o:
          return "Portal";
        case n:
          return "Profiler";
        case i:
          return "StrictMode";
        case c:
          return "Suspense";
        case p:
          return "SuspenseList";
      }
      if (typeof _ == "object")
        switch (_.$$typeof) {
          case l:
            var x = _;
            return W(x) + ".Consumer";
          case s:
            var $ = _;
            return W($._context) + ".Provider";
          case a:
            return N(_, _.render, "ForwardRef");
          case d:
            var O = _.displayName || null;
            return O !== null ? O : j(_.type) || "Memo";
          case h: {
            var Y = _, re = Y._payload, V = Y._init;
            try {
              return j(V(re));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var L = Object.assign, I = 0, z, Q, ee, ge, ne, ce, me;
    function $e() {
    }
    $e.__reactDisabledLog = !0;
    function xe() {
      {
        if (I === 0) {
          z = console.log, Q = console.info, ee = console.warn, ge = console.error, ne = console.group, ce = console.groupCollapsed, me = console.groupEnd;
          var _ = {
            configurable: !0,
            enumerable: !0,
            value: $e,
            writable: !0
          };
          Object.defineProperties(console, {
            info: _,
            log: _,
            warn: _,
            error: _,
            group: _,
            groupCollapsed: _,
            groupEnd: _
          });
        }
        I++;
      }
    }
    function ye() {
      {
        if (I--, I === 0) {
          var _ = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: L({}, _, {
              value: z
            }),
            info: L({}, _, {
              value: Q
            }),
            warn: L({}, _, {
              value: ee
            }),
            error: L({}, _, {
              value: ge
            }),
            group: L({}, _, {
              value: ne
            }),
            groupCollapsed: L({}, _, {
              value: ce
            }),
            groupEnd: L({}, _, {
              value: me
            })
          });
        }
        I < 0 && v("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Se = k.ReactCurrentDispatcher, R;
    function X(_, x, $) {
      {
        if (R === void 0)
          try {
            throw Error();
          } catch (Y) {
            var O = Y.stack.trim().match(/\n( *(at )?)/);
            R = O && O[1] || "";
          }
        return `
` + R + _;
      }
    }
    var de = !1, Z;
    {
      var J = typeof WeakMap == "function" ? WeakMap : Map;
      Z = new J();
    }
    function K(_, x) {
      if (!_ || de)
        return "";
      {
        var $ = Z.get(_);
        if ($ !== void 0)
          return $;
      }
      var O;
      de = !0;
      var Y = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var re;
      re = Se.current, Se.current = null, xe();
      try {
        if (x) {
          var V = function() {
            throw Error();
          };
          if (Object.defineProperty(V.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(V, []);
            } catch (Ne) {
              O = Ne;
            }
            Reflect.construct(_, [], V);
          } else {
            try {
              V.call();
            } catch (Ne) {
              O = Ne;
            }
            _.call(V.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (Ne) {
            O = Ne;
          }
          _();
        }
      } catch (Ne) {
        if (Ne && O && typeof Ne.stack == "string") {
          for (var B = Ne.stack.split(`
`), ke = O.stack.split(`
`), le = B.length - 1, se = ke.length - 1; le >= 1 && se >= 0 && B[le] !== ke[se]; )
            se--;
          for (; le >= 1 && se >= 0; le--, se--)
            if (B[le] !== ke[se]) {
              if (le !== 1 || se !== 1)
                do
                  if (le--, se--, se < 0 || B[le] !== ke[se]) {
                    var Pe = `
` + B[le].replace(" at new ", " at ");
                    return _.displayName && Pe.includes("<anonymous>") && (Pe = Pe.replace("<anonymous>", _.displayName)), typeof _ == "function" && Z.set(_, Pe), Pe;
                  }
                while (le >= 1 && se >= 0);
              break;
            }
        }
      } finally {
        de = !1, Se.current = re, ye(), Error.prepareStackTrace = Y;
      }
      var rr = _ ? _.displayName || _.name : "", Xo = rr ? X(rr) : "";
      return typeof _ == "function" && Z.set(_, Xo), Xo;
    }
    function ve(_, x, $) {
      return K(_, !1);
    }
    function ue(_) {
      var x = _.prototype;
      return !!(x && x.isReactComponent);
    }
    function ze(_, x, $) {
      if (_ == null)
        return "";
      if (typeof _ == "function")
        return K(_, ue(_));
      if (typeof _ == "string")
        return X(_);
      switch (_) {
        case c:
          return X("Suspense");
        case p:
          return X("SuspenseList");
      }
      if (typeof _ == "object")
        switch (_.$$typeof) {
          case a:
            return ve(_.render);
          case d:
            return ze(_.type, x, $);
          case h: {
            var O = _, Y = O._payload, re = O._init;
            try {
              return ze(re(Y), x, $);
            } catch {
            }
          }
        }
      return "";
    }
    var Re = Object.prototype.hasOwnProperty, Me = {}, yr = k.ReactDebugCurrentFrame;
    function Je(_) {
      if (_) {
        var x = _._owner, $ = ze(_.type, _._source, x ? x.type : null);
        yr.setExtraStackFrame($);
      } else
        yr.setExtraStackFrame(null);
    }
    function Qe(_, x, $, O, Y) {
      {
        var re = Function.call.bind(Re);
        for (var V in _)
          if (re(_, V)) {
            var B = void 0;
            try {
              if (typeof _[V] != "function") {
                var ke = Error((O || "React class") + ": " + $ + " type `" + V + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof _[V] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw ke.name = "Invariant Violation", ke;
              }
              B = _[V](x, V, O, $, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (le) {
              B = le;
            }
            B && !(B instanceof Error) && (Je(Y), v("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", O || "React class", $, V, typeof B), Je(null)), B instanceof Error && !(B.message in Me) && (Me[B.message] = !0, Je(Y), v("Failed %s type: %s", $, B.message), Je(null));
          }
      }
    }
    var Ji = Array.isArray;
    function Zr(_) {
      return Ji(_);
    }
    function Qi(_) {
      {
        var x = typeof Symbol == "function" && Symbol.toStringTag, $ = x && _[Symbol.toStringTag] || _.constructor.name || "Object";
        return $;
      }
    }
    function en(_) {
      try {
        return Do(_), !1;
      } catch {
        return !0;
      }
    }
    function Do(_) {
      return "" + _;
    }
    function qo(_) {
      if (en(_))
        return v("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Qi(_)), Do(_);
    }
    var dr = k.ReactCurrentOwner, rn = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, Io, Lo, Jr;
    Jr = {};
    function on(_) {
      if (Re.call(_, "ref")) {
        var x = Object.getOwnPropertyDescriptor(_, "ref").get;
        if (x && x.isReactWarning)
          return !1;
      }
      return _.ref !== void 0;
    }
    function tn(_) {
      if (Re.call(_, "key")) {
        var x = Object.getOwnPropertyDescriptor(_, "key").get;
        if (x && x.isReactWarning)
          return !1;
      }
      return _.key !== void 0;
    }
    function nn(_, x) {
      if (typeof _.ref == "string" && dr.current && x && dr.current.stateNode !== x) {
        var $ = j(dr.current.type);
        Jr[$] || (v('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', j(dr.current.type), _.ref), Jr[$] = !0);
      }
    }
    function ln(_, x) {
      {
        var $ = function() {
          Io || (Io = !0, v("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", x));
        };
        $.isReactWarning = !0, Object.defineProperty(_, "key", {
          get: $,
          configurable: !0
        });
      }
    }
    function sn(_, x) {
      {
        var $ = function() {
          Lo || (Lo = !0, v("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", x));
        };
        $.isReactWarning = !0, Object.defineProperty(_, "ref", {
          get: $,
          configurable: !0
        });
      }
    }
    var an = function(_, x, $, O, Y, re, V) {
      var B = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: r,
        // Built-in properties that belong on the element
        type: _,
        key: x,
        ref: $,
        props: V,
        // Record the component responsible for creating this element.
        _owner: re
      };
      return B._store = {}, Object.defineProperty(B._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(B, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: O
      }), Object.defineProperty(B, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: Y
      }), Object.freeze && (Object.freeze(B.props), Object.freeze(B)), B;
    };
    function _n(_, x, $, O, Y) {
      {
        var re, V = {}, B = null, ke = null;
        $ !== void 0 && (qo($), B = "" + $), tn(x) && (qo(x.key), B = "" + x.key), on(x) && (ke = x.ref, nn(x, Y));
        for (re in x)
          Re.call(x, re) && !rn.hasOwnProperty(re) && (V[re] = x[re]);
        if (_ && _.defaultProps) {
          var le = _.defaultProps;
          for (re in le)
            V[re] === void 0 && (V[re] = le[re]);
        }
        if (B || ke) {
          var se = typeof _ == "function" ? _.displayName || _.name || "Unknown" : _;
          B && ln(V, se), ke && sn(V, se);
        }
        return an(_, B, ke, Y, O, dr.current, V);
      }
    }
    var Qr = k.ReactCurrentOwner, Mo = k.ReactDebugCurrentFrame;
    function er(_) {
      if (_) {
        var x = _._owner, $ = ze(_.type, _._source, x ? x.type : null);
        Mo.setExtraStackFrame($);
      } else
        Mo.setExtraStackFrame(null);
    }
    var eo;
    eo = !1;
    function ro(_) {
      return typeof _ == "object" && _ !== null && _.$$typeof === r;
    }
    function Fo() {
      {
        if (Qr.current) {
          var _ = j(Qr.current.type);
          if (_)
            return `

Check the render method of \`` + _ + "`.";
        }
        return "";
      }
    }
    function cn(_) {
      {
        if (_ !== void 0) {
          var x = _.fileName.replace(/^.*[\\\/]/, ""), $ = _.lineNumber;
          return `

Check your code at ` + x + ":" + $ + ".";
        }
        return "";
      }
    }
    var Ho = {};
    function dn(_) {
      {
        var x = Fo();
        if (!x) {
          var $ = typeof _ == "string" ? _ : _.displayName || _.name;
          $ && (x = `

Check the top-level render call using <` + $ + ">.");
        }
        return x;
      }
    }
    function Bo(_, x) {
      {
        if (!_._store || _._store.validated || _.key != null)
          return;
        _._store.validated = !0;
        var $ = dn(x);
        if (Ho[$])
          return;
        Ho[$] = !0;
        var O = "";
        _ && _._owner && _._owner !== Qr.current && (O = " It was passed a child from " + j(_._owner.type) + "."), er(_), v('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', $, O), er(null);
      }
    }
    function Wo(_, x) {
      {
        if (typeof _ != "object")
          return;
        if (Zr(_))
          for (var $ = 0; $ < _.length; $++) {
            var O = _[$];
            ro(O) && Bo(O, x);
          }
        else if (ro(_))
          _._store && (_._store.validated = !0);
        else if (_) {
          var Y = m(_);
          if (typeof Y == "function" && Y !== _.entries)
            for (var re = Y.call(_), V; !(V = re.next()).done; )
              ro(V.value) && Bo(V.value, x);
        }
      }
    }
    function pn(_) {
      {
        var x = _.type;
        if (x == null || typeof x == "string")
          return;
        var $;
        if (typeof x == "function")
          $ = x.propTypes;
        else if (typeof x == "object" && (x.$$typeof === a || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        x.$$typeof === d))
          $ = x.propTypes;
        else
          return;
        if ($) {
          var O = j(x);
          Qe($, _.props, "prop", O, _);
        } else if (x.PropTypes !== void 0 && !eo) {
          eo = !0;
          var Y = j(x);
          v("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", Y || "Unknown");
        }
        typeof x.getDefaultProps == "function" && !x.getDefaultProps.isReactClassApproved && v("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function gn(_) {
      {
        for (var x = Object.keys(_.props), $ = 0; $ < x.length; $++) {
          var O = x[$];
          if (O !== "children" && O !== "key") {
            er(_), v("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", O), er(null);
            break;
          }
        }
        _.ref !== null && (er(_), v("Invalid attribute `ref` supplied to `React.Fragment`."), er(null));
      }
    }
    function Vo(_, x, $, O, Y, re) {
      {
        var V = U(_);
        if (!V) {
          var B = "";
          (_ === void 0 || typeof _ == "object" && _ !== null && Object.keys(_).length === 0) && (B += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var ke = cn(Y);
          ke ? B += ke : B += Fo();
          var le;
          _ === null ? le = "null" : Zr(_) ? le = "array" : _ !== void 0 && _.$$typeof === r ? (le = "<" + (j(_.type) || "Unknown") + " />", B = " Did you accidentally export a JSX literal instead of a component?") : le = typeof _, v("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", le, B);
        }
        var se = _n(_, x, $, Y, re);
        if (se == null)
          return se;
        if (V) {
          var Pe = x.children;
          if (Pe !== void 0)
            if (O)
              if (Zr(Pe)) {
                for (var rr = 0; rr < Pe.length; rr++)
                  Wo(Pe[rr], _);
                Object.freeze && Object.freeze(Pe);
              } else
                v("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              Wo(Pe, _);
        }
        return _ === t ? gn(se) : pn(se), se;
      }
    }
    function un(_, x, $) {
      return Vo(_, x, $, !0);
    }
    function fn(_, x, $) {
      return Vo(_, x, $, !1);
    }
    var hn = fn, mn = un;
    gr.Fragment = t, gr.jsx = hn, gr.jsxs = mn;
  }()), gr;
}
process.env.NODE_ENV === "production" ? po.exports = Cn() : po.exports = wn();
var y = po.exports;
function $n(e, r) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var t = o.call(e, r || "default");
    if (typeof t != "object")
      return t;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function Sn(e) {
  var r = $n(e, "string");
  return typeof r == "symbol" ? r : String(r);
}
function Pn(e, r, o) {
  return r = Sn(r), r in e ? Object.defineProperty(e, r, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = o, e;
}
function Yo(e, r) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(e);
    r && (t = t.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, t);
  }
  return o;
}
function Go(e) {
  for (var r = 1; r < arguments.length; r++) {
    var o = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Yo(Object(o), !0).forEach(function(t) {
      Pn(e, t, o[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : Yo(Object(o)).forEach(function(t) {
      Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
    });
  }
  return e;
}
var En = (e, r, o) => {
  for (var t of Object.keys(e)) {
    var i;
    if (e[t] !== ((i = r[t]) !== null && i !== void 0 ? i : o[t]))
      return !1;
  }
  return !0;
}, fe = (e) => {
  var r = (o) => {
    var t = e.defaultClassName, i = Go(Go({}, e.defaultVariants), o);
    for (var n in i) {
      var s, l = (s = i[n]) !== null && s !== void 0 ? s : e.defaultVariants[n];
      if (l != null) {
        var a = l;
        typeof a == "boolean" && (a = a === !0 ? "true" : "false");
        var c = (
          // @ts-expect-error
          e.variantClassNames[n][a]
        );
        c && (t += " " + c);
      }
    }
    for (var [p, d] of e.compoundVariants)
      En(p, i, e.defaultVariants) && (t += " " + d);
    return t;
  };
  return r.variants = () => Object.keys(e.variantClassNames), r;
}, Tn = fe({ defaultClassName: "avi_AVI_BASE__1bycfvg2i", variantClassNames: { size: { xs: "avi_size_xs__1bycfvg2", sm: "avi_size_sm__1bycfvg3", md: "avi_size_md__1bycfvg4", lg: "avi_size_lg__1bycfvg5" }, shape: { circle: "avi_shape_circle__1bycfvg6", square: "avi_shape_square__1bycfvg7", rounded: "avi_shape_rounded__1bycfvg8" }, variant: { transparent: "avi_variant_transparent__1bycfvg9", current: "avi_variant_current__1bycfvga", white: "avi_variant_white__1bycfvgb", black: "avi_variant_black__1bycfvgc", gray100: "avi_variant_gray100__1bycfvgd", gray200: "avi_variant_gray200__1bycfvge", gray300: "avi_variant_gray300__1bycfvgf", pale100: "avi_variant_pale100__1bycfvgg", pale200: "avi_variant_pale200__1bycfvgh", pale300: "avi_variant_pale300__1bycfvgi", pale400: "avi_variant_pale400__1bycfvgj", pale500: "avi_variant_pale500__1bycfvgk", hyper0: "avi_variant_hyper0__1bycfvgl", hyper1: "avi_variant_hyper1__1bycfvgm", hyper2: "avi_variant_hyper2__1bycfvgn", hyper3: "avi_variant_hyper3__1bycfvgo", hyper4: "avi_variant_hyper4__1bycfvgp", hyper5: "avi_variant_hyper5__1bycfvgq", hyper6: "avi_variant_hyper6__1bycfvgr", hyper7: "avi_variant_hyper7__1bycfvgs", hyper8: "avi_variant_hyper8__1bycfvgt", hyper9: "avi_variant_hyper9__1bycfvgu", hyper10: "avi_variant_hyper10__1bycfvgv", hyper11: "avi_variant_hyper11__1bycfvgw", hyper12: "avi_variant_hyper12__1bycfvgx", hyper13: "avi_variant_hyper13__1bycfvgy", lemon0: "avi_variant_lemon0__1bycfvgz", lemon1: "avi_variant_lemon1__1bycfvg10", lemon2: "avi_variant_lemon2__1bycfvg11", lemon3: "avi_variant_lemon3__1bycfvg12", lemon4: "avi_variant_lemon4__1bycfvg13", lemon5: "avi_variant_lemon5__1bycfvg14", lemon6: "avi_variant_lemon6__1bycfvg15", lemon7: "avi_variant_lemon7__1bycfvg16", lemon8: "avi_variant_lemon8__1bycfvg17", lemon9: "avi_variant_lemon9__1bycfvg18", lemon10: "avi_variant_lemon10__1bycfvg19", lemon11: "avi_variant_lemon11__1bycfvg1a", lemon12: "avi_variant_lemon12__1bycfvg1b", lemon13: "avi_variant_lemon13__1bycfvg1c", slate1: "avi_variant_slate1__1bycfvg1d", slate2: "avi_variant_slate2__1bycfvg1e", slate3: "avi_variant_slate3__1bycfvg1f", slate4: "avi_variant_slate4__1bycfvg1g", slate5: "avi_variant_slate5__1bycfvg1h", slate6: "avi_variant_slate6__1bycfvg1i", slate7: "avi_variant_slate7__1bycfvg1j", slate8: "avi_variant_slate8__1bycfvg1k", slate9: "avi_variant_slate9__1bycfvg1l", slate10: "avi_variant_slate10__1bycfvg1m", slate11: "avi_variant_slate11__1bycfvg1n", slate12: "avi_variant_slate12__1bycfvg1o", slate13: "avi_variant_slate13__1bycfvg1p", sapphire0: "avi_variant_sapphire0__1bycfvg1q", sapphire1: "avi_variant_sapphire1__1bycfvg1r", sapphire2: "avi_variant_sapphire2__1bycfvg1s", sapphire3: "avi_variant_sapphire3__1bycfvg1t", sapphire4: "avi_variant_sapphire4__1bycfvg1u", sapphire5: "avi_variant_sapphire5__1bycfvg1v", sapphire6: "avi_variant_sapphire6__1bycfvg1w", sapphire7: "avi_variant_sapphire7__1bycfvg1x", sapphire8: "avi_variant_sapphire8__1bycfvg1y", sapphire9: "avi_variant_sapphire9__1bycfvg1z", sapphire10: "avi_variant_sapphire10__1bycfvg20", sapphire11: "avi_variant_sapphire11__1bycfvg21", sapphire12: "avi_variant_sapphire12__1bycfvg22", sapphire13: "avi_variant_sapphire13__1bycfvg23", volt0: "avi_variant_volt0__1bycfvg24", volt1: "avi_variant_volt1__1bycfvg25", volt2: "avi_variant_volt2__1bycfvg26", volt3: "avi_variant_volt3__1bycfvg27", volt4: "avi_variant_volt4__1bycfvg28", volt5: "avi_variant_volt5__1bycfvg29", volt6: "avi_variant_volt6__1bycfvg2a", volt7: "avi_variant_volt7__1bycfvg2b", volt8: "avi_variant_volt8__1bycfvg2c", volt9: "avi_variant_volt9__1bycfvg2d", volt10: "avi_variant_volt10__1bycfvg2e", volt11: "avi_variant_volt11__1bycfvg2f", volt12: "avi_variant_volt12__1bycfvg2g", volt13: "avi_variant_volt13__1bycfvg2h" } }, defaultVariants: { size: "sm", shape: "rounded" }, compoundVariants: [] }), Rt = "avi_avi_img__1bycfvg0", An = "avi_fall_back__1bycfvg1";
function Ot(e) {
  var r, o, t = "";
  if (typeof e == "string" || typeof e == "number")
    t += e;
  else if (typeof e == "object")
    if (Array.isArray(e))
      for (r = 0; r < e.length; r++)
        e[r] && (o = Ot(e[r])) && (t && (t += " "), t += o);
    else
      for (r in e)
        e[r] && (t && (t += " "), t += r);
  return t;
}
function D() {
  for (var e, r, o = 0, t = ""; o < arguments.length; )
    (e = arguments[o++]) && (r = Ot(e)) && (t && (t += " "), t += r);
  return t;
}
const Nt = wo.Image, zn = wo.Fallback, Rn = H.forwardRef(
  ({ className: e, size: r = "xs", shape: o = "rounded", ...t }, i) => /* @__PURE__ */ y.jsx(
    wo.Root,
    {
      ...t,
      ref: i,
      className: D(Tn({ size: r, shape: o }), e)
    }
  )
), jt = H.forwardRef(
  ({ className: e, ...r }, o) => /* @__PURE__ */ y.jsx(
    zn,
    {
      ...r,
      ref: o,
      className: D(An, e)
    }
  )
), Dt = H.forwardRef(({ className: e, ...r }, o) => /* @__PURE__ */ y.jsx(
  Nt,
  {
    ...r,
    ref: o,
    className: D(Rt, e)
  }
)), On = "https://cdn.atlrdsgn.com/assets/github/atlrdsgn/A2.jpg", qt = H.forwardRef(({ className: e, ...r }, o) => /* @__PURE__ */ y.jsx(
  Nt,
  {
    ...r,
    ref: o,
    src: On,
    className: D(Rt, e)
  }
)), Ke = (e) => /* @__PURE__ */ y.jsx(Rn, { ...e });
Ke.Fallback = jt;
Ke.Image = Dt;
Ke.Demo = qt;
Ke.displayName = "Avi";
Ke.Fallback.displayName = "AviFallback";
Ke.Image.displayName = "AviImage";
Ke.Demo.displayName = "AviDemoImage";
jt.displayName = "AviFallback";
Dt.displayName = "AviImage";
qt.displayName = "AviDemoImage";
var Nn = fe({ defaultClassName: "banner_BASE_BANNER__137hknt8", variantClassNames: { size: { small: "banner_size_small__137hknt0", medium: "banner_size_medium__137hknt1", large: "banner_size_large__137hknt2" }, border: { true: "b a n e r _ p l y B o d t u 1 3 7 h k 6" }, variant: { one: "banner_variant_one__137hknt3", two: "banner_variant_two__137hknt4", three: "banner_variant_three__137hknt5" } }, defaultVariants: { size: "medium", border: !1, variant: "one" }, compoundVariants: [] });
const jn = ({
  children: e,
  className: r,
  size: o,
  variant: t,
  border: i,
  ...n
}) => /* @__PURE__ */ y.jsx(
  "div",
  {
    ...n,
    className: D(r, Nn({ size: o, variant: t, border: i })),
    children: e
  }
);
jn.displayName = "Banner";
var Dn = fe({ defaultClassName: "btn_buttonBase__aefdx68", variantClassNames: { size: { xs: "btn_size_xs__aefdx60", sm: "btn_size_sm__aefdx61", md: "btn_size_md__aefdx62", lg: "btn_size_lg__aefdx63" }, variant: { slate: "btn_variant_slate__aefdx64", jade: "btn_variant_jade__aefdx65", hyper: "btn_variant_hyper__aefdx66", neon: "btn_variant_neon__aefdx67" } }, defaultVariants: { size: "sm", variant: "slate" }, compoundVariants: [] });
const qn = ({
  children: e,
  type: r = "button",
  as: o = "a",
  onClick: t = () => {
  },
  href: i,
  target: n = "_self",
  rel: s = "noopener noreferrer",
  size: l = "sm",
  variant: a = "hyper",
  ...c
}) => {
  const p = (d) => {
    i ? (d.preventDefault(), window.open(i, n, s)) : d.preventDefault(), t(d);
  };
  return /* @__PURE__ */ y.jsx(
    "button",
    {
      ...c,
      type: r,
      className: Dn({ size: l, variant: a }),
      onClick: p,
      children: e
    }
  );
};
qn.displayName = "Button";
var In = "canvas_canvas__1dqe6mp0", Ln = "canvas_canvas_blur__1dqe6mp1";
const Mn = H.forwardRef(
  ({ children: e, ...r }, o) => /* @__PURE__ */ y.jsx(
    "div",
    {
      ref: o,
      className: D(In),
      ...r,
      children: e
    }
  )
), Fn = H.forwardRef(
  ({ children: e, ...r }, o) => /* @__PURE__ */ y.jsx(
    "div",
    {
      ref: o,
      className: D(Ln),
      ...r,
      children: e
    }
  )
);
Mn.displayName = "Canvas";
Fn.displayName = "Blurred-Canvas";
var Hn = fe({ defaultClassName: "chip_CHIP_ROOT__1yx7lz87", variantClassNames: { size: { xsmall: "chip_size_xsmall__1yx7lz80", small: "chip_size_small__1yx7lz81", medium: "chip_size_medium__1yx7lz82" }, shape: { rounded: "chip_shape_rounded__1yx7lz83", pill: "chip_shape_pill__1yx7lz84" }, variant: { slate: "chip_variant_slate__1yx7lz85", hyper: "chip_variant_hyper__1yx7lz86" } }, defaultVariants: { size: "small", shape: "pill", variant: "slate" }, compoundVariants: [] });
const Bn = ({
  children: e,
  className: r,
  size: o = "small",
  shape: t = "pill",
  variant: i = "slate",
  ...n
}) => /* @__PURE__ */ y.jsx(
  "span",
  {
    ...n,
    className: D(r, Hn({ size: o, shape: t, variant: i })),
    children: e
  }
);
Bn.displayName = "Chip";
var Wn = fe({ defaultClassName: "container_CONTAINER_BASE__zhlr5ea", variantClassNames: { align: { start: "container_align_start__zhlr5e6", center: "container_align_center__zhlr5e7", end: "container_align_end__zhlr5e8" }, width: { small: "container_width_small__zhlr5e0", medium: "container_width_medium__zhlr5e1", large: "container_width_large__zhlr5e2", xlarge: "container_width_xlarge__zhlr5e3", max: "container_width_max__zhlr5e4", full: "container_width_full__zhlr5e5" }, border: { true: "container_border_true__zhlr5e9" } }, defaultVariants: { align: "start", width: "max", border: !1 }, compoundVariants: [] });
const Vn = ({
  children: e,
  className: r,
  width: o = "max",
  align: t = "start",
  border: i = !1,
  ...n
}) => /* @__PURE__ */ y.jsx(
  "div",
  {
    ...n,
    className: D(r, Wn({ width: o, align: t, border: i })),
    children: e
  }
);
Vn.displayName = "Container";
var Xn = fe({ defaultClassName: "flex_FLEX_BASE__18w0vmkl", variantClassNames: { direction: { row: "flex_direction_row__18w0vmk0", column: "flex_direction_column__18w0vmk1", rowReverse: "flex_direction_rowReverse__18w0vmk2", columnReverse: "flex_direction_columnReverse__18w0vmk3" }, align: { start: "flex_align_start__18w0vmk4", center: "flex_align_center__18w0vmk5", end: "flex_align_end__18w0vmk6", stretch: "flex_align_stretch__18w0vmk7", baseline: "flex_align_baseline__18w0vmk8" }, justify: { start: "flex_justify_start__18w0vmk9", center: "flex_justify_center__18w0vmka", end: "flex_justify_end__18w0vmkb", between: "flex_justify_between__18w0vmkc" }, gap: { xs: "flex_gap_xs__18w0vmkd", sm: "flex_gap_sm__18w0vmke", md: "flex_gap_md__18w0vmkf", lg: "flex_gap_lg__18w0vmkg", xl: "flex_gap_xl__18w0vmkh" }, wrap: { wrap: "flex_wrap_wrap__18w0vmki", nowrap: "flex_wrap_nowrap__18w0vmkj", wrapReverse: "flex_wrap_wrapReverse__18w0vmkk" } }, defaultVariants: { direction: "row", align: "start", justify: "start", gap: "sm", wrap: "wrap" }, compoundVariants: [] });
const Un = H.forwardRef(
  ({
    children: e,
    direction: r = "row",
    align: o = "center",
    justify: t = "center",
    gap: i = "sm",
    ...n
    //..
  }, s) => /* @__PURE__ */ y.jsx(
    "div",
    {
      ...n,
      ref: s,
      className: Xn({ direction: r, align: o, justify: t, gap: i }),
      children: e
    }
  )
);
Un.displayName = "Flex";
var Kn = "grid_grid__10xm3zb2", Yn = "var(--gridItemMinWidth__10xm3zb0)", Gn = "var(--gridMaxRowItems__10xm3zb1)";
function Zo(e) {
  var r = e.match(/^var\((.*)\)$/);
  return r ? r[1] : e;
}
function Zn(e, r) {
  var o = e;
  for (var t of r) {
    if (!(t in o))
      throw new Error("Path ".concat(r.join(" -> "), " does not exist in object"));
    o = o[t];
  }
  return o;
}
function It(e, r) {
  var o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [], t = e.constructor();
  for (var i in e) {
    var n = e[i], s = [...o, i];
    typeof n == "string" || typeof n == "number" || n == null ? t[i] = r(n, s) : typeof n == "object" && !Array.isArray(n) ? t[i] = It(n, r, s) : console.warn('Skipping invalid key "'.concat(s.join("."), '". Should be a string, number, null or object. Received: "').concat(Array.isArray(n) ? "Array" : typeof n, '"'));
  }
  return t;
}
function Jn(e, r) {
  var o = {};
  if (typeof r == "object") {
    var t = e;
    It(r, (s, l) => {
      var a = Zn(t, l);
      o[Zo(a)] = String(s);
    });
  } else {
    var i = e;
    for (var n in i)
      o[Zo(n)] = i[n];
  }
  return Object.defineProperty(o, "toString", {
    value: function() {
      return Object.keys(this).map((l) => "".concat(l, ":").concat(this[l])).join(";");
    },
    writable: !1
  }), o;
}
var Qn = "reset_base__ltqw8z0", el = { article: "reset_block__ltqw8z1", aside: "reset_block__ltqw8z1", details: "reset_block__ltqw8z1", figcaption: "reset_block__ltqw8z1", figure: "reset_block__ltqw8z1", footer: "reset_block__ltqw8z1", header: "reset_block__ltqw8z1", hgroup: "reset_block__ltqw8z1", menu: "reset_block__ltqw8z1", nav: "reset_block__ltqw8z1", section: "reset_block__ltqw8z1", ul: "reset_list__ltqw8z3", ol: "reset_list__ltqw8z3", blockquote: "reset_quote__ltqw8z4", q: "reset_quote__ltqw8z4", body: "reset_body__ltqw8z2", a: "reset_a__ltqw8zg", table: "reset_table__ltqw8z5", mark: "reset_mark__ltqw8za reset_transparent__ltqw8z7", select: "reset_block__ltqw8z1 reset_appearance__ltqw8z6 reset_field__ltqw8z8 reset_select__ltqw8zb", button: "reset_transparent__ltqw8z7", textarea: "reset_block__ltqw8z1 reset_appearance__ltqw8z6 reset_field__ltqw8z8", input: "reset_block__ltqw8z1 reset_appearance__ltqw8z6 reset_field__ltqw8z8 reset_input__ltqw8zd" };
function rl(e, r) {
  return Object.defineProperty(e, "__recipe__", {
    value: r,
    writable: !1
  }), e;
}
var Lt = rl;
function ol(e) {
  var {
    conditions: r
  } = e;
  if (!r)
    throw new Error("Styles have no conditions");
  function o(t) {
    if (typeof t == "string" || typeof t == "number" || typeof t == "boolean") {
      if (!r.defaultCondition)
        throw new Error("No default condition");
      return {
        [r.defaultCondition]: t
      };
    }
    if (Array.isArray(t)) {
      if (!("responsiveArray" in r))
        throw new Error("Responsive arrays are not supported");
      var i = {};
      for (var n in r.responsiveArray)
        t[n] != null && (i[r.responsiveArray[n]] = t[n]);
      return i;
    }
    return t;
  }
  return Lt(o, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createNormalizeValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function Mt(e) {
  var {
    conditions: r
  } = e;
  if (!r)
    throw new Error("Styles have no conditions");
  var o = ol(e);
  function t(i, n) {
    if (typeof i == "string" || typeof i == "number" || typeof i == "boolean") {
      if (!r.defaultCondition)
        throw new Error("No default condition");
      return n(i, r.defaultCondition);
    }
    var s = Array.isArray(i) ? o(i) : i, l = {};
    for (var a in s)
      s[a] != null && (l[a] = n(s[a], a));
    return l;
  }
  return Lt(t, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createMapValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function tl(e, r) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var t = o.call(e, r || "default");
    if (typeof t != "object")
      return t;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function il(e) {
  var r = tl(e, "string");
  return typeof r == "symbol" ? r : String(r);
}
function nl(e, r, o) {
  return r = il(r), r in e ? Object.defineProperty(e, r, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = o, e;
}
function Jo(e, r) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(e);
    r && (t = t.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, t);
  }
  return o;
}
function oo(e) {
  for (var r = 1; r < arguments.length; r++) {
    var o = arguments[r] != null ? arguments[r] : {};
    r % 2 ? Jo(Object(o), !0).forEach(function(t) {
      nl(e, t, o[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : Jo(Object(o)).forEach(function(t) {
      Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
    });
  }
  return e;
}
var ll = (e) => function() {
  for (var r = arguments.length, o = new Array(r), t = 0; t < r; t++)
    o[t] = arguments[t];
  var i = Object.assign({}, ...o.map((a) => a.styles)), n = Object.keys(i), s = n.filter((a) => "mappings" in i[a]), l = (a) => {
    var c = [], p = {}, d = oo({}, a), h = !1;
    for (var u of s) {
      var f = a[u];
      if (f != null) {
        var g = i[u];
        h = !0;
        for (var m of g.mappings)
          p[m] = f, d[m] == null && delete d[m];
      }
    }
    var k = h ? oo(oo({}, p), d) : a, v = function() {
      var E = k[b], P = i[b];
      try {
        if (P.mappings)
          return "continue";
        if (typeof E == "string" || typeof E == "number") {
          if (process.env.NODE_ENV !== "production" && !P.values[E].defaultClass)
            throw new Error();
          c.push(P.values[E].defaultClass);
        } else if (Array.isArray(E))
          for (var T = 0; T < E.length; T++) {
            var F = E[T];
            if (F != null) {
              var U = P.responsiveArray[T];
              if (process.env.NODE_ENV !== "production" && !P.values[F].conditions[U])
                throw new Error();
              c.push(P.values[F].conditions[U]);
            }
          }
        else
          for (var N in E) {
            var W = E[N];
            if (W != null) {
              if (process.env.NODE_ENV !== "production" && !P.values[W].conditions[N])
                throw new Error();
              c.push(P.values[W].conditions[N]);
            }
          }
      } catch (ge) {
        if (process.env.NODE_ENV !== "production") {
          class ne extends Error {
            constructor(me) {
              super(me), this.name = "SprinklesError";
            }
          }
          var j = (ce) => typeof ce == "string" ? '"'.concat(ce, '"') : ce, L = (ce, me, $e) => {
            throw new ne('"'.concat(ce, '" has no value ').concat(j(me), ". Possible values are ").concat(Object.keys($e).map(j).join(", ")));
          };
          if (!P)
            throw new ne('"'.concat(b, '" is not a valid sprinkle'));
          if ((typeof E == "string" || typeof E == "number") && (E in P.values || L(b, E, P.values), !P.values[E].defaultClass))
            throw new ne('"'.concat(b, '" has no default condition. You must specify which conditions to target explicitly. Possible options are ').concat(Object.keys(P.values[E].conditions).map(j).join(", ")));
          if (typeof E == "object") {
            if (!("conditions" in P.values[Object.keys(P.values)[0]]))
              throw new ne('"'.concat(b, '" is not a conditional property'));
            if (Array.isArray(E)) {
              if (!("responsiveArray" in P))
                throw new ne('"'.concat(b, '" does not support responsive arrays'));
              var I = P.responsiveArray.length;
              if (I < E.length)
                throw new ne('"'.concat(b, '" only supports up to ').concat(I, " breakpoints. You passed ").concat(E.length));
              for (var z of E)
                P.values[z] || L(b, z, P.values);
            } else
              for (var Q in E) {
                var ee = E[Q];
                if (ee != null && (P.values[ee] || L(b, ee, P.values), !P.values[ee].conditions[Q]))
                  throw new ne('"'.concat(b, '" has no condition named ').concat(j(Q), ". Possible values are ").concat(Object.keys(P.values[ee].conditions).map(j).join(", ")));
              }
          }
        }
        throw ge;
      }
    };
    for (var b in k)
      var C = v();
    return e(c.join(" "));
  };
  return Object.assign(l, {
    properties: new Set(n)
  });
}, sl = (e) => e, al = function() {
  return ll(sl)(...arguments);
}, zc = Mt({ conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 } }), Ft = Mt({ conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] } }), Ht = al(function() {
  var e = { conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] }, styles: { all: { values: { unset: { conditions: { small: "sprinkles_all_unset_small__i77g9o0", medium: "sprinkles_all_unset_medium__i77g9o1", large: "sprinkles_all_unset_large__i77g9o2", xlarge: "sprinkles_all_unset_xlarge__i77g9o3" }, defaultClass: "sprinkles_all_unset_small__i77g9o0" } }, responsiveArray: void 0 }, boxSizing: { values: { "border-box": { conditions: { small: "sprinkles_boxSizing_border-box_small__i77g9o4", medium: "sprinkles_boxSizing_border-box_medium__i77g9o5", large: "sprinkles_boxSizing_border-box_large__i77g9o6", xlarge: "sprinkles_boxSizing_border-box_xlarge__i77g9o7" }, defaultClass: "sprinkles_boxSizing_border-box_small__i77g9o4" } }, responsiveArray: void 0 }, appearance: { values: { none: { conditions: { small: "sprinkles_appearance_none_small__i77g9o8", medium: "sprinkles_appearance_none_medium__i77g9o9", large: "sprinkles_appearance_none_large__i77g9oa", xlarge: "sprinkles_appearance_none_xlarge__i77g9ob" }, defaultClass: "sprinkles_appearance_none_small__i77g9o8" } }, responsiveArray: void 0 }, outline: { values: { none: { conditions: { small: "sprinkles_outline_none_small__i77g9oc", medium: "sprinkles_outline_none_medium__i77g9od", large: "sprinkles_outline_none_large__i77g9oe", xlarge: "sprinkles_outline_none_xlarge__i77g9of" }, defaultClass: "sprinkles_outline_none_small__i77g9oc" } }, responsiveArray: void 0 }, userSelect: { values: { none: { conditions: { small: "sprinkles_userSelect_none_small__i77g9og", medium: "sprinkles_userSelect_none_medium__i77g9oh", large: "sprinkles_userSelect_none_large__i77g9oi", xlarge: "sprinkles_userSelect_none_xlarge__i77g9oj" }, defaultClass: "sprinkles_userSelect_none_small__i77g9og" }, auto: { conditions: { small: "sprinkles_userSelect_auto_small__i77g9ok", medium: "sprinkles_userSelect_auto_medium__i77g9ol", large: "sprinkles_userSelect_auto_large__i77g9om", xlarge: "sprinkles_userSelect_auto_xlarge__i77g9on" }, defaultClass: "sprinkles_userSelect_auto_small__i77g9ok" } }, responsiveArray: void 0 }, fontVariantNumeric: { values: { "tabular-nums": { conditions: { small: "sprinkles_fontVariantNumeric_tabular-nums_small__i77g9oo", medium: "sprinkles_fontVariantNumeric_tabular-nums_medium__i77g9op", large: "sprinkles_fontVariantNumeric_tabular-nums_large__i77g9oq", xlarge: "sprinkles_fontVariantNumeric_tabular-nums_xlarge__i77g9or" }, defaultClass: "sprinkles_fontVariantNumeric_tabular-nums_small__i77g9oo" } }, responsiveArray: void 0 }, WebkitTapHighlightColor: { values: { "rgba(0,0,0,0)": { conditions: { small: "sprinkles_WebkitTapHighlightColor_rgba(0,0,0,0)_small__i77g9os", medium: "sprinkles_WebkitTapHighlightColor_rgba(0,0,0,0)_medium__i77g9ot", large: "sprinkles_WebkitTapHighlightColor_rgba(0,0,0,0)_large__i77g9ou", xlarge: "sprinkles_WebkitTapHighlightColor_rgba(0,0,0,0)_xlarge__i77g9ov" }, defaultClass: "sprinkles_WebkitTapHighlightColor_rgba(0,0,0,0)_small__i77g9os" } }, responsiveArray: void 0 }, display: { values: { none: { conditions: { small: "sprinkles_display_none_small__i77g9ow", medium: "sprinkles_display_none_medium__i77g9ox", large: "sprinkles_display_none_large__i77g9oy", xlarge: "sprinkles_display_none_xlarge__i77g9oz" }, defaultClass: "sprinkles_display_none_small__i77g9ow" }, flex: { conditions: { small: "sprinkles_display_flex_small__i77g9o10", medium: "sprinkles_display_flex_medium__i77g9o11", large: "sprinkles_display_flex_large__i77g9o12", xlarge: "sprinkles_display_flex_xlarge__i77g9o13" }, defaultClass: "sprinkles_display_flex_small__i77g9o10" }, block: { conditions: { small: "sprinkles_display_block_small__i77g9o14", medium: "sprinkles_display_block_medium__i77g9o15", large: "sprinkles_display_block_large__i77g9o16", xlarge: "sprinkles_display_block_xlarge__i77g9o17" }, defaultClass: "sprinkles_display_block_small__i77g9o14" }, "inline-block": { conditions: { small: "sprinkles_display_inline-block_small__i77g9o18", medium: "sprinkles_display_inline-block_medium__i77g9o19", large: "sprinkles_display_inline-block_large__i77g9o1a", xlarge: "sprinkles_display_inline-block_xlarge__i77g9o1b" }, defaultClass: "sprinkles_display_inline-block_small__i77g9o18" }, "inline-flex": { conditions: { small: "sprinkles_display_inline-flex_small__i77g9o1c", medium: "sprinkles_display_inline-flex_medium__i77g9o1d", large: "sprinkles_display_inline-flex_large__i77g9o1e", xlarge: "sprinkles_display_inline-flex_xlarge__i77g9o1f" }, defaultClass: "sprinkles_display_inline-flex_small__i77g9o1c" }, inline: { conditions: { small: "sprinkles_display_inline_small__i77g9o1g", medium: "sprinkles_display_inline_medium__i77g9o1h", large: "sprinkles_display_inline_large__i77g9o1i", xlarge: "sprinkles_display_inline_xlarge__i77g9o1j" }, defaultClass: "sprinkles_display_inline_small__i77g9o1g" } }, responsiveArray: void 0 }, flex: { values: { 1: { conditions: { small: "sprinkles_flex_1_small__i77g9o1k", medium: "sprinkles_flex_1_medium__i77g9o1l", large: "sprinkles_flex_1_large__i77g9o1m", xlarge: "sprinkles_flex_1_xlarge__i77g9o1n" }, defaultClass: "sprinkles_flex_1_small__i77g9o1k" }, auto: { conditions: { small: "sprinkles_flex_auto_small__i77g9o1o", medium: "sprinkles_flex_auto_medium__i77g9o1p", large: "sprinkles_flex_auto_large__i77g9o1q", xlarge: "sprinkles_flex_auto_xlarge__i77g9o1r" }, defaultClass: "sprinkles_flex_auto_small__i77g9o1o" }, initial: { conditions: { small: "sprinkles_flex_initial_small__i77g9o1s", medium: "sprinkles_flex_initial_medium__i77g9o1t", large: "sprinkles_flex_initial_large__i77g9o1u", xlarge: "sprinkles_flex_initial_xlarge__i77g9o1v" }, defaultClass: "sprinkles_flex_initial_small__i77g9o1s" }, none: { conditions: { small: "sprinkles_flex_none_small__i77g9o1w", medium: "sprinkles_flex_none_medium__i77g9o1x", large: "sprinkles_flex_none_large__i77g9o1y", xlarge: "sprinkles_flex_none_xlarge__i77g9o1z" }, defaultClass: "sprinkles_flex_none_small__i77g9o1w" } }, responsiveArray: void 0 }, flexDirection: { values: { row: { conditions: { small: "sprinkles_flexDirection_row_small__i77g9o20", medium: "sprinkles_flexDirection_row_medium__i77g9o21", large: "sprinkles_flexDirection_row_large__i77g9o22", xlarge: "sprinkles_flexDirection_row_xlarge__i77g9o23" }, defaultClass: "sprinkles_flexDirection_row_small__i77g9o20" }, column: { conditions: { small: "sprinkles_flexDirection_column_small__i77g9o24", medium: "sprinkles_flexDirection_column_medium__i77g9o25", large: "sprinkles_flexDirection_column_large__i77g9o26", xlarge: "sprinkles_flexDirection_column_xlarge__i77g9o27" }, defaultClass: "sprinkles_flexDirection_column_small__i77g9o24" }, "row-reverse": { conditions: { small: "sprinkles_flexDirection_row-reverse_small__i77g9o28", medium: "sprinkles_flexDirection_row-reverse_medium__i77g9o29", large: "sprinkles_flexDirection_row-reverse_large__i77g9o2a", xlarge: "sprinkles_flexDirection_row-reverse_xlarge__i77g9o2b" }, defaultClass: "sprinkles_flexDirection_row-reverse_small__i77g9o28" }, "column-reverse": { conditions: { small: "sprinkles_flexDirection_column-reverse_small__i77g9o2c", medium: "sprinkles_flexDirection_column-reverse_medium__i77g9o2d", large: "sprinkles_flexDirection_column-reverse_large__i77g9o2e", xlarge: "sprinkles_flexDirection_column-reverse_xlarge__i77g9o2f" }, defaultClass: "sprinkles_flexDirection_column-reverse_small__i77g9o2c" } }, responsiveArray: void 0 }, flexWrap: { values: { nowrap: { conditions: { small: "sprinkles_flexWrap_nowrap_small__i77g9o2g", medium: "sprinkles_flexWrap_nowrap_medium__i77g9o2h", large: "sprinkles_flexWrap_nowrap_large__i77g9o2i", xlarge: "sprinkles_flexWrap_nowrap_xlarge__i77g9o2j" }, defaultClass: "sprinkles_flexWrap_nowrap_small__i77g9o2g" }, wrap: { conditions: { small: "sprinkles_flexWrap_wrap_small__i77g9o2k", medium: "sprinkles_flexWrap_wrap_medium__i77g9o2l", large: "sprinkles_flexWrap_wrap_large__i77g9o2m", xlarge: "sprinkles_flexWrap_wrap_xlarge__i77g9o2n" }, defaultClass: "sprinkles_flexWrap_wrap_small__i77g9o2k" }, "wrap-reverse": { conditions: { small: "sprinkles_flexWrap_wrap-reverse_small__i77g9o2o", medium: "sprinkles_flexWrap_wrap-reverse_medium__i77g9o2p", large: "sprinkles_flexWrap_wrap-reverse_large__i77g9o2q", xlarge: "sprinkles_flexWrap_wrap-reverse_xlarge__i77g9o2r" }, defaultClass: "sprinkles_flexWrap_wrap-reverse_small__i77g9o2o" } }, responsiveArray: void 0 }, justifyContent: { values: { "flex-start": { conditions: { small: "sprinkles_justifyContent_flex-start_small__i77g9o2s", medium: "sprinkles_justifyContent_flex-start_medium__i77g9o2t", large: "sprinkles_justifyContent_flex-start_large__i77g9o2u", xlarge: "sprinkles_justifyContent_flex-start_xlarge__i77g9o2v" }, defaultClass: "sprinkles_justifyContent_flex-start_small__i77g9o2s" }, center: { conditions: { small: "sprinkles_justifyContent_center_small__i77g9o2w", medium: "sprinkles_justifyContent_center_medium__i77g9o2x", large: "sprinkles_justifyContent_center_large__i77g9o2y", xlarge: "sprinkles_justifyContent_center_xlarge__i77g9o2z" }, defaultClass: "sprinkles_justifyContent_center_small__i77g9o2w" }, "flex-end": { conditions: { small: "sprinkles_justifyContent_flex-end_small__i77g9o30", medium: "sprinkles_justifyContent_flex-end_medium__i77g9o31", large: "sprinkles_justifyContent_flex-end_large__i77g9o32", xlarge: "sprinkles_justifyContent_flex-end_xlarge__i77g9o33" }, defaultClass: "sprinkles_justifyContent_flex-end_small__i77g9o30" }, stretch: { conditions: { small: "sprinkles_justifyContent_stretch_small__i77g9o34", medium: "sprinkles_justifyContent_stretch_medium__i77g9o35", large: "sprinkles_justifyContent_stretch_large__i77g9o36", xlarge: "sprinkles_justifyContent_stretch_xlarge__i77g9o37" }, defaultClass: "sprinkles_justifyContent_stretch_small__i77g9o34" }, "space-between": { conditions: { small: "sprinkles_justifyContent_space-between_small__i77g9o38", medium: "sprinkles_justifyContent_space-between_medium__i77g9o39", large: "sprinkles_justifyContent_space-between_large__i77g9o3a", xlarge: "sprinkles_justifyContent_space-between_xlarge__i77g9o3b" }, defaultClass: "sprinkles_justifyContent_space-between_small__i77g9o38" }, "space-around": { conditions: { small: "sprinkles_justifyContent_space-around_small__i77g9o3c", medium: "sprinkles_justifyContent_space-around_medium__i77g9o3d", large: "sprinkles_justifyContent_space-around_large__i77g9o3e", xlarge: "sprinkles_justifyContent_space-around_xlarge__i77g9o3f" }, defaultClass: "sprinkles_justifyContent_space-around_small__i77g9o3c" } }, responsiveArray: void 0 }, alignItems: { values: { "flex-start": { conditions: { small: "sprinkles_alignItems_flex-start_small__i77g9o3g", medium: "sprinkles_alignItems_flex-start_medium__i77g9o3h", large: "sprinkles_alignItems_flex-start_large__i77g9o3i", xlarge: "sprinkles_alignItems_flex-start_xlarge__i77g9o3j" }, defaultClass: "sprinkles_alignItems_flex-start_small__i77g9o3g" }, center: { conditions: { small: "sprinkles_alignItems_center_small__i77g9o3k", medium: "sprinkles_alignItems_center_medium__i77g9o3l", large: "sprinkles_alignItems_center_large__i77g9o3m", xlarge: "sprinkles_alignItems_center_xlarge__i77g9o3n" }, defaultClass: "sprinkles_alignItems_center_small__i77g9o3k" }, "flex-end": { conditions: { small: "sprinkles_alignItems_flex-end_small__i77g9o3o", medium: "sprinkles_alignItems_flex-end_medium__i77g9o3p", large: "sprinkles_alignItems_flex-end_large__i77g9o3q", xlarge: "sprinkles_alignItems_flex-end_xlarge__i77g9o3r" }, defaultClass: "sprinkles_alignItems_flex-end_small__i77g9o3o" }, stretch: { conditions: { small: "sprinkles_alignItems_stretch_small__i77g9o3s", medium: "sprinkles_alignItems_stretch_medium__i77g9o3t", large: "sprinkles_alignItems_stretch_large__i77g9o3u", xlarge: "sprinkles_alignItems_stretch_xlarge__i77g9o3v" }, defaultClass: "sprinkles_alignItems_stretch_small__i77g9o3s" }, baseline: { conditions: { small: "sprinkles_alignItems_baseline_small__i77g9o3w", medium: "sprinkles_alignItems_baseline_medium__i77g9o3x", large: "sprinkles_alignItems_baseline_large__i77g9o3y", xlarge: "sprinkles_alignItems_baseline_xlarge__i77g9o3z" }, defaultClass: "sprinkles_alignItems_baseline_small__i77g9o3w" } }, responsiveArray: void 0 }, alignContent: { values: { "flex-start": { conditions: { small: "sprinkles_alignContent_flex-start_small__i77g9o40", medium: "sprinkles_alignContent_flex-start_medium__i77g9o41", large: "sprinkles_alignContent_flex-start_large__i77g9o42", xlarge: "sprinkles_alignContent_flex-start_xlarge__i77g9o43" }, defaultClass: "sprinkles_alignContent_flex-start_small__i77g9o40" }, center: { conditions: { small: "sprinkles_alignContent_center_small__i77g9o44", medium: "sprinkles_alignContent_center_medium__i77g9o45", large: "sprinkles_alignContent_center_large__i77g9o46", xlarge: "sprinkles_alignContent_center_xlarge__i77g9o47" }, defaultClass: "sprinkles_alignContent_center_small__i77g9o44" }, "flex-end": { conditions: { small: "sprinkles_alignContent_flex-end_small__i77g9o48", medium: "sprinkles_alignContent_flex-end_medium__i77g9o49", large: "sprinkles_alignContent_flex-end_large__i77g9o4a", xlarge: "sprinkles_alignContent_flex-end_xlarge__i77g9o4b" }, defaultClass: "sprinkles_alignContent_flex-end_small__i77g9o48" }, stretch: { conditions: { small: "sprinkles_alignContent_stretch_small__i77g9o4c", medium: "sprinkles_alignContent_stretch_medium__i77g9o4d", large: "sprinkles_alignContent_stretch_large__i77g9o4e", xlarge: "sprinkles_alignContent_stretch_xlarge__i77g9o4f" }, defaultClass: "sprinkles_alignContent_stretch_small__i77g9o4c" } }, responsiveArray: void 0 }, verticalAlign: { values: { top: { conditions: { small: "sprinkles_verticalAlign_top_small__i77g9o4g", medium: "sprinkles_verticalAlign_top_medium__i77g9o4h", large: "sprinkles_verticalAlign_top_large__i77g9o4i", xlarge: "sprinkles_verticalAlign_top_xlarge__i77g9o4j" }, defaultClass: "sprinkles_verticalAlign_top_small__i77g9o4g" }, middle: { conditions: { small: "sprinkles_verticalAlign_middle_small__i77g9o4k", medium: "sprinkles_verticalAlign_middle_medium__i77g9o4l", large: "sprinkles_verticalAlign_middle_large__i77g9o4m", xlarge: "sprinkles_verticalAlign_middle_xlarge__i77g9o4n" }, defaultClass: "sprinkles_verticalAlign_middle_small__i77g9o4k" }, bottom: { conditions: { small: "sprinkles_verticalAlign_bottom_small__i77g9o4o", medium: "sprinkles_verticalAlign_bottom_medium__i77g9o4p", large: "sprinkles_verticalAlign_bottom_large__i77g9o4q", xlarge: "sprinkles_verticalAlign_bottom_xlarge__i77g9o4r" }, defaultClass: "sprinkles_verticalAlign_bottom_small__i77g9o4o" }, baseline: { conditions: { small: "sprinkles_verticalAlign_baseline_small__i77g9o4s", medium: "sprinkles_verticalAlign_baseline_medium__i77g9o4t", large: "sprinkles_verticalAlign_baseline_large__i77g9o4u", xlarge: "sprinkles_verticalAlign_baseline_xlarge__i77g9o4v" }, defaultClass: "sprinkles_verticalAlign_baseline_small__i77g9o4s" }, "text-top": { conditions: { small: "sprinkles_verticalAlign_text-top_small__i77g9o4w", medium: "sprinkles_verticalAlign_text-top_medium__i77g9o4x", large: "sprinkles_verticalAlign_text-top_large__i77g9o4y", xlarge: "sprinkles_verticalAlign_text-top_xlarge__i77g9o4z" }, defaultClass: "sprinkles_verticalAlign_text-top_small__i77g9o4w" }, "text-bottom": { conditions: { small: "sprinkles_verticalAlign_text-bottom_small__i77g9o50", medium: "sprinkles_verticalAlign_text-bottom_medium__i77g9o51", large: "sprinkles_verticalAlign_text-bottom_large__i77g9o52", xlarge: "sprinkles_verticalAlign_text-bottom_xlarge__i77g9o53" }, defaultClass: "sprinkles_verticalAlign_text-bottom_small__i77g9o50" } }, responsiveArray: void 0 }, position: { values: { initial: { conditions: { small: "sprinkles_position_initial_small__i77g9o54", medium: "sprinkles_position_initial_medium__i77g9o55", large: "sprinkles_position_initial_large__i77g9o56", xlarge: "sprinkles_position_initial_xlarge__i77g9o57" }, defaultClass: "sprinkles_position_initial_small__i77g9o54" }, inherit: { conditions: { small: "sprinkles_position_inherit_small__i77g9o58", medium: "sprinkles_position_inherit_medium__i77g9o59", large: "sprinkles_position_inherit_large__i77g9o5a", xlarge: "sprinkles_position_inherit_xlarge__i77g9o5b" }, defaultClass: "sprinkles_position_inherit_small__i77g9o58" }, unset: { conditions: { small: "sprinkles_position_unset_small__i77g9o5c", medium: "sprinkles_position_unset_medium__i77g9o5d", large: "sprinkles_position_unset_large__i77g9o5e", xlarge: "sprinkles_position_unset_xlarge__i77g9o5f" }, defaultClass: "sprinkles_position_unset_small__i77g9o5c" }, relative: { conditions: { small: "sprinkles_position_relative_small__i77g9o5g", medium: "sprinkles_position_relative_medium__i77g9o5h", large: "sprinkles_position_relative_large__i77g9o5i", xlarge: "sprinkles_position_relative_xlarge__i77g9o5j" }, defaultClass: "sprinkles_position_relative_small__i77g9o5g" }, absolute: { conditions: { small: "sprinkles_position_absolute_small__i77g9o5k", medium: "sprinkles_position_absolute_medium__i77g9o5l", large: "sprinkles_position_absolute_large__i77g9o5m", xlarge: "sprinkles_position_absolute_xlarge__i77g9o5n" }, defaultClass: "sprinkles_position_absolute_small__i77g9o5k" }, fixed: { conditions: { small: "sprinkles_position_fixed_small__i77g9o5o", medium: "sprinkles_position_fixed_medium__i77g9o5p", large: "sprinkles_position_fixed_large__i77g9o5q", xlarge: "sprinkles_position_fixed_xlarge__i77g9o5r" }, defaultClass: "sprinkles_position_fixed_small__i77g9o5o" }, sticky: { conditions: { small: "sprinkles_position_sticky_small__i77g9o5s", medium: "sprinkles_position_sticky_medium__i77g9o5t", large: "sprinkles_position_sticky_large__i77g9o5u", xlarge: "sprinkles_position_sticky_xlarge__i77g9o5v" }, defaultClass: "sprinkles_position_sticky_small__i77g9o5s" } }, responsiveArray: void 0 }, margin: { values: { 0: { conditions: { small: "sprinkles_margin_0_small__i77g9o68", medium: "sprinkles_margin_0_medium__i77g9o69", large: "sprinkles_margin_0_large__i77g9o6a", xlarge: "sprinkles_margin_0_xlarge__i77g9o6b" }, defaultClass: "sprinkles_margin_0_small__i77g9o68" }, initial: { conditions: { small: "sprinkles_margin_initial_small__i77g9o5w", medium: "sprinkles_margin_initial_medium__i77g9o5x", large: "sprinkles_margin_initial_large__i77g9o5y", xlarge: "sprinkles_margin_initial_xlarge__i77g9o5z" }, defaultClass: "sprinkles_margin_initial_small__i77g9o5w" }, inherit: { conditions: { small: "sprinkles_margin_inherit_small__i77g9o60", medium: "sprinkles_margin_inherit_medium__i77g9o61", large: "sprinkles_margin_inherit_large__i77g9o62", xlarge: "sprinkles_margin_inherit_xlarge__i77g9o63" }, defaultClass: "sprinkles_margin_inherit_small__i77g9o60" }, unset: { conditions: { small: "sprinkles_margin_unset_small__i77g9o64", medium: "sprinkles_margin_unset_medium__i77g9o65", large: "sprinkles_margin_unset_large__i77g9o66", xlarge: "sprinkles_margin_unset_xlarge__i77g9o67" }, defaultClass: "sprinkles_margin_unset_small__i77g9o64" }, auto: { conditions: { small: "sprinkles_margin_auto_small__i77g9o6c", medium: "sprinkles_margin_auto_medium__i77g9o6d", large: "sprinkles_margin_auto_large__i77g9o6e", xlarge: "sprinkles_margin_auto_xlarge__i77g9o6f" }, defaultClass: "sprinkles_margin_auto_small__i77g9o6c" }, none: { conditions: { small: "sprinkles_margin_none_small__i77g9o6g", medium: "sprinkles_margin_none_medium__i77g9o6h", large: "sprinkles_margin_none_large__i77g9o6i", xlarge: "sprinkles_margin_none_xlarge__i77g9o6j" }, defaultClass: "sprinkles_margin_none_small__i77g9o6g" } }, responsiveArray: void 0 }, padding: { values: { 0: { conditions: { small: "sprinkles_padding_0_small__i77g9o6w", medium: "sprinkles_padding_0_medium__i77g9o6x", large: "sprinkles_padding_0_large__i77g9o6y", xlarge: "sprinkles_padding_0_xlarge__i77g9o6z" }, defaultClass: "sprinkles_padding_0_small__i77g9o6w" }, initial: { conditions: { small: "sprinkles_padding_initial_small__i77g9o6k", medium: "sprinkles_padding_initial_medium__i77g9o6l", large: "sprinkles_padding_initial_large__i77g9o6m", xlarge: "sprinkles_padding_initial_xlarge__i77g9o6n" }, defaultClass: "sprinkles_padding_initial_small__i77g9o6k" }, inherit: { conditions: { small: "sprinkles_padding_inherit_small__i77g9o6o", medium: "sprinkles_padding_inherit_medium__i77g9o6p", large: "sprinkles_padding_inherit_large__i77g9o6q", xlarge: "sprinkles_padding_inherit_xlarge__i77g9o6r" }, defaultClass: "sprinkles_padding_inherit_small__i77g9o6o" }, unset: { conditions: { small: "sprinkles_padding_unset_small__i77g9o6s", medium: "sprinkles_padding_unset_medium__i77g9o6t", large: "sprinkles_padding_unset_large__i77g9o6u", xlarge: "sprinkles_padding_unset_xlarge__i77g9o6v" }, defaultClass: "sprinkles_padding_unset_small__i77g9o6s" }, none: { conditions: { small: "sprinkles_padding_none_small__i77g9o70", medium: "sprinkles_padding_none_medium__i77g9o71", large: "sprinkles_padding_none_large__i77g9o72", xlarge: "sprinkles_padding_none_xlarge__i77g9o73" }, defaultClass: "sprinkles_padding_none_small__i77g9o70" }, auto: { conditions: { small: "sprinkles_padding_auto_small__i77g9o74", medium: "sprinkles_padding_auto_medium__i77g9o75", large: "sprinkles_padding_auto_large__i77g9o76", xlarge: "sprinkles_padding_auto_xlarge__i77g9o77" }, defaultClass: "sprinkles_padding_auto_small__i77g9o74" }, "4px": { conditions: { small: "sprinkles_padding_4px_small__i77g9o78", medium: "sprinkles_padding_4px_medium__i77g9o79", large: "sprinkles_padding_4px_large__i77g9o7a", xlarge: "sprinkles_padding_4px_xlarge__i77g9o7b" }, defaultClass: "sprinkles_padding_4px_small__i77g9o78" }, "8px": { conditions: { small: "sprinkles_padding_8px_small__i77g9o7c", medium: "sprinkles_padding_8px_medium__i77g9o7d", large: "sprinkles_padding_8px_large__i77g9o7e", xlarge: "sprinkles_padding_8px_xlarge__i77g9o7f" }, defaultClass: "sprinkles_padding_8px_small__i77g9o7c" }, "10px": { conditions: { small: "sprinkles_padding_10px_small__i77g9o7g", medium: "sprinkles_padding_10px_medium__i77g9o7h", large: "sprinkles_padding_10px_large__i77g9o7i", xlarge: "sprinkles_padding_10px_xlarge__i77g9o7j" }, defaultClass: "sprinkles_padding_10px_small__i77g9o7g" }, "12px": { conditions: { small: "sprinkles_padding_12px_small__i77g9o7k", medium: "sprinkles_padding_12px_medium__i77g9o7l", large: "sprinkles_padding_12px_large__i77g9o7m", xlarge: "sprinkles_padding_12px_xlarge__i77g9o7n" }, defaultClass: "sprinkles_padding_12px_small__i77g9o7k" }, "16px": { conditions: { small: "sprinkles_padding_16px_small__i77g9o7o", medium: "sprinkles_padding_16px_medium__i77g9o7p", large: "sprinkles_padding_16px_large__i77g9o7q", xlarge: "sprinkles_padding_16px_xlarge__i77g9o7r" }, defaultClass: "sprinkles_padding_16px_small__i77g9o7o" }, "20px": { conditions: { small: "sprinkles_padding_20px_small__i77g9o7s", medium: "sprinkles_padding_20px_medium__i77g9o7t", large: "sprinkles_padding_20px_large__i77g9o7u", xlarge: "sprinkles_padding_20px_xlarge__i77g9o7v" }, defaultClass: "sprinkles_padding_20px_small__i77g9o7s" } }, responsiveArray: void 0 }, width: { values: { auto: { conditions: { small: "sprinkles_width_auto_small__i77g9o7w", medium: "sprinkles_width_auto_medium__i77g9o7x", large: "sprinkles_width_auto_large__i77g9o7y", xlarge: "sprinkles_width_auto_xlarge__i77g9o7z" }, defaultClass: "sprinkles_width_auto_small__i77g9o7w" }, "100%": { conditions: { small: "sprinkles_width_100%_small__i77g9o80", medium: "sprinkles_width_100%_medium__i77g9o81", large: "sprinkles_width_100%_large__i77g9o82", xlarge: "sprinkles_width_100%_xlarge__i77g9o83" }, defaultClass: "sprinkles_width_100%_small__i77g9o80" } }, responsiveArray: void 0 }, height: { values: { auto: { conditions: { small: "sprinkles_height_auto_small__i77g9o84", medium: "sprinkles_height_auto_medium__i77g9o85", large: "sprinkles_height_auto_large__i77g9o86", xlarge: "sprinkles_height_auto_xlarge__i77g9o87" }, defaultClass: "sprinkles_height_auto_small__i77g9o84" }, "100%": { conditions: { small: "sprinkles_height_100%_small__i77g9o88", medium: "sprinkles_height_100%_medium__i77g9o89", large: "sprinkles_height_100%_large__i77g9o8a", xlarge: "sprinkles_height_100%_xlarge__i77g9o8b" }, defaultClass: "sprinkles_height_100%_small__i77g9o88" } }, responsiveArray: void 0 }, gap: { values: { 0: { conditions: { small: "sprinkles_gap_0_small__i77g9o8c", medium: "sprinkles_gap_0_medium__i77g9o8d", large: "sprinkles_gap_0_large__i77g9o8e", xlarge: "sprinkles_gap_0_xlarge__i77g9o8f" }, defaultClass: "sprinkles_gap_0_small__i77g9o8c" }, "4px 4px": { conditions: { small: "sprinkles_gap_4px_4px_small__i77g9o8g", medium: "sprinkles_gap_4px_4px_medium__i77g9o8h", large: "sprinkles_gap_4px_4px_large__i77g9o8i", xlarge: "sprinkles_gap_4px_4px_xlarge__i77g9o8j" }, defaultClass: "sprinkles_gap_4px_4px_small__i77g9o8g" }, "8px 8px": { conditions: { small: "sprinkles_gap_8px_8px_small__i77g9o8k", medium: "sprinkles_gap_8px_8px_medium__i77g9o8l", large: "sprinkles_gap_8px_8px_large__i77g9o8m", xlarge: "sprinkles_gap_8px_8px_xlarge__i77g9o8n" }, defaultClass: "sprinkles_gap_8px_8px_small__i77g9o8k" }, "10px 10px": { conditions: { small: "sprinkles_gap_10px_10px_small__i77g9o8o", medium: "sprinkles_gap_10px_10px_medium__i77g9o8p", large: "sprinkles_gap_10px_10px_large__i77g9o8q", xlarge: "sprinkles_gap_10px_10px_xlarge__i77g9o8r" }, defaultClass: "sprinkles_gap_10px_10px_small__i77g9o8o" }, "12px 12px": { conditions: { small: "sprinkles_gap_12px_12px_small__i77g9o8s", medium: "sprinkles_gap_12px_12px_medium__i77g9o8t", large: "sprinkles_gap_12px_12px_large__i77g9o8u", xlarge: "sprinkles_gap_12px_12px_xlarge__i77g9o8v" }, defaultClass: "sprinkles_gap_12px_12px_small__i77g9o8s" }, "16px 16px": { conditions: { small: "sprinkles_gap_16px_16px_small__i77g9o8w", medium: "sprinkles_gap_16px_16px_medium__i77g9o8x", large: "sprinkles_gap_16px_16px_large__i77g9o8y", xlarge: "sprinkles_gap_16px_16px_xlarge__i77g9o8z" }, defaultClass: "sprinkles_gap_16px_16px_small__i77g9o8w" }, "20px 20px": { conditions: { small: "sprinkles_gap_20px_20px_small__i77g9o90", medium: "sprinkles_gap_20px_20px_medium__i77g9o91", large: "sprinkles_gap_20px_20px_large__i77g9o92", xlarge: "sprinkles_gap_20px_20px_xlarge__i77g9o93" }, defaultClass: "sprinkles_gap_20px_20px_small__i77g9o90" } }, responsiveArray: void 0 }, mixBlendMode: { values: { initial: { conditions: { small: "sprinkles_mixBlendMode_initial_small__i77g9o94", medium: "sprinkles_mixBlendMode_initial_medium__i77g9o95", large: "sprinkles_mixBlendMode_initial_large__i77g9o96", xlarge: "sprinkles_mixBlendMode_initial_xlarge__i77g9o97" }, defaultClass: "sprinkles_mixBlendMode_initial_small__i77g9o94" }, inherit: { conditions: { small: "sprinkles_mixBlendMode_inherit_small__i77g9o98", medium: "sprinkles_mixBlendMode_inherit_medium__i77g9o99", large: "sprinkles_mixBlendMode_inherit_large__i77g9o9a", xlarge: "sprinkles_mixBlendMode_inherit_xlarge__i77g9o9b" }, defaultClass: "sprinkles_mixBlendMode_inherit_small__i77g9o98" }, unset: { conditions: { small: "sprinkles_mixBlendMode_unset_small__i77g9o9c", medium: "sprinkles_mixBlendMode_unset_medium__i77g9o9d", large: "sprinkles_mixBlendMode_unset_large__i77g9o9e", xlarge: "sprinkles_mixBlendMode_unset_xlarge__i77g9o9f" }, defaultClass: "sprinkles_mixBlendMode_unset_small__i77g9o9c" }, difference: { conditions: { small: "sprinkles_mixBlendMode_difference_small__i77g9o9g", medium: "sprinkles_mixBlendMode_difference_medium__i77g9o9h", large: "sprinkles_mixBlendMode_difference_large__i77g9o9i", xlarge: "sprinkles_mixBlendMode_difference_xlarge__i77g9o9j" }, defaultClass: "sprinkles_mixBlendMode_difference_small__i77g9o9g" }, multiply: { conditions: { small: "sprinkles_mixBlendMode_multiply_small__i77g9o9k", medium: "sprinkles_mixBlendMode_multiply_medium__i77g9o9l", large: "sprinkles_mixBlendMode_multiply_large__i77g9o9m", xlarge: "sprinkles_mixBlendMode_multiply_xlarge__i77g9o9n" }, defaultClass: "sprinkles_mixBlendMode_multiply_small__i77g9o9k" }, screen: { conditions: { small: "sprinkles_mixBlendMode_screen_small__i77g9o9o", medium: "sprinkles_mixBlendMode_screen_medium__i77g9o9p", large: "sprinkles_mixBlendMode_screen_large__i77g9o9q", xlarge: "sprinkles_mixBlendMode_screen_xlarge__i77g9o9r" }, defaultClass: "sprinkles_mixBlendMode_screen_small__i77g9o9o" }, overlay: { conditions: { small: "sprinkles_mixBlendMode_overlay_small__i77g9o9s", medium: "sprinkles_mixBlendMode_overlay_medium__i77g9o9t", large: "sprinkles_mixBlendMode_overlay_large__i77g9o9u", xlarge: "sprinkles_mixBlendMode_overlay_xlarge__i77g9o9v" }, defaultClass: "sprinkles_mixBlendMode_overlay_small__i77g9o9s" } }, responsiveArray: void 0 }, fontWeight: { values: { inherit: { conditions: { small: "sprinkles_fontWeight_inherit_small__i77g9o9w", medium: "sprinkles_fontWeight_inherit_medium__i77g9o9x", large: "sprinkles_fontWeight_inherit_large__i77g9o9y", xlarge: "sprinkles_fontWeight_inherit_xlarge__i77g9o9z" }, defaultClass: "sprinkles_fontWeight_inherit_small__i77g9o9w" }, normal: { conditions: { small: "sprinkles_fontWeight_normal_small__i77g9oa0", medium: "sprinkles_fontWeight_normal_medium__i77g9oa1", large: "sprinkles_fontWeight_normal_large__i77g9oa2", xlarge: "sprinkles_fontWeight_normal_xlarge__i77g9oa3" }, defaultClass: "sprinkles_fontWeight_normal_small__i77g9oa0" }, bold: { conditions: { small: "sprinkles_fontWeight_bold_small__i77g9oa4", medium: "sprinkles_fontWeight_bold_medium__i77g9oa5", large: "sprinkles_fontWeight_bold_large__i77g9oa6", xlarge: "sprinkles_fontWeight_bold_xlarge__i77g9oa7" }, defaultClass: "sprinkles_fontWeight_bold_small__i77g9oa4" }, strong: { conditions: { small: "sprinkles_fontWeight_strong_small__i77g9oa8", medium: "sprinkles_fontWeight_strong_medium__i77g9oa9", large: "sprinkles_fontWeight_strong_large__i77g9oaa", xlarge: "sprinkles_fontWeight_strong_xlarge__i77g9oab" }, defaultClass: "sprinkles_fontWeight_strong_small__i77g9oa8" } }, responsiveArray: void 0 }, textTransform: { values: { capitalize: { conditions: { small: "sprinkles_textTransform_capitalize_small__i77g9oac", medium: "sprinkles_textTransform_capitalize_medium__i77g9oad", large: "sprinkles_textTransform_capitalize_large__i77g9oae", xlarge: "sprinkles_textTransform_capitalize_xlarge__i77g9oaf" }, defaultClass: "sprinkles_textTransform_capitalize_small__i77g9oac" }, lowercase: { conditions: { small: "sprinkles_textTransform_lowercase_small__i77g9oag", medium: "sprinkles_textTransform_lowercase_medium__i77g9oah", large: "sprinkles_textTransform_lowercase_large__i77g9oai", xlarge: "sprinkles_textTransform_lowercase_xlarge__i77g9oaj" }, defaultClass: "sprinkles_textTransform_lowercase_small__i77g9oag" }, uppercase: { conditions: { small: "sprinkles_textTransform_uppercase_small__i77g9oak", medium: "sprinkles_textTransform_uppercase_medium__i77g9oal", large: "sprinkles_textTransform_uppercase_large__i77g9oam", xlarge: "sprinkles_textTransform_uppercase_xlarge__i77g9oan" }, defaultClass: "sprinkles_textTransform_uppercase_small__i77g9oak" } }, responsiveArray: void 0 }, transitionProperty: { values: { none: { conditions: { small: "sprinkles_transitionProperty_none_small__i77g9oao", medium: "sprinkles_transitionProperty_none_medium__i77g9oap", large: "sprinkles_transitionProperty_none_large__i77g9oaq", xlarge: "sprinkles_transitionProperty_none_xlarge__i77g9oar" }, defaultClass: "sprinkles_transitionProperty_none_small__i77g9oao" }, all: { conditions: { small: "sprinkles_transitionProperty_all_small__i77g9oas", medium: "sprinkles_transitionProperty_all_medium__i77g9oat", large: "sprinkles_transitionProperty_all_large__i77g9oau", xlarge: "sprinkles_transitionProperty_all_xlarge__i77g9oav" }, defaultClass: "sprinkles_transitionProperty_all_small__i77g9oas" }, initial: { conditions: { small: "sprinkles_transitionProperty_initial_small__i77g9oaw", medium: "sprinkles_transitionProperty_initial_medium__i77g9oax", large: "sprinkles_transitionProperty_initial_large__i77g9oay", xlarge: "sprinkles_transitionProperty_initial_xlarge__i77g9oaz" }, defaultClass: "sprinkles_transitionProperty_initial_small__i77g9oaw" } }, responsiveArray: void 0 }, transitionTimingFunction: { values: { linear: { conditions: { small: "sprinkles_transitionTimingFunction_linear_small__i77g9ob0", medium: "sprinkles_transitionTimingFunction_linear_medium__i77g9ob1", large: "sprinkles_transitionTimingFunction_linear_large__i77g9ob2", xlarge: "sprinkles_transitionTimingFunction_linear_xlarge__i77g9ob3" }, defaultClass: "sprinkles_transitionTimingFunction_linear_small__i77g9ob0" }, "cubic-bezier(0.4, 0, 1, 1)": { conditions: { small: "sprinkles_transitionTimingFunction_cubic-bezier(0.4,_0,_1,_1)_small__i77g9ob4", medium: "sprinkles_transitionTimingFunction_cubic-bezier(0.4,_0,_1,_1)_medium__i77g9ob5", large: "sprinkles_transitionTimingFunction_cubic-bezier(0.4,_0,_1,_1)_large__i77g9ob6", xlarge: "sprinkles_transitionTimingFunction_cubic-bezier(0.4,_0,_1,_1)_xlarge__i77g9ob7" }, defaultClass: "sprinkles_transitionTimingFunction_cubic-bezier(0.4,_0,_1,_1)_small__i77g9ob4" }, "cubic-bezier(0, 0, 0.2, 1)": { conditions: { small: "sprinkles_transitionTimingFunction_cubic-bezier(0,_0,_0.2,_1)_small__i77g9ob8", medium: "sprinkles_transitionTimingFunction_cubic-bezier(0,_0,_0.2,_1)_medium__i77g9ob9", large: "sprinkles_transitionTimingFunction_cubic-bezier(0,_0,_0.2,_1)_large__i77g9oba", xlarge: "sprinkles_transitionTimingFunction_cubic-bezier(0,_0,_0.2,_1)_xlarge__i77g9obb" }, defaultClass: "sprinkles_transitionTimingFunction_cubic-bezier(0,_0,_0.2,_1)_small__i77g9ob8" }, "cubic-bezier(0.42, 0, 0.58, 1)": { conditions: { small: "sprinkles_transitionTimingFunction_cubic-bezier(0.42,_0,_0.58,_1)_small__i77g9obc", medium: "sprinkles_transitionTimingFunction_cubic-bezier(0.42,_0,_0.58,_1)_medium__i77g9obd", large: "sprinkles_transitionTimingFunction_cubic-bezier(0.42,_0,_0.58,_1)_large__i77g9obe", xlarge: "sprinkles_transitionTimingFunction_cubic-bezier(0.42,_0,_0.58,_1)_xlarge__i77g9obf" }, defaultClass: "sprinkles_transitionTimingFunction_cubic-bezier(0.42,_0,_0.58,_1)_small__i77g9obc" } }, responsiveArray: void 0 }, transitionDuration: { values: { "150ms": { conditions: { small: "sprinkles_transitionDuration_150ms_small__i77g9obg", medium: "sprinkles_transitionDuration_150ms_medium__i77g9obh", large: "sprinkles_transitionDuration_150ms_large__i77g9obi", xlarge: "sprinkles_transitionDuration_150ms_xlarge__i77g9obj" }, defaultClass: "sprinkles_transitionDuration_150ms_small__i77g9obg" }, "300ms": { conditions: { small: "sprinkles_transitionDuration_300ms_small__i77g9obk", medium: "sprinkles_transitionDuration_300ms_medium__i77g9obl", large: "sprinkles_transitionDuration_300ms_large__i77g9obm", xlarge: "sprinkles_transitionDuration_300ms_xlarge__i77g9obn" }, defaultClass: "sprinkles_transitionDuration_300ms_small__i77g9obk" }, "500ms": { conditions: { small: "sprinkles_transitionDuration_500ms_small__i77g9obo", medium: "sprinkles_transitionDuration_500ms_medium__i77g9obp", large: "sprinkles_transitionDuration_500ms_large__i77g9obq", xlarge: "sprinkles_transitionDuration_500ms_xlarge__i77g9obr" }, defaultClass: "sprinkles_transitionDuration_500ms_small__i77g9obo" }, "700ms": { conditions: { small: "sprinkles_transitionDuration_700ms_small__i77g9obs", medium: "sprinkles_transitionDuration_700ms_medium__i77g9obt", large: "sprinkles_transitionDuration_700ms_large__i77g9obu", xlarge: "sprinkles_transitionDuration_700ms_xlarge__i77g9obv" }, defaultClass: "sprinkles_transitionDuration_700ms_small__i77g9obs" }, "1000ms": { conditions: { small: "sprinkles_transitionDuration_1000ms_small__i77g9obw", medium: "sprinkles_transitionDuration_1000ms_medium__i77g9obx", large: "sprinkles_transitionDuration_1000ms_large__i77g9oby", xlarge: "sprinkles_transitionDuration_1000ms_xlarge__i77g9obz" }, defaultClass: "sprinkles_transitionDuration_1000ms_small__i77g9obw" } }, responsiveArray: void 0 } } };
  return e.styles.all.responsiveArray = e.conditions.responsiveArray, e.styles.boxSizing.responsiveArray = e.conditions.responsiveArray, e.styles.appearance.responsiveArray = e.conditions.responsiveArray, e.styles.outline.responsiveArray = e.conditions.responsiveArray, e.styles.userSelect.responsiveArray = e.conditions.responsiveArray, e.styles.fontVariantNumeric.responsiveArray = e.conditions.responsiveArray, e.styles.WebkitTapHighlightColor.responsiveArray = e.conditions.responsiveArray, e.styles.display.responsiveArray = e.conditions.responsiveArray, e.styles.flex.responsiveArray = e.conditions.responsiveArray, e.styles.flexDirection.responsiveArray = e.conditions.responsiveArray, e.styles.flexWrap.responsiveArray = e.conditions.responsiveArray, e.styles.justifyContent.responsiveArray = e.conditions.responsiveArray, e.styles.alignItems.responsiveArray = e.conditions.responsiveArray, e.styles.alignContent.responsiveArray = e.conditions.responsiveArray, e.styles.verticalAlign.responsiveArray = e.conditions.responsiveArray, e.styles.position.responsiveArray = e.conditions.responsiveArray, e.styles.margin.responsiveArray = e.conditions.responsiveArray, e.styles.padding.responsiveArray = e.conditions.responsiveArray, e.styles.width.responsiveArray = e.conditions.responsiveArray, e.styles.height.responsiveArray = e.conditions.responsiveArray, e.styles.gap.responsiveArray = e.conditions.responsiveArray, e.styles.mixBlendMode.responsiveArray = e.conditions.responsiveArray, e.styles.fontWeight.responsiveArray = e.conditions.responsiveArray, e.styles.textTransform.responsiveArray = e.conditions.responsiveArray, e.styles.transitionProperty.responsiveArray = e.conditions.responsiveArray, e.styles.transitionTimingFunction.responsiveArray = e.conditions.responsiveArray, e.styles.transitionDuration.responsiveArray = e.conditions.responsiveArray, e;
}(), { conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 }, styles: { color: { values: { transparent: { conditions: { light: "sprinkles_color_transparent_light__i77g9oc0", dark: "sprinkles_color_transparent_dark__i77g9oc1" }, defaultClass: "sprinkles_color_transparent_light__i77g9oc0" }, current: { conditions: { light: "sprinkles_color_current_light__i77g9oc2", dark: "sprinkles_color_current_dark__i77g9oc3" }, defaultClass: "sprinkles_color_current_light__i77g9oc2" }, white: { conditions: { light: "sprinkles_color_white_light__i77g9oc4", dark: "sprinkles_color_white_dark__i77g9oc5" }, defaultClass: "sprinkles_color_white_light__i77g9oc4" }, black: { conditions: { light: "sprinkles_color_black_light__i77g9oc6", dark: "sprinkles_color_black_dark__i77g9oc7" }, defaultClass: "sprinkles_color_black_light__i77g9oc6" }, gray100: { conditions: { light: "sprinkles_color_gray100_light__i77g9oc8", dark: "sprinkles_color_gray100_dark__i77g9oc9" }, defaultClass: "sprinkles_color_gray100_light__i77g9oc8" }, gray200: { conditions: { light: "sprinkles_color_gray200_light__i77g9oca", dark: "sprinkles_color_gray200_dark__i77g9ocb" }, defaultClass: "sprinkles_color_gray200_light__i77g9oca" }, gray300: { conditions: { light: "sprinkles_color_gray300_light__i77g9occ", dark: "sprinkles_color_gray300_dark__i77g9ocd" }, defaultClass: "sprinkles_color_gray300_light__i77g9occ" }, pale100: { conditions: { light: "sprinkles_color_pale100_light__i77g9oce", dark: "sprinkles_color_pale100_dark__i77g9ocf" }, defaultClass: "sprinkles_color_pale100_light__i77g9oce" }, pale200: { conditions: { light: "sprinkles_color_pale200_light__i77g9ocg", dark: "sprinkles_color_pale200_dark__i77g9och" }, defaultClass: "sprinkles_color_pale200_light__i77g9ocg" }, pale300: { conditions: { light: "sprinkles_color_pale300_light__i77g9oci", dark: "sprinkles_color_pale300_dark__i77g9ocj" }, defaultClass: "sprinkles_color_pale300_light__i77g9oci" }, pale400: { conditions: { light: "sprinkles_color_pale400_light__i77g9ock", dark: "sprinkles_color_pale400_dark__i77g9ocl" }, defaultClass: "sprinkles_color_pale400_light__i77g9ock" }, pale500: { conditions: { light: "sprinkles_color_pale500_light__i77g9ocm", dark: "sprinkles_color_pale500_dark__i77g9ocn" }, defaultClass: "sprinkles_color_pale500_light__i77g9ocm" }, hyper0: { conditions: { light: "sprinkles_color_hyper0_light__i77g9oco", dark: "sprinkles_color_hyper0_dark__i77g9ocp" }, defaultClass: "sprinkles_color_hyper0_light__i77g9oco" }, hyper1: { conditions: { light: "sprinkles_color_hyper1_light__i77g9ocq", dark: "sprinkles_color_hyper1_dark__i77g9ocr" }, defaultClass: "sprinkles_color_hyper1_light__i77g9ocq" }, hyper2: { conditions: { light: "sprinkles_color_hyper2_light__i77g9ocs", dark: "sprinkles_color_hyper2_dark__i77g9oct" }, defaultClass: "sprinkles_color_hyper2_light__i77g9ocs" }, hyper3: { conditions: { light: "sprinkles_color_hyper3_light__i77g9ocu", dark: "sprinkles_color_hyper3_dark__i77g9ocv" }, defaultClass: "sprinkles_color_hyper3_light__i77g9ocu" }, hyper4: { conditions: { light: "sprinkles_color_hyper4_light__i77g9ocw", dark: "sprinkles_color_hyper4_dark__i77g9ocx" }, defaultClass: "sprinkles_color_hyper4_light__i77g9ocw" }, hyper5: { conditions: { light: "sprinkles_color_hyper5_light__i77g9ocy", dark: "sprinkles_color_hyper5_dark__i77g9ocz" }, defaultClass: "sprinkles_color_hyper5_light__i77g9ocy" }, hyper6: { conditions: { light: "sprinkles_color_hyper6_light__i77g9od0", dark: "sprinkles_color_hyper6_dark__i77g9od1" }, defaultClass: "sprinkles_color_hyper6_light__i77g9od0" }, hyper7: { conditions: { light: "sprinkles_color_hyper7_light__i77g9od2", dark: "sprinkles_color_hyper7_dark__i77g9od3" }, defaultClass: "sprinkles_color_hyper7_light__i77g9od2" }, hyper8: { conditions: { light: "sprinkles_color_hyper8_light__i77g9od4", dark: "sprinkles_color_hyper8_dark__i77g9od5" }, defaultClass: "sprinkles_color_hyper8_light__i77g9od4" }, hyper9: { conditions: { light: "sprinkles_color_hyper9_light__i77g9od6", dark: "sprinkles_color_hyper9_dark__i77g9od7" }, defaultClass: "sprinkles_color_hyper9_light__i77g9od6" }, hyper10: { conditions: { light: "sprinkles_color_hyper10_light__i77g9od8", dark: "sprinkles_color_hyper10_dark__i77g9od9" }, defaultClass: "sprinkles_color_hyper10_light__i77g9od8" }, hyper11: { conditions: { light: "sprinkles_color_hyper11_light__i77g9oda", dark: "sprinkles_color_hyper11_dark__i77g9odb" }, defaultClass: "sprinkles_color_hyper11_light__i77g9oda" }, hyper12: { conditions: { light: "sprinkles_color_hyper12_light__i77g9odc", dark: "sprinkles_color_hyper12_dark__i77g9odd" }, defaultClass: "sprinkles_color_hyper12_light__i77g9odc" }, hyper13: { conditions: { light: "sprinkles_color_hyper13_light__i77g9ode", dark: "sprinkles_color_hyper13_dark__i77g9odf" }, defaultClass: "sprinkles_color_hyper13_light__i77g9ode" }, lemon0: { conditions: { light: "sprinkles_color_lemon0_light__i77g9odg", dark: "sprinkles_color_lemon0_dark__i77g9odh" }, defaultClass: "sprinkles_color_lemon0_light__i77g9odg" }, lemon1: { conditions: { light: "sprinkles_color_lemon1_light__i77g9odi", dark: "sprinkles_color_lemon1_dark__i77g9odj" }, defaultClass: "sprinkles_color_lemon1_light__i77g9odi" }, lemon2: { conditions: { light: "sprinkles_color_lemon2_light__i77g9odk", dark: "sprinkles_color_lemon2_dark__i77g9odl" }, defaultClass: "sprinkles_color_lemon2_light__i77g9odk" }, lemon3: { conditions: { light: "sprinkles_color_lemon3_light__i77g9odm", dark: "sprinkles_color_lemon3_dark__i77g9odn" }, defaultClass: "sprinkles_color_lemon3_light__i77g9odm" }, lemon4: { conditions: { light: "sprinkles_color_lemon4_light__i77g9odo", dark: "sprinkles_color_lemon4_dark__i77g9odp" }, defaultClass: "sprinkles_color_lemon4_light__i77g9odo" }, lemon5: { conditions: { light: "sprinkles_color_lemon5_light__i77g9odq", dark: "sprinkles_color_lemon5_dark__i77g9odr" }, defaultClass: "sprinkles_color_lemon5_light__i77g9odq" }, lemon6: { conditions: { light: "sprinkles_color_lemon6_light__i77g9ods", dark: "sprinkles_color_lemon6_dark__i77g9odt" }, defaultClass: "sprinkles_color_lemon6_light__i77g9ods" }, lemon7: { conditions: { light: "sprinkles_color_lemon7_light__i77g9odu", dark: "sprinkles_color_lemon7_dark__i77g9odv" }, defaultClass: "sprinkles_color_lemon7_light__i77g9odu" }, lemon8: { conditions: { light: "sprinkles_color_lemon8_light__i77g9odw", dark: "sprinkles_color_lemon8_dark__i77g9odx" }, defaultClass: "sprinkles_color_lemon8_light__i77g9odw" }, lemon9: { conditions: { light: "sprinkles_color_lemon9_light__i77g9ody", dark: "sprinkles_color_lemon9_dark__i77g9odz" }, defaultClass: "sprinkles_color_lemon9_light__i77g9ody" }, lemon10: { conditions: { light: "sprinkles_color_lemon10_light__i77g9oe0", dark: "sprinkles_color_lemon10_dark__i77g9oe1" }, defaultClass: "sprinkles_color_lemon10_light__i77g9oe0" }, lemon11: { conditions: { light: "sprinkles_color_lemon11_light__i77g9oe2", dark: "sprinkles_color_lemon11_dark__i77g9oe3" }, defaultClass: "sprinkles_color_lemon11_light__i77g9oe2" }, lemon12: { conditions: { light: "sprinkles_color_lemon12_light__i77g9oe4", dark: "sprinkles_color_lemon12_dark__i77g9oe5" }, defaultClass: "sprinkles_color_lemon12_light__i77g9oe4" }, lemon13: { conditions: { light: "sprinkles_color_lemon13_light__i77g9oe6", dark: "sprinkles_color_lemon13_dark__i77g9oe7" }, defaultClass: "sprinkles_color_lemon13_light__i77g9oe6" }, slate1: { conditions: { light: "sprinkles_color_slate1_light__i77g9oe8", dark: "sprinkles_color_slate1_dark__i77g9oe9" }, defaultClass: "sprinkles_color_slate1_light__i77g9oe8" }, slate2: { conditions: { light: "sprinkles_color_slate2_light__i77g9oea", dark: "sprinkles_color_slate2_dark__i77g9oeb" }, defaultClass: "sprinkles_color_slate2_light__i77g9oea" }, slate3: { conditions: { light: "sprinkles_color_slate3_light__i77g9oec", dark: "sprinkles_color_slate3_dark__i77g9oed" }, defaultClass: "sprinkles_color_slate3_light__i77g9oec" }, slate4: { conditions: { light: "sprinkles_color_slate4_light__i77g9oee", dark: "sprinkles_color_slate4_dark__i77g9oef" }, defaultClass: "sprinkles_color_slate4_light__i77g9oee" }, slate5: { conditions: { light: "sprinkles_color_slate5_light__i77g9oeg", dark: "sprinkles_color_slate5_dark__i77g9oeh" }, defaultClass: "sprinkles_color_slate5_light__i77g9oeg" }, slate6: { conditions: { light: "sprinkles_color_slate6_light__i77g9oei", dark: "sprinkles_color_slate6_dark__i77g9oej" }, defaultClass: "sprinkles_color_slate6_light__i77g9oei" }, slate7: { conditions: { light: "sprinkles_color_slate7_light__i77g9oek", dark: "sprinkles_color_slate7_dark__i77g9oel" }, defaultClass: "sprinkles_color_slate7_light__i77g9oek" }, slate8: { conditions: { light: "sprinkles_color_slate8_light__i77g9oem", dark: "sprinkles_color_slate8_dark__i77g9oen" }, defaultClass: "sprinkles_color_slate8_light__i77g9oem" }, slate9: { conditions: { light: "sprinkles_color_slate9_light__i77g9oeo", dark: "sprinkles_color_slate9_dark__i77g9oep" }, defaultClass: "sprinkles_color_slate9_light__i77g9oeo" }, slate10: { conditions: { light: "sprinkles_color_slate10_light__i77g9oeq", dark: "sprinkles_color_slate10_dark__i77g9oer" }, defaultClass: "sprinkles_color_slate10_light__i77g9oeq" }, slate11: { conditions: { light: "sprinkles_color_slate11_light__i77g9oes", dark: "sprinkles_color_slate11_dark__i77g9oet" }, defaultClass: "sprinkles_color_slate11_light__i77g9oes" }, slate12: { conditions: { light: "sprinkles_color_slate12_light__i77g9oeu", dark: "sprinkles_color_slate12_dark__i77g9oev" }, defaultClass: "sprinkles_color_slate12_light__i77g9oeu" }, slate13: { conditions: { light: "sprinkles_color_slate13_light__i77g9oew", dark: "sprinkles_color_slate13_dark__i77g9oex" }, defaultClass: "sprinkles_color_slate13_light__i77g9oew" }, sapphire0: { conditions: { light: "sprinkles_color_sapphire0_light__i77g9oey", dark: "sprinkles_color_sapphire0_dark__i77g9oez" }, defaultClass: "sprinkles_color_sapphire0_light__i77g9oey" }, sapphire1: { conditions: { light: "sprinkles_color_sapphire1_light__i77g9of0", dark: "sprinkles_color_sapphire1_dark__i77g9of1" }, defaultClass: "sprinkles_color_sapphire1_light__i77g9of0" }, sapphire2: { conditions: { light: "sprinkles_color_sapphire2_light__i77g9of2", dark: "sprinkles_color_sapphire2_dark__i77g9of3" }, defaultClass: "sprinkles_color_sapphire2_light__i77g9of2" }, sapphire3: { conditions: { light: "sprinkles_color_sapphire3_light__i77g9of4", dark: "sprinkles_color_sapphire3_dark__i77g9of5" }, defaultClass: "sprinkles_color_sapphire3_light__i77g9of4" }, sapphire4: { conditions: { light: "sprinkles_color_sapphire4_light__i77g9of6", dark: "sprinkles_color_sapphire4_dark__i77g9of7" }, defaultClass: "sprinkles_color_sapphire4_light__i77g9of6" }, sapphire5: { conditions: { light: "sprinkles_color_sapphire5_light__i77g9of8", dark: "sprinkles_color_sapphire5_dark__i77g9of9" }, defaultClass: "sprinkles_color_sapphire5_light__i77g9of8" }, sapphire6: { conditions: { light: "sprinkles_color_sapphire6_light__i77g9ofa", dark: "sprinkles_color_sapphire6_dark__i77g9ofb" }, defaultClass: "sprinkles_color_sapphire6_light__i77g9ofa" }, sapphire7: { conditions: { light: "sprinkles_color_sapphire7_light__i77g9ofc", dark: "sprinkles_color_sapphire7_dark__i77g9ofd" }, defaultClass: "sprinkles_color_sapphire7_light__i77g9ofc" }, sapphire8: { conditions: { light: "sprinkles_color_sapphire8_light__i77g9ofe", dark: "sprinkles_color_sapphire8_dark__i77g9off" }, defaultClass: "sprinkles_color_sapphire8_light__i77g9ofe" }, sapphire9: { conditions: { light: "sprinkles_color_sapphire9_light__i77g9ofg", dark: "sprinkles_color_sapphire9_dark__i77g9ofh" }, defaultClass: "sprinkles_color_sapphire9_light__i77g9ofg" }, sapphire10: { conditions: { light: "sprinkles_color_sapphire10_light__i77g9ofi", dark: "sprinkles_color_sapphire10_dark__i77g9ofj" }, defaultClass: "sprinkles_color_sapphire10_light__i77g9ofi" }, sapphire11: { conditions: { light: "sprinkles_color_sapphire11_light__i77g9ofk", dark: "sprinkles_color_sapphire11_dark__i77g9ofl" }, defaultClass: "sprinkles_color_sapphire11_light__i77g9ofk" }, sapphire12: { conditions: { light: "sprinkles_color_sapphire12_light__i77g9ofm", dark: "sprinkles_color_sapphire12_dark__i77g9ofn" }, defaultClass: "sprinkles_color_sapphire12_light__i77g9ofm" }, sapphire13: { conditions: { light: "sprinkles_color_sapphire13_light__i77g9ofo", dark: "sprinkles_color_sapphire13_dark__i77g9ofp" }, defaultClass: "sprinkles_color_sapphire13_light__i77g9ofo" }, volt0: { conditions: { light: "sprinkles_color_volt0_light__i77g9ofq", dark: "sprinkles_color_volt0_dark__i77g9ofr" }, defaultClass: "sprinkles_color_volt0_light__i77g9ofq" }, volt1: { conditions: { light: "sprinkles_color_volt1_light__i77g9ofs", dark: "sprinkles_color_volt1_dark__i77g9oft" }, defaultClass: "sprinkles_color_volt1_light__i77g9ofs" }, volt2: { conditions: { light: "sprinkles_color_volt2_light__i77g9ofu", dark: "sprinkles_color_volt2_dark__i77g9ofv" }, defaultClass: "sprinkles_color_volt2_light__i77g9ofu" }, volt3: { conditions: { light: "sprinkles_color_volt3_light__i77g9ofw", dark: "sprinkles_color_volt3_dark__i77g9ofx" }, defaultClass: "sprinkles_color_volt3_light__i77g9ofw" }, volt4: { conditions: { light: "sprinkles_color_volt4_light__i77g9ofy", dark: "sprinkles_color_volt4_dark__i77g9ofz" }, defaultClass: "sprinkles_color_volt4_light__i77g9ofy" }, volt5: { conditions: { light: "sprinkles_color_volt5_light__i77g9og0", dark: "sprinkles_color_volt5_dark__i77g9og1" }, defaultClass: "sprinkles_color_volt5_light__i77g9og0" }, volt6: { conditions: { light: "sprinkles_color_volt6_light__i77g9og2", dark: "sprinkles_color_volt6_dark__i77g9og3" }, defaultClass: "sprinkles_color_volt6_light__i77g9og2" }, volt7: { conditions: { light: "sprinkles_color_volt7_light__i77g9og4", dark: "sprinkles_color_volt7_dark__i77g9og5" }, defaultClass: "sprinkles_color_volt7_light__i77g9og4" }, volt8: { conditions: { light: "sprinkles_color_volt8_light__i77g9og6", dark: "sprinkles_color_volt8_dark__i77g9og7" }, defaultClass: "sprinkles_color_volt8_light__i77g9og6" }, volt9: { conditions: { light: "sprinkles_color_volt9_light__i77g9og8", dark: "sprinkles_color_volt9_dark__i77g9og9" }, defaultClass: "sprinkles_color_volt9_light__i77g9og8" }, volt10: { conditions: { light: "sprinkles_color_volt10_light__i77g9oga", dark: "sprinkles_color_volt10_dark__i77g9ogb" }, defaultClass: "sprinkles_color_volt10_light__i77g9oga" }, volt11: { conditions: { light: "sprinkles_color_volt11_light__i77g9ogc", dark: "sprinkles_color_volt11_dark__i77g9ogd" }, defaultClass: "sprinkles_color_volt11_light__i77g9ogc" }, volt12: { conditions: { light: "sprinkles_color_volt12_light__i77g9oge", dark: "sprinkles_color_volt12_dark__i77g9ogf" }, defaultClass: "sprinkles_color_volt12_light__i77g9oge" }, volt13: { conditions: { light: "sprinkles_color_volt13_light__i77g9ogg", dark: "sprinkles_color_volt13_dark__i77g9ogh" }, defaultClass: "sprinkles_color_volt13_light__i77g9ogg" } } }, backgroundColor: { values: { transparent: { conditions: { light: "sprinkles_backgroundColor_transparent_light__i77g9ogi", dark: "sprinkles_backgroundColor_transparent_dark__i77g9ogj" }, defaultClass: "sprinkles_backgroundColor_transparent_light__i77g9ogi" }, current: { conditions: { light: "sprinkles_backgroundColor_current_light__i77g9ogk", dark: "sprinkles_backgroundColor_current_dark__i77g9ogl" }, defaultClass: "sprinkles_backgroundColor_current_light__i77g9ogk" }, white: { conditions: { light: "sprinkles_backgroundColor_white_light__i77g9ogm", dark: "sprinkles_backgroundColor_white_dark__i77g9ogn" }, defaultClass: "sprinkles_backgroundColor_white_light__i77g9ogm" }, black: { conditions: { light: "sprinkles_backgroundColor_black_light__i77g9ogo", dark: "sprinkles_backgroundColor_black_dark__i77g9ogp" }, defaultClass: "sprinkles_backgroundColor_black_light__i77g9ogo" }, gray100: { conditions: { light: "sprinkles_backgroundColor_gray100_light__i77g9ogq", dark: "sprinkles_backgroundColor_gray100_dark__i77g9ogr" }, defaultClass: "sprinkles_backgroundColor_gray100_light__i77g9ogq" }, gray200: { conditions: { light: "sprinkles_backgroundColor_gray200_light__i77g9ogs", dark: "sprinkles_backgroundColor_gray200_dark__i77g9ogt" }, defaultClass: "sprinkles_backgroundColor_gray200_light__i77g9ogs" }, gray300: { conditions: { light: "sprinkles_backgroundColor_gray300_light__i77g9ogu", dark: "sprinkles_backgroundColor_gray300_dark__i77g9ogv" }, defaultClass: "sprinkles_backgroundColor_gray300_light__i77g9ogu" }, pale100: { conditions: { light: "sprinkles_backgroundColor_pale100_light__i77g9ogw", dark: "sprinkles_backgroundColor_pale100_dark__i77g9ogx" }, defaultClass: "sprinkles_backgroundColor_pale100_light__i77g9ogw" }, pale200: { conditions: { light: "sprinkles_backgroundColor_pale200_light__i77g9ogy", dark: "sprinkles_backgroundColor_pale200_dark__i77g9ogz" }, defaultClass: "sprinkles_backgroundColor_pale200_light__i77g9ogy" }, pale300: { conditions: { light: "sprinkles_backgroundColor_pale300_light__i77g9oh0", dark: "sprinkles_backgroundColor_pale300_dark__i77g9oh1" }, defaultClass: "sprinkles_backgroundColor_pale300_light__i77g9oh0" }, pale400: { conditions: { light: "sprinkles_backgroundColor_pale400_light__i77g9oh2", dark: "sprinkles_backgroundColor_pale400_dark__i77g9oh3" }, defaultClass: "sprinkles_backgroundColor_pale400_light__i77g9oh2" }, pale500: { conditions: { light: "sprinkles_backgroundColor_pale500_light__i77g9oh4", dark: "sprinkles_backgroundColor_pale500_dark__i77g9oh5" }, defaultClass: "sprinkles_backgroundColor_pale500_light__i77g9oh4" }, hyper0: { conditions: { light: "sprinkles_backgroundColor_hyper0_light__i77g9oh6", dark: "sprinkles_backgroundColor_hyper0_dark__i77g9oh7" }, defaultClass: "sprinkles_backgroundColor_hyper0_light__i77g9oh6" }, hyper1: { conditions: { light: "sprinkles_backgroundColor_hyper1_light__i77g9oh8", dark: "sprinkles_backgroundColor_hyper1_dark__i77g9oh9" }, defaultClass: "sprinkles_backgroundColor_hyper1_light__i77g9oh8" }, hyper2: { conditions: { light: "sprinkles_backgroundColor_hyper2_light__i77g9oha", dark: "sprinkles_backgroundColor_hyper2_dark__i77g9ohb" }, defaultClass: "sprinkles_backgroundColor_hyper2_light__i77g9oha" }, hyper3: { conditions: { light: "sprinkles_backgroundColor_hyper3_light__i77g9ohc", dark: "sprinkles_backgroundColor_hyper3_dark__i77g9ohd" }, defaultClass: "sprinkles_backgroundColor_hyper3_light__i77g9ohc" }, hyper4: { conditions: { light: "sprinkles_backgroundColor_hyper4_light__i77g9ohe", dark: "sprinkles_backgroundColor_hyper4_dark__i77g9ohf" }, defaultClass: "sprinkles_backgroundColor_hyper4_light__i77g9ohe" }, hyper5: { conditions: { light: "sprinkles_backgroundColor_hyper5_light__i77g9ohg", dark: "sprinkles_backgroundColor_hyper5_dark__i77g9ohh" }, defaultClass: "sprinkles_backgroundColor_hyper5_light__i77g9ohg" }, hyper6: { conditions: { light: "sprinkles_backgroundColor_hyper6_light__i77g9ohi", dark: "sprinkles_backgroundColor_hyper6_dark__i77g9ohj" }, defaultClass: "sprinkles_backgroundColor_hyper6_light__i77g9ohi" }, hyper7: { conditions: { light: "sprinkles_backgroundColor_hyper7_light__i77g9ohk", dark: "sprinkles_backgroundColor_hyper7_dark__i77g9ohl" }, defaultClass: "sprinkles_backgroundColor_hyper7_light__i77g9ohk" }, hyper8: { conditions: { light: "sprinkles_backgroundColor_hyper8_light__i77g9ohm", dark: "sprinkles_backgroundColor_hyper8_dark__i77g9ohn" }, defaultClass: "sprinkles_backgroundColor_hyper8_light__i77g9ohm" }, hyper9: { conditions: { light: "sprinkles_backgroundColor_hyper9_light__i77g9oho", dark: "sprinkles_backgroundColor_hyper9_dark__i77g9ohp" }, defaultClass: "sprinkles_backgroundColor_hyper9_light__i77g9oho" }, hyper10: { conditions: { light: "sprinkles_backgroundColor_hyper10_light__i77g9ohq", dark: "sprinkles_backgroundColor_hyper10_dark__i77g9ohr" }, defaultClass: "sprinkles_backgroundColor_hyper10_light__i77g9ohq" }, hyper11: { conditions: { light: "sprinkles_backgroundColor_hyper11_light__i77g9ohs", dark: "sprinkles_backgroundColor_hyper11_dark__i77g9oht" }, defaultClass: "sprinkles_backgroundColor_hyper11_light__i77g9ohs" }, hyper12: { conditions: { light: "sprinkles_backgroundColor_hyper12_light__i77g9ohu", dark: "sprinkles_backgroundColor_hyper12_dark__i77g9ohv" }, defaultClass: "sprinkles_backgroundColor_hyper12_light__i77g9ohu" }, hyper13: { conditions: { light: "sprinkles_backgroundColor_hyper13_light__i77g9ohw", dark: "sprinkles_backgroundColor_hyper13_dark__i77g9ohx" }, defaultClass: "sprinkles_backgroundColor_hyper13_light__i77g9ohw" }, lemon0: { conditions: { light: "sprinkles_backgroundColor_lemon0_light__i77g9ohy", dark: "sprinkles_backgroundColor_lemon0_dark__i77g9ohz" }, defaultClass: "sprinkles_backgroundColor_lemon0_light__i77g9ohy" }, lemon1: { conditions: { light: "sprinkles_backgroundColor_lemon1_light__i77g9oi0", dark: "sprinkles_backgroundColor_lemon1_dark__i77g9oi1" }, defaultClass: "sprinkles_backgroundColor_lemon1_light__i77g9oi0" }, lemon2: { conditions: { light: "sprinkles_backgroundColor_lemon2_light__i77g9oi2", dark: "sprinkles_backgroundColor_lemon2_dark__i77g9oi3" }, defaultClass: "sprinkles_backgroundColor_lemon2_light__i77g9oi2" }, lemon3: { conditions: { light: "sprinkles_backgroundColor_lemon3_light__i77g9oi4", dark: "sprinkles_backgroundColor_lemon3_dark__i77g9oi5" }, defaultClass: "sprinkles_backgroundColor_lemon3_light__i77g9oi4" }, lemon4: { conditions: { light: "sprinkles_backgroundColor_lemon4_light__i77g9oi6", dark: "sprinkles_backgroundColor_lemon4_dark__i77g9oi7" }, defaultClass: "sprinkles_backgroundColor_lemon4_light__i77g9oi6" }, lemon5: { conditions: { light: "sprinkles_backgroundColor_lemon5_light__i77g9oi8", dark: "sprinkles_backgroundColor_lemon5_dark__i77g9oi9" }, defaultClass: "sprinkles_backgroundColor_lemon5_light__i77g9oi8" }, lemon6: { conditions: { light: "sprinkles_backgroundColor_lemon6_light__i77g9oia", dark: "sprinkles_backgroundColor_lemon6_dark__i77g9oib" }, defaultClass: "sprinkles_backgroundColor_lemon6_light__i77g9oia" }, lemon7: { conditions: { light: "sprinkles_backgroundColor_lemon7_light__i77g9oic", dark: "sprinkles_backgroundColor_lemon7_dark__i77g9oid" }, defaultClass: "sprinkles_backgroundColor_lemon7_light__i77g9oic" }, lemon8: { conditions: { light: "sprinkles_backgroundColor_lemon8_light__i77g9oie", dark: "sprinkles_backgroundColor_lemon8_dark__i77g9oif" }, defaultClass: "sprinkles_backgroundColor_lemon8_light__i77g9oie" }, lemon9: { conditions: { light: "sprinkles_backgroundColor_lemon9_light__i77g9oig", dark: "sprinkles_backgroundColor_lemon9_dark__i77g9oih" }, defaultClass: "sprinkles_backgroundColor_lemon9_light__i77g9oig" }, lemon10: { conditions: { light: "sprinkles_backgroundColor_lemon10_light__i77g9oii", dark: "sprinkles_backgroundColor_lemon10_dark__i77g9oij" }, defaultClass: "sprinkles_backgroundColor_lemon10_light__i77g9oii" }, lemon11: { conditions: { light: "sprinkles_backgroundColor_lemon11_light__i77g9oik", dark: "sprinkles_backgroundColor_lemon11_dark__i77g9oil" }, defaultClass: "sprinkles_backgroundColor_lemon11_light__i77g9oik" }, lemon12: { conditions: { light: "sprinkles_backgroundColor_lemon12_light__i77g9oim", dark: "sprinkles_backgroundColor_lemon12_dark__i77g9oin" }, defaultClass: "sprinkles_backgroundColor_lemon12_light__i77g9oim" }, lemon13: { conditions: { light: "sprinkles_backgroundColor_lemon13_light__i77g9oio", dark: "sprinkles_backgroundColor_lemon13_dark__i77g9oip" }, defaultClass: "sprinkles_backgroundColor_lemon13_light__i77g9oio" }, slate1: { conditions: { light: "sprinkles_backgroundColor_slate1_light__i77g9oiq", dark: "sprinkles_backgroundColor_slate1_dark__i77g9oir" }, defaultClass: "sprinkles_backgroundColor_slate1_light__i77g9oiq" }, slate2: { conditions: { light: "sprinkles_backgroundColor_slate2_light__i77g9ois", dark: "sprinkles_backgroundColor_slate2_dark__i77g9oit" }, defaultClass: "sprinkles_backgroundColor_slate2_light__i77g9ois" }, slate3: { conditions: { light: "sprinkles_backgroundColor_slate3_light__i77g9oiu", dark: "sprinkles_backgroundColor_slate3_dark__i77g9oiv" }, defaultClass: "sprinkles_backgroundColor_slate3_light__i77g9oiu" }, slate4: { conditions: { light: "sprinkles_backgroundColor_slate4_light__i77g9oiw", dark: "sprinkles_backgroundColor_slate4_dark__i77g9oix" }, defaultClass: "sprinkles_backgroundColor_slate4_light__i77g9oiw" }, slate5: { conditions: { light: "sprinkles_backgroundColor_slate5_light__i77g9oiy", dark: "sprinkles_backgroundColor_slate5_dark__i77g9oiz" }, defaultClass: "sprinkles_backgroundColor_slate5_light__i77g9oiy" }, slate6: { conditions: { light: "sprinkles_backgroundColor_slate6_light__i77g9oj0", dark: "sprinkles_backgroundColor_slate6_dark__i77g9oj1" }, defaultClass: "sprinkles_backgroundColor_slate6_light__i77g9oj0" }, slate7: { conditions: { light: "sprinkles_backgroundColor_slate7_light__i77g9oj2", dark: "sprinkles_backgroundColor_slate7_dark__i77g9oj3" }, defaultClass: "sprinkles_backgroundColor_slate7_light__i77g9oj2" }, slate8: { conditions: { light: "sprinkles_backgroundColor_slate8_light__i77g9oj4", dark: "sprinkles_backgroundColor_slate8_dark__i77g9oj5" }, defaultClass: "sprinkles_backgroundColor_slate8_light__i77g9oj4" }, slate9: { conditions: { light: "sprinkles_backgroundColor_slate9_light__i77g9oj6", dark: "sprinkles_backgroundColor_slate9_dark__i77g9oj7" }, defaultClass: "sprinkles_backgroundColor_slate9_light__i77g9oj6" }, slate10: { conditions: { light: "sprinkles_backgroundColor_slate10_light__i77g9oj8", dark: "sprinkles_backgroundColor_slate10_dark__i77g9oj9" }, defaultClass: "sprinkles_backgroundColor_slate10_light__i77g9oj8" }, slate11: { conditions: { light: "sprinkles_backgroundColor_slate11_light__i77g9oja", dark: "sprinkles_backgroundColor_slate11_dark__i77g9ojb" }, defaultClass: "sprinkles_backgroundColor_slate11_light__i77g9oja" }, slate12: { conditions: { light: "sprinkles_backgroundColor_slate12_light__i77g9ojc", dark: "sprinkles_backgroundColor_slate12_dark__i77g9ojd" }, defaultClass: "sprinkles_backgroundColor_slate12_light__i77g9ojc" }, slate13: { conditions: { light: "sprinkles_backgroundColor_slate13_light__i77g9oje", dark: "sprinkles_backgroundColor_slate13_dark__i77g9ojf" }, defaultClass: "sprinkles_backgroundColor_slate13_light__i77g9oje" }, sapphire0: { conditions: { light: "sprinkles_backgroundColor_sapphire0_light__i77g9ojg", dark: "sprinkles_backgroundColor_sapphire0_dark__i77g9ojh" }, defaultClass: "sprinkles_backgroundColor_sapphire0_light__i77g9ojg" }, sapphire1: { conditions: { light: "sprinkles_backgroundColor_sapphire1_light__i77g9oji", dark: "sprinkles_backgroundColor_sapphire1_dark__i77g9ojj" }, defaultClass: "sprinkles_backgroundColor_sapphire1_light__i77g9oji" }, sapphire2: { conditions: { light: "sprinkles_backgroundColor_sapphire2_light__i77g9ojk", dark: "sprinkles_backgroundColor_sapphire2_dark__i77g9ojl" }, defaultClass: "sprinkles_backgroundColor_sapphire2_light__i77g9ojk" }, sapphire3: { conditions: { light: "sprinkles_backgroundColor_sapphire3_light__i77g9ojm", dark: "sprinkles_backgroundColor_sapphire3_dark__i77g9ojn" }, defaultClass: "sprinkles_backgroundColor_sapphire3_light__i77g9ojm" }, sapphire4: { conditions: { light: "sprinkles_backgroundColor_sapphire4_light__i77g9ojo", dark: "sprinkles_backgroundColor_sapphire4_dark__i77g9ojp" }, defaultClass: "sprinkles_backgroundColor_sapphire4_light__i77g9ojo" }, sapphire5: { conditions: { light: "sprinkles_backgroundColor_sapphire5_light__i77g9ojq", dark: "sprinkles_backgroundColor_sapphire5_dark__i77g9ojr" }, defaultClass: "sprinkles_backgroundColor_sapphire5_light__i77g9ojq" }, sapphire6: { conditions: { light: "sprinkles_backgroundColor_sapphire6_light__i77g9ojs", dark: "sprinkles_backgroundColor_sapphire6_dark__i77g9ojt" }, defaultClass: "sprinkles_backgroundColor_sapphire6_light__i77g9ojs" }, sapphire7: { conditions: { light: "sprinkles_backgroundColor_sapphire7_light__i77g9oju", dark: "sprinkles_backgroundColor_sapphire7_dark__i77g9ojv" }, defaultClass: "sprinkles_backgroundColor_sapphire7_light__i77g9oju" }, sapphire8: { conditions: { light: "sprinkles_backgroundColor_sapphire8_light__i77g9ojw", dark: "sprinkles_backgroundColor_sapphire8_dark__i77g9ojx" }, defaultClass: "sprinkles_backgroundColor_sapphire8_light__i77g9ojw" }, sapphire9: { conditions: { light: "sprinkles_backgroundColor_sapphire9_light__i77g9ojy", dark: "sprinkles_backgroundColor_sapphire9_dark__i77g9ojz" }, defaultClass: "sprinkles_backgroundColor_sapphire9_light__i77g9ojy" }, sapphire10: { conditions: { light: "sprinkles_backgroundColor_sapphire10_light__i77g9ok0", dark: "sprinkles_backgroundColor_sapphire10_dark__i77g9ok1" }, defaultClass: "sprinkles_backgroundColor_sapphire10_light__i77g9ok0" }, sapphire11: { conditions: { light: "sprinkles_backgroundColor_sapphire11_light__i77g9ok2", dark: "sprinkles_backgroundColor_sapphire11_dark__i77g9ok3" }, defaultClass: "sprinkles_backgroundColor_sapphire11_light__i77g9ok2" }, sapphire12: { conditions: { light: "sprinkles_backgroundColor_sapphire12_light__i77g9ok4", dark: "sprinkles_backgroundColor_sapphire12_dark__i77g9ok5" }, defaultClass: "sprinkles_backgroundColor_sapphire12_light__i77g9ok4" }, sapphire13: { conditions: { light: "sprinkles_backgroundColor_sapphire13_light__i77g9ok6", dark: "sprinkles_backgroundColor_sapphire13_dark__i77g9ok7" }, defaultClass: "sprinkles_backgroundColor_sapphire13_light__i77g9ok6" }, volt0: { conditions: { light: "sprinkles_backgroundColor_volt0_light__i77g9ok8", dark: "sprinkles_backgroundColor_volt0_dark__i77g9ok9" }, defaultClass: "sprinkles_backgroundColor_volt0_light__i77g9ok8" }, volt1: { conditions: { light: "sprinkles_backgroundColor_volt1_light__i77g9oka", dark: "sprinkles_backgroundColor_volt1_dark__i77g9okb" }, defaultClass: "sprinkles_backgroundColor_volt1_light__i77g9oka" }, volt2: { conditions: { light: "sprinkles_backgroundColor_volt2_light__i77g9okc", dark: "sprinkles_backgroundColor_volt2_dark__i77g9okd" }, defaultClass: "sprinkles_backgroundColor_volt2_light__i77g9okc" }, volt3: { conditions: { light: "sprinkles_backgroundColor_volt3_light__i77g9oke", dark: "sprinkles_backgroundColor_volt3_dark__i77g9okf" }, defaultClass: "sprinkles_backgroundColor_volt3_light__i77g9oke" }, volt4: { conditions: { light: "sprinkles_backgroundColor_volt4_light__i77g9okg", dark: "sprinkles_backgroundColor_volt4_dark__i77g9okh" }, defaultClass: "sprinkles_backgroundColor_volt4_light__i77g9okg" }, volt5: { conditions: { light: "sprinkles_backgroundColor_volt5_light__i77g9oki", dark: "sprinkles_backgroundColor_volt5_dark__i77g9okj" }, defaultClass: "sprinkles_backgroundColor_volt5_light__i77g9oki" }, volt6: { conditions: { light: "sprinkles_backgroundColor_volt6_light__i77g9okk", dark: "sprinkles_backgroundColor_volt6_dark__i77g9okl" }, defaultClass: "sprinkles_backgroundColor_volt6_light__i77g9okk" }, volt7: { conditions: { light: "sprinkles_backgroundColor_volt7_light__i77g9okm", dark: "sprinkles_backgroundColor_volt7_dark__i77g9okn" }, defaultClass: "sprinkles_backgroundColor_volt7_light__i77g9okm" }, volt8: { conditions: { light: "sprinkles_backgroundColor_volt8_light__i77g9oko", dark: "sprinkles_backgroundColor_volt8_dark__i77g9okp" }, defaultClass: "sprinkles_backgroundColor_volt8_light__i77g9oko" }, volt9: { conditions: { light: "sprinkles_backgroundColor_volt9_light__i77g9okq", dark: "sprinkles_backgroundColor_volt9_dark__i77g9okr" }, defaultClass: "sprinkles_backgroundColor_volt9_light__i77g9okq" }, volt10: { conditions: { light: "sprinkles_backgroundColor_volt10_light__i77g9oks", dark: "sprinkles_backgroundColor_volt10_dark__i77g9okt" }, defaultClass: "sprinkles_backgroundColor_volt10_light__i77g9oks" }, volt11: { conditions: { light: "sprinkles_backgroundColor_volt11_light__i77g9oku", dark: "sprinkles_backgroundColor_volt11_dark__i77g9okv" }, defaultClass: "sprinkles_backgroundColor_volt11_light__i77g9oku" }, volt12: { conditions: { light: "sprinkles_backgroundColor_volt12_light__i77g9okw", dark: "sprinkles_backgroundColor_volt12_dark__i77g9okx" }, defaultClass: "sprinkles_backgroundColor_volt12_light__i77g9okw" }, volt13: { conditions: { light: "sprinkles_backgroundColor_volt13_light__i77g9oky", dark: "sprinkles_backgroundColor_volt13_dark__i77g9okz" }, defaultClass: "sprinkles_backgroundColor_volt13_light__i77g9oky" } } }, borderColor: { values: { transparent: { conditions: { light: "sprinkles_borderColor_transparent_light__i77g9ol0", dark: "sprinkles_borderColor_transparent_dark__i77g9ol1" }, defaultClass: "sprinkles_borderColor_transparent_light__i77g9ol0" }, current: { conditions: { light: "sprinkles_borderColor_current_light__i77g9ol2", dark: "sprinkles_borderColor_current_dark__i77g9ol3" }, defaultClass: "sprinkles_borderColor_current_light__i77g9ol2" }, white: { conditions: { light: "sprinkles_borderColor_white_light__i77g9ol4", dark: "sprinkles_borderColor_white_dark__i77g9ol5" }, defaultClass: "sprinkles_borderColor_white_light__i77g9ol4" }, black: { conditions: { light: "sprinkles_borderColor_black_light__i77g9ol6", dark: "sprinkles_borderColor_black_dark__i77g9ol7" }, defaultClass: "sprinkles_borderColor_black_light__i77g9ol6" }, gray100: { conditions: { light: "sprinkles_borderColor_gray100_light__i77g9ol8", dark: "sprinkles_borderColor_gray100_dark__i77g9ol9" }, defaultClass: "sprinkles_borderColor_gray100_light__i77g9ol8" }, gray200: { conditions: { light: "sprinkles_borderColor_gray200_light__i77g9ola", dark: "sprinkles_borderColor_gray200_dark__i77g9olb" }, defaultClass: "sprinkles_borderColor_gray200_light__i77g9ola" }, gray300: { conditions: { light: "sprinkles_borderColor_gray300_light__i77g9olc", dark: "sprinkles_borderColor_gray300_dark__i77g9old" }, defaultClass: "sprinkles_borderColor_gray300_light__i77g9olc" }, pale100: { conditions: { light: "sprinkles_borderColor_pale100_light__i77g9ole", dark: "sprinkles_borderColor_pale100_dark__i77g9olf" }, defaultClass: "sprinkles_borderColor_pale100_light__i77g9ole" }, pale200: { conditions: { light: "sprinkles_borderColor_pale200_light__i77g9olg", dark: "sprinkles_borderColor_pale200_dark__i77g9olh" }, defaultClass: "sprinkles_borderColor_pale200_light__i77g9olg" }, pale300: { conditions: { light: "sprinkles_borderColor_pale300_light__i77g9oli", dark: "sprinkles_borderColor_pale300_dark__i77g9olj" }, defaultClass: "sprinkles_borderColor_pale300_light__i77g9oli" }, pale400: { conditions: { light: "sprinkles_borderColor_pale400_light__i77g9olk", dark: "sprinkles_borderColor_pale400_dark__i77g9oll" }, defaultClass: "sprinkles_borderColor_pale400_light__i77g9olk" }, pale500: { conditions: { light: "sprinkles_borderColor_pale500_light__i77g9olm", dark: "sprinkles_borderColor_pale500_dark__i77g9oln" }, defaultClass: "sprinkles_borderColor_pale500_light__i77g9olm" }, hyper0: { conditions: { light: "sprinkles_borderColor_hyper0_light__i77g9olo", dark: "sprinkles_borderColor_hyper0_dark__i77g9olp" }, defaultClass: "sprinkles_borderColor_hyper0_light__i77g9olo" }, hyper1: { conditions: { light: "sprinkles_borderColor_hyper1_light__i77g9olq", dark: "sprinkles_borderColor_hyper1_dark__i77g9olr" }, defaultClass: "sprinkles_borderColor_hyper1_light__i77g9olq" }, hyper2: { conditions: { light: "sprinkles_borderColor_hyper2_light__i77g9ols", dark: "sprinkles_borderColor_hyper2_dark__i77g9olt" }, defaultClass: "sprinkles_borderColor_hyper2_light__i77g9ols" }, hyper3: { conditions: { light: "sprinkles_borderColor_hyper3_light__i77g9olu", dark: "sprinkles_borderColor_hyper3_dark__i77g9olv" }, defaultClass: "sprinkles_borderColor_hyper3_light__i77g9olu" }, hyper4: { conditions: { light: "sprinkles_borderColor_hyper4_light__i77g9olw", dark: "sprinkles_borderColor_hyper4_dark__i77g9olx" }, defaultClass: "sprinkles_borderColor_hyper4_light__i77g9olw" }, hyper5: { conditions: { light: "sprinkles_borderColor_hyper5_light__i77g9oly", dark: "sprinkles_borderColor_hyper5_dark__i77g9olz" }, defaultClass: "sprinkles_borderColor_hyper5_light__i77g9oly" }, hyper6: { conditions: { light: "sprinkles_borderColor_hyper6_light__i77g9om0", dark: "sprinkles_borderColor_hyper6_dark__i77g9om1" }, defaultClass: "sprinkles_borderColor_hyper6_light__i77g9om0" }, hyper7: { conditions: { light: "sprinkles_borderColor_hyper7_light__i77g9om2", dark: "sprinkles_borderColor_hyper7_dark__i77g9om3" }, defaultClass: "sprinkles_borderColor_hyper7_light__i77g9om2" }, hyper8: { conditions: { light: "sprinkles_borderColor_hyper8_light__i77g9om4", dark: "sprinkles_borderColor_hyper8_dark__i77g9om5" }, defaultClass: "sprinkles_borderColor_hyper8_light__i77g9om4" }, hyper9: { conditions: { light: "sprinkles_borderColor_hyper9_light__i77g9om6", dark: "sprinkles_borderColor_hyper9_dark__i77g9om7" }, defaultClass: "sprinkles_borderColor_hyper9_light__i77g9om6" }, hyper10: { conditions: { light: "sprinkles_borderColor_hyper10_light__i77g9om8", dark: "sprinkles_borderColor_hyper10_dark__i77g9om9" }, defaultClass: "sprinkles_borderColor_hyper10_light__i77g9om8" }, hyper11: { conditions: { light: "sprinkles_borderColor_hyper11_light__i77g9oma", dark: "sprinkles_borderColor_hyper11_dark__i77g9omb" }, defaultClass: "sprinkles_borderColor_hyper11_light__i77g9oma" }, hyper12: { conditions: { light: "sprinkles_borderColor_hyper12_light__i77g9omc", dark: "sprinkles_borderColor_hyper12_dark__i77g9omd" }, defaultClass: "sprinkles_borderColor_hyper12_light__i77g9omc" }, hyper13: { conditions: { light: "sprinkles_borderColor_hyper13_light__i77g9ome", dark: "sprinkles_borderColor_hyper13_dark__i77g9omf" }, defaultClass: "sprinkles_borderColor_hyper13_light__i77g9ome" }, lemon0: { conditions: { light: "sprinkles_borderColor_lemon0_light__i77g9omg", dark: "sprinkles_borderColor_lemon0_dark__i77g9omh" }, defaultClass: "sprinkles_borderColor_lemon0_light__i77g9omg" }, lemon1: { conditions: { light: "sprinkles_borderColor_lemon1_light__i77g9omi", dark: "sprinkles_borderColor_lemon1_dark__i77g9omj" }, defaultClass: "sprinkles_borderColor_lemon1_light__i77g9omi" }, lemon2: { conditions: { light: "sprinkles_borderColor_lemon2_light__i77g9omk", dark: "sprinkles_borderColor_lemon2_dark__i77g9oml" }, defaultClass: "sprinkles_borderColor_lemon2_light__i77g9omk" }, lemon3: { conditions: { light: "sprinkles_borderColor_lemon3_light__i77g9omm", dark: "sprinkles_borderColor_lemon3_dark__i77g9omn" }, defaultClass: "sprinkles_borderColor_lemon3_light__i77g9omm" }, lemon4: { conditions: { light: "sprinkles_borderColor_lemon4_light__i77g9omo", dark: "sprinkles_borderColor_lemon4_dark__i77g9omp" }, defaultClass: "sprinkles_borderColor_lemon4_light__i77g9omo" }, lemon5: { conditions: { light: "sprinkles_borderColor_lemon5_light__i77g9omq", dark: "sprinkles_borderColor_lemon5_dark__i77g9omr" }, defaultClass: "sprinkles_borderColor_lemon5_light__i77g9omq" }, lemon6: { conditions: { light: "sprinkles_borderColor_lemon6_light__i77g9oms", dark: "sprinkles_borderColor_lemon6_dark__i77g9omt" }, defaultClass: "sprinkles_borderColor_lemon6_light__i77g9oms" }, lemon7: { conditions: { light: "sprinkles_borderColor_lemon7_light__i77g9omu", dark: "sprinkles_borderColor_lemon7_dark__i77g9omv" }, defaultClass: "sprinkles_borderColor_lemon7_light__i77g9omu" }, lemon8: { conditions: { light: "sprinkles_borderColor_lemon8_light__i77g9omw", dark: "sprinkles_borderColor_lemon8_dark__i77g9omx" }, defaultClass: "sprinkles_borderColor_lemon8_light__i77g9omw" }, lemon9: { conditions: { light: "sprinkles_borderColor_lemon9_light__i77g9omy", dark: "sprinkles_borderColor_lemon9_dark__i77g9omz" }, defaultClass: "sprinkles_borderColor_lemon9_light__i77g9omy" }, lemon10: { conditions: { light: "sprinkles_borderColor_lemon10_light__i77g9on0", dark: "sprinkles_borderColor_lemon10_dark__i77g9on1" }, defaultClass: "sprinkles_borderColor_lemon10_light__i77g9on0" }, lemon11: { conditions: { light: "sprinkles_borderColor_lemon11_light__i77g9on2", dark: "sprinkles_borderColor_lemon11_dark__i77g9on3" }, defaultClass: "sprinkles_borderColor_lemon11_light__i77g9on2" }, lemon12: { conditions: { light: "sprinkles_borderColor_lemon12_light__i77g9on4", dark: "sprinkles_borderColor_lemon12_dark__i77g9on5" }, defaultClass: "sprinkles_borderColor_lemon12_light__i77g9on4" }, lemon13: { conditions: { light: "sprinkles_borderColor_lemon13_light__i77g9on6", dark: "sprinkles_borderColor_lemon13_dark__i77g9on7" }, defaultClass: "sprinkles_borderColor_lemon13_light__i77g9on6" }, slate1: { conditions: { light: "sprinkles_borderColor_slate1_light__i77g9on8", dark: "sprinkles_borderColor_slate1_dark__i77g9on9" }, defaultClass: "sprinkles_borderColor_slate1_light__i77g9on8" }, slate2: { conditions: { light: "sprinkles_borderColor_slate2_light__i77g9ona", dark: "sprinkles_borderColor_slate2_dark__i77g9onb" }, defaultClass: "sprinkles_borderColor_slate2_light__i77g9ona" }, slate3: { conditions: { light: "sprinkles_borderColor_slate3_light__i77g9onc", dark: "sprinkles_borderColor_slate3_dark__i77g9ond" }, defaultClass: "sprinkles_borderColor_slate3_light__i77g9onc" }, slate4: { conditions: { light: "sprinkles_borderColor_slate4_light__i77g9one", dark: "sprinkles_borderColor_slate4_dark__i77g9onf" }, defaultClass: "sprinkles_borderColor_slate4_light__i77g9one" }, slate5: { conditions: { light: "sprinkles_borderColor_slate5_light__i77g9ong", dark: "sprinkles_borderColor_slate5_dark__i77g9onh" }, defaultClass: "sprinkles_borderColor_slate5_light__i77g9ong" }, slate6: { conditions: { light: "sprinkles_borderColor_slate6_light__i77g9oni", dark: "sprinkles_borderColor_slate6_dark__i77g9onj" }, defaultClass: "sprinkles_borderColor_slate6_light__i77g9oni" }, slate7: { conditions: { light: "sprinkles_borderColor_slate7_light__i77g9onk", dark: "sprinkles_borderColor_slate7_dark__i77g9onl" }, defaultClass: "sprinkles_borderColor_slate7_light__i77g9onk" }, slate8: { conditions: { light: "sprinkles_borderColor_slate8_light__i77g9onm", dark: "sprinkles_borderColor_slate8_dark__i77g9onn" }, defaultClass: "sprinkles_borderColor_slate8_light__i77g9onm" }, slate9: { conditions: { light: "sprinkles_borderColor_slate9_light__i77g9ono", dark: "sprinkles_borderColor_slate9_dark__i77g9onp" }, defaultClass: "sprinkles_borderColor_slate9_light__i77g9ono" }, slate10: { conditions: { light: "sprinkles_borderColor_slate10_light__i77g9onq", dark: "sprinkles_borderColor_slate10_dark__i77g9onr" }, defaultClass: "sprinkles_borderColor_slate10_light__i77g9onq" }, slate11: { conditions: { light: "sprinkles_borderColor_slate11_light__i77g9ons", dark: "sprinkles_borderColor_slate11_dark__i77g9ont" }, defaultClass: "sprinkles_borderColor_slate11_light__i77g9ons" }, slate12: { conditions: { light: "sprinkles_borderColor_slate12_light__i77g9onu", dark: "sprinkles_borderColor_slate12_dark__i77g9onv" }, defaultClass: "sprinkles_borderColor_slate12_light__i77g9onu" }, slate13: { conditions: { light: "sprinkles_borderColor_slate13_light__i77g9onw", dark: "sprinkles_borderColor_slate13_dark__i77g9onx" }, defaultClass: "sprinkles_borderColor_slate13_light__i77g9onw" }, sapphire0: { conditions: { light: "sprinkles_borderColor_sapphire0_light__i77g9ony", dark: "sprinkles_borderColor_sapphire0_dark__i77g9onz" }, defaultClass: "sprinkles_borderColor_sapphire0_light__i77g9ony" }, sapphire1: { conditions: { light: "sprinkles_borderColor_sapphire1_light__i77g9oo0", dark: "sprinkles_borderColor_sapphire1_dark__i77g9oo1" }, defaultClass: "sprinkles_borderColor_sapphire1_light__i77g9oo0" }, sapphire2: { conditions: { light: "sprinkles_borderColor_sapphire2_light__i77g9oo2", dark: "sprinkles_borderColor_sapphire2_dark__i77g9oo3" }, defaultClass: "sprinkles_borderColor_sapphire2_light__i77g9oo2" }, sapphire3: { conditions: { light: "sprinkles_borderColor_sapphire3_light__i77g9oo4", dark: "sprinkles_borderColor_sapphire3_dark__i77g9oo5" }, defaultClass: "sprinkles_borderColor_sapphire3_light__i77g9oo4" }, sapphire4: { conditions: { light: "sprinkles_borderColor_sapphire4_light__i77g9oo6", dark: "sprinkles_borderColor_sapphire4_dark__i77g9oo7" }, defaultClass: "sprinkles_borderColor_sapphire4_light__i77g9oo6" }, sapphire5: { conditions: { light: "sprinkles_borderColor_sapphire5_light__i77g9oo8", dark: "sprinkles_borderColor_sapphire5_dark__i77g9oo9" }, defaultClass: "sprinkles_borderColor_sapphire5_light__i77g9oo8" }, sapphire6: { conditions: { light: "sprinkles_borderColor_sapphire6_light__i77g9ooa", dark: "sprinkles_borderColor_sapphire6_dark__i77g9oob" }, defaultClass: "sprinkles_borderColor_sapphire6_light__i77g9ooa" }, sapphire7: { conditions: { light: "sprinkles_borderColor_sapphire7_light__i77g9ooc", dark: "sprinkles_borderColor_sapphire7_dark__i77g9ood" }, defaultClass: "sprinkles_borderColor_sapphire7_light__i77g9ooc" }, sapphire8: { conditions: { light: "sprinkles_borderColor_sapphire8_light__i77g9ooe", dark: "sprinkles_borderColor_sapphire8_dark__i77g9oof" }, defaultClass: "sprinkles_borderColor_sapphire8_light__i77g9ooe" }, sapphire9: { conditions: { light: "sprinkles_borderColor_sapphire9_light__i77g9oog", dark: "sprinkles_borderColor_sapphire9_dark__i77g9ooh" }, defaultClass: "sprinkles_borderColor_sapphire9_light__i77g9oog" }, sapphire10: { conditions: { light: "sprinkles_borderColor_sapphire10_light__i77g9ooi", dark: "sprinkles_borderColor_sapphire10_dark__i77g9ooj" }, defaultClass: "sprinkles_borderColor_sapphire10_light__i77g9ooi" }, sapphire11: { conditions: { light: "sprinkles_borderColor_sapphire11_light__i77g9ook", dark: "sprinkles_borderColor_sapphire11_dark__i77g9ool" }, defaultClass: "sprinkles_borderColor_sapphire11_light__i77g9ook" }, sapphire12: { conditions: { light: "sprinkles_borderColor_sapphire12_light__i77g9oom", dark: "sprinkles_borderColor_sapphire12_dark__i77g9oon" }, defaultClass: "sprinkles_borderColor_sapphire12_light__i77g9oom" }, sapphire13: { conditions: { light: "sprinkles_borderColor_sapphire13_light__i77g9ooo", dark: "sprinkles_borderColor_sapphire13_dark__i77g9oop" }, defaultClass: "sprinkles_borderColor_sapphire13_light__i77g9ooo" }, volt0: { conditions: { light: "sprinkles_borderColor_volt0_light__i77g9ooq", dark: "sprinkles_borderColor_volt0_dark__i77g9oor" }, defaultClass: "sprinkles_borderColor_volt0_light__i77g9ooq" }, volt1: { conditions: { light: "sprinkles_borderColor_volt1_light__i77g9oos", dark: "sprinkles_borderColor_volt1_dark__i77g9oot" }, defaultClass: "sprinkles_borderColor_volt1_light__i77g9oos" }, volt2: { conditions: { light: "sprinkles_borderColor_volt2_light__i77g9oou", dark: "sprinkles_borderColor_volt2_dark__i77g9oov" }, defaultClass: "sprinkles_borderColor_volt2_light__i77g9oou" }, volt3: { conditions: { light: "sprinkles_borderColor_volt3_light__i77g9oow", dark: "sprinkles_borderColor_volt3_dark__i77g9oox" }, defaultClass: "sprinkles_borderColor_volt3_light__i77g9oow" }, volt4: { conditions: { light: "sprinkles_borderColor_volt4_light__i77g9ooy", dark: "sprinkles_borderColor_volt4_dark__i77g9ooz" }, defaultClass: "sprinkles_borderColor_volt4_light__i77g9ooy" }, volt5: { conditions: { light: "sprinkles_borderColor_volt5_light__i77g9op0", dark: "sprinkles_borderColor_volt5_dark__i77g9op1" }, defaultClass: "sprinkles_borderColor_volt5_light__i77g9op0" }, volt6: { conditions: { light: "sprinkles_borderColor_volt6_light__i77g9op2", dark: "sprinkles_borderColor_volt6_dark__i77g9op3" }, defaultClass: "sprinkles_borderColor_volt6_light__i77g9op2" }, volt7: { conditions: { light: "sprinkles_borderColor_volt7_light__i77g9op4", dark: "sprinkles_borderColor_volt7_dark__i77g9op5" }, defaultClass: "sprinkles_borderColor_volt7_light__i77g9op4" }, volt8: { conditions: { light: "sprinkles_borderColor_volt8_light__i77g9op6", dark: "sprinkles_borderColor_volt8_dark__i77g9op7" }, defaultClass: "sprinkles_borderColor_volt8_light__i77g9op6" }, volt9: { conditions: { light: "sprinkles_borderColor_volt9_light__i77g9op8", dark: "sprinkles_borderColor_volt9_dark__i77g9op9" }, defaultClass: "sprinkles_borderColor_volt9_light__i77g9op8" }, volt10: { conditions: { light: "sprinkles_borderColor_volt10_light__i77g9opa", dark: "sprinkles_borderColor_volt10_dark__i77g9opb" }, defaultClass: "sprinkles_borderColor_volt10_light__i77g9opa" }, volt11: { conditions: { light: "sprinkles_borderColor_volt11_light__i77g9opc", dark: "sprinkles_borderColor_volt11_dark__i77g9opd" }, defaultClass: "sprinkles_borderColor_volt11_light__i77g9opc" }, volt12: { conditions: { light: "sprinkles_borderColor_volt12_light__i77g9ope", dark: "sprinkles_borderColor_volt12_dark__i77g9opf" }, defaultClass: "sprinkles_borderColor_volt12_light__i77g9ope" }, volt13: { conditions: { light: "sprinkles_borderColor_volt13_light__i77g9opg", dark: "sprinkles_borderColor_volt13_dark__i77g9oph" }, defaultClass: "sprinkles_borderColor_volt13_light__i77g9opg" } } } } });
const _l = ({ reset: e, ...r }) => {
  const o = Ht(r), t = e ? [Qn, el[e]] : null;
  return D(t, o);
}, Rc = {
  small: 0,
  medium: 768,
  large: 1200,
  xlarge: 1600
};
var Oc = cl, ur = { base: "kit_kitClass__1oxbat10", light: "kit_lightTheme__1oxbat154", dark: "kit_darkTheme__1oxbat155" }, cl = { media: { breakpoints: { small: "var(--media-breakpoints-small__1oxbat11)", medium: "var(--media-breakpoints-medium__1oxbat12)", large: "var(--media-breakpoints-large__1oxbat13)", xlarge: "var(--media-breakpoints-xlarge__1oxbat14)" }, colorModes: { LIGHT: "var(--media-colorModes-LIGHT__1oxbat15)", DARK: "var(--media-colorModes-DARK__1oxbat16)" } }, font: { family: { system: "var(--font-family-system__1oxbat17)", mono: "var(--font-family-mono__1oxbat18)" }, heading: { H1: "var(--font-heading-H1__1oxbat19)", H2: "var(--font-heading-H2__1oxbat1a)", H3: "var(--font-heading-H3__1oxbat1b)", H4: "var(--font-heading-H4__1oxbat1c)", H5: "var(--font-heading-H5__1oxbat1d)", H6: "var(--font-heading-H6__1oxbat1e)" }, size: { MINI: "var(--font-size-MINI__1oxbat1f)", XS: "var(--font-size-XS__1oxbat1g)", SM: "var(--font-size-SM__1oxbat1h)", MD: "var(--font-size-MD__1oxbat1i)", LG: "var(--font-size-LG__1oxbat1j)", XL: "var(--font-size-XL__1oxbat1k)", XXL: "var(--font-size-XXL__1oxbat1l)", "3XL": "var(--font-size-3XL__1oxbat1m)", "4XL": "var(--font-size-4XL__1oxbat1n)", "5XL": "var(--font-size-5XL__1oxbat1o)", "6XL": "var(--font-size-6XL__1oxbat1p)", "7XL": "var(--font-size-7XL__1oxbat1q)", "8XL": "var(--font-size-8XL__1oxbat1r)", "9XL": "var(--font-size-9XL__1oxbat1s)" }, lineheight: { MINI: "var(--font-lineheight-MINI__1oxbat1t)", XS: "var(--font-lineheight-XS__1oxbat1u)", SM: "var(--font-lineheight-SM__1oxbat1v)", MD: "var(--font-lineheight-MD__1oxbat1w)", LG: "var(--font-lineheight-LG__1oxbat1x)", XL: "var(--font-lineheight-XL__1oxbat1y)", XXL: "var(--font-lineheight-XXL__1oxbat1z)", "3XL": "var(--font-lineheight-3XL__1oxbat110)", "4XL": "var(--font-lineheight-4XL__1oxbat111)", "5XL": "var(--font-lineheight-5XL__1oxbat112)", "6XL": "var(--font-lineheight-6XL__1oxbat113)", "7XL": "var(--font-lineheight-7XL__1oxbat114)", "8XL": "var(--font-lineheight-8XL__1oxbat115)", "9XL": "var(--font-lineheight-9XL__1oxbat116)" }, weight: { SUPRLITE: "var(--font-weight-SUPRLITE__1oxbat117)", ULTRALITE: "var(--font-weight-ULTRALITE__1oxbat118)", LITE: "var(--font-weight-LITE__1oxbat119)", REGULAR: "var(--font-weight-REGULAR__1oxbat11a)", MEDIUM: "var(--font-weight-MEDIUM__1oxbat11b)", SEMIBOLD: "var(--font-weight-SEMIBOLD__1oxbat11c)", BOLD: "var(--font-weight-BOLD__1oxbat11d)", HEAVY: "var(--font-weight-HEAVY__1oxbat11e)", BLACK: "var(--font-weight-BLACK__1oxbat11f)" } }, radii: { ZERO: "var(--radii-ZERO__1oxbat11g)", NO: "var(--radii-NO__1oxbat11h)", DF: "var(--radii-DF__1oxbat11i)", XS: "var(--radii-XS__1oxbat11j)", SM: "var(--radii-SM__1oxbat11k)", MD: "var(--radii-MD__1oxbat11l)", LG: "var(--radii-LG__1oxbat11m)", XL: "var(--radii-XL__1oxbat11n)", XXL: "var(--radii-XXL__1oxbat11o)", PILL: "var(--radii-PILL__1oxbat11p)" }, space: { ZERO: "var(--space-ZERO__1oxbat11q)", NO: "var(--space-NO__1oxbat11r)", DF: "var(--space-DF__1oxbat11s)", APX: "var(--space-APX__1oxbat11t)", BPX: "var(--space-BPX__1oxbat11u)", CPX: "var(--space-CPX__1oxbat11v)", DPX: "var(--space-DPX__1oxbat11w)", EPX: "var(--space-EPX__1oxbat11x)", FPX: "var(--space-FPX__1oxbat11y)", GPX: "var(--space-GPX__1oxbat11z)", HPX: "var(--space-HPX__1oxbat120)", IPX: "var(--space-IPX__1oxbat121)", JPX: "var(--space-JPX__1oxbat122)", KPX: "var(--space-KPX__1oxbat123)", LPX: "var(--space-LPX__1oxbat124)", MPX: "var(--space-MPX__1oxbat125)", NPX: "var(--space-NPX__1oxbat126)", OPX: "var(--space-OPX__1oxbat127)", PPX: "var(--space-PPX__1oxbat128)", QPX: "var(--space-QPX__1oxbat129)", RPX: "var(--space-RPX__1oxbat12a)", SPX: "var(--space-SPX__1oxbat12b)", TPX: "var(--space-TPX__1oxbat12c)", UPX: "var(--space-UPX__1oxbat12d)", VPX: "var(--space-VPX__1oxbat12e)", WPX: "var(--space-WPX__1oxbat12f)", XPX: "var(--space-XPX__1oxbat12g)", YPX: "var(--space-YPX__1oxbat12h)", ZPX: "var(--space-ZPX__1oxbat12i)" }, z: { indice: { ZERO: "var(--z-indice-ZERO__1oxbat12j)", DF: "var(--z-indice-DF__1oxbat12k)", LOW: "var(--z-indice-LOW__1oxbat12l)", MED: "var(--z-indice-MED__1oxbat12m)", HIGH: "var(--z-indice-HIGH__1oxbat12n)", TOP: "var(--z-indice-TOP__1oxbat12o)", MAX: "var(--z-indice-MAX__1oxbat12p)" } }, shadow: { NO: "var(--shadow-NO__1oxbat12q)", DF: "var(--shadow-DF__1oxbat12r)", LOW: "var(--shadow-LOW__1oxbat12s)", MED: "var(--shadow-MED__1oxbat12t)", HIGH: "var(--shadow-HIGH__1oxbat12u)" }, color: { transparent: "var(--color-transparent__1oxbat12v)", current: "var(--color-current__1oxbat12w)", white: "var(--color-white__1oxbat12x)", black: "var(--color-black__1oxbat12y)", gray100: "var(--color-gray100__1oxbat12z)", gray200: "var(--color-gray200__1oxbat130)", gray300: "var(--color-gray300__1oxbat131)", pale100: "var(--color-pale100__1oxbat132)", pale200: "var(--color-pale200__1oxbat133)", pale300: "var(--color-pale300__1oxbat134)", pale400: "var(--color-pale400__1oxbat135)", pale500: "var(--color-pale500__1oxbat136)", hyper0: "var(--color-hyper0__1oxbat137)", hyper1: "var(--color-hyper1__1oxbat138)", hyper2: "var(--color-hyper2__1oxbat139)", hyper3: "var(--color-hyper3__1oxbat13a)", hyper4: "var(--color-hyper4__1oxbat13b)", hyper5: "var(--color-hyper5__1oxbat13c)", hyper6: "var(--color-hyper6__1oxbat13d)", hyper7: "var(--color-hyper7__1oxbat13e)", hyper8: "var(--color-hyper8__1oxbat13f)", hyper9: "var(--color-hyper9__1oxbat13g)", hyper10: "var(--color-hyper10__1oxbat13h)", hyper11: "var(--color-hyper11__1oxbat13i)", hyper12: "var(--color-hyper12__1oxbat13j)", hyper13: "var(--color-hyper13__1oxbat13k)", lemon0: "var(--color-lemon0__1oxbat13l)", lemon1: "var(--color-lemon1__1oxbat13m)", lemon2: "var(--color-lemon2__1oxbat13n)", lemon3: "var(--color-lemon3__1oxbat13o)", lemon4: "var(--color-lemon4__1oxbat13p)", lemon5: "var(--color-lemon5__1oxbat13q)", lemon6: "var(--color-lemon6__1oxbat13r)", lemon7: "var(--color-lemon7__1oxbat13s)", lemon8: "var(--color-lemon8__1oxbat13t)", lemon9: "var(--color-lemon9__1oxbat13u)", lemon10: "var(--color-lemon10__1oxbat13v)", lemon11: "var(--color-lemon11__1oxbat13w)", lemon12: "var(--color-lemon12__1oxbat13x)", lemon13: "var(--color-lemon13__1oxbat13y)", slate1: "var(--color-slate1__1oxbat13z)", slate2: "var(--color-slate2__1oxbat140)", slate3: "var(--color-slate3__1oxbat141)", slate4: "var(--color-slate4__1oxbat142)", slate5: "var(--color-slate5__1oxbat143)", slate6: "var(--color-slate6__1oxbat144)", slate7: "var(--color-slate7__1oxbat145)", slate8: "var(--color-slate8__1oxbat146)", slate9: "var(--color-slate9__1oxbat147)", slate10: "var(--color-slate10__1oxbat148)", slate11: "var(--color-slate11__1oxbat149)", slate12: "var(--color-slate12__1oxbat14a)", slate13: "var(--color-slate13__1oxbat14b)", sapphire0: "var(--color-sapphire0__1oxbat14c)", sapphire1: "var(--color-sapphire1__1oxbat14d)", sapphire2: "var(--color-sapphire2__1oxbat14e)", sapphire3: "var(--color-sapphire3__1oxbat14f)", sapphire4: "var(--color-sapphire4__1oxbat14g)", sapphire5: "var(--color-sapphire5__1oxbat14h)", sapphire6: "var(--color-sapphire6__1oxbat14i)", sapphire7: "var(--color-sapphire7__1oxbat14j)", sapphire8: "var(--color-sapphire8__1oxbat14k)", sapphire9: "var(--color-sapphire9__1oxbat14l)", sapphire10: "var(--color-sapphire10__1oxbat14m)", sapphire11: "var(--color-sapphire11__1oxbat14n)", sapphire12: "var(--color-sapphire12__1oxbat14o)", sapphire13: "var(--color-sapphire13__1oxbat14p)", volt0: "var(--color-volt0__1oxbat14q)", volt1: "var(--color-volt1__1oxbat14r)", volt2: "var(--color-volt2__1oxbat14s)", volt3: "var(--color-volt3__1oxbat14t)", volt4: "var(--color-volt4__1oxbat14u)", volt5: "var(--color-volt5__1oxbat14v)", volt6: "var(--color-volt6__1oxbat14w)", volt7: "var(--color-volt7__1oxbat14x)", volt8: "var(--color-volt8__1oxbat14y)", volt9: "var(--color-volt9__1oxbat14z)", volt10: "var(--color-volt10__1oxbat150)", volt11: "var(--color-volt11__1oxbat151)", volt12: "var(--color-volt12__1oxbat152)", volt13: "var(--color-volt13__1oxbat153)" } };
const dl = {
  light: `html:not(${ur.light}) &`,
  dark: `html${ur.dark} &`
}, Qo = (e, r) => !r || Object.keys(r).length === 0 ? {} : {
  [dl[e]]: r
}, Nc = ({ lightMode: e, darkMode: r }) => ({
  ...e || r ? {
    selectors: {
      ...Qo("light", e),
      ...Qo("dark", r)
    }
  } : {}
}), Bt = mr({
  theme: "light",
  toggleTheme: null
}), jc = () => {
  const e = Mr(Bt);
  if (!e)
    throw new Error("Atelier® Kit components must be used within [KitProvider]");
  return e;
}, Dc = ({
  children: e
}) => {
  const [r, o] = G("light"), t = () => {
    o((n) => n === "light" ? "dark" : "light");
  }, i = r === "light" ? ur.dark : ur.light;
  return /* @__PURE__ */ y.jsx(Bt.Provider, { value: { theme: r, toggleTheme: t }, children: /* @__PURE__ */ y.jsx("div", { className: `${ur.base} ${i}`, children: e }) });
}, pl = ({ color: e = "currentColor", ...r }) => /* @__PURE__ */ y.jsx(
  "svg",
  {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...r,
    children: /* @__PURE__ */ y.jsx(
      "path",
      {
        d: "M12.0916 14.9959C12.2854 14.9802 12.4708 14.902 12.6225 14.7846L16.6417 11.583C16.8439 11.4343 16.9703 11.2151 16.9956 10.9725C17.0209 10.7298 16.9366 10.495 16.7681 10.3149C16.5996 10.1349 16.3552 10.0175 16.1024 10.0096C15.8412 9.99399 15.5884 10.0801 15.3946 10.2366L11.9989 12.945L8.60325 10.2366C8.40945 10.0723 8.15667 9.98616 7.90388 10.0018C7.64268 10.0175 7.39832 10.1271 7.2298 10.3149C7.06128 10.495 6.98545 10.7376 7.0023 10.9725C7.02758 11.2151 7.15397 11.4343 7.35619 11.583L11.3754 14.7846C11.5692 14.9411 11.8304 15.0194 12.0832 14.9959H12.0916Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
), qc = ({ color: e = "currentColor", ...r }) => /* @__PURE__ */ y.jsx(y.Fragment, {}), gl = ({ color: e = "currentColor", ...r }) => /* @__PURE__ */ y.jsx(y.Fragment, { children: /* @__PURE__ */ y.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...r,
    children: /* @__PURE__ */ y.jsx(
      "path",
      {
        d: "M15.3529 1L8.64709 1C8.08172 1 7.78927 1.71527 8.17595 2.15231L11.2933 5.67559C11.676 6.10814 12.324 6.10814 12.7067 5.67559L15.8241 2.15231C16.2107 1.71527 15.9183 1 15.3529 1Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
) }), ul = ({ color: e = "currentColor", ...r }) => /* @__PURE__ */ y.jsx(y.Fragment, { children: /* @__PURE__ */ y.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...r,
    children: /* @__PURE__ */ y.jsx(
      "path",
      {
        d: "M8.64709 6H15.3529C15.9183 6 16.2107 5.28473 15.8241 4.84769L12.7067 1.32441C12.324 0.891862 11.676 0.891862 11.2933 1.32441L8.17595 4.84769C7.78927 5.28473 8.08172 6 8.64709 6Z",
        fill: e,
        "fill-rule": "evenodd",
        "clip-rule": "evenodd"
      }
    )
  }
) }), Cr = {
  background: "#9E9CA6",
  inner: "#F6F4F0"
}, Ic = ({
  color: e = Cr.background,
  width: r,
  height: o,
  ...t
}) => /* @__PURE__ */ y.jsx(y.Fragment, { children: /* @__PURE__ */ y.jsxs(
  "svg",
  {
    width: r || "18",
    height: o || "18",
    viewBox: "0 0 18 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: [
      /* @__PURE__ */ y.jsx(
        "path",
        {
          d: "M6.9 16H11.1C14.6 16 16 14.6 16 11.1V6.9C16 3.4 14.6 2 11.1 2H6.9C3.4 2 2 3.4 2 6.9V11.1C2 14.6 3.4 16 6.9 16Z",
          fill: e,
          stroke: e,
          strokeWidth: "1.4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ y.jsx(
        "path",
        {
          d: "M7.14 6.49999L4 11.5H6.68L7.15 10.7H10.8L11.26 11.5H14L10.86 6.49999H7.14ZM7.82 9.53999L8.98 7.55999L10.12 9.53999H7.82Z",
          fill: Cr.inner
        }
      ),
      /* @__PURE__ */ y.jsx(
        "path",
        {
          d: "M12.35 8.14999C12.44 8.23999 12.54 8.30999 12.66 8.35999C12.78 8.40999 12.9 8.42999 13.04 8.42999C13.18 8.42999 13.3 8.40999 13.42 8.35999C13.54 8.30999 13.64 8.23999 13.73 8.14999C13.82 8.05999 13.89 7.95999 13.94 7.83999C13.99 7.71999 14.01 7.59999 14.01 7.45999C14.01 7.31999 13.99 7.19999 13.94 7.07999C13.89 6.95999 13.82 6.85999 13.73 6.76999C13.64 6.67999 13.54 6.60999 13.42 6.55999C13.3 6.50999 13.18 6.48999 13.04 6.48999C12.9 6.48999 12.78 6.50999 12.66 6.55999C12.54 6.60999 12.44 6.67999 12.35 6.76999C12.26 6.85999 12.19 6.95999 12.14 7.07999C12.09 7.19999 12.07 7.31999 12.07 7.45999C12.07 7.59999 12.09 7.71999 12.14 7.83999C12.19 7.95999 12.26 8.05999 12.35 8.14999ZM12.4 7.09999C12.47 6.98999 12.55 6.89999 12.66 6.83999C12.77 6.76999 12.89 6.73999 13.03 6.73999C13.17 6.73999 13.29 6.76999 13.39 6.83999C13.5 6.89999 13.59 6.98999 13.65 7.09999C13.72 7.20999 13.75 7.32999 13.75 7.46999C13.75 7.60999 13.72 7.72999 13.65 7.82999C13.59 7.93999 13.5 8.02999 13.39 8.08999C13.28 8.15999 13.16 8.18999 13.03 8.18999C12.9 8.18999 12.77 8.15999 12.66 8.08999C12.55 8.01999 12.46 7.93999 12.4 7.82999C12.33 7.71999 12.3 7.59999 12.3 7.46999C12.3 7.33999 12.33 7.20999 12.4 7.09999Z",
          fill: Cr.inner
        }
      ),
      /* @__PURE__ */ y.jsx(
        "path",
        {
          d: "M12.9 7.59999H13.08L13.23 7.89999H13.46L13.28 7.54999C13.28 7.54999 13.35 7.49999 13.38 7.45999C13.41 7.40999 13.43 7.35999 13.43 7.29999C13.43 7.23999 13.42 7.17999 13.39 7.13999C13.36 7.09999 13.32 7.05999 13.28 7.03999C13.24 7.01999 13.19 7.00999 13.15 7.00999H12.71V7.89999H12.92V7.59999H12.9ZM13.07 7.15999C13.07 7.15999 13.12 7.15999 13.15 7.18999C13.18 7.20999 13.19 7.23999 13.19 7.29999C13.19 7.35999 13.18 7.38999 13.15 7.40999C13.12 7.42999 13.09 7.44999 13.06 7.44999H12.89V7.16999H13.06L13.07 7.15999Z",
          fill: Cr.inner
        }
      )
    ]
  }
) }), $o = q(
  ({ as: e = "div", className: r, ...o }, t) => {
    const i = {}, n = {};
    for (const l in o)
      Ht.properties.has(l) ? i[l] = o[l] : n[l] = o[l];
    const s = _l({
      reset: typeof e == "string" ? e : "div",
      ...i
    });
    return w(e, {
      className: D(s, r),
      ...n,
      ref: t
    });
  }
);
$o.displayName = "RectBox";
const Lc = H.forwardRef(function({
  children: r,
  gridItemMinWidth: o = "300px",
  gridMaxRowItems: t,
  style: i = {},
  ...n
}, s) {
  return /* @__PURE__ */ y.jsx(
    $o,
    {
      ...n,
      ref: s,
      className: `${Kn} ${n.className ?? ""}`,
      style: {
        ...i,
        ...Jn({
          [Yn]: o,
          [Gn]: t && String(t) || String(Xe.count(r))
        })
      },
      flexDirection: "row",
      children: r
    }
  );
});
var fl = fe({ defaultClassName: "heading_HEADING_BASE__1n0su94k", variantClassNames: { font: { system: "heading_font_system__1n0su940", mono: "heading_font_mono__1n0su941" }, size: { display: "heading_size_display__1n0su942", H1: "heading_size_H1__1n0su943", H2: "heading_size_H2__1n0su944", H3: "heading_size_H3__1n0su945", H4: "heading_size_H4__1n0su946", H5: "heading_size_H5__1n0su947", H6: "heading_size_H6__1n0su948" }, weight: { superlite: "heading_weight_superlite__1n0su949", lite: "heading_weight_lite__1n0su94a", normal: "heading_weight_normal__1n0su94b", medium: "heading_weight_medium__1n0su94c", semibold: "heading_weight_semibold__1n0su94d", bold: "heading_weight_bold__1n0su94e", heavy: "heading_weight_heavy__1n0su94f", black: "heading_weight_black__1n0su94g" }, align: { left: "heading_align_left__1n0su94h", center: "heading_align_center__1n0su94i", right: "heading_align_right__1n0su94j" } }, defaultVariants: { font: "system", size: "H1", weight: "semibold", align: "left" }, compoundVariants: [] });
const hl = H.forwardRef(
  ({
    className: e,
    font: r = "system",
    size: o = "H1",
    weight: t = "semibold",
    align: i = "left",
    ...n
  }, s) => /* @__PURE__ */ y.jsx(
    "h1",
    {
      ...n,
      ref: s,
      className: D(e, fl({ font: r, size: o, weight: t, align: i }))
    }
  )
);
hl.displayName = "Heading";
function M() {
  return M = Object.assign ? Object.assign.bind() : function(e) {
    for (var r = 1; r < arguments.length; r++) {
      var o = arguments[r];
      for (var t in o)
        Object.prototype.hasOwnProperty.call(o, t) && (e[t] = o[t]);
    }
    return e;
  }, M.apply(this, arguments);
}
function oe(e, r, { checkForDefaultPrevented: o = !0 } = {}) {
  return function(i) {
    if (e == null || e(i), o === !1 || !i.defaultPrevented)
      return r == null ? void 0 : r(i);
  };
}
function Fr(e, r = []) {
  let o = [];
  function t(n, s) {
    const l = /* @__PURE__ */ mr(s), a = o.length;
    o = [
      ...o,
      s
    ];
    function c(d) {
      const { scope: h, children: u, ...f } = d, g = (h == null ? void 0 : h[e][a]) || l, m = lr(
        () => f,
        Object.values(f)
      );
      return /* @__PURE__ */ w(g.Provider, {
        value: m
      }, u);
    }
    function p(d, h) {
      const u = (h == null ? void 0 : h[e][a]) || l, f = Mr(u);
      if (f)
        return f;
      if (s !== void 0)
        return s;
      throw new Error(`\`${d}\` must be used within \`${n}\``);
    }
    return c.displayName = n + "Provider", [
      c,
      p
    ];
  }
  const i = () => {
    const n = o.map((s) => /* @__PURE__ */ mr(s));
    return function(l) {
      const a = (l == null ? void 0 : l[e]) || n;
      return lr(
        () => ({
          [`__scope${e}`]: {
            ...l,
            [e]: a
          }
        }),
        [
          l,
          a
        ]
      );
    };
  };
  return i.scopeName = e, [
    t,
    ml(i, ...r)
  ];
}
function ml(...e) {
  const r = e[0];
  if (e.length === 1)
    return r;
  const o = () => {
    const t = e.map(
      (i) => ({
        useScope: i(),
        scopeName: i.scopeName
      })
    );
    return function(n) {
      const s = t.reduce((l, { useScope: a, scopeName: c }) => {
        const d = a(n)[`__scope${c}`];
        return {
          ...l,
          ...d
        };
      }, {});
      return lr(
        () => ({
          [`__scope${r.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return o.scopeName = r.scopeName, o;
}
function qe(e) {
  const r = te(e);
  return ie(() => {
    r.current = e;
  }), lr(
    () => (...o) => {
      var t;
      return (t = r.current) === null || t === void 0 ? void 0 : t.call(r, ...o);
    },
    []
  );
}
function go({ prop: e, defaultProp: r, onChange: o = () => {
} }) {
  const [t, i] = vl({
    defaultProp: r,
    onChange: o
  }), n = e !== void 0, s = n ? e : t, l = qe(o), a = ae((c) => {
    if (n) {
      const d = typeof c == "function" ? c(e) : c;
      d !== e && l(d);
    } else
      i(c);
  }, [
    n,
    e,
    i,
    l
  ]);
  return [
    s,
    a
  ];
}
function vl({ defaultProp: e, onChange: r }) {
  const o = G(e), [t] = o, i = te(t), n = qe(r);
  return ie(() => {
    i.current !== t && (n(t), i.current = t);
  }, [
    t,
    i,
    n
  ]), o;
}
function kl(e, r) {
  typeof e == "function" ? e(r) : e != null && (e.current = r);
}
function Wt(...e) {
  return (r) => e.forEach(
    (o) => kl(o, r)
  );
}
function pe(...e) {
  return ae(Wt(...e), e);
}
function _r(e) {
  return e.split("-")[1];
}
function So(e) {
  return e === "y" ? "height" : "width";
}
function De(e) {
  return e.split("-")[0];
}
function Ye(e) {
  return ["top", "bottom"].includes(De(e)) ? "x" : "y";
}
function et(e, r, o) {
  let { reference: t, floating: i } = e;
  const n = t.x + t.width / 2 - i.width / 2, s = t.y + t.height / 2 - i.height / 2, l = Ye(r), a = So(l), c = t[a] / 2 - i[a] / 2, p = l === "x";
  let d;
  switch (De(r)) {
    case "top":
      d = { x: n, y: t.y - i.height };
      break;
    case "bottom":
      d = { x: n, y: t.y + t.height };
      break;
    case "right":
      d = { x: t.x + t.width, y: s };
      break;
    case "left":
      d = { x: t.x - i.width, y: s };
      break;
    default:
      d = { x: t.x, y: t.y };
  }
  switch (_r(r)) {
    case "start":
      d[l] -= c * (o && p ? -1 : 1);
      break;
    case "end":
      d[l] += c * (o && p ? -1 : 1);
  }
  return d;
}
const bl = async (e, r, o) => {
  const { placement: t = "bottom", strategy: i = "absolute", middleware: n = [], platform: s } = o, l = n.filter(Boolean), a = await (s.isRTL == null ? void 0 : s.isRTL(r));
  let c = await s.getElementRects({ reference: e, floating: r, strategy: i }), { x: p, y: d } = et(c, t, a), h = t, u = {}, f = 0;
  for (let g = 0; g < l.length; g++) {
    const { name: m, fn: k } = l[g], { x: v, y: b, data: C, reset: S } = await k({ x: p, y: d, initialPlacement: t, placement: h, strategy: i, middlewareData: u, rects: c, platform: s, elements: { reference: e, floating: r } });
    p = v ?? p, d = b ?? d, u = { ...u, [m]: { ...u[m], ...C } }, S && f <= 50 && (f++, typeof S == "object" && (S.placement && (h = S.placement), S.rects && (c = S.rects === !0 ? await s.getElementRects({ reference: e, floating: r, strategy: i }) : S.rects), { x: p, y: d } = et(c, h, a)), g = -1);
  }
  return { x: p, y: d, placement: h, strategy: i, middlewareData: u };
};
function Vt(e) {
  return typeof e != "number" ? function(r) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...r };
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function jr(e) {
  return { ...e, top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height };
}
async function vr(e, r) {
  var o;
  r === void 0 && (r = {});
  const { x: t, y: i, platform: n, rects: s, elements: l, strategy: a } = e, { boundary: c = "clippingAncestors", rootBoundary: p = "viewport", elementContext: d = "floating", altBoundary: h = !1, padding: u = 0 } = r, f = Vt(u), g = l[h ? d === "floating" ? "reference" : "floating" : d], m = jr(await n.getClippingRect({ element: (o = await (n.isElement == null ? void 0 : n.isElement(g))) == null || o ? g : g.contextElement || await (n.getDocumentElement == null ? void 0 : n.getDocumentElement(l.floating)), boundary: c, rootBoundary: p, strategy: a })), k = d === "floating" ? { ...s.floating, x: t, y: i } : s.reference, v = await (n.getOffsetParent == null ? void 0 : n.getOffsetParent(l.floating)), b = await (n.isElement == null ? void 0 : n.isElement(v)) && await (n.getScale == null ? void 0 : n.getScale(v)) || { x: 1, y: 1 }, C = jr(n.convertOffsetParentRelativeRectToViewportRelativeRect ? await n.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: k, offsetParent: v, strategy: a }) : k);
  return { top: (m.top - C.top + f.top) / b.y, bottom: (C.bottom - m.bottom + f.bottom) / b.y, left: (m.left - C.left + f.left) / b.x, right: (C.right - m.right + f.right) / b.x };
}
const uo = Math.min, Ve = Math.max;
function fo(e, r, o) {
  return Ve(e, uo(r, o));
}
const rt = (e) => ({ name: "arrow", options: e, async fn(r) {
  const { element: o, padding: t = 0 } = e || {}, { x: i, y: n, placement: s, rects: l, platform: a, elements: c } = r;
  if (o == null)
    return {};
  const p = Vt(t), d = { x: i, y: n }, h = Ye(s), u = So(h), f = await a.getDimensions(o), g = h === "y", m = g ? "top" : "left", k = g ? "bottom" : "right", v = g ? "clientHeight" : "clientWidth", b = l.reference[u] + l.reference[h] - d[h] - l.floating[u], C = d[h] - l.reference[h], S = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(o));
  let E = S ? S[v] : 0;
  E && await (a.isElement == null ? void 0 : a.isElement(S)) || (E = c.floating[v] || l.floating[u]);
  const P = b / 2 - C / 2, T = p[m], F = E - f[u] - p[k], U = E / 2 - f[u] / 2 + P, N = fo(T, U, F), W = _r(s) != null && U != N && l.reference[u] / 2 - (U < T ? p[m] : p[k]) - f[u] / 2 < 0;
  return { [h]: d[h] - (W ? U < T ? T - U : F - U : 0), data: { [h]: N, centerOffset: U - N } };
} }), Xt = ["top", "right", "bottom", "left"];
Xt.reduce((e, r) => e.concat(r, r + "-start", r + "-end"), []);
const xl = { left: "right", right: "left", bottom: "top", top: "bottom" };
function Dr(e) {
  return e.replace(/left|right|bottom|top/g, (r) => xl[r]);
}
function yl(e, r, o) {
  o === void 0 && (o = !1);
  const t = _r(e), i = Ye(e), n = So(i);
  let s = i === "x" ? t === (o ? "end" : "start") ? "right" : "left" : t === "start" ? "bottom" : "top";
  return r.reference[n] > r.floating[n] && (s = Dr(s)), { main: s, cross: Dr(s) };
}
const Cl = { start: "end", end: "start" };
function to(e) {
  return e.replace(/start|end/g, (r) => Cl[r]);
}
const wl = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(r) {
    var o;
    const { placement: t, middlewareData: i, rects: n, initialPlacement: s, platform: l, elements: a } = r, { mainAxis: c = !0, crossAxis: p = !0, fallbackPlacements: d, fallbackStrategy: h = "bestFit", fallbackAxisSideDirection: u = "none", flipAlignment: f = !0, ...g } = e, m = De(t), k = De(s) === s, v = await (l.isRTL == null ? void 0 : l.isRTL(a.floating)), b = d || (k || !f ? [Dr(s)] : function(N) {
      const W = Dr(N);
      return [to(N), W, to(W)];
    }(s));
    d || u === "none" || b.push(...function(N, W, j, L) {
      const I = _r(N);
      let z = function(Q, ee, ge) {
        const ne = ["left", "right"], ce = ["right", "left"], me = ["top", "bottom"], $e = ["bottom", "top"];
        switch (Q) {
          case "top":
          case "bottom":
            return ge ? ee ? ce : ne : ee ? ne : ce;
          case "left":
          case "right":
            return ee ? me : $e;
          default:
            return [];
        }
      }(De(N), j === "start", L);
      return I && (z = z.map((Q) => Q + "-" + I), W && (z = z.concat(z.map(to)))), z;
    }(s, f, u, v));
    const C = [s, ...b], S = await vr(r, g), E = [];
    let P = ((o = i.flip) == null ? void 0 : o.overflows) || [];
    if (c && E.push(S[m]), p) {
      const { main: N, cross: W } = yl(t, n, v);
      E.push(S[N], S[W]);
    }
    if (P = [...P, { placement: t, overflows: E }], !E.every((N) => N <= 0)) {
      var T, F;
      const N = (((T = i.flip) == null ? void 0 : T.index) || 0) + 1, W = C[N];
      if (W)
        return { data: { index: N, overflows: P }, reset: { placement: W } };
      let j = (F = P.filter((L) => L.overflows[0] <= 0).sort((L, I) => L.overflows[1] - I.overflows[1])[0]) == null ? void 0 : F.placement;
      if (!j)
        switch (h) {
          case "bestFit": {
            var U;
            const L = (U = P.map((I) => [I.placement, I.overflows.filter((z) => z > 0).reduce((z, Q) => z + Q, 0)]).sort((I, z) => I[1] - z[1])[0]) == null ? void 0 : U[0];
            L && (j = L);
            break;
          }
          case "initialPlacement":
            j = s;
        }
      if (t !== j)
        return { reset: { placement: j } };
    }
    return {};
  } };
};
function ot(e, r) {
  return { top: e.top - r.height, right: e.right - r.width, bottom: e.bottom - r.height, left: e.left - r.width };
}
function tt(e) {
  return Xt.some((r) => e[r] >= 0);
}
const $l = function(e) {
  return e === void 0 && (e = {}), { name: "hide", options: e, async fn(r) {
    const { strategy: o = "referenceHidden", ...t } = e, { rects: i } = r;
    switch (o) {
      case "referenceHidden": {
        const n = ot(await vr(r, { ...t, elementContext: "reference" }), i.reference);
        return { data: { referenceHiddenOffsets: n, referenceHidden: tt(n) } };
      }
      case "escaped": {
        const n = ot(await vr(r, { ...t, altBoundary: !0 }), i.floating);
        return { data: { escapedOffsets: n, escaped: tt(n) } };
      }
      default:
        return {};
    }
  } };
}, Sl = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(r) {
    const { x: o, y: t } = r, i = await async function(n, s) {
      const { placement: l, platform: a, elements: c } = n, p = await (a.isRTL == null ? void 0 : a.isRTL(c.floating)), d = De(l), h = _r(l), u = Ye(l) === "x", f = ["left", "top"].includes(d) ? -1 : 1, g = p && u ? -1 : 1, m = typeof s == "function" ? s(n) : s;
      let { mainAxis: k, crossAxis: v, alignmentAxis: b } = typeof m == "number" ? { mainAxis: m, crossAxis: 0, alignmentAxis: null } : { mainAxis: 0, crossAxis: 0, alignmentAxis: null, ...m };
      return h && typeof b == "number" && (v = h === "end" ? -1 * b : b), u ? { x: v * g, y: k * f } : { x: k * f, y: v * g };
    }(r, e);
    return { x: o + i.x, y: t + i.y, data: i };
  } };
};
function Ut(e) {
  return e === "x" ? "y" : "x";
}
const Pl = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(r) {
    const { x: o, y: t, placement: i } = r, { mainAxis: n = !0, crossAxis: s = !1, limiter: l = { fn: (m) => {
      let { x: k, y: v } = m;
      return { x: k, y: v };
    } }, ...a } = e, c = { x: o, y: t }, p = await vr(r, a), d = Ye(De(i)), h = Ut(d);
    let u = c[d], f = c[h];
    if (n) {
      const m = d === "y" ? "bottom" : "right";
      u = fo(u + p[d === "y" ? "top" : "left"], u, u - p[m]);
    }
    if (s) {
      const m = h === "y" ? "bottom" : "right";
      f = fo(f + p[h === "y" ? "top" : "left"], f, f - p[m]);
    }
    const g = l.fn({ ...r, [d]: u, [h]: f });
    return { ...g, data: { x: g.x - o, y: g.y - t } };
  } };
}, El = function(e) {
  return e === void 0 && (e = {}), { options: e, fn(r) {
    const { x: o, y: t, placement: i, rects: n, middlewareData: s } = r, { offset: l = 0, mainAxis: a = !0, crossAxis: c = !0 } = e, p = { x: o, y: t }, d = Ye(i), h = Ut(d);
    let u = p[d], f = p[h];
    const g = typeof l == "function" ? l(r) : l, m = typeof g == "number" ? { mainAxis: g, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...g };
    if (a) {
      const b = d === "y" ? "height" : "width", C = n.reference[d] - n.floating[b] + m.mainAxis, S = n.reference[d] + n.reference[b] - m.mainAxis;
      u < C ? u = C : u > S && (u = S);
    }
    if (c) {
      var k, v;
      const b = d === "y" ? "width" : "height", C = ["top", "left"].includes(De(i)), S = n.reference[h] - n.floating[b] + (C && ((k = s.offset) == null ? void 0 : k[h]) || 0) + (C ? 0 : m.crossAxis), E = n.reference[h] + n.reference[b] + (C ? 0 : ((v = s.offset) == null ? void 0 : v[h]) || 0) - (C ? m.crossAxis : 0);
      f < S ? f = S : f > E && (f = E);
    }
    return { [d]: u, [h]: f };
  } };
}, Tl = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(r) {
    const { placement: o, rects: t, platform: i, elements: n } = r, { apply: s = () => {
    }, ...l } = e, a = await vr(r, l), c = De(o), p = _r(o), d = Ye(o) === "x", { width: h, height: u } = t.floating;
    let f, g;
    c === "top" || c === "bottom" ? (f = c, g = p === (await (i.isRTL == null ? void 0 : i.isRTL(n.floating)) ? "start" : "end") ? "left" : "right") : (g = c, f = p === "end" ? "top" : "bottom");
    const m = u - a[f], k = h - a[g], v = !r.middlewareData.shift;
    let b = m, C = k;
    if (d) {
      const E = h - a.left - a.right;
      C = p || v ? uo(k, E) : E;
    } else {
      const E = u - a.top - a.bottom;
      b = p || v ? uo(m, E) : E;
    }
    if (v && !p) {
      const E = Ve(a.left, 0), P = Ve(a.right, 0), T = Ve(a.top, 0), F = Ve(a.bottom, 0);
      d ? C = h - 2 * (E !== 0 || P !== 0 ? E + P : Ve(a.left, a.right)) : b = u - 2 * (T !== 0 || F !== 0 ? T + F : Ve(a.top, a.bottom));
    }
    await s({ ...r, availableWidth: C, availableHeight: b });
    const S = await i.getDimensions(n.floating);
    return h !== S.width || u !== S.height ? { reset: { rects: !0 } } : {};
  } };
};
function Ee(e) {
  var r;
  return ((r = e.ownerDocument) == null ? void 0 : r.defaultView) || window;
}
function Te(e) {
  return Ee(e).getComputedStyle(e);
}
function Kt(e) {
  return e instanceof Ee(e).Node;
}
function We(e) {
  return Kt(e) ? (e.nodeName || "").toLowerCase() : "";
}
function Ae(e) {
  return e instanceof Ee(e).HTMLElement;
}
function Ce(e) {
  return e instanceof Ee(e).Element;
}
function it(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof Ee(e).ShadowRoot || e instanceof ShadowRoot;
}
function kr(e) {
  const { overflow: r, overflowX: o, overflowY: t, display: i } = Te(e);
  return /auto|scroll|overlay|hidden|clip/.test(r + t + o) && !["inline", "contents"].includes(i);
}
function Al(e) {
  return ["table", "td", "th"].includes(We(e));
}
function ho(e) {
  const r = Po(), o = Te(e);
  return o.transform !== "none" || o.perspective !== "none" || !r && !!o.backdropFilter && o.backdropFilter !== "none" || !r && !!o.filter && o.filter !== "none" || ["transform", "perspective", "filter"].some((t) => (o.willChange || "").includes(t)) || ["paint", "layout", "strict", "content"].some((t) => (o.contain || "").includes(t));
}
function Po() {
  return !(typeof CSS > "u" || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
}
function Hr(e) {
  return ["html", "body", "#document"].includes(We(e));
}
const nt = Math.min, fr = Math.max, qr = Math.round;
function Yt(e) {
  const r = Te(e);
  let o = parseFloat(r.width) || 0, t = parseFloat(r.height) || 0;
  const i = Ae(e), n = i ? e.offsetWidth : o, s = i ? e.offsetHeight : t, l = qr(o) !== n || qr(t) !== s;
  return l && (o = n, t = s), { width: o, height: t, fallback: l };
}
function Gt(e) {
  return Ce(e) ? e : e.contextElement;
}
const Zt = { x: 1, y: 1 };
function nr(e) {
  const r = Gt(e);
  if (!Ae(r))
    return Zt;
  const o = r.getBoundingClientRect(), { width: t, height: i, fallback: n } = Yt(r);
  let s = (n ? qr(o.width) : o.width) / t, l = (n ? qr(o.height) : o.height) / i;
  return s && Number.isFinite(s) || (s = 1), l && Number.isFinite(l) || (l = 1), { x: s, y: l };
}
const lt = { x: 0, y: 0 };
function Jt(e, r, o) {
  var t, i;
  if (r === void 0 && (r = !0), !Po())
    return lt;
  const n = e ? Ee(e) : window;
  return !o || r && o !== n ? lt : { x: ((t = n.visualViewport) == null ? void 0 : t.offsetLeft) || 0, y: ((i = n.visualViewport) == null ? void 0 : i.offsetTop) || 0 };
}
function Ue(e, r, o, t) {
  r === void 0 && (r = !1), o === void 0 && (o = !1);
  const i = e.getBoundingClientRect(), n = Gt(e);
  let s = Zt;
  r && (t ? Ce(t) && (s = nr(t)) : s = nr(e));
  const l = Jt(n, o, t);
  let a = (i.left + l.x) / s.x, c = (i.top + l.y) / s.y, p = i.width / s.x, d = i.height / s.y;
  if (n) {
    const h = Ee(n), u = t && Ce(t) ? Ee(t) : t;
    let f = h.frameElement;
    for (; f && t && u !== h; ) {
      const g = nr(f), m = f.getBoundingClientRect(), k = getComputedStyle(f);
      m.x += (f.clientLeft + parseFloat(k.paddingLeft)) * g.x, m.y += (f.clientTop + parseFloat(k.paddingTop)) * g.y, a *= g.x, c *= g.y, p *= g.x, d *= g.y, a += m.x, c += m.y, f = Ee(f).frameElement;
    }
  }
  return jr({ width: p, height: d, x: a, y: c });
}
function He(e) {
  return ((Kt(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function Br(e) {
  return Ce(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function Qt(e) {
  return Ue(He(e)).left + Br(e).scrollLeft;
}
function sr(e) {
  if (We(e) === "html")
    return e;
  const r = e.assignedSlot || e.parentNode || it(e) && e.host || He(e);
  return it(r) ? r.host : r;
}
function ei(e) {
  const r = sr(e);
  return Hr(r) ? r.ownerDocument.body : Ae(r) && kr(r) ? r : ei(r);
}
function hr(e, r) {
  var o;
  r === void 0 && (r = []);
  const t = ei(e), i = t === ((o = e.ownerDocument) == null ? void 0 : o.body), n = Ee(t);
  return i ? r.concat(n, n.visualViewport || [], kr(t) ? t : []) : r.concat(t, hr(t));
}
function st(e, r, o) {
  let t;
  if (r === "viewport")
    t = function(i, n) {
      const s = Ee(i), l = He(i), a = s.visualViewport;
      let c = l.clientWidth, p = l.clientHeight, d = 0, h = 0;
      if (a) {
        c = a.width, p = a.height;
        const u = Po();
        (!u || u && n === "fixed") && (d = a.offsetLeft, h = a.offsetTop);
      }
      return { width: c, height: p, x: d, y: h };
    }(e, o);
  else if (r === "document")
    t = function(i) {
      const n = He(i), s = Br(i), l = i.ownerDocument.body, a = fr(n.scrollWidth, n.clientWidth, l.scrollWidth, l.clientWidth), c = fr(n.scrollHeight, n.clientHeight, l.scrollHeight, l.clientHeight);
      let p = -s.scrollLeft + Qt(i);
      const d = -s.scrollTop;
      return Te(l).direction === "rtl" && (p += fr(n.clientWidth, l.clientWidth) - a), { width: a, height: c, x: p, y: d };
    }(He(e));
  else if (Ce(r))
    t = function(i, n) {
      const s = Ue(i, !0, n === "fixed"), l = s.top + i.clientTop, a = s.left + i.clientLeft, c = Ae(i) ? nr(i) : { x: 1, y: 1 };
      return { width: i.clientWidth * c.x, height: i.clientHeight * c.y, x: a * c.x, y: l * c.y };
    }(r, o);
  else {
    const i = Jt(e);
    t = { ...r, x: r.x - i.x, y: r.y - i.y };
  }
  return jr(t);
}
function ri(e, r) {
  const o = sr(e);
  return !(o === r || !Ce(o) || Hr(o)) && (Te(o).position === "fixed" || ri(o, r));
}
function at(e, r) {
  return Ae(e) && Te(e).position !== "fixed" ? r ? r(e) : e.offsetParent : null;
}
function _t(e, r) {
  const o = Ee(e);
  if (!Ae(e))
    return o;
  let t = at(e, r);
  for (; t && Al(t) && Te(t).position === "static"; )
    t = at(t, r);
  return t && (We(t) === "html" || We(t) === "body" && Te(t).position === "static" && !ho(t)) ? o : t || function(i) {
    let n = sr(i);
    for (; Ae(n) && !Hr(n); ) {
      if (ho(n))
        return n;
      n = sr(n);
    }
    return null;
  }(e) || o;
}
function zl(e, r, o) {
  const t = Ae(r), i = He(r), n = o === "fixed", s = Ue(e, !0, n, r);
  let l = { scrollLeft: 0, scrollTop: 0 };
  const a = { x: 0, y: 0 };
  if (t || !t && !n)
    if ((We(r) !== "body" || kr(i)) && (l = Br(r)), Ae(r)) {
      const c = Ue(r, !0, n, r);
      a.x = c.x + r.clientLeft, a.y = c.y + r.clientTop;
    } else
      i && (a.x = Qt(i));
  return { x: s.left + l.scrollLeft - a.x, y: s.top + l.scrollTop - a.y, width: s.width, height: s.height };
}
const Rl = { getClippingRect: function(e) {
  let { element: r, boundary: o, rootBoundary: t, strategy: i } = e;
  const n = o === "clippingAncestors" ? function(c, p) {
    const d = p.get(c);
    if (d)
      return d;
    let h = hr(c).filter((m) => Ce(m) && We(m) !== "body"), u = null;
    const f = Te(c).position === "fixed";
    let g = f ? sr(c) : c;
    for (; Ce(g) && !Hr(g); ) {
      const m = Te(g), k = ho(g);
      k || m.position !== "fixed" || (u = null), (f ? !k && !u : !k && m.position === "static" && u && ["absolute", "fixed"].includes(u.position) || kr(g) && !k && ri(c, g)) ? h = h.filter((v) => v !== g) : u = m, g = sr(g);
    }
    return p.set(c, h), h;
  }(r, this._c) : [].concat(o), s = [...n, t], l = s[0], a = s.reduce((c, p) => {
    const d = st(r, p, i);
    return c.top = fr(d.top, c.top), c.right = nt(d.right, c.right), c.bottom = nt(d.bottom, c.bottom), c.left = fr(d.left, c.left), c;
  }, st(r, l, i));
  return { width: a.right - a.left, height: a.bottom - a.top, x: a.left, y: a.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: r, offsetParent: o, strategy: t } = e;
  const i = Ae(o), n = He(o);
  if (o === n)
    return r;
  let s = { scrollLeft: 0, scrollTop: 0 }, l = { x: 1, y: 1 };
  const a = { x: 0, y: 0 };
  if ((i || !i && t !== "fixed") && ((We(o) !== "body" || kr(n)) && (s = Br(o)), Ae(o))) {
    const c = Ue(o);
    l = nr(o), a.x = c.x + o.clientLeft, a.y = c.y + o.clientTop;
  }
  return { width: r.width * l.x, height: r.height * l.y, x: r.x * l.x - s.scrollLeft * l.x + a.x, y: r.y * l.y - s.scrollTop * l.y + a.y };
}, isElement: Ce, getDimensions: function(e) {
  return Yt(e);
}, getOffsetParent: _t, getDocumentElement: He, getScale: nr, async getElementRects(e) {
  let { reference: r, floating: o, strategy: t } = e;
  const i = this.getOffsetParent || _t, n = this.getDimensions;
  return { reference: zl(r, await i(o), t), floating: { x: 0, y: 0, ...await n(o) } };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Te(e).direction === "rtl" };
function Ol(e, r, o, t) {
  t === void 0 && (t = {});
  const { ancestorScroll: i = !0, ancestorResize: n = !0, elementResize: s = !0, animationFrame: l = !1 } = t, a = i || n ? [...Ce(e) ? hr(e) : e.contextElement ? hr(e.contextElement) : [], ...hr(r)] : [];
  a.forEach((h) => {
    const u = !Ce(h) && h.toString().includes("V");
    !i || l && !u || h.addEventListener("scroll", o, { passive: !0 }), n && h.addEventListener("resize", o);
  });
  let c, p = null;
  s && (p = new ResizeObserver(() => {
    o();
  }), Ce(e) && !l && p.observe(e), Ce(e) || !e.contextElement || l || p.observe(e.contextElement), p.observe(r));
  let d = l ? Ue(e) : null;
  return l && function h() {
    const u = Ue(e);
    !d || u.x === d.x && u.y === d.y && u.width === d.width && u.height === d.height || o(), d = u, c = requestAnimationFrame(h);
  }(), o(), () => {
    var h;
    a.forEach((u) => {
      i && u.removeEventListener("scroll", o), n && u.removeEventListener("resize", o);
    }), (h = p) == null || h.disconnect(), p = null, l && cancelAnimationFrame(c);
  };
}
const Nl = (e, r, o) => {
  const t = /* @__PURE__ */ new Map(), i = { platform: Rl, ...o }, n = { ...i.platform, _c: t };
  return bl(e, r, { ...i, platform: n });
}, jl = (e) => {
  const {
    element: r,
    padding: o
  } = e;
  function t(i) {
    return {}.hasOwnProperty.call(i, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(i) {
      return r && t(r) ? r.current != null ? rt({
        element: r.current,
        padding: o
      }).fn(i) : {} : r ? rt({
        element: r,
        padding: o
      }).fn(i) : {};
    }
  };
};
var Ar = typeof document < "u" ? Tt : ie;
function Ir(e, r) {
  if (e === r)
    return !0;
  if (typeof e != typeof r)
    return !1;
  if (typeof e == "function" && e.toString() === r.toString())
    return !0;
  let o, t, i;
  if (e && r && typeof e == "object") {
    if (Array.isArray(e)) {
      if (o = e.length, o != r.length)
        return !1;
      for (t = o; t-- !== 0; )
        if (!Ir(e[t], r[t]))
          return !1;
      return !0;
    }
    if (i = Object.keys(e), o = i.length, o !== Object.keys(r).length)
      return !1;
    for (t = o; t-- !== 0; )
      if (!{}.hasOwnProperty.call(r, i[t]))
        return !1;
    for (t = o; t-- !== 0; ) {
      const n = i[t];
      if (!(n === "_owner" && e.$$typeof) && !Ir(e[n], r[n]))
        return !1;
    }
    return !0;
  }
  return e !== e && r !== r;
}
function oi(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function ct(e, r) {
  const o = oi(e);
  return Math.round(r * o) / o;
}
function dt(e) {
  const r = A.useRef(e);
  return Ar(() => {
    r.current = e;
  }), r;
}
function Dl(e) {
  e === void 0 && (e = {});
  const {
    placement: r = "bottom",
    strategy: o = "absolute",
    middleware: t = [],
    platform: i,
    elements: {
      reference: n,
      floating: s
    } = {},
    transform: l = !0,
    whileElementsMounted: a,
    open: c
  } = e, [p, d] = A.useState({
    x: 0,
    y: 0,
    strategy: o,
    placement: r,
    middlewareData: {},
    isPositioned: !1
  }), [h, u] = A.useState(t);
  Ir(h, t) || u(t);
  const [f, g] = A.useState(null), [m, k] = A.useState(null), v = A.useCallback((z) => {
    z != E.current && (E.current = z, g(z));
  }, [g]), b = A.useCallback((z) => {
    z !== P.current && (P.current = z, k(z));
  }, [k]), C = n || f, S = s || m, E = A.useRef(null), P = A.useRef(null), T = A.useRef(p), F = dt(a), U = dt(i), N = A.useCallback(() => {
    if (!E.current || !P.current)
      return;
    const z = {
      placement: r,
      strategy: o,
      middleware: h
    };
    U.current && (z.platform = U.current), Nl(E.current, P.current, z).then((Q) => {
      const ee = {
        ...Q,
        isPositioned: !0
      };
      W.current && !Ir(T.current, ee) && (T.current = ee, kn.flushSync(() => {
        d(ee);
      }));
    });
  }, [h, r, o, U]);
  Ar(() => {
    c === !1 && T.current.isPositioned && (T.current.isPositioned = !1, d((z) => ({
      ...z,
      isPositioned: !1
    })));
  }, [c]);
  const W = A.useRef(!1);
  Ar(() => (W.current = !0, () => {
    W.current = !1;
  }), []), Ar(() => {
    if (C && (E.current = C), S && (P.current = S), C && S) {
      if (F.current)
        return F.current(C, S, N);
      N();
    }
  }, [C, S, N, F]);
  const j = A.useMemo(() => ({
    reference: E,
    floating: P,
    setReference: v,
    setFloating: b
  }), [v, b]), L = A.useMemo(() => ({
    reference: C,
    floating: S
  }), [C, S]), I = A.useMemo(() => {
    const z = {
      position: o,
      left: 0,
      top: 0
    };
    if (!L.floating)
      return z;
    const Q = ct(L.floating, p.x), ee = ct(L.floating, p.y);
    return l ? {
      ...z,
      transform: "translate(" + Q + "px, " + ee + "px)",
      ...oi(L.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: o,
      left: Q,
      top: ee
    };
  }, [o, l, L.floating, p.x, p.y]);
  return A.useMemo(() => ({
    ...p,
    update: N,
    refs: j,
    elements: L,
    floatingStyles: I
  }), [p, N, j, L, I]);
}
const br = /* @__PURE__ */ q((e, r) => {
  const { children: o, ...t } = e, i = Xe.toArray(o), n = i.find(Il);
  if (n) {
    const s = n.props.children, l = i.map((a) => a === n ? Xe.count(s) > 1 ? Xe.only(null) : /* @__PURE__ */ Or(s) ? s.props.children : null : a);
    return /* @__PURE__ */ w(mo, M({}, t, {
      ref: r
    }), /* @__PURE__ */ Or(s) ? /* @__PURE__ */ yo(s, void 0, l) : null);
  }
  return /* @__PURE__ */ w(mo, M({}, t, {
    ref: r
  }), o);
});
br.displayName = "Slot";
const mo = /* @__PURE__ */ q((e, r) => {
  const { children: o, ...t } = e;
  return /* @__PURE__ */ Or(o) ? /* @__PURE__ */ yo(o, {
    ...Ll(t, o.props),
    ref: r ? Wt(r, o.ref) : o.ref
  }) : Xe.count(o) > 1 ? Xe.only(null) : null;
});
mo.displayName = "SlotClone";
const ql = ({ children: e }) => /* @__PURE__ */ w(Co, null, e);
function Il(e) {
  return /* @__PURE__ */ Or(e) && e.type === ql;
}
function Ll(e, r) {
  const o = {
    ...r
  };
  for (const t in r) {
    const i = e[t], n = r[t];
    /^on[A-Z]/.test(t) ? i && n ? o[t] = (...l) => {
      n(...l), i(...l);
    } : i && (o[t] = i) : t === "style" ? o[t] = {
      ...i,
      ...n
    } : t === "className" && (o[t] = [
      i,
      n
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...o
  };
}
const Ml = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], _e = Ml.reduce((e, r) => {
  const o = /* @__PURE__ */ q((t, i) => {
    const { asChild: n, ...s } = t, l = n ? br : r;
    return ie(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ w(l, M({}, s, {
      ref: i
    }));
  });
  return o.displayName = `Primitive.${r}`, {
    ...e,
    [r]: o
  };
}, {});
function Fl(e, r) {
  e && At(
    () => e.dispatchEvent(r)
  );
}
const Hl = /* @__PURE__ */ q((e, r) => {
  const { children: o, width: t = 10, height: i = 5, ...n } = e;
  return /* @__PURE__ */ w(_e.svg, M({}, n, {
    ref: r,
    width: t,
    height: i,
    viewBox: "0 0 30 10",
    preserveAspectRatio: "none"
  }), e.asChild ? o : /* @__PURE__ */ w("polygon", {
    points: "0,0 30,0 15,10"
  }));
}), Bl = Hl, be = globalThis != null && globalThis.document ? Tt : () => {
};
function Wl(e) {
  const [r, o] = G(void 0);
  return be(() => {
    if (e) {
      o({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const t = new ResizeObserver((i) => {
        if (!Array.isArray(i) || !i.length)
          return;
        const n = i[0];
        let s, l;
        if ("borderBoxSize" in n) {
          const a = n.borderBoxSize, c = Array.isArray(a) ? a[0] : a;
          s = c.inlineSize, l = c.blockSize;
        } else
          s = e.offsetWidth, l = e.offsetHeight;
        o({
          width: s,
          height: l
        });
      });
      return t.observe(e, {
        box: "border-box"
      }), () => t.unobserve(e);
    } else
      o(void 0);
  }, [
    e
  ]), r;
}
const ti = "Popper", [ii, Wr] = Fr(ti), [Vl, ni] = ii(ti), Xl = (e) => {
  const { __scopePopper: r, children: o } = e, [t, i] = G(null);
  return /* @__PURE__ */ w(Vl, {
    scope: r,
    anchor: t,
    onAnchorChange: i
  }, o);
}, Ul = "PopperAnchor", Kl = /* @__PURE__ */ q((e, r) => {
  const { __scopePopper: o, virtualRef: t, ...i } = e, n = ni(Ul, o), s = te(null), l = pe(r, s);
  return ie(() => {
    n.onAnchorChange((t == null ? void 0 : t.current) || s.current);
  }), t ? null : /* @__PURE__ */ w(_e.div, M({}, i, {
    ref: l
  }));
}), li = "PopperContent", [Yl, Gl] = ii(li), Zl = /* @__PURE__ */ q((e, r) => {
  var o, t, i, n, s, l, a, c;
  const { __scopePopper: p, side: d = "bottom", sideOffset: h = 0, align: u = "center", alignOffset: f = 0, arrowPadding: g = 0, collisionBoundary: m = [], collisionPadding: k = 0, sticky: v = "partial", hideWhenDetached: b = !1, avoidCollisions: C = !0, onPlaced: S, ...E } = e, P = ni(li, p), [T, F] = G(null), U = pe(
    r,
    (ue) => F(ue)
  ), [N, W] = G(null), j = Wl(N), L = (o = j == null ? void 0 : j.width) !== null && o !== void 0 ? o : 0, I = (t = j == null ? void 0 : j.height) !== null && t !== void 0 ? t : 0, z = d + (u !== "center" ? "-" + u : ""), Q = typeof k == "number" ? k : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...k
  }, ee = Array.isArray(m) ? m : [
    m
  ], ge = ee.length > 0, ne = {
    padding: Q,
    boundary: ee.filter(rs),
    // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
    altBoundary: ge
  }, { refs: ce, floatingStyles: me, placement: $e, isPositioned: xe, middlewareData: ye } = Dl({
    // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
    strategy: "fixed",
    placement: z,
    whileElementsMounted: Ol,
    elements: {
      reference: P.anchor
    },
    middleware: [
      Sl({
        mainAxis: h + I,
        alignmentAxis: f
      }),
      C && Pl({
        mainAxis: !0,
        crossAxis: !1,
        limiter: v === "partial" ? El() : void 0,
        ...ne
      }),
      C && wl({
        ...ne
      }),
      Tl({
        ...ne,
        apply: ({ elements: ue, rects: ze, availableWidth: Re, availableHeight: Me }) => {
          const { width: yr, height: Je } = ze.reference, Qe = ue.floating.style;
          Qe.setProperty("--radix-popper-available-width", `${Re}px`), Qe.setProperty("--radix-popper-available-height", `${Me}px`), Qe.setProperty("--radix-popper-anchor-width", `${yr}px`), Qe.setProperty("--radix-popper-anchor-height", `${Je}px`);
        }
      }),
      N && jl({
        element: N,
        padding: g
      }),
      os({
        arrowWidth: L,
        arrowHeight: I
      }),
      b && $l({
        strategy: "referenceHidden"
      })
    ]
  }), [Se, R] = si($e), X = qe(S);
  be(() => {
    xe && (X == null || X());
  }, [
    xe,
    X
  ]);
  const de = (i = ye.arrow) === null || i === void 0 ? void 0 : i.x, Z = (n = ye.arrow) === null || n === void 0 ? void 0 : n.y, J = ((s = ye.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0, [K, ve] = G();
  return be(() => {
    T && ve(window.getComputedStyle(T).zIndex);
  }, [
    T
  ]), /* @__PURE__ */ w("div", {
    ref: ce.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...me,
      transform: xe ? me.transform : "translate(0, -200%)",
      // keep off the page when measuring
      minWidth: "max-content",
      zIndex: K,
      ["--radix-popper-transform-origin"]: [
        (l = ye.transformOrigin) === null || l === void 0 ? void 0 : l.x,
        (a = ye.transformOrigin) === null || a === void 0 ? void 0 : a.y
      ].join(" ")
    },
    dir: e.dir
  }, /* @__PURE__ */ w(Yl, {
    scope: p,
    placedSide: Se,
    onArrowChange: W,
    arrowX: de,
    arrowY: Z,
    shouldHideArrow: J
  }, /* @__PURE__ */ w(_e.div, M({
    "data-side": Se,
    "data-align": R
  }, E, {
    ref: U,
    style: {
      ...E.style,
      // if the PopperContent hasn't been placed yet (not all measurements done)
      // we prevent animations so that users's animation don't kick in too early referring wrong sides
      animation: xe ? void 0 : "none",
      // hide the content if using the hide middleware and should be hidden
      opacity: (c = ye.hide) !== null && c !== void 0 && c.referenceHidden ? 0 : void 0
    }
  }))));
}), Jl = "PopperArrow", Ql = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, es = /* @__PURE__ */ q(function(r, o) {
  const { __scopePopper: t, ...i } = r, n = Gl(Jl, t), s = Ql[n.placedSide];
  return (
    // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
    // doesn't report size as we'd expect on SVG elements.
    // it reports their bounding box which is effectively the largest path inside the SVG.
    /* @__PURE__ */ w("span", {
      ref: n.onArrowChange,
      style: {
        position: "absolute",
        left: n.arrowX,
        top: n.arrowY,
        [s]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0"
        }[n.placedSide],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)"
        }[n.placedSide],
        visibility: n.shouldHideArrow ? "hidden" : void 0
      }
    }, /* @__PURE__ */ w(Bl, M({}, i, {
      ref: o,
      style: {
        ...i.style,
        // ensures the element can be measured correctly (mostly for if SVG)
        display: "block"
      }
    })))
  );
});
function rs(e) {
  return e !== null;
}
const os = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(r) {
    var o, t, i, n, s;
    const { placement: l, rects: a, middlewareData: c } = r, d = ((o = c.arrow) === null || o === void 0 ? void 0 : o.centerOffset) !== 0, h = d ? 0 : e.arrowWidth, u = d ? 0 : e.arrowHeight, [f, g] = si(l), m = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[g], k = ((t = (i = c.arrow) === null || i === void 0 ? void 0 : i.x) !== null && t !== void 0 ? t : 0) + h / 2, v = ((n = (s = c.arrow) === null || s === void 0 ? void 0 : s.y) !== null && n !== void 0 ? n : 0) + u / 2;
    let b = "", C = "";
    return f === "bottom" ? (b = d ? m : `${k}px`, C = `${-u}px`) : f === "top" ? (b = d ? m : `${k}px`, C = `${a.floating.height + u}px`) : f === "right" ? (b = `${-u}px`, C = d ? m : `${v}px`) : f === "left" && (b = `${a.floating.width + u}px`, C = d ? m : `${v}px`), {
      data: {
        x: b,
        y: C
      }
    };
  }
});
function si(e) {
  const [r, o = "center"] = e.split("-");
  return [
    r,
    o
  ];
}
const ai = Xl, _i = Kl, ci = Zl, ts = es, di = /* @__PURE__ */ q((e, r) => {
  var o;
  const { container: t = globalThis == null || (o = globalThis.document) === null || o === void 0 ? void 0 : o.body, ...i } = e;
  return t ? /* @__PURE__ */ bn.createPortal(/* @__PURE__ */ w(_e.div, M({}, i, {
    ref: r
  })), t) : null;
});
function is(e, r) {
  return vn((o, t) => {
    const i = r[o][t];
    return i ?? o;
  }, e);
}
const Eo = (e) => {
  const { present: r, children: o } = e, t = ns(r), i = typeof o == "function" ? o({
    present: t.isPresent
  }) : Xe.only(o), n = pe(t.ref, i.ref);
  return typeof o == "function" || t.isPresent ? /* @__PURE__ */ yo(i, {
    ref: n
  }) : null;
};
Eo.displayName = "Presence";
function ns(e) {
  const [r, o] = G(), t = te({}), i = te(e), n = te("none"), s = e ? "mounted" : "unmounted", [l, a] = is(s, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return ie(() => {
    const c = wr(t.current);
    n.current = l === "mounted" ? c : "none";
  }, [
    l
  ]), be(() => {
    const c = t.current, p = i.current;
    if (p !== e) {
      const h = n.current, u = wr(c);
      e ? a("MOUNT") : u === "none" || (c == null ? void 0 : c.display) === "none" ? a("UNMOUNT") : a(p && h !== u ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
    }
  }, [
    e,
    a
  ]), be(() => {
    if (r) {
      const c = (d) => {
        const u = wr(t.current).includes(d.animationName);
        d.target === r && u && At(
          () => a("ANIMATION_END")
        );
      }, p = (d) => {
        d.target === r && (n.current = wr(t.current));
      };
      return r.addEventListener("animationstart", p), r.addEventListener("animationcancel", c), r.addEventListener("animationend", c), () => {
        r.removeEventListener("animationstart", p), r.removeEventListener("animationcancel", c), r.removeEventListener("animationend", c);
      };
    } else
      a("ANIMATION_END");
  }, [
    r,
    a
  ]), {
    isPresent: [
      "mounted",
      "unmountSuspended"
    ].includes(l),
    ref: ae((c) => {
      c && (t.current = getComputedStyle(c)), o(c);
    }, [])
  };
}
function wr(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function ls(e, r = globalThis == null ? void 0 : globalThis.document) {
  const o = qe(e);
  ie(() => {
    const t = (i) => {
      i.key === "Escape" && o(i);
    };
    return r.addEventListener("keydown", t), () => r.removeEventListener("keydown", t);
  }, [
    o,
    r
  ]);
}
const vo = "dismissableLayer.update", ss = "dismissableLayer.pointerDownOutside", as = "dismissableLayer.focusOutside";
let pt;
const _s = /* @__PURE__ */ mr({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), pi = /* @__PURE__ */ q((e, r) => {
  var o;
  const { disableOutsidePointerEvents: t = !1, onEscapeKeyDown: i, onPointerDownOutside: n, onFocusOutside: s, onInteractOutside: l, onDismiss: a, ...c } = e, p = Mr(_s), [d, h] = G(null), u = (o = d == null ? void 0 : d.ownerDocument) !== null && o !== void 0 ? o : globalThis == null ? void 0 : globalThis.document, [, f] = G({}), g = pe(
    r,
    (T) => h(T)
  ), m = Array.from(p.layers), [k] = [
    ...p.layersWithOutsidePointerEventsDisabled
  ].slice(-1), v = m.indexOf(k), b = d ? m.indexOf(d) : -1, C = p.layersWithOutsidePointerEventsDisabled.size > 0, S = b >= v, E = cs((T) => {
    const F = T.target, U = [
      ...p.branches
    ].some(
      (N) => N.contains(F)
    );
    !S || U || (n == null || n(T), l == null || l(T), T.defaultPrevented || a == null || a());
  }, u), P = ds((T) => {
    const F = T.target;
    [
      ...p.branches
    ].some(
      (N) => N.contains(F)
    ) || (s == null || s(T), l == null || l(T), T.defaultPrevented || a == null || a());
  }, u);
  return ls((T) => {
    b === p.layers.size - 1 && (i == null || i(T), !T.defaultPrevented && a && (T.preventDefault(), a()));
  }, u), ie(() => {
    if (d)
      return t && (p.layersWithOutsidePointerEventsDisabled.size === 0 && (pt = u.body.style.pointerEvents, u.body.style.pointerEvents = "none"), p.layersWithOutsidePointerEventsDisabled.add(d)), p.layers.add(d), gt(), () => {
        t && p.layersWithOutsidePointerEventsDisabled.size === 1 && (u.body.style.pointerEvents = pt);
      };
  }, [
    d,
    u,
    t,
    p
  ]), ie(() => () => {
    d && (p.layers.delete(d), p.layersWithOutsidePointerEventsDisabled.delete(d), gt());
  }, [
    d,
    p
  ]), ie(() => {
    const T = () => f({});
    return document.addEventListener(vo, T), () => document.removeEventListener(vo, T);
  }, []), /* @__PURE__ */ w(_e.div, M({}, c, {
    ref: g,
    style: {
      pointerEvents: C ? S ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: oe(e.onFocusCapture, P.onFocusCapture),
    onBlurCapture: oe(e.onBlurCapture, P.onBlurCapture),
    onPointerDownCapture: oe(e.onPointerDownCapture, E.onPointerDownCapture)
  }));
});
function cs(e, r = globalThis == null ? void 0 : globalThis.document) {
  const o = qe(e), t = te(!1), i = te(() => {
  });
  return ie(() => {
    const n = (l) => {
      if (l.target && !t.current) {
        let c = function() {
          gi(ss, o, a, {
            discrete: !0
          });
        };
        const a = {
          originalEvent: l
        };
        l.pointerType === "touch" ? (r.removeEventListener("click", i.current), i.current = c, r.addEventListener("click", i.current, {
          once: !0
        })) : c();
      }
      t.current = !1;
    }, s = window.setTimeout(() => {
      r.addEventListener("pointerdown", n);
    }, 0);
    return () => {
      window.clearTimeout(s), r.removeEventListener("pointerdown", n), r.removeEventListener("click", i.current);
    };
  }, [
    r,
    o
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => t.current = !0
  };
}
function ds(e, r = globalThis == null ? void 0 : globalThis.document) {
  const o = qe(e), t = te(!1);
  return ie(() => {
    const i = (n) => {
      n.target && !t.current && gi(as, o, {
        originalEvent: n
      }, {
        discrete: !1
      });
    };
    return r.addEventListener("focusin", i), () => r.removeEventListener("focusin", i);
  }, [
    r,
    o
  ]), {
    onFocusCapture: () => t.current = !0,
    onBlurCapture: () => t.current = !1
  };
}
function gt() {
  const e = new CustomEvent(vo);
  document.dispatchEvent(e);
}
function gi(e, r, o, { discrete: t }) {
  const i = o.originalEvent.target, n = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: o
  });
  r && i.addEventListener(e, r, {
    once: !0
  }), t ? Fl(i, n) : i.dispatchEvent(n);
}
let io;
const ui = "HoverCard", [fi, Mc] = Fr(ui, [
  Wr
]), Vr = Wr(), [ps, Xr] = fi(ui), gs = (e) => {
  const { __scopeHoverCard: r, children: o, open: t, defaultOpen: i, onOpenChange: n, openDelay: s = 700, closeDelay: l = 300 } = e, a = Vr(r), c = te(0), p = te(0), d = te(!1), h = te(!1), [u = !1, f] = go({
    prop: t,
    defaultProp: i,
    onChange: n
  }), g = ae(() => {
    clearTimeout(p.current), c.current = window.setTimeout(
      () => f(!0),
      s
    );
  }, [
    s,
    f
  ]), m = ae(() => {
    clearTimeout(c.current), !d.current && !h.current && (p.current = window.setTimeout(
      () => f(!1),
      l
    ));
  }, [
    l,
    f
  ]), k = ae(
    () => f(!1),
    [
      f
    ]
  );
  return ie(() => () => {
    clearTimeout(c.current), clearTimeout(p.current);
  }, []), /* @__PURE__ */ w(ps, {
    scope: r,
    open: u,
    onOpenChange: f,
    onOpen: g,
    onClose: m,
    onDismiss: k,
    hasSelectionRef: d,
    isPointerDownOnContentRef: h
  }, /* @__PURE__ */ w(ai, a, o));
}, us = "HoverCardTrigger", fs = /* @__PURE__ */ q((e, r) => {
  const { __scopeHoverCard: o, ...t } = e, i = Xr(us, o), n = Vr(o);
  return /* @__PURE__ */ w(_i, M({
    asChild: !0
  }, n), /* @__PURE__ */ w(_e.a, M({
    "data-state": i.open ? "open" : "closed"
  }, t, {
    ref: r,
    onPointerEnter: oe(e.onPointerEnter, Lr(i.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lr(i.onClose)),
    onFocus: oe(e.onFocus, i.onOpen),
    onBlur: oe(e.onBlur, i.onClose),
    onTouchStart: oe(
      e.onTouchStart,
      (s) => s.preventDefault()
    )
  })));
}), hi = "HoverCardPortal", [hs, ms] = fi(hi, {
  forceMount: void 0
}), vs = (e) => {
  const { __scopeHoverCard: r, forceMount: o, children: t, container: i } = e, n = Xr(hi, r);
  return /* @__PURE__ */ w(hs, {
    scope: r,
    forceMount: o
  }, /* @__PURE__ */ w(Eo, {
    present: o || n.open
  }, /* @__PURE__ */ w(di, {
    asChild: !0,
    container: i
  }, t)));
}, ko = "HoverCardContent", ks = /* @__PURE__ */ q((e, r) => {
  const o = ms(ko, e.__scopeHoverCard), { forceMount: t = o.forceMount, ...i } = e, n = Xr(ko, e.__scopeHoverCard);
  return /* @__PURE__ */ w(Eo, {
    present: t || n.open
  }, /* @__PURE__ */ w(bs, M({
    "data-state": n.open ? "open" : "closed"
  }, i, {
    onPointerEnter: oe(e.onPointerEnter, Lr(n.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lr(n.onClose)),
    ref: r
  })));
}), bs = /* @__PURE__ */ q((e, r) => {
  const { __scopeHoverCard: o, onEscapeKeyDown: t, onPointerDownOutside: i, onFocusOutside: n, onInteractOutside: s, ...l } = e, a = Xr(ko, o), c = Vr(o), p = te(null), d = pe(r, p), [h, u] = G(!1);
  return ie(() => {
    if (h) {
      const f = document.body;
      return io = f.style.userSelect || f.style.webkitUserSelect, f.style.userSelect = "none", f.style.webkitUserSelect = "none", () => {
        f.style.userSelect = io, f.style.webkitUserSelect = io;
      };
    }
  }, [
    h
  ]), ie(() => {
    if (p.current) {
      const f = () => {
        u(!1), a.isPointerDownOnContentRef.current = !1, setTimeout(() => {
          var g;
          ((g = document.getSelection()) === null || g === void 0 ? void 0 : g.toString()) !== "" && (a.hasSelectionRef.current = !0);
        });
      };
      return document.addEventListener("pointerup", f), () => {
        document.removeEventListener("pointerup", f), a.hasSelectionRef.current = !1, a.isPointerDownOnContentRef.current = !1;
      };
    }
  }, [
    a.isPointerDownOnContentRef,
    a.hasSelectionRef
  ]), ie(() => {
    p.current && ys(p.current).forEach(
      (g) => g.setAttribute("tabindex", "-1")
    );
  }), /* @__PURE__ */ w(pi, {
    asChild: !0,
    disableOutsidePointerEvents: !1,
    onInteractOutside: s,
    onEscapeKeyDown: t,
    onPointerDownOutside: i,
    onFocusOutside: oe(n, (f) => {
      f.preventDefault();
    }),
    onDismiss: a.onDismiss
  }, /* @__PURE__ */ w(ci, M({}, c, l, {
    onPointerDown: oe(l.onPointerDown, (f) => {
      f.currentTarget.contains(f.target) && u(!0), a.hasSelectionRef.current = !1, a.isPointerDownOnContentRef.current = !0;
    }),
    ref: d,
    style: {
      ...l.style,
      userSelect: h ? "text" : void 0,
      // Safari requires prefix
      WebkitUserSelect: h ? "text" : void 0,
      "--radix-hover-card-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-hover-card-content-available-width": "var(--radix-popper-available-width)",
      "--radix-hover-card-content-available-height": "var(--radix-popper-available-height)",
      "--radix-hover-card-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-hover-card-trigger-height": "var(--radix-popper-anchor-height)"
    }
  })));
}), xs = /* @__PURE__ */ q((e, r) => {
  const { __scopeHoverCard: o, ...t } = e, i = Vr(o);
  return /* @__PURE__ */ w(ts, M({}, i, t, {
    ref: r
  }));
});
function Lr(e) {
  return (r) => r.pointerType === "touch" ? void 0 : e();
}
function ys(e) {
  const r = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (t) => t.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
  });
  for (; o.nextNode(); )
    r.push(o.currentNode);
  return r;
}
const Cs = gs, ws = fs, $s = vs, Ss = ks, Ps = xs;
var Es = "hover.card_hoverCardContent__1v4ltqn1", Ts = "hover.card_hoverCardTrigger__1v4ltqn0";
const mi = Ps, As = Cs, To = $s, vi = H.forwardRef((e, r) => /* @__PURE__ */ y.jsx(
  ws,
  {
    ref: r,
    type: "button",
    className: D(Ts, e.className),
    ...e,
    children: e.children
  }
)), ki = H.forwardRef((e, r) => /* @__PURE__ */ y.jsx(To, { children: /* @__PURE__ */ y.jsx(
  Ss,
  {
    ref: r,
    className: D(Es, e.className),
    ...e,
    children: e.children
  }
) })), xr = (e) => /* @__PURE__ */ y.jsx(As, { ...e });
xr.Trigger = vi;
xr.Content = ki;
xr.Arrow = mi;
xr.Portal = To;
xr.displayName = "HoverCard";
vi.displayName = "HoverCardTrigger";
ki.displayName = "HoverCardContent";
mi.displayName = "HoverCardArrow";
To.displayName = "HoverCardPortal";
var zs = fe({ defaultClassName: "inline_INLINE_BASE__44zw2k3", variantClassNames: { font: { inherit: "inline_font_inherit__44zw2k0", system: "inline_font_system__44zw2k1", mono: "inline_font_mono__44zw2k2" }, hover: { true: "sprinkles_transitionProperty_all_small__i77g9oas sprinkles_transitionDuration_150ms_small__i77g9obg sprinkles_transitionTimingFunction_linear_small__i77g9ob0", false: "inline_inline_hover_false__44zw2ka" }, strong: { true: "sprinkles_fontWeight_bold_small__i77g9oa4", false: "inline_inline_strong_false__44zw2kc" } }, defaultVariants: { font: "inherit", hover: !1, strong: !1 }, compoundVariants: [] });
const Rs = H.forwardRef(
  ({ children: e, className: r, font: o = "inherit", hover: t = !1, strong: i = !1, ...n }, s) => /* @__PURE__ */ y.jsx(
    "span",
    {
      ref: s,
      className: D(r, zs({ font: o, hover: t, strong: i })),
      ...n,
      children: e
    }
  )
);
Rs.displayName = "SpanInline";
var Os = fe({ defaultClassName: "input_input_base__1l37a3c6", variantClassNames: { size: { small: "input_size_small__1l37a3c2", medium: "input_size_medium__1l37a3c3" }, variant: { slate: "input_variant_slate__1l37a3c4", hyper: "input_variant_hyper__1l37a3c5" } }, defaultVariants: { size: "medium", variant: "slate" }, compoundVariants: [] }), Ns = "input_input_label__1l37a3c1", js = "input_input_root__1l37a3c0";
const bi = q(
  ({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsx(
    "div",
    {
      ref: t,
      className: D(r, js),
      ...o,
      children: e
    }
  )
), xi = q(
  ({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsx(
    "label",
    {
      ref: t,
      className: D(r, Ns),
      ...o,
      children: /* @__PURE__ */ y.jsx("span", { children: e })
    }
  )
), Ds = q(
  ({ className: e, size: r = "medium", variant: o = "slate", ...t }, i) => /* @__PURE__ */ y.jsx(
    "input",
    {
      ref: i,
      className: D(e, Os({ size: r, variant: o })),
      ...t
    }
  )
), Ao = (e) => /* @__PURE__ */ y.jsx(Ds, { ...e });
Ao.Flex = bi;
Ao.Label = xi;
Ao.displayName = "Input";
bi.displayName = "Input.Flex";
xi.displayName = "Input.Label";
var qs = "menubar_menubar_content__d9r7gl3", Is = "menubar_menubar_item__d9r7gl2", Ls = "menubar_menubar_root__d9r7gl0", Ms = "menubar_menubar_trigger__d9r7gl1", Fs = "menubar_submenu_content__d9r7gl5", Hs = "menubar_submenu_trigger__d9r7gl4";
const yi = Ie.Menu, Ci = Ie.Sub, wi = Ie.Portal, Bs = H.forwardRef(({ children: e, className: r, loop: o = !0, ...t }, i) => /* @__PURE__ */ y.jsx(
  Ie.Root,
  {
    ...t,
    ref: i,
    className: D(r, Ls),
    loop: o,
    children: e
  }
)), $i = H.forwardRef(({ children: e, className: r, side: o = "bottom", sideOffset: t = 10, ...i }, n) => /* @__PURE__ */ y.jsx(
  Ie.Content,
  {
    ...i,
    ref: n,
    className: D(r, qs),
    side: o,
    sideOffset: t,
    children: e
  }
)), Si = H.forwardRef(({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsx(
  Ie.Item,
  {
    ...o,
    ref: t,
    className: D(r, Is),
    children: e
  }
)), Pi = H.forwardRef(({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsx(
  Ie.Trigger,
  {
    ...o,
    ref: t,
    className: D(r, Ms),
    children: e
  }
)), Ei = H.forwardRef(({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsx(
  Ie.SubTrigger,
  {
    ...o,
    ref: t,
    className: D(r, Hs),
    children: e
  }
)), Ti = H.forwardRef(({ children: e, className: r, sideOffset: o = 10, ...t }, i) => /* @__PURE__ */ y.jsx(
  Ie.SubContent,
  {
    ...t,
    ref: i,
    className: D(r, Fs),
    sideOffset: o,
    children: e
  }
)), Le = (e) => /* @__PURE__ */ y.jsx(Bs, { ...e });
Le.displayName = "Menubar";
Le.Menu = yi;
Le.Trigger = Pi;
Le.Content = $i;
Le.Item = Si;
Le.SubMenu = Ci;
Le.SubTrigger = Ei;
Le.SubContent = Ti;
Le.Portal = wi;
yi.displayName = "Menubar-Menu";
Pi.displayName = "Menubar-Trigger";
$i.displayName = "Menubar-Content";
Si.displayName = "Menubar-Item";
Ci.displayName = "Menubar-SubMenu";
Ei.displayName = "Menubar-SubTrigger";
Ti.displayName = "Menubar-SubContent";
wi.displayName = "Menubar-Portal";
var Ws = fe({ defaultClassName: "para_PARAGRAPH_BASE__qohxgz2s", variantClassNames: { size: { xs: "para_size_xs__qohxgz0", sm: "para_size_sm__qohxgz1", md: "para_size_md__qohxgz2", lg: "para_size_lg__qohxgz3", xl: "para_size_xl__qohxgz4" }, color: { transparent: "para_color_transparent__qohxgz5", current: "para_color_current__qohxgz6", white: "para_color_white__qohxgz7", black: "para_color_black__qohxgz8", gray100: "para_color_gray100__qohxgz9", gray200: "para_color_gray200__qohxgza", gray300: "para_color_gray300__qohxgzb", pale100: "para_color_pale100__qohxgzc", pale200: "para_color_pale200__qohxgzd", pale300: "para_color_pale300__qohxgze", pale400: "para_color_pale400__qohxgzf", pale500: "para_color_pale500__qohxgzg", hyper0: "para_color_hyper0__qohxgzh", hyper1: "para_color_hyper1__qohxgzi", hyper2: "para_color_hyper2__qohxgzj", hyper3: "para_color_hyper3__qohxgzk", hyper4: "para_color_hyper4__qohxgzl", hyper5: "para_color_hyper5__qohxgzm", hyper6: "para_color_hyper6__qohxgzn", hyper7: "para_color_hyper7__qohxgzo", hyper8: "para_color_hyper8__qohxgzp", hyper9: "para_color_hyper9__qohxgzq", hyper10: "para_color_hyper10__qohxgzr", hyper11: "para_color_hyper11__qohxgzs", hyper12: "para_color_hyper12__qohxgzt", hyper13: "para_color_hyper13__qohxgzu", lemon0: "para_color_lemon0__qohxgzv", lemon1: "para_color_lemon1__qohxgzw", lemon2: "para_color_lemon2__qohxgzx", lemon3: "para_color_lemon3__qohxgzy", lemon4: "para_color_lemon4__qohxgzz", lemon5: "para_color_lemon5__qohxgz10", lemon6: "para_color_lemon6__qohxgz11", lemon7: "para_color_lemon7__qohxgz12", lemon8: "para_color_lemon8__qohxgz13", lemon9: "para_color_lemon9__qohxgz14", lemon10: "para_color_lemon10__qohxgz15", lemon11: "para_color_lemon11__qohxgz16", lemon12: "para_color_lemon12__qohxgz17", lemon13: "para_color_lemon13__qohxgz18", slate1: "para_color_slate1__qohxgz19", slate2: "para_color_slate2__qohxgz1a", slate3: "para_color_slate3__qohxgz1b", slate4: "para_color_slate4__qohxgz1c", slate5: "para_color_slate5__qohxgz1d", slate6: "para_color_slate6__qohxgz1e", slate7: "para_color_slate7__qohxgz1f", slate8: "para_color_slate8__qohxgz1g", slate9: "para_color_slate9__qohxgz1h", slate10: "para_color_slate10__qohxgz1i", slate11: "para_color_slate11__qohxgz1j", slate12: "para_color_slate12__qohxgz1k", slate13: "para_color_slate13__qohxgz1l", sapphire0: "para_color_sapphire0__qohxgz1m", sapphire1: "para_color_sapphire1__qohxgz1n", sapphire2: "para_color_sapphire2__qohxgz1o", sapphire3: "para_color_sapphire3__qohxgz1p", sapphire4: "para_color_sapphire4__qohxgz1q", sapphire5: "para_color_sapphire5__qohxgz1r", sapphire6: "para_color_sapphire6__qohxgz1s", sapphire7: "para_color_sapphire7__qohxgz1t", sapphire8: "para_color_sapphire8__qohxgz1u", sapphire9: "para_color_sapphire9__qohxgz1v", sapphire10: "para_color_sapphire10__qohxgz1w", sapphire11: "para_color_sapphire11__qohxgz1x", sapphire12: "para_color_sapphire12__qohxgz1y", sapphire13: "para_color_sapphire13__qohxgz1z", volt0: "para_color_volt0__qohxgz20", volt1: "para_color_volt1__qohxgz21", volt2: "para_color_volt2__qohxgz22", volt3: "para_color_volt3__qohxgz23", volt4: "para_color_volt4__qohxgz24", volt5: "para_color_volt5__qohxgz25", volt6: "para_color_volt6__qohxgz26", volt7: "para_color_volt7__qohxgz27", volt8: "para_color_volt8__qohxgz28", volt9: "para_color_volt9__qohxgz29", volt10: "para_color_volt10__qohxgz2a", volt11: "para_color_volt11__qohxgz2b", volt12: "para_color_volt12__qohxgz2c", volt13: "para_color_volt13__qohxgz2d" }, weight: { superlite: "para_weight_superlite__qohxgz2e", lite: "para_weight_lite__qohxgz2f", normal: "para_weight_normal__qohxgz2g", medium: "para_weight_medium__qohxgz2h", semibold: "para_weight_semibold__qohxgz2i", bold: "para_weight_bold__qohxgz2j", heavy: "para_weight_heavy__qohxgz2k", black: "para_weight_black__qohxgz2l" }, align: { left: "para_align_left__qohxgz2m", center: "para_align_center__qohxgz2n", right: "para_align_right__qohxgz2o" }, font: { system: "para_font_system__qohxgz2p", inter: "para_font_inter__qohxgz2q", mono: "para_font_mono__qohxgz2r" } }, defaultVariants: { size: "sm", color: "slate12", weight: "normal", align: "left", font: "system" }, compoundVariants: [] });
const Vs = q(
  ({ children: e, className: r, size: o, color: t, weight: i, align: n, font: s, ...l }, a) => /* @__PURE__ */ y.jsx(
    "p",
    {
      ref: a,
      className: D(r, Ws({ size: o, color: t, weight: i, align: n, font: s })),
      ...l,
      children: e
    }
  )
);
Vs.displayName = "Paragraph";
var Xs = fe({ defaultClassName: "passlink_base__1g4z5m4c", variantClassNames: { size: { xs: "passlink_size_xs__1g4z5m40", sm: "passlink_size_sm__1g4z5m41", md: "passlink_size_md__1g4z5m42", lg: "passlink_size_lg__1g4z5m43", xl: "passlink_size_xl__1g4z5m44", xxl: "passlink_size_xxl__1g4z5m45" }, variant: { inherit: "passlink_variant_inherit__1g4z5m46", primary: "passlink_variant_primary__1g4z5m47", secondary: "passlink_variant_secondary__1g4z5m48" }, font: { inherit: "passlink_font_inherit__1g4z5m49", system: "passlink_font_system__1g4z5m4a", mono: "passlink_font_mono__1g4z5m4b" } }, defaultVariants: { size: "sm", variant: "primary" }, compoundVariants: [] });
const Us = q(
  ({
    children: e,
    className: r,
    href: o,
    variant: t,
    target: i = "_self",
    size: n = "sm",
    font: s = "inherit",
    ...l
  }, a) => /* @__PURE__ */ y.jsx(
    "a",
    {
      ref: a,
      href: o,
      target: i,
      className: D(Xs({ size: n, variant: t }), r),
      ...l,
      children: e
    }
  )
);
Us.displayName = "PassLink";
var Ks = "popover_popoverContent__1k7gvp51";
const Ys = Be.Portal, Gs = Be.Root, Zs = Be.Trigger, Js = H.forwardRef(
  ({ className: e, align: r = "center", sideOffset: o = 6, side: t = "bottom", ...i }, n) => /* @__PURE__ */ y.jsx(Be.Portal, { children: /* @__PURE__ */ y.jsx(
    Be.Content,
    {
      ref: n,
      align: r,
      sideOffset: o,
      side: t,
      className: D(Ks, e),
      ...i
    }
  ) })
), we = (e) => /* @__PURE__ */ y.jsx(Gs, { ...e });
we.Trigger = Zs;
we.Content = Js;
we.Portal = Ys;
we.Anchor = Be.Anchor;
we.Arrow = Be.Arrow;
we.Close = Be.Close;
we.displayName = "Popover";
we.Trigger.displayName = "PopoverTrigger";
we.Content.displayName = "PopoverContent";
we.Portal.displayName = "PopoverPortal";
we.Anchor.displayName = "PopoverAnchor";
we.Arrow.displayName = "PopoverArrow";
we.Close.displayName = "PopoverClose";
var Qs = fe({ defaultClassName: "section_SEC_ROOT__ti68jl4", variantClassNames: { size: { sm: "section_size_sm__ti68jl0", md: "section_size_md__ti68jl1", lg: "section_size_lg__ti68jl2", vw: "section_size_vw__ti68jl3" } }, defaultVariants: { size: "vw" }, compoundVariants: [] });
const ea = ({
  children: e,
  className: r,
  size: o = "vw",
  ...t
}) => /* @__PURE__ */ y.jsx(
  "div",
  {
    ...t,
    className: D(r, Qs({ size: o })),
    children: e
  }
);
ea.displayName = "Section";
function ut(e, [r, o]) {
  return Math.min(o, Math.max(r, e));
}
function ra(e) {
  const r = e + "CollectionProvider", [o, t] = Fr(r), [i, n] = o(r, {
    collectionRef: {
      current: null
    },
    itemMap: /* @__PURE__ */ new Map()
  }), s = (u) => {
    const { scope: f, children: g } = u, m = H.useRef(null), k = H.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ H.createElement(i, {
      scope: f,
      itemMap: k,
      collectionRef: m
    }, g);
  }, l = e + "CollectionSlot", a = /* @__PURE__ */ H.forwardRef((u, f) => {
    const { scope: g, children: m } = u, k = n(l, g), v = pe(f, k.collectionRef);
    return /* @__PURE__ */ H.createElement(br, {
      ref: v
    }, m);
  }), c = e + "CollectionItemSlot", p = "data-radix-collection-item", d = /* @__PURE__ */ H.forwardRef((u, f) => {
    const { scope: g, children: m, ...k } = u, v = H.useRef(null), b = pe(f, v), C = n(c, g);
    return H.useEffect(() => (C.itemMap.set(v, {
      ref: v,
      ...k
    }), () => void C.itemMap.delete(v))), /* @__PURE__ */ H.createElement(br, {
      [p]: "",
      ref: b
    }, m);
  });
  function h(u) {
    const f = n(e + "CollectionConsumer", u);
    return H.useCallback(() => {
      const m = f.collectionRef.current;
      if (!m)
        return [];
      const k = Array.from(m.querySelectorAll(`[${p}]`));
      return Array.from(f.itemMap.values()).sort(
        (C, S) => k.indexOf(C.ref.current) - k.indexOf(S.ref.current)
      );
    }, [
      f.collectionRef,
      f.itemMap
    ]);
  }
  return [
    {
      Provider: s,
      Slot: a,
      ItemSlot: d
    },
    h,
    t
  ];
}
const oa = /* @__PURE__ */ mr(void 0);
function ta(e) {
  const r = Mr(oa);
  return e || r || "ltr";
}
let no = 0;
function ia() {
  ie(() => {
    var e, r;
    const o = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = o[0]) !== null && e !== void 0 ? e : ft()), document.body.insertAdjacentElement("beforeend", (r = o[1]) !== null && r !== void 0 ? r : ft()), no++, () => {
      no === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (t) => t.remove()
      ), no--;
    };
  }, []);
}
function ft() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
const lo = "focusScope.autoFocusOnMount", so = "focusScope.autoFocusOnUnmount", ht = {
  bubbles: !1,
  cancelable: !0
}, na = /* @__PURE__ */ q((e, r) => {
  const { loop: o = !1, trapped: t = !1, onMountAutoFocus: i, onUnmountAutoFocus: n, ...s } = e, [l, a] = G(null), c = qe(i), p = qe(n), d = te(null), h = pe(
    r,
    (g) => a(g)
  ), u = te({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  ie(() => {
    if (t) {
      let g = function(b) {
        if (u.paused || !l)
          return;
        const C = b.target;
        l.contains(C) ? d.current = C : Fe(d.current, {
          select: !0
        });
      }, m = function(b) {
        if (u.paused || !l)
          return;
        const C = b.relatedTarget;
        C !== null && (l.contains(C) || Fe(d.current, {
          select: !0
        }));
      }, k = function(b) {
        const C = document.activeElement;
        for (const S of b)
          S.removedNodes.length > 0 && (l != null && l.contains(C) || Fe(l));
      };
      document.addEventListener("focusin", g), document.addEventListener("focusout", m);
      const v = new MutationObserver(k);
      return l && v.observe(l, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", g), document.removeEventListener("focusout", m), v.disconnect();
      };
    }
  }, [
    t,
    l,
    u.paused
  ]), ie(() => {
    if (l) {
      vt.add(u);
      const g = document.activeElement;
      if (!l.contains(g)) {
        const k = new CustomEvent(lo, ht);
        l.addEventListener(lo, c), l.dispatchEvent(k), k.defaultPrevented || (la(da(Ai(l)), {
          select: !0
        }), document.activeElement === g && Fe(l));
      }
      return () => {
        l.removeEventListener(lo, c), setTimeout(() => {
          const k = new CustomEvent(so, ht);
          l.addEventListener(so, p), l.dispatchEvent(k), k.defaultPrevented || Fe(g ?? document.body, {
            select: !0
          }), l.removeEventListener(so, p), vt.remove(u);
        }, 0);
      };
    }
  }, [
    l,
    c,
    p,
    u
  ]);
  const f = ae((g) => {
    if (!o && !t || u.paused)
      return;
    const m = g.key === "Tab" && !g.altKey && !g.ctrlKey && !g.metaKey, k = document.activeElement;
    if (m && k) {
      const v = g.currentTarget, [b, C] = sa(v);
      b && C ? !g.shiftKey && k === C ? (g.preventDefault(), o && Fe(b, {
        select: !0
      })) : g.shiftKey && k === b && (g.preventDefault(), o && Fe(C, {
        select: !0
      })) : k === v && g.preventDefault();
    }
  }, [
    o,
    t,
    u.paused
  ]);
  return /* @__PURE__ */ w(_e.div, M({
    tabIndex: -1
  }, s, {
    ref: h,
    onKeyDown: f
  }));
});
function la(e, { select: r = !1 } = {}) {
  const o = document.activeElement;
  for (const t of e)
    if (Fe(t, {
      select: r
    }), document.activeElement !== o)
      return;
}
function sa(e) {
  const r = Ai(e), o = mt(r, e), t = mt(r.reverse(), e);
  return [
    o,
    t
  ];
}
function Ai(e) {
  const r = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (t) => {
      const i = t.tagName === "INPUT" && t.type === "hidden";
      return t.disabled || t.hidden || i ? NodeFilter.FILTER_SKIP : t.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; o.nextNode(); )
    r.push(o.currentNode);
  return r;
}
function mt(e, r) {
  for (const o of e)
    if (!aa(o, {
      upTo: r
    }))
      return o;
}
function aa(e, { upTo: r }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (r !== void 0 && e === r)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function _a(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Fe(e, { select: r = !1 } = {}) {
  if (e && e.focus) {
    const o = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== o && _a(e) && r && e.select();
  }
}
const vt = ca();
function ca() {
  let e = [];
  return {
    add(r) {
      const o = e[0];
      r !== o && (o == null || o.pause()), e = kt(e, r), e.unshift(r);
    },
    remove(r) {
      var o;
      e = kt(e, r), (o = e[0]) === null || o === void 0 || o.resume();
    }
  };
}
function kt(e, r) {
  const o = [
    ...e
  ], t = o.indexOf(r);
  return t !== -1 && o.splice(t, 1), o;
}
function da(e) {
  return e.filter(
    (r) => r.tagName !== "A"
  );
}
const pa = A["useId".toString()] || (() => {
});
let ga = 0;
function zo(e) {
  const [r, o] = A.useState(pa());
  return be(() => {
    e || o(
      (t) => t ?? String(ga++)
    );
  }, [
    e
  ]), e || (r ? `radix-${r}` : "");
}
function ua(e) {
  const r = te({
    value: e,
    previous: e
  });
  return lr(() => (r.current.value !== e && (r.current.previous = r.current.value, r.current.value = e), r.current.previous), [
    e
  ]);
}
const fa = /* @__PURE__ */ q((e, r) => /* @__PURE__ */ w(_e.span, M({}, e, {
  ref: r,
  style: {
    // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
})));
var ha = function(e) {
  if (typeof document > "u")
    return null;
  var r = Array.isArray(e) ? e[0] : e;
  return r.ownerDocument.body;
}, or = /* @__PURE__ */ new WeakMap(), $r = /* @__PURE__ */ new WeakMap(), Sr = {}, ao = 0, zi = function(e) {
  return e && (e.host || zi(e.parentNode));
}, ma = function(e, r) {
  return r.map(function(o) {
    if (e.contains(o))
      return o;
    var t = zi(o);
    return t && e.contains(t) ? t : (console.error("aria-hidden", o, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(o) {
    return !!o;
  });
}, va = function(e, r, o, t) {
  var i = ma(r, Array.isArray(e) ? e : [e]);
  Sr[o] || (Sr[o] = /* @__PURE__ */ new WeakMap());
  var n = Sr[o], s = [], l = /* @__PURE__ */ new Set(), a = new Set(i), c = function(d) {
    !d || l.has(d) || (l.add(d), c(d.parentNode));
  };
  i.forEach(c);
  var p = function(d) {
    !d || a.has(d) || Array.prototype.forEach.call(d.children, function(h) {
      if (l.has(h))
        p(h);
      else {
        var u = h.getAttribute(t), f = u !== null && u !== "false", g = (or.get(h) || 0) + 1, m = (n.get(h) || 0) + 1;
        or.set(h, g), n.set(h, m), s.push(h), g === 1 && f && $r.set(h, !0), m === 1 && h.setAttribute(o, "true"), f || h.setAttribute(t, "true");
      }
    });
  };
  return p(r), l.clear(), ao++, function() {
    s.forEach(function(d) {
      var h = or.get(d) - 1, u = n.get(d) - 1;
      or.set(d, h), n.set(d, u), h || ($r.has(d) || d.removeAttribute(t), $r.delete(d)), u || d.removeAttribute(o);
    }), ao--, ao || (or = /* @__PURE__ */ new WeakMap(), or = /* @__PURE__ */ new WeakMap(), $r = /* @__PURE__ */ new WeakMap(), Sr = {});
  };
}, ka = function(e, r, o) {
  o === void 0 && (o = "data-aria-hidden");
  var t = Array.from(Array.isArray(e) ? e : [e]), i = r || ha(e);
  return i ? (t.push.apply(t, Array.from(i.querySelectorAll("[aria-live]"))), va(t, i, o, "aria-hidden")) : function() {
    return null;
  };
}, Oe = function() {
  return Oe = Object.assign || function(r) {
    for (var o, t = 1, i = arguments.length; t < i; t++) {
      o = arguments[t];
      for (var n in o)
        Object.prototype.hasOwnProperty.call(o, n) && (r[n] = o[n]);
    }
    return r;
  }, Oe.apply(this, arguments);
};
function Ri(e, r) {
  var o = {};
  for (var t in e)
    Object.prototype.hasOwnProperty.call(e, t) && r.indexOf(t) < 0 && (o[t] = e[t]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var i = 0, t = Object.getOwnPropertySymbols(e); i < t.length; i++)
      r.indexOf(t[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, t[i]) && (o[t[i]] = e[t[i]]);
  return o;
}
function ba(e, r, o) {
  if (o || arguments.length === 2)
    for (var t = 0, i = r.length, n; t < i; t++)
      (n || !(t in r)) && (n || (n = Array.prototype.slice.call(r, 0, t)), n[t] = r[t]);
  return e.concat(n || Array.prototype.slice.call(r));
}
var zr = "right-scroll-bar-position", Rr = "width-before-scroll-bar", xa = "with-scroll-bars-hidden", ya = "--removed-body-scroll-bar-size";
function Ca(e, r) {
  return typeof e == "function" ? e(r) : e && (e.current = r), e;
}
function wa(e, r) {
  var o = G(function() {
    return {
      // value
      value: e,
      // last callback
      callback: r,
      // "memoized" public interface
      facade: {
        get current() {
          return o.value;
        },
        set current(t) {
          var i = o.value;
          i !== t && (o.value = t, o.callback(t, i));
        }
      }
    };
  })[0];
  return o.callback = r, o.facade;
}
function $a(e, r) {
  return wa(r || null, function(o) {
    return e.forEach(function(t) {
      return Ca(t, o);
    });
  });
}
function Sa(e) {
  return e;
}
function Pa(e, r) {
  r === void 0 && (r = Sa);
  var o = [], t = !1, i = {
    read: function() {
      if (t)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return o.length ? o[o.length - 1] : e;
    },
    useMedium: function(n) {
      var s = r(n, t);
      return o.push(s), function() {
        o = o.filter(function(l) {
          return l !== s;
        });
      };
    },
    assignSyncMedium: function(n) {
      for (t = !0; o.length; ) {
        var s = o;
        o = [], s.forEach(n);
      }
      o = {
        push: function(l) {
          return n(l);
        },
        filter: function() {
          return o;
        }
      };
    },
    assignMedium: function(n) {
      t = !0;
      var s = [];
      if (o.length) {
        var l = o;
        o = [], l.forEach(n), s = o;
      }
      var a = function() {
        var p = s;
        s = [], p.forEach(n);
      }, c = function() {
        return Promise.resolve().then(a);
      };
      c(), o = {
        push: function(p) {
          s.push(p), c();
        },
        filter: function(p) {
          return s = s.filter(p), o;
        }
      };
    }
  };
  return i;
}
function Ea(e) {
  e === void 0 && (e = {});
  var r = Pa(null);
  return r.options = Oe({ async: !0, ssr: !1 }, e), r;
}
var Oi = function(e) {
  var r = e.sideCar, o = Ri(e, ["sideCar"]);
  if (!r)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var t = r.read();
  if (!t)
    throw new Error("Sidecar medium not found");
  return A.createElement(t, Oe({}, o));
};
Oi.isSideCarExport = !0;
function Ta(e, r) {
  return e.useMedium(r), Oi;
}
var Ni = Ea(), _o = function() {
}, Ur = A.forwardRef(function(e, r) {
  var o = A.useRef(null), t = A.useState({
    onScrollCapture: _o,
    onWheelCapture: _o,
    onTouchMoveCapture: _o
  }), i = t[0], n = t[1], s = e.forwardProps, l = e.children, a = e.className, c = e.removeScrollBar, p = e.enabled, d = e.shards, h = e.sideCar, u = e.noIsolation, f = e.inert, g = e.allowPinchZoom, m = e.as, k = m === void 0 ? "div" : m, v = Ri(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), b = h, C = $a([o, r]), S = Oe(Oe({}, v), i);
  return A.createElement(
    A.Fragment,
    null,
    p && A.createElement(b, { sideCar: Ni, removeScrollBar: c, shards: d, noIsolation: u, inert: f, setCallbacks: n, allowPinchZoom: !!g, lockRef: o }),
    s ? A.cloneElement(A.Children.only(l), Oe(Oe({}, S), { ref: C })) : A.createElement(k, Oe({}, S, { className: a, ref: C }), l)
  );
});
Ur.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
Ur.classNames = {
  fullWidth: Rr,
  zeroRight: zr
};
var bt, Aa = function() {
  if (bt)
    return bt;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function za() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var r = Aa();
  return r && e.setAttribute("nonce", r), e;
}
function Ra(e, r) {
  e.styleSheet ? e.styleSheet.cssText = r : e.appendChild(document.createTextNode(r));
}
function Oa(e) {
  var r = document.head || document.getElementsByTagName("head")[0];
  r.appendChild(e);
}
var Na = function() {
  var e = 0, r = null;
  return {
    add: function(o) {
      e == 0 && (r = za()) && (Ra(r, o), Oa(r)), e++;
    },
    remove: function() {
      e--, !e && r && (r.parentNode && r.parentNode.removeChild(r), r = null);
    }
  };
}, ja = function() {
  var e = Na();
  return function(r, o) {
    A.useEffect(function() {
      return e.add(r), function() {
        e.remove();
      };
    }, [r && o]);
  };
}, ji = function() {
  var e = ja(), r = function(o) {
    var t = o.styles, i = o.dynamic;
    return e(t, i), null;
  };
  return r;
}, Da = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, co = function(e) {
  return parseInt(e || "", 10) || 0;
}, qa = function(e) {
  var r = window.getComputedStyle(document.body), o = r[e === "padding" ? "paddingLeft" : "marginLeft"], t = r[e === "padding" ? "paddingTop" : "marginTop"], i = r[e === "padding" ? "paddingRight" : "marginRight"];
  return [co(o), co(t), co(i)];
}, Ia = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return Da;
  var r = qa(e), o = document.documentElement.clientWidth, t = window.innerWidth;
  return {
    left: r[0],
    top: r[1],
    right: r[2],
    gap: Math.max(0, t - o + r[2] - r[0])
  };
}, La = ji(), Ma = function(e, r, o, t) {
  var i = e.left, n = e.top, s = e.right, l = e.gap;
  return o === void 0 && (o = "margin"), `
  .`.concat(xa, ` {
   overflow: hidden `).concat(t, `;
   padding-right: `).concat(l, "px ").concat(t, `;
  }
  body {
    overflow: hidden `).concat(t, `;
    overscroll-behavior: contain;
    `).concat([
    r && "position: relative ".concat(t, ";"),
    o === "margin" && `
    padding-left: `.concat(i, `px;
    padding-top: `).concat(n, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(l, "px ").concat(t, `;
    `),
    o === "padding" && "padding-right: ".concat(l, "px ").concat(t, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(zr, ` {
    right: `).concat(l, "px ").concat(t, `;
  }
  
  .`).concat(Rr, ` {
    margin-right: `).concat(l, "px ").concat(t, `;
  }
  
  .`).concat(zr, " .").concat(zr, ` {
    right: 0 `).concat(t, `;
  }
  
  .`).concat(Rr, " .").concat(Rr, ` {
    margin-right: 0 `).concat(t, `;
  }
  
  body {
    `).concat(ya, ": ").concat(l, `px;
  }
`);
}, Fa = function(e) {
  var r = e.noRelative, o = e.noImportant, t = e.gapMode, i = t === void 0 ? "margin" : t, n = A.useMemo(function() {
    return Ia(i);
  }, [i]);
  return A.createElement(La, { styles: Ma(n, !r, i, o ? "" : "!important") });
}, bo = !1;
if (typeof window < "u")
  try {
    var Pr = Object.defineProperty({}, "passive", {
      get: function() {
        return bo = !0, !0;
      }
    });
    window.addEventListener("test", Pr, Pr), window.removeEventListener("test", Pr, Pr);
  } catch {
    bo = !1;
  }
var tr = bo ? { passive: !1 } : !1, Ha = function(e) {
  return e.tagName === "TEXTAREA";
}, Di = function(e, r) {
  var o = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    o[r] !== "hidden" && // contains scroll inside self
    !(o.overflowY === o.overflowX && !Ha(e) && o[r] === "visible")
  );
}, Ba = function(e) {
  return Di(e, "overflowY");
}, Wa = function(e) {
  return Di(e, "overflowX");
}, xt = function(e, r) {
  var o = r;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var t = qi(e, o);
    if (t) {
      var i = Ii(e, o), n = i[1], s = i[2];
      if (n > s)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== document.body);
  return !1;
}, Va = function(e) {
  var r = e.scrollTop, o = e.scrollHeight, t = e.clientHeight;
  return [
    r,
    o,
    t
  ];
}, Xa = function(e) {
  var r = e.scrollLeft, o = e.scrollWidth, t = e.clientWidth;
  return [
    r,
    o,
    t
  ];
}, qi = function(e, r) {
  return e === "v" ? Ba(r) : Wa(r);
}, Ii = function(e, r) {
  return e === "v" ? Va(r) : Xa(r);
}, Ua = function(e, r) {
  return e === "h" && r === "rtl" ? -1 : 1;
}, Ka = function(e, r, o, t, i) {
  var n = Ua(e, window.getComputedStyle(r).direction), s = n * t, l = o.target, a = r.contains(l), c = !1, p = s > 0, d = 0, h = 0;
  do {
    var u = Ii(e, l), f = u[0], g = u[1], m = u[2], k = g - m - n * f;
    (f || k) && qi(e, l) && (d += k, h += f), l = l.parentNode;
  } while (
    // portaled content
    !a && l !== document.body || // self content
    a && (r.contains(l) || r === l)
  );
  return (p && (i && d === 0 || !i && s > d) || !p && (i && h === 0 || !i && -s > h)) && (c = !0), c;
}, Er = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, yt = function(e) {
  return [e.deltaX, e.deltaY];
}, Ct = function(e) {
  return e && "current" in e ? e.current : e;
}, Ya = function(e, r) {
  return e[0] === r[0] && e[1] === r[1];
}, Ga = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Za = 0, ir = [];
function Ja(e) {
  var r = A.useRef([]), o = A.useRef([0, 0]), t = A.useRef(), i = A.useState(Za++)[0], n = A.useState(function() {
    return ji();
  })[0], s = A.useRef(e);
  A.useEffect(function() {
    s.current = e;
  }, [e]), A.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(i));
      var g = ba([e.lockRef.current], (e.shards || []).map(Ct), !0).filter(Boolean);
      return g.forEach(function(m) {
        return m.classList.add("allow-interactivity-".concat(i));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(i)), g.forEach(function(m) {
          return m.classList.remove("allow-interactivity-".concat(i));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var l = A.useCallback(function(g, m) {
    if ("touches" in g && g.touches.length === 2)
      return !s.current.allowPinchZoom;
    var k = Er(g), v = o.current, b = "deltaX" in g ? g.deltaX : v[0] - k[0], C = "deltaY" in g ? g.deltaY : v[1] - k[1], S, E = g.target, P = Math.abs(b) > Math.abs(C) ? "h" : "v";
    if ("touches" in g && P === "h" && E.type === "range")
      return !1;
    var T = xt(P, E);
    if (!T)
      return !0;
    if (T ? S = P : (S = P === "v" ? "h" : "v", T = xt(P, E)), !T)
      return !1;
    if (!t.current && "changedTouches" in g && (b || C) && (t.current = S), !S)
      return !0;
    var F = t.current || S;
    return Ka(F, m, g, F === "h" ? b : C, !0);
  }, []), a = A.useCallback(function(g) {
    var m = g;
    if (!(!ir.length || ir[ir.length - 1] !== n)) {
      var k = "deltaY" in m ? yt(m) : Er(m), v = r.current.filter(function(S) {
        return S.name === m.type && S.target === m.target && Ya(S.delta, k);
      })[0];
      if (v && v.should) {
        m.cancelable && m.preventDefault();
        return;
      }
      if (!v) {
        var b = (s.current.shards || []).map(Ct).filter(Boolean).filter(function(S) {
          return S.contains(m.target);
        }), C = b.length > 0 ? l(m, b[0]) : !s.current.noIsolation;
        C && m.cancelable && m.preventDefault();
      }
    }
  }, []), c = A.useCallback(function(g, m, k, v) {
    var b = { name: g, delta: m, target: k, should: v };
    r.current.push(b), setTimeout(function() {
      r.current = r.current.filter(function(C) {
        return C !== b;
      });
    }, 1);
  }, []), p = A.useCallback(function(g) {
    o.current = Er(g), t.current = void 0;
  }, []), d = A.useCallback(function(g) {
    c(g.type, yt(g), g.target, l(g, e.lockRef.current));
  }, []), h = A.useCallback(function(g) {
    c(g.type, Er(g), g.target, l(g, e.lockRef.current));
  }, []);
  A.useEffect(function() {
    return ir.push(n), e.setCallbacks({
      onScrollCapture: d,
      onWheelCapture: d,
      onTouchMoveCapture: h
    }), document.addEventListener("wheel", a, tr), document.addEventListener("touchmove", a, tr), document.addEventListener("touchstart", p, tr), function() {
      ir = ir.filter(function(g) {
        return g !== n;
      }), document.removeEventListener("wheel", a, tr), document.removeEventListener("touchmove", a, tr), document.removeEventListener("touchstart", p, tr);
    };
  }, []);
  var u = e.removeScrollBar, f = e.inert;
  return A.createElement(
    A.Fragment,
    null,
    f ? A.createElement(n, { styles: Ga(i) }) : null,
    u ? A.createElement(Fa, { gapMode: "margin" }) : null
  );
}
const Qa = Ta(Ni, Ja);
var Li = A.forwardRef(function(e, r) {
  return A.createElement(Ur, Oe({}, e, { ref: r, sideCar: Qa }));
});
Li.classNames = Ur.classNames;
const e_ = Li, r_ = [
  " ",
  "Enter",
  "ArrowUp",
  "ArrowDown"
], o_ = [
  " ",
  "Enter"
], Kr = "Select", [Yr, Gr, t_] = ra(Kr), [cr, Fc] = Fr(Kr, [
  t_,
  Wr
]), Ro = Wr(), [i_, Ge] = cr(Kr), [n_, l_] = cr(Kr), s_ = (e) => {
  const { __scopeSelect: r, children: o, open: t, defaultOpen: i, onOpenChange: n, value: s, defaultValue: l, onValueChange: a, dir: c, name: p, autoComplete: d, disabled: h, required: u } = e, f = Ro(r), [g, m] = G(null), [k, v] = G(null), [b, C] = G(!1), S = ta(c), [E = !1, P] = go({
    prop: t,
    defaultProp: i,
    onChange: n
  }), [T, F] = go({
    prop: s,
    defaultProp: l,
    onChange: a
  }), U = te(null), N = g ? !!g.closest("form") : !0, [W, j] = G(/* @__PURE__ */ new Set()), L = Array.from(W).map(
    (I) => I.props.value
  ).join(";");
  return /* @__PURE__ */ w(ai, f, /* @__PURE__ */ w(i_, {
    required: u,
    scope: r,
    trigger: g,
    onTriggerChange: m,
    valueNode: k,
    onValueNodeChange: v,
    valueNodeHasChildren: b,
    onValueNodeHasChildrenChange: C,
    contentId: zo(),
    value: T,
    onValueChange: F,
    open: E,
    onOpenChange: P,
    dir: S,
    triggerPointerDownPosRef: U,
    disabled: h
  }, /* @__PURE__ */ w(Yr.Provider, {
    scope: r
  }, /* @__PURE__ */ w(n_, {
    scope: e.__scopeSelect,
    onNativeOptionAdd: ae((I) => {
      j(
        (z) => new Set(z).add(I)
      );
    }, []),
    onNativeOptionRemove: ae((I) => {
      j((z) => {
        const Q = new Set(z);
        return Q.delete(I), Q;
      });
    }, [])
  }, o)), N ? /* @__PURE__ */ w(Bi, {
    key: L,
    "aria-hidden": !0,
    required: u,
    tabIndex: -1,
    name: p,
    autoComplete: d,
    value: T,
    onChange: (I) => F(I.target.value),
    disabled: h
  }, T === void 0 ? /* @__PURE__ */ w("option", {
    value: ""
  }) : null, Array.from(W)) : null));
}, a_ = "SelectTrigger", __ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, disabled: t = !1, ...i } = e, n = Ro(o), s = Ge(a_, o), l = s.disabled || t, a = pe(r, s.onTriggerChange), c = Gr(o), [p, d, h] = Wi((f) => {
    const g = c().filter(
      (v) => !v.disabled
    ), m = g.find(
      (v) => v.value === s.value
    ), k = Vi(g, f, m);
    k !== void 0 && s.onValueChange(k.value);
  }), u = () => {
    l || (s.onOpenChange(!0), h());
  };
  return /* @__PURE__ */ w(_i, M({
    asChild: !0
  }, n), /* @__PURE__ */ w(_e.button, M({
    type: "button",
    role: "combobox",
    "aria-controls": s.contentId,
    "aria-expanded": s.open,
    "aria-required": s.required,
    "aria-autocomplete": "none",
    dir: s.dir,
    "data-state": s.open ? "open" : "closed",
    disabled: l,
    "data-disabled": l ? "" : void 0,
    "data-placeholder": s.value === void 0 ? "" : void 0
  }, i, {
    ref: a,
    onClick: oe(i.onClick, (f) => {
      f.currentTarget.focus();
    }),
    onPointerDown: oe(i.onPointerDown, (f) => {
      const g = f.target;
      g.hasPointerCapture(f.pointerId) && g.releasePointerCapture(f.pointerId), f.button === 0 && f.ctrlKey === !1 && (u(), s.triggerPointerDownPosRef.current = {
        x: Math.round(f.pageX),
        y: Math.round(f.pageY)
      }, f.preventDefault());
    }),
    onKeyDown: oe(i.onKeyDown, (f) => {
      const g = p.current !== "";
      !(f.ctrlKey || f.altKey || f.metaKey) && f.key.length === 1 && d(f.key), !(g && f.key === " ") && r_.includes(f.key) && (u(), f.preventDefault());
    })
  })));
}), c_ = "SelectValue", d_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, className: t, style: i, children: n, placeholder: s, ...l } = e, a = Ge(c_, o), { onValueNodeHasChildrenChange: c } = a, p = n !== void 0, d = pe(r, a.onValueNodeChange);
  return be(() => {
    c(p);
  }, [
    c,
    p
  ]), /* @__PURE__ */ w(_e.span, M({}, l, {
    ref: d,
    style: {
      pointerEvents: "none"
    }
  }), a.value === void 0 && s !== void 0 ? s : n);
}), p_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, children: t, ...i } = e;
  return /* @__PURE__ */ w(_e.span, M({
    "aria-hidden": !0
  }, i, {
    ref: r
  }), t || "▼");
}), g_ = (e) => /* @__PURE__ */ w(di, M({
  asChild: !0
}, e)), ar = "SelectContent", u_ = /* @__PURE__ */ q((e, r) => {
  const o = Ge(ar, e.__scopeSelect), [t, i] = G();
  if (be(() => {
    i(new DocumentFragment());
  }, []), !o.open) {
    const n = t;
    return n ? /* @__PURE__ */ zt(/* @__PURE__ */ w(Mi, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ w(Yr.Slot, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ w("div", null, e.children))), n) : null;
  }
  return /* @__PURE__ */ w(f_, M({}, e, {
    ref: r
  }));
}), je = 10, [Mi, Ze] = cr(ar), f_ = /* @__PURE__ */ q((e, r) => {
  const {
    __scopeSelect: o,
    position: t = "item-aligned",
    onCloseAutoFocus: i,
    onEscapeKeyDown: n,
    onPointerDownOutside: s,
    side: l,
    sideOffset: a,
    align: c,
    alignOffset: p,
    arrowPadding: d,
    collisionBoundary: h,
    collisionPadding: u,
    sticky: f,
    hideWhenDetached: g,
    avoidCollisions: m,
    //
    ...k
  } = e, v = Ge(ar, o), [b, C] = G(null), [S, E] = G(null), P = pe(
    r,
    (R) => C(R)
  ), [T, F] = G(null), [U, N] = G(null), W = Gr(o), [j, L] = G(!1), I = te(!1);
  ie(() => {
    if (b)
      return ka(b);
  }, [
    b
  ]), ia();
  const z = ae((R) => {
    const [X, ...de] = W().map(
      (K) => K.ref.current
    ), [Z] = de.slice(-1), J = document.activeElement;
    for (const K of R)
      if (K === J || (K == null || K.scrollIntoView({
        block: "nearest"
      }), K === X && S && (S.scrollTop = 0), K === Z && S && (S.scrollTop = S.scrollHeight), K == null || K.focus(), document.activeElement !== J))
        return;
  }, [
    W,
    S
  ]), Q = ae(
    () => z([
      T,
      b
    ]),
    [
      z,
      T,
      b
    ]
  );
  ie(() => {
    j && Q();
  }, [
    j,
    Q
  ]);
  const { onOpenChange: ee, triggerPointerDownPosRef: ge } = v;
  ie(() => {
    if (b) {
      let R = {
        x: 0,
        y: 0
      };
      const X = (Z) => {
        var J, K, ve, ue;
        R = {
          x: Math.abs(Math.round(Z.pageX) - ((J = (K = ge.current) === null || K === void 0 ? void 0 : K.x) !== null && J !== void 0 ? J : 0)),
          y: Math.abs(Math.round(Z.pageY) - ((ve = (ue = ge.current) === null || ue === void 0 ? void 0 : ue.y) !== null && ve !== void 0 ? ve : 0))
        };
      }, de = (Z) => {
        R.x <= 10 && R.y <= 10 ? Z.preventDefault() : b.contains(Z.target) || ee(!1), document.removeEventListener("pointermove", X), ge.current = null;
      };
      return ge.current !== null && (document.addEventListener("pointermove", X), document.addEventListener("pointerup", de, {
        capture: !0,
        once: !0
      })), () => {
        document.removeEventListener("pointermove", X), document.removeEventListener("pointerup", de, {
          capture: !0
        });
      };
    }
  }, [
    b,
    ee,
    ge
  ]), ie(() => {
    const R = () => ee(!1);
    return window.addEventListener("blur", R), window.addEventListener("resize", R), () => {
      window.removeEventListener("blur", R), window.removeEventListener("resize", R);
    };
  }, [
    ee
  ]);
  const [ne, ce] = Wi((R) => {
    const X = W().filter(
      (J) => !J.disabled
    ), de = X.find(
      (J) => J.ref.current === document.activeElement
    ), Z = Vi(X, R, de);
    Z && setTimeout(
      () => Z.ref.current.focus()
    );
  }), me = ae((R, X, de) => {
    const Z = !I.current && !de;
    (v.value !== void 0 && v.value === X || Z) && (F(R), Z && (I.current = !0));
  }, [
    v.value
  ]), $e = ae(
    () => b == null ? void 0 : b.focus(),
    [
      b
    ]
  ), xe = ae((R, X, de) => {
    const Z = !I.current && !de;
    (v.value !== void 0 && v.value === X || Z) && N(R);
  }, [
    v.value
  ]), ye = t === "popper" ? wt : h_, Se = ye === wt ? {
    side: l,
    sideOffset: a,
    align: c,
    alignOffset: p,
    arrowPadding: d,
    collisionBoundary: h,
    collisionPadding: u,
    sticky: f,
    hideWhenDetached: g,
    avoidCollisions: m
  } : {};
  return /* @__PURE__ */ w(Mi, {
    scope: o,
    content: b,
    viewport: S,
    onViewportChange: E,
    itemRefCallback: me,
    selectedItem: T,
    onItemLeave: $e,
    itemTextRefCallback: xe,
    focusSelectedItem: Q,
    selectedItemText: U,
    position: t,
    isPositioned: j,
    searchRef: ne
  }, /* @__PURE__ */ w(e_, {
    as: br,
    allowPinchZoom: !0
  }, /* @__PURE__ */ w(na, {
    asChild: !0,
    trapped: v.open,
    onMountAutoFocus: (R) => {
      R.preventDefault();
    },
    onUnmountAutoFocus: oe(i, (R) => {
      var X;
      (X = v.trigger) === null || X === void 0 || X.focus({
        preventScroll: !0
      }), R.preventDefault();
    })
  }, /* @__PURE__ */ w(pi, {
    asChild: !0,
    disableOutsidePointerEvents: !0,
    onEscapeKeyDown: n,
    onPointerDownOutside: s,
    onFocusOutside: (R) => R.preventDefault(),
    onDismiss: () => v.onOpenChange(!1)
  }, /* @__PURE__ */ w(ye, M({
    role: "listbox",
    id: v.contentId,
    "data-state": v.open ? "open" : "closed",
    dir: v.dir,
    onContextMenu: (R) => R.preventDefault()
  }, k, Se, {
    onPlaced: () => L(!0),
    ref: P,
    style: {
      // flex layout so we can place the scroll buttons properly
      display: "flex",
      flexDirection: "column",
      // reset the outline by default as the content MAY get focused
      outline: "none",
      ...k.style
    },
    onKeyDown: oe(k.onKeyDown, (R) => {
      const X = R.ctrlKey || R.altKey || R.metaKey;
      if (R.key === "Tab" && R.preventDefault(), !X && R.key.length === 1 && ce(R.key), [
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End"
      ].includes(R.key)) {
        let Z = W().filter(
          (J) => !J.disabled
        ).map(
          (J) => J.ref.current
        );
        if ([
          "ArrowUp",
          "End"
        ].includes(R.key) && (Z = Z.slice().reverse()), [
          "ArrowUp",
          "ArrowDown"
        ].includes(R.key)) {
          const J = R.target, K = Z.indexOf(J);
          Z = Z.slice(K + 1);
        }
        setTimeout(
          () => z(Z)
        ), R.preventDefault();
      }
    })
  }))))));
}), h_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, onPlaced: t, ...i } = e, n = Ge(ar, o), s = Ze(ar, o), [l, a] = G(null), [c, p] = G(null), d = pe(
    r,
    (P) => p(P)
  ), h = Gr(o), u = te(!1), f = te(!0), { viewport: g, selectedItem: m, selectedItemText: k, focusSelectedItem: v } = s, b = ae(() => {
    if (n.trigger && n.valueNode && l && c && g && m && k) {
      const P = n.trigger.getBoundingClientRect(), T = c.getBoundingClientRect(), F = n.valueNode.getBoundingClientRect(), U = k.getBoundingClientRect();
      if (n.dir !== "rtl") {
        const J = U.left - T.left, K = F.left - J, ve = P.left - K, ue = P.width + ve, ze = Math.max(ue, T.width), Re = window.innerWidth - je, Me = ut(K, [
          je,
          Re - ze
        ]);
        l.style.minWidth = ue + "px", l.style.left = Me + "px";
      } else {
        const J = T.right - U.right, K = window.innerWidth - F.right - J, ve = window.innerWidth - P.right - K, ue = P.width + ve, ze = Math.max(ue, T.width), Re = window.innerWidth - je, Me = ut(K, [
          je,
          Re - ze
        ]);
        l.style.minWidth = ue + "px", l.style.right = Me + "px";
      }
      const N = h(), W = window.innerHeight - je * 2, j = g.scrollHeight, L = window.getComputedStyle(c), I = parseInt(L.borderTopWidth, 10), z = parseInt(L.paddingTop, 10), Q = parseInt(L.borderBottomWidth, 10), ee = parseInt(L.paddingBottom, 10), ge = I + z + j + ee + Q, ne = Math.min(m.offsetHeight * 5, ge), ce = window.getComputedStyle(g), me = parseInt(ce.paddingTop, 10), $e = parseInt(ce.paddingBottom, 10), xe = P.top + P.height / 2 - je, ye = W - xe, Se = m.offsetHeight / 2, R = m.offsetTop + Se, X = I + z + R, de = ge - X;
      if (X <= xe) {
        const J = m === N[N.length - 1].ref.current;
        l.style.bottom = "0px";
        const K = c.clientHeight - g.offsetTop - g.offsetHeight, ve = Math.max(ye, Se + (J ? $e : 0) + K + Q), ue = X + ve;
        l.style.height = ue + "px";
      } else {
        const J = m === N[0].ref.current;
        l.style.top = "0px";
        const ve = Math.max(xe, I + g.offsetTop + (J ? me : 0) + Se) + de;
        l.style.height = ve + "px", g.scrollTop = X - xe + g.offsetTop;
      }
      l.style.margin = `${je}px 0`, l.style.minHeight = ne + "px", l.style.maxHeight = W + "px", t == null || t(), requestAnimationFrame(
        () => u.current = !0
      );
    }
  }, [
    h,
    n.trigger,
    n.valueNode,
    l,
    c,
    g,
    m,
    k,
    n.dir,
    t
  ]);
  be(
    () => b(),
    [
      b
    ]
  );
  const [C, S] = G();
  be(() => {
    c && S(window.getComputedStyle(c).zIndex);
  }, [
    c
  ]);
  const E = ae((P) => {
    P && f.current === !0 && (b(), v == null || v(), f.current = !1);
  }, [
    b,
    v
  ]);
  return /* @__PURE__ */ w(m_, {
    scope: o,
    contentWrapper: l,
    shouldExpandOnScrollRef: u,
    onScrollButtonChange: E
  }, /* @__PURE__ */ w("div", {
    ref: a,
    style: {
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      zIndex: C
    }
  }, /* @__PURE__ */ w(_e.div, M({}, i, {
    ref: d,
    style: {
      // When we get the height of the content, it includes borders. If we were to set
      // the height without having `boxSizing: 'border-box'` it would be too big.
      boxSizing: "border-box",
      // We need to ensure the content doesn't get taller than the wrapper
      maxHeight: "100%",
      ...i.style
    }
  }))));
}), wt = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, align: t = "start", collisionPadding: i = je, ...n } = e, s = Ro(o);
  return /* @__PURE__ */ w(ci, M({}, s, n, {
    ref: r,
    align: t,
    collisionPadding: i,
    style: {
      // Ensure border-box for floating-ui calculations
      boxSizing: "border-box",
      ...n.style,
      "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-select-content-available-width": "var(--radix-popper-available-width)",
      "--radix-select-content-available-height": "var(--radix-popper-available-height)",
      "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
    }
  }));
}), [m_, Oo] = cr(ar, {}), $t = "SelectViewport", v_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, ...t } = e, i = Ze($t, o), n = Oo($t, o), s = pe(r, i.onViewportChange), l = te(0);
  return /* @__PURE__ */ w(Co, null, /* @__PURE__ */ w("style", {
    dangerouslySetInnerHTML: {
      __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
    }
  }), /* @__PURE__ */ w(Yr.Slot, {
    scope: o
  }, /* @__PURE__ */ w(_e.div, M({
    "data-radix-select-viewport": "",
    role: "presentation"
  }, t, {
    ref: s,
    style: {
      // we use position: 'relative' here on the `viewport` so that when we call
      // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
      // (independent of the scrollUpButton).
      position: "relative",
      flex: 1,
      overflow: "auto",
      ...t.style
    },
    onScroll: oe(t.onScroll, (a) => {
      const c = a.currentTarget, { contentWrapper: p, shouldExpandOnScrollRef: d } = n;
      if (d != null && d.current && p) {
        const h = Math.abs(l.current - c.scrollTop);
        if (h > 0) {
          const u = window.innerHeight - je * 2, f = parseFloat(p.style.minHeight), g = parseFloat(p.style.height), m = Math.max(f, g);
          if (m < u) {
            const k = m + h, v = Math.min(u, k), b = k - v;
            p.style.height = v + "px", p.style.bottom === "0px" && (c.scrollTop = b > 0 ? b : 0, p.style.justifyContent = "flex-end");
          }
        }
      }
      l.current = c.scrollTop;
    })
  }))));
}), k_ = "SelectGroup", [b_, x_] = cr(k_), y_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, ...t } = e, i = zo();
  return /* @__PURE__ */ w(b_, {
    scope: o,
    id: i
  }, /* @__PURE__ */ w(_e.div, M({
    role: "group",
    "aria-labelledby": i
  }, t, {
    ref: r
  })));
}), C_ = "SelectLabel", w_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, ...t } = e, i = x_(C_, o);
  return /* @__PURE__ */ w(_e.div, M({
    id: i.id
  }, t, {
    ref: r
  }));
}), xo = "SelectItem", [$_, Fi] = cr(xo), S_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, value: t, disabled: i = !1, textValue: n, ...s } = e, l = Ge(xo, o), a = Ze(xo, o), c = l.value === t, [p, d] = G(n ?? ""), [h, u] = G(!1), f = pe(r, (k) => {
    var v;
    return (v = a.itemRefCallback) === null || v === void 0 ? void 0 : v.call(a, k, t, i);
  }), g = zo(), m = () => {
    i || (l.onValueChange(t), l.onOpenChange(!1));
  };
  return /* @__PURE__ */ w($_, {
    scope: o,
    value: t,
    disabled: i,
    textId: g,
    isSelected: c,
    onItemTextChange: ae((k) => {
      d((v) => {
        var b;
        return v || ((b = k == null ? void 0 : k.textContent) !== null && b !== void 0 ? b : "").trim();
      });
    }, [])
  }, /* @__PURE__ */ w(Yr.ItemSlot, {
    scope: o,
    value: t,
    disabled: i,
    textValue: p
  }, /* @__PURE__ */ w(_e.div, M({
    role: "option",
    "aria-labelledby": g,
    "data-highlighted": h ? "" : void 0,
    "aria-selected": c && h,
    "data-state": c ? "checked" : "unchecked",
    "aria-disabled": i || void 0,
    "data-disabled": i ? "" : void 0,
    tabIndex: i ? void 0 : -1
  }, s, {
    ref: f,
    onFocus: oe(
      s.onFocus,
      () => u(!0)
    ),
    onBlur: oe(
      s.onBlur,
      () => u(!1)
    ),
    onPointerUp: oe(s.onPointerUp, m),
    onPointerMove: oe(s.onPointerMove, (k) => {
      if (i) {
        var v;
        (v = a.onItemLeave) === null || v === void 0 || v.call(a);
      } else
        k.currentTarget.focus({
          preventScroll: !0
        });
    }),
    onPointerLeave: oe(s.onPointerLeave, (k) => {
      if (k.currentTarget === document.activeElement) {
        var v;
        (v = a.onItemLeave) === null || v === void 0 || v.call(a);
      }
    }),
    onKeyDown: oe(s.onKeyDown, (k) => {
      var v;
      ((v = a.searchRef) === null || v === void 0 ? void 0 : v.current) !== "" && k.key === " " || (o_.includes(k.key) && m(), k.key === " " && k.preventDefault());
    })
  }))));
}), Tr = "SelectItemText", P_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, className: t, style: i, ...n } = e, s = Ge(Tr, o), l = Ze(Tr, o), a = Fi(Tr, o), c = l_(Tr, o), [p, d] = G(null), h = pe(
    r,
    (k) => d(k),
    a.onItemTextChange,
    (k) => {
      var v;
      return (v = l.itemTextRefCallback) === null || v === void 0 ? void 0 : v.call(l, k, a.value, a.disabled);
    }
  ), u = p == null ? void 0 : p.textContent, f = lr(
    () => /* @__PURE__ */ w("option", {
      key: a.value,
      value: a.value,
      disabled: a.disabled
    }, u),
    [
      a.disabled,
      a.value,
      u
    ]
  ), { onNativeOptionAdd: g, onNativeOptionRemove: m } = c;
  return be(() => (g(f), () => m(f)), [
    g,
    m,
    f
  ]), /* @__PURE__ */ w(Co, null, /* @__PURE__ */ w(_e.span, M({
    id: a.textId
  }, n, {
    ref: h
  })), a.isSelected && s.valueNode && !s.valueNodeHasChildren ? /* @__PURE__ */ zt(n.children, s.valueNode) : null);
}), E_ = "SelectItemIndicator", T_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, ...t } = e;
  return Fi(E_, o).isSelected ? /* @__PURE__ */ w(_e.span, M({
    "aria-hidden": !0
  }, t, {
    ref: r
  })) : null;
}), St = "SelectScrollUpButton", A_ = /* @__PURE__ */ q((e, r) => {
  const o = Ze(St, e.__scopeSelect), t = Oo(St, e.__scopeSelect), [i, n] = G(!1), s = pe(r, t.onScrollButtonChange);
  return be(() => {
    if (o.viewport && o.isPositioned) {
      let a = function() {
        const c = l.scrollTop > 0;
        n(c);
      };
      const l = o.viewport;
      return a(), l.addEventListener("scroll", a), () => l.removeEventListener("scroll", a);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ w(Hi, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: l, selectedItem: a } = o;
      l && a && (l.scrollTop = l.scrollTop - a.offsetHeight);
    }
  })) : null;
}), Pt = "SelectScrollDownButton", z_ = /* @__PURE__ */ q((e, r) => {
  const o = Ze(Pt, e.__scopeSelect), t = Oo(Pt, e.__scopeSelect), [i, n] = G(!1), s = pe(r, t.onScrollButtonChange);
  return be(() => {
    if (o.viewport && o.isPositioned) {
      let a = function() {
        const c = l.scrollHeight - l.clientHeight, p = Math.ceil(l.scrollTop) < c;
        n(p);
      };
      const l = o.viewport;
      return a(), l.addEventListener("scroll", a), () => l.removeEventListener("scroll", a);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ w(Hi, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: l, selectedItem: a } = o;
      l && a && (l.scrollTop = l.scrollTop + a.offsetHeight);
    }
  })) : null;
}), Hi = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, onAutoScroll: t, ...i } = e, n = Ze("SelectScrollButton", o), s = te(null), l = Gr(o), a = ae(() => {
    s.current !== null && (window.clearInterval(s.current), s.current = null);
  }, []);
  return ie(() => () => a(), [
    a
  ]), be(() => {
    var c;
    const p = l().find(
      (d) => d.ref.current === document.activeElement
    );
    p == null || (c = p.ref.current) === null || c === void 0 || c.scrollIntoView({
      block: "nearest"
    });
  }, [
    l
  ]), /* @__PURE__ */ w(_e.div, M({
    "aria-hidden": !0
  }, i, {
    ref: r,
    style: {
      flexShrink: 0,
      ...i.style
    },
    onPointerDown: oe(i.onPointerDown, () => {
      s.current === null && (s.current = window.setInterval(t, 50));
    }),
    onPointerMove: oe(i.onPointerMove, () => {
      var c;
      (c = n.onItemLeave) === null || c === void 0 || c.call(n), s.current === null && (s.current = window.setInterval(t, 50));
    }),
    onPointerLeave: oe(i.onPointerLeave, () => {
      a();
    })
  }));
}), R_ = /* @__PURE__ */ q((e, r) => {
  const { __scopeSelect: o, ...t } = e;
  return /* @__PURE__ */ w(_e.div, M({
    "aria-hidden": !0
  }, t, {
    ref: r
  }));
}), Bi = /* @__PURE__ */ q((e, r) => {
  const { value: o, ...t } = e, i = te(null), n = pe(r, i), s = ua(o);
  return ie(() => {
    const l = i.current, a = window.HTMLSelectElement.prototype, p = Object.getOwnPropertyDescriptor(a, "value").set;
    if (s !== o && p) {
      const d = new Event("change", {
        bubbles: !0
      });
      p.call(l, o), l.dispatchEvent(d);
    }
  }, [
    s,
    o
  ]), /* @__PURE__ */ w(fa, {
    asChild: !0
  }, /* @__PURE__ */ w("select", M({}, t, {
    ref: n,
    defaultValue: o
  })));
});
Bi.displayName = "BubbleSelect";
function Wi(e) {
  const r = qe(e), o = te(""), t = te(0), i = ae((s) => {
    const l = o.current + s;
    r(l), function a(c) {
      o.current = c, window.clearTimeout(t.current), c !== "" && (t.current = window.setTimeout(
        () => a(""),
        1e3
      ));
    }(l);
  }, [
    r
  ]), n = ae(() => {
    o.current = "", window.clearTimeout(t.current);
  }, []);
  return ie(() => () => window.clearTimeout(t.current), []), [
    o,
    i,
    n
  ];
}
function Vi(e, r, o) {
  const i = r.length > 1 && Array.from(r).every(
    (c) => c === r[0]
  ) ? r[0] : r, n = o ? e.indexOf(o) : -1;
  let s = O_(e, Math.max(n, 0));
  i.length === 1 && (s = s.filter(
    (c) => c !== o
  ));
  const a = s.find(
    (c) => c.textValue.toLowerCase().startsWith(i.toLowerCase())
  );
  return a !== o ? a : void 0;
}
function O_(e, r) {
  return e.map(
    (o, t) => e[(r + t) % e.length]
  );
}
const N_ = s_, j_ = __, D_ = d_, q_ = p_, I_ = g_, L_ = u_, M_ = v_, F_ = y_, H_ = w_, B_ = S_, W_ = P_, V_ = T_, Xi = A_, Ui = z_, X_ = R_;
var U_ = "select_scroll_down__ibaddl9", K_ = "select_scroll_up__ibaddla", Y_ = "select_select_content__ibaddl2", G_ = "select_select_group__ibaddl8", Z_ = "select_select_icon__ibaddl7", J_ = "select_select_item__ibaddl3", Q_ = "select_select_item_indicate__ibaddl4", ec = "select_select_label__ibaddl5", rc = "select_select_separator__ibaddl6", oc = "select_select_trigger__ibaddl1";
const tc = N_, ic = H.forwardRef(({ children: e, placeholder: r, ...o }, t) => /* @__PURE__ */ y.jsx(
  D_,
  {
    ...o,
    ref: t,
    placeholder: r
  }
)), nc = H.forwardRef(({ className: e, asChild: r, ...o }, t) => /* @__PURE__ */ y.jsx(
  q_,
  {
    ...o,
    ref: t,
    asChild: r,
    className: D(Z_, e),
    children: /* @__PURE__ */ y.jsx(pl, {})
  }
)), lc = ({
  children: e,
  asChild: r,
  className: o,
  ...t
}) => /* @__PURE__ */ y.jsx(
  j_,
  {
    ...t,
    asChild: r,
    className: D(o, oc),
    children: e
  }
), sc = ({
  children: e,
  className: r,
  position: o = "popper",
  side: t = "bottom",
  sideOffset: i,
  align: n,
  alignOffset: s = 0,
  avoidCollisions: l = !0,
  sticky: a = "partial",
  hideWhenDetached: c = !1,
  ...p
}) => /* @__PURE__ */ y.jsx(I_, { children: /* @__PURE__ */ y.jsxs(
  L_,
  {
    ...p,
    className: D(Y_, r),
    position: o,
    side: t,
    sideOffset: i,
    align: n,
    alignOffset: s,
    avoidCollisions: l,
    sticky: a,
    hideWhenDetached: c,
    children: [
      /* @__PURE__ */ y.jsx(Xi, { className: D(K_, r), children: /* @__PURE__ */ y.jsx(ul, {}) }),
      /* @__PURE__ */ y.jsx(M_, { children: e }),
      /* @__PURE__ */ y.jsx(Ui, { className: D(U_, r), children: /* @__PURE__ */ y.jsx(gl, {}) })
    ]
  }
) }), ac = H.forwardRef(({ children: e, className: r, ...o }, t) => /* @__PURE__ */ y.jsxs(
  B_,
  {
    ...o,
    ref: t,
    className: D(J_, r),
    children: [
      /* @__PURE__ */ y.jsx(W_, { children: e }),
      /* @__PURE__ */ y.jsx(Ki, {})
    ]
  }
)), Ki = ({
  className: e,
  ...r
}) => /* @__PURE__ */ y.jsx(
  V_,
  {
    ...r,
    className: D(Q_, e)
  }
), _c = ({ className: e, ...r }) => /* @__PURE__ */ y.jsx(
  X_,
  {
    ...r,
    className: D(rc, e)
  }
), cc = ({ children: e, className: r, ...o }) => /* @__PURE__ */ y.jsx(
  H_,
  {
    ...o,
    className: D(ec, r),
    children: e
  }
), dc = ({ children: e, className: r, ...o }) => /* @__PURE__ */ y.jsx(
  F_,
  {
    ...o,
    className: D(G_, r),
    children: e
  }
), he = (e) => /* @__PURE__ */ y.jsx(tc, { ...e });
he.Trigger = lc;
he.Value = ic;
he.Content = sc;
he.Item = ac;
he.Icon = nc;
he.Indicator = Ki;
he.Separator = _c;
he.Label = cc;
he.Group = dc;
he.ScrollUpButton = Xi;
he.ScrollDownButton = Ui;
he.displayName = "Select";
he.Value.displayName = "Select.Value";
he.Item.displayName = "Select.Item";
he.ScrollUpButton.displayName = "Select.ScrollUpButton";
he.ScrollDownButton.displayName = "Select.ScrollDownButton";
var pc = fe({ defaultClassName: "space_SPACE_BASE__1yr5zenb", variantClassNames: { size: { xs: "space_size_xs__1yr5zen0", sm: "space_size_sm__1yr5zen1", md: "space_size_md__1yr5zen2", lg: "space_size_lg__1yr5zen3", xl: "space_size_xl__1yr5zen4", xxl: "space_size_xxl__1yr5zen5", "3xl": "space_size_3xl__1yr5zen6", "4xl": "space_size_4xl__1yr5zen7", "5xl": "space_size_5xl__1yr5zen8", "6xl": "space_size_6xl__1yr5zen9", "7xl": "space_size_7xl__1yr5zena" } }, defaultVariants: { size: "sm" }, compoundVariants: [] });
const gc = q(
  ({ size: e = "sm", className: r, ...o }, t) => {
    const i = pc({ size: e });
    return /* @__PURE__ */ y.jsx(
      "div",
      {
        ...o,
        ref: t,
        className: r ? `${r} ${i}` : i
      }
    );
  }
);
gc.displayName = "Space";
const Et = {
  1: "wrap",
  0: "nowrap"
}, uc = {
  horizontal: "row",
  vertical: "column"
}, fc = (e) => e ? Ft(e, (r) => uc[r]) : void 0, hc = (e) => e ? typeof e == "boolean" ? Et[1] : Ft(
  e,
  // Hack to convert boolean to number since Sprinkles does not support
  // boolean responsive keys
  (r) => Et[+r]
) : void 0, Hc = [
  "a",
  "article",
  "div",
  "form",
  "header",
  "label",
  "li",
  "main",
  "section",
  "span"
], Bc = ({
  as: e = "div",
  align: r,
  children: o,
  justify: t,
  flex: i,
  direction: n = "vertical",
  space: s = "4px 4px",
  wrap: l
}) => {
  const a = fc(n), c = hc(l);
  return /* @__PURE__ */ y.jsx(
    $o,
    {
      alignItems: r,
      as: e,
      display: "flex",
      flex: i,
      flexDirection: a,
      flexWrap: c,
      gap: s,
      justifyContent: t,
      children: o
    }
  );
};
var mc = fe({ defaultClassName: "switch_BASE_ROOT__17w677g0", variantClassNames: { size: { small: "switch_rootSize_small__17w677g2", medium: "switch_rootSize_medium__17w677g3" } }, defaultVariants: { size: "small" }, compoundVariants: [] }), vc = fe({ defaultClassName: "switch_BASE_TOGGLE__17w677g1", variantClassNames: { size: { small: "switch_toggleSize_small__17w677g4", medium: "switch_toggleSize_medium__17w677g5" } }, defaultVariants: { size: "small" }, compoundVariants: [] });
const kc = ({
  className: e,
  asChild: r,
  defaultChecked: o,
  checked: t,
  onCheckedChange: i,
  disabled: n,
  required: s,
  name: l,
  value: a,
  size: c = "small",
  ...p
}) => /* @__PURE__ */ y.jsx(
  yn,
  {
    ...p,
    asChild: r,
    className: D(e, mc({ size: c })),
    defaultChecked: o,
    checked: t,
    onCheckedChange: i,
    disabled: n,
    required: s,
    name: l,
    value: a
  }
), Yi = q((e, r) => {
  const { className: o, size: t = "small", asChild: i = !1, ...n } = e;
  return /* @__PURE__ */ y.jsx(
    xn,
    {
      ...n,
      ref: r,
      asChild: i,
      className: D(o, vc({ size: t }))
    }
  );
}), No = (e) => /* @__PURE__ */ y.jsx(kc, { ...e });
No.Toggle = Yi;
No.displayName = "Switch";
No.Toggle.displayName = "Switch.Toggle";
Yi.displayName = "Switch.Toggle";
var bc = fe({ defaultClassName: "text_TEXT_BASE__fpsfqv34", variantClassNames: { font: { system: "text_font_system__fpsfqv0", inter: "text_font_inter__fpsfqv1", mono: "text_font_mono__fpsfqv2" }, size: { xs: "text_size_xs__fpsfqv3", sm: "text_size_sm__fpsfqv4", md: "text_size_md__fpsfqv5", lg: "text_size_lg__fpsfqv6", xl: "text_size_xl__fpsfqv7", xxl: "text_size_xxl__fpsfqv8", "3xl": "text_size_3xl__fpsfqv9", "4xl": "text_size_4xl__fpsfqva", "5xl": "text_size_5xl__fpsfqvb", "6xl": "text_size_6xl__fpsfqvc", "7xl": "text_size_7xl__fpsfqvd", "8xl": "text_size_8xl__fpsfqve", "9xl": "text_size_9xl__fpsfqvf" }, weight: { superlite: "text_weight_superlite__fpsfqvg", lite: "text_weight_lite__fpsfqvh", normal: "text_weight_normal__fpsfqvi", medium: "text_weight_medium__fpsfqvj", semibold: "text_weight_semibold__fpsfqvk", bold: "text_weight_bold__fpsfqvl", heavy: "text_weight_heavy__fpsfqvm", black: "text_weight_black__fpsfqvn" }, color: { transparent: "text_color_transparent__fpsfqvo", current: "text_color_current__fpsfqvp", white: "text_color_white__fpsfqvq", black: "text_color_black__fpsfqvr", gray100: "text_color_gray100__fpsfqvs", gray200: "text_color_gray200__fpsfqvt", gray300: "text_color_gray300__fpsfqvu", pale100: "text_color_pale100__fpsfqvv", pale200: "text_color_pale200__fpsfqvw", pale300: "text_color_pale300__fpsfqvx", pale400: "text_color_pale400__fpsfqvy", pale500: "text_color_pale500__fpsfqvz", hyper0: "text_color_hyper0__fpsfqv10", hyper1: "text_color_hyper1__fpsfqv11", hyper2: "text_color_hyper2__fpsfqv12", hyper3: "text_color_hyper3__fpsfqv13", hyper4: "text_color_hyper4__fpsfqv14", hyper5: "text_color_hyper5__fpsfqv15", hyper6: "text_color_hyper6__fpsfqv16", hyper7: "text_color_hyper7__fpsfqv17", hyper8: "text_color_hyper8__fpsfqv18", hyper9: "text_color_hyper9__fpsfqv19", hyper10: "text_color_hyper10__fpsfqv1a", hyper11: "text_color_hyper11__fpsfqv1b", hyper12: "text_color_hyper12__fpsfqv1c", hyper13: "text_color_hyper13__fpsfqv1d", lemon0: "text_color_lemon0__fpsfqv1e", lemon1: "text_color_lemon1__fpsfqv1f", lemon2: "text_color_lemon2__fpsfqv1g", lemon3: "text_color_lemon3__fpsfqv1h", lemon4: "text_color_lemon4__fpsfqv1i", lemon5: "text_color_lemon5__fpsfqv1j", lemon6: "text_color_lemon6__fpsfqv1k", lemon7: "text_color_lemon7__fpsfqv1l", lemon8: "text_color_lemon8__fpsfqv1m", lemon9: "text_color_lemon9__fpsfqv1n", lemon10: "text_color_lemon10__fpsfqv1o", lemon11: "text_color_lemon11__fpsfqv1p", lemon12: "text_color_lemon12__fpsfqv1q", lemon13: "text_color_lemon13__fpsfqv1r", slate1: "text_color_slate1__fpsfqv1s", slate2: "text_color_slate2__fpsfqv1t", slate3: "text_color_slate3__fpsfqv1u", slate4: "text_color_slate4__fpsfqv1v", slate5: "text_color_slate5__fpsfqv1w", slate6: "text_color_slate6__fpsfqv1x", slate7: "text_color_slate7__fpsfqv1y", slate8: "text_color_slate8__fpsfqv1z", slate9: "text_color_slate9__fpsfqv20", slate10: "text_color_slate10__fpsfqv21", slate11: "text_color_slate11__fpsfqv22", slate12: "text_color_slate12__fpsfqv23", slate13: "text_color_slate13__fpsfqv24", sapphire0: "text_color_sapphire0__fpsfqv25", sapphire1: "text_color_sapphire1__fpsfqv26", sapphire2: "text_color_sapphire2__fpsfqv27", sapphire3: "text_color_sapphire3__fpsfqv28", sapphire4: "text_color_sapphire4__fpsfqv29", sapphire5: "text_color_sapphire5__fpsfqv2a", sapphire6: "text_color_sapphire6__fpsfqv2b", sapphire7: "text_color_sapphire7__fpsfqv2c", sapphire8: "text_color_sapphire8__fpsfqv2d", sapphire9: "text_color_sapphire9__fpsfqv2e", sapphire10: "text_color_sapphire10__fpsfqv2f", sapphire11: "text_color_sapphire11__fpsfqv2g", sapphire12: "text_color_sapphire12__fpsfqv2h", sapphire13: "text_color_sapphire13__fpsfqv2i", volt0: "text_color_volt0__fpsfqv2j", volt1: "text_color_volt1__fpsfqv2k", volt2: "text_color_volt2__fpsfqv2l", volt3: "text_color_volt3__fpsfqv2m", volt4: "text_color_volt4__fpsfqv2n", volt5: "text_color_volt5__fpsfqv2o", volt6: "text_color_volt6__fpsfqv2p", volt7: "text_color_volt7__fpsfqv2q", volt8: "text_color_volt8__fpsfqv2r", volt9: "text_color_volt9__fpsfqv2s", volt10: "text_color_volt10__fpsfqv2t", volt11: "text_color_volt11__fpsfqv2u", volt12: "text_color_volt12__fpsfqv2v", volt13: "text_color_volt13__fpsfqv2w" }, align: { left: "text_align_left__fpsfqv2x", center: "text_align_center__fpsfqv2y", right: "text_align_right__fpsfqv2z" }, casing: { none: "text_casing_none__fpsfqv30", uppercase: "text_casing_uppercase__fpsfqv31", lowercase: "text_casing_lowercase__fpsfqv32", capitalize: "text_casing_capitalize__fpsfqv33" } }, defaultVariants: { font: "system", size: "md", weight: "medium", color: "slate5", align: "left", casing: "none" }, compoundVariants: [] });
const xc = H.forwardRef(
  ({
    children: e,
    className: r,
    font: o = "inter",
    size: t = "md",
    align: i = "left",
    color: n = "slate5",
    weight: s = "medium",
    casing: l,
    ...a
  }, c) => /* @__PURE__ */ y.jsx(
    "p",
    {
      ref: c,
      className: D(r, bc({ font: o, size: t, align: i, color: n, weight: s, casing: l })),
      ...a,
      children: e
    }
  )
);
xc.displayName = "Text";
var yc = "tip_tip_content__fgg2xl1", Cc = "tip_tip_trigger__fgg2xl0";
const wc = 500, $c = 300, Sc = !1, Pc = ({ children: e, ...r }) => /* @__PURE__ */ y.jsx(
  Nr.Provider,
  {
    delayDuration: wc,
    skipDelayDuration: $c,
    disableHoverableContent: Sc,
    children: /* @__PURE__ */ y.jsx(Nr.Root, { ...r, children: e })
  }
), Gi = H.forwardRef(
  ({
    children: e,
    className: r,
    onEscapeKeyDown: o,
    onPointerDownOutside: t,
    forceMount: i,
    side: n = "right",
    sideOffset: s = 10,
    align: l = "center",
    alignOffset: a = 0,
    avoidCollisions: c = !0,
    sticky: p = "always",
    hideWhenDetached: d = !1,
    //..
    ...h
  }, u) => /* @__PURE__ */ y.jsx(
    Nr.Content,
    {
      ...h,
      ref: u,
      "aria-label": "atelier-tip",
      side: n,
      sideOffset: s,
      align: l,
      alignOffset: a,
      avoidCollisions: c,
      sticky: p,
      hideWhenDetached: d,
      className: D(r, yc),
      children: e
    }
  )
), Zi = H.forwardRef(
  ({ children: e, ...r }, o) => /* @__PURE__ */ y.jsx(
    Nr.Trigger,
    {
      ...r,
      ref: o,
      className: Cc,
      children: e
    }
  )
), jo = (e) => /* @__PURE__ */ y.jsx(Pc, { ...e });
jo.Trigger = Zi;
jo.Content = Gi;
jo.displayName = "Tip";
Zi.displayName = "TipTrigger";
Gi.displayName = "TipContent";
export {
  pl as ArrowDownIcon,
  qc as ArrowUpIcon,
  Ke as Avi,
  jn as Banner,
  qn as Button,
  Mn as Canvas,
  Fn as CanvasBlur,
  Bn as Chip,
  Vn as Container,
  Un as Flex,
  Lc as Grid,
  hl as Heading,
  xr as HoverCard,
  Rs as Inline,
  Ao as Input,
  Bt as KitContext,
  Dc as KitProvider,
  Ic as LogoIcon,
  Le as Menubar,
  Vs as Paragraph,
  Us as PassLink,
  we as Popover,
  $o as Rect,
  ea as Section,
  he as Select,
  gl as SmallArrowDownIcon,
  ul as SmallArrowUpIcon,
  gc as Space,
  Bc as Stack,
  No as Switch,
  xc as Text,
  jo as Tip,
  _l as atoms,
  Qn as base,
  Rc as breakpoints,
  Nc as colorModeStyle,
  fc as directionToFlexDirection,
  el as element,
  Oc as kit,
  zc as mapColorValue,
  Ft as mapResponsiveValue,
  Ht as sprinkles,
  jc as useTheme,
  Hc as validStackComponents,
  hc as wrapToFlexWrap
};
//# sourceMappingURL=index.js.map
