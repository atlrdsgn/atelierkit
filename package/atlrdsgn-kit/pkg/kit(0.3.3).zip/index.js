/*! 
    atelierkit© v0.3.3. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
     */
import * as A from "react";
import H, { createContext as ht, useContext as Mt, useState as G, forwardRef as D, createElement as $, Children as Ue, useMemo as at, useRef as ne, useEffect as ie, useCallback as le, useLayoutEffect as An, isValidElement as Nt, cloneElement as wo, Fragment as _o, useReducer as br } from "react";
import * as $o from "@radix-ui/react-avatar";
import * as xr from "react-dom";
import Cr, { flushSync as Rn, createPortal as On } from "react-dom";
import * as Ie from "@radix-ui/react-menubar";
import * as Ve from "@radix-ui/react-popover";
import { Thumb as wr, Root as _r } from "@radix-ui/react-switch";
import * as qt from "@radix-ui/react-tooltip";
var fo = { exports: {} }, ft = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Xo;
function $r() {
  if (Xo)
    return ft;
  Xo = 1;
  var e = H, t = Symbol.for("react.element"), o = Symbol.for("react.fragment"), n = Object.prototype.hasOwnProperty, i = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, r = { key: !0, ref: !0, __self: !0, __source: !0 };
  function s(a, l, d) {
    var f, u = {}, m = null, p = null;
    d !== void 0 && (m = "" + d), l.key !== void 0 && (m = "" + l.key), l.ref !== void 0 && (p = l.ref);
    for (f in l)
      n.call(l, f) && !r.hasOwnProperty(f) && (u[f] = l[f]);
    if (a && a.defaultProps)
      for (f in l = a.defaultProps, l)
        u[f] === void 0 && (u[f] = l[f]);
    return { $$typeof: t, type: a, key: m, ref: p, props: u, _owner: i.current };
  }
  return ft.Fragment = o, ft.jsx = s, ft.jsxs = s, ft;
}
var gt = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ko;
function kr() {
  return Ko || (Ko = 1, process.env.NODE_ENV !== "production" && function() {
    var e = H, t = Symbol.for("react.element"), o = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), a = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), d = Symbol.for("react.suspense"), f = Symbol.for("react.suspense_list"), u = Symbol.for("react.memo"), m = Symbol.for("react.lazy"), p = Symbol.for("react.offscreen"), v = Symbol.iterator, g = "@@iterator";
    function h(c) {
      if (c === null || typeof c != "object")
        return null;
      var C = v && c[v] || c[g];
      return typeof C == "function" ? C : null;
    }
    var b = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function y(c) {
      {
        for (var C = arguments.length, k = new Array(C > 1 ? C - 1 : 0), N = 1; N < C; N++)
          k[N - 1] = arguments[N];
        x("error", c, k);
      }
    }
    function x(c, C, k) {
      {
        var N = b.ReactDebugCurrentFrame, Y = N.getStackAddendum();
        Y !== "" && (C += "%s", k = k.concat([Y]));
        var te = k.map(function(B) {
          return String(B);
        });
        te.unshift("Warning: " + C), Function.prototype.apply.call(console[c], console, te);
      }
    }
    var _ = !1, S = !1, E = !1, P = !1, T = !1, F;
    F = Symbol.for("react.module.reference");
    function X(c) {
      return !!(typeof c == "string" || typeof c == "function" || c === n || c === r || T || c === i || c === d || c === f || P || c === p || _ || S || E || typeof c == "object" && c !== null && (c.$$typeof === m || c.$$typeof === u || c.$$typeof === s || c.$$typeof === a || c.$$typeof === l || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      c.$$typeof === F || c.getModuleId !== void 0));
    }
    function q(c, C, k) {
      var N = c.displayName;
      if (N)
        return N;
      var Y = C.displayName || C.name || "";
      return Y !== "" ? k + "(" + Y + ")" : k;
    }
    function W(c) {
      return c.displayName || "Context";
    }
    function j(c) {
      if (c == null)
        return null;
      if (typeof c.tag == "number" && y("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof c == "function")
        return c.displayName || c.name || null;
      if (typeof c == "string")
        return c;
      switch (c) {
        case n:
          return "Fragment";
        case o:
          return "Portal";
        case r:
          return "Profiler";
        case i:
          return "StrictMode";
        case d:
          return "Suspense";
        case f:
          return "SuspenseList";
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case a:
            var C = c;
            return W(C) + ".Consumer";
          case s:
            var k = c;
            return W(k._context) + ".Provider";
          case l:
            return q(c, c.render, "ForwardRef");
          case u:
            var N = c.displayName || null;
            return N !== null ? N : j(c.type) || "Memo";
          case m: {
            var Y = c, te = Y._payload, B = Y._init;
            try {
              return j(B(te));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var L = Object.assign, I = 0, R, Q, ee, pe, re, ue, me;
    function ke() {
    }
    ke.__reactDisabledLog = !0;
    function Ce() {
      {
        if (I === 0) {
          R = console.log, Q = console.info, ee = console.warn, pe = console.error, re = console.group, ue = console.groupCollapsed, me = console.groupEnd;
          var c = {
            configurable: !0,
            enumerable: !0,
            value: ke,
            writable: !0
          };
          Object.defineProperties(console, {
            info: c,
            log: c,
            warn: c,
            error: c,
            group: c,
            groupCollapsed: c,
            groupEnd: c
          });
        }
        I++;
      }
    }
    function we() {
      {
        if (I--, I === 0) {
          var c = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: L({}, c, {
              value: R
            }),
            info: L({}, c, {
              value: Q
            }),
            warn: L({}, c, {
              value: ee
            }),
            error: L({}, c, {
              value: pe
            }),
            group: L({}, c, {
              value: re
            }),
            groupCollapsed: L({}, c, {
              value: ue
            }),
            groupEnd: L({}, c, {
              value: me
            })
          });
        }
        I < 0 && y("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Se = b.ReactCurrentDispatcher, O;
    function U(c, C, k) {
      {
        if (O === void 0)
          try {
            throw Error();
          } catch (Y) {
            var N = Y.stack.trim().match(/\n( *(at )?)/);
            O = N && N[1] || "";
          }
        return `
` + O + c;
      }
    }
    var fe = !1, Z;
    {
      var J = typeof WeakMap == "function" ? WeakMap : Map;
      Z = new J();
    }
    function K(c, C) {
      if (!c || fe)
        return "";
      {
        var k = Z.get(c);
        if (k !== void 0)
          return k;
      }
      var N;
      fe = !0;
      var Y = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var te;
      te = Se.current, Se.current = null, Ce();
      try {
        if (C) {
          var B = function() {
            throw Error();
          };
          if (Object.defineProperty(B.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(B, []);
            } catch (qe) {
              N = qe;
            }
            Reflect.construct(c, [], B);
          } else {
            try {
              B.call();
            } catch (qe) {
              N = qe;
            }
            c.call(B.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (qe) {
            N = qe;
          }
          c();
        }
      } catch (qe) {
        if (qe && N && typeof qe.stack == "string") {
          for (var V = qe.stack.split(`
`), ye = N.stack.split(`
`), ae = V.length - 1, se = ye.length - 1; ae >= 1 && se >= 0 && V[ae] !== ye[se]; )
            se--;
          for (; ae >= 1 && se >= 0; ae--, se--)
            if (V[ae] !== ye[se]) {
              if (ae !== 1 || se !== 1)
                do
                  if (ae--, se--, se < 0 || V[ae] !== ye[se]) {
                    var Pe = `
` + V[ae].replace(" at new ", " at ");
                    return c.displayName && Pe.includes("<anonymous>") && (Pe = Pe.replace("<anonymous>", c.displayName)), typeof c == "function" && Z.set(c, Pe), Pe;
                  }
                while (ae >= 1 && se >= 0);
              break;
            }
        }
      } finally {
        fe = !1, Se.current = te, we(), Error.prepareStackTrace = Y;
      }
      var tt = c ? c.displayName || c.name : "", Uo = tt ? U(tt) : "";
      return typeof c == "function" && Z.set(c, Uo), Uo;
    }
    function he(c, C, k) {
      return K(c, !1);
    }
    function ve(c) {
      var C = c.prototype;
      return !!(C && C.isReactComponent);
    }
    function Re(c, C, k) {
      if (c == null)
        return "";
      if (typeof c == "function")
        return K(c, ve(c));
      if (typeof c == "string")
        return U(c);
      switch (c) {
        case d:
          return U("Suspense");
        case f:
          return U("SuspenseList");
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case l:
            return he(c.render);
          case u:
            return Re(c.type, C, k);
          case m: {
            var N = c, Y = N._payload, te = N._init;
            try {
              return Re(te(Y), C, k);
            } catch {
            }
          }
        }
      return "";
    }
    var Oe = Object.prototype.hasOwnProperty, Me = {}, wt = b.ReactDebugCurrentFrame;
    function Je(c) {
      if (c) {
        var C = c._owner, k = Re(c.type, c._source, C ? C.type : null);
        wt.setExtraStackFrame(k);
      } else
        wt.setExtraStackFrame(null);
    }
    function Qe(c, C, k, N, Y) {
      {
        var te = Function.call.bind(Oe);
        for (var B in c)
          if (te(c, B)) {
            var V = void 0;
            try {
              if (typeof c[B] != "function") {
                var ye = Error((N || "React class") + ": " + k + " type `" + B + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof c[B] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw ye.name = "Invariant Violation", ye;
              }
              V = c[B](C, B, N, k, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (ae) {
              V = ae;
            }
            V && !(V instanceof Error) && (Je(Y), y("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", N || "React class", k, B, typeof V), Je(null)), V instanceof Error && !(V.message in Me) && (Me[V.message] = !0, Je(Y), y("Failed %s type: %s", k, V.message), Je(null));
          }
      }
    }
    var er = Array.isArray;
    function Zt(c) {
      return er(c);
    }
    function tr(c) {
      {
        var C = typeof Symbol == "function" && Symbol.toStringTag, k = C && c[Symbol.toStringTag] || c.constructor.name || "Object";
        return k;
      }
    }
    function or(c) {
      try {
        return zo(c), !1;
      } catch {
        return !0;
      }
    }
    function zo(c) {
      return "" + c;
    }
    function Do(c) {
      if (or(c))
        return y("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", tr(c)), zo(c);
    }
    var ut = b.ReactCurrentOwner, nr = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, Io, Lo, Jt;
    Jt = {};
    function ir(c) {
      if (Oe.call(c, "ref")) {
        var C = Object.getOwnPropertyDescriptor(c, "ref").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.ref !== void 0;
    }
    function rr(c) {
      if (Oe.call(c, "key")) {
        var C = Object.getOwnPropertyDescriptor(c, "key").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.key !== void 0;
    }
    function ar(c, C) {
      if (typeof c.ref == "string" && ut.current && C && ut.current.stateNode !== C) {
        var k = j(ut.current.type);
        Jt[k] || (y('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', j(ut.current.type), c.ref), Jt[k] = !0);
      }
    }
    function sr(c, C) {
      {
        var k = function() {
          Io || (Io = !0, y("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "key", {
          get: k,
          configurable: !0
        });
      }
    }
    function lr(c, C) {
      {
        var k = function() {
          Lo || (Lo = !0, y("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "ref", {
          get: k,
          configurable: !0
        });
      }
    }
    var cr = function(c, C, k, N, Y, te, B) {
      var V = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: t,
        // Built-in properties that belong on the element
        type: c,
        key: C,
        ref: k,
        props: B,
        // Record the component responsible for creating this element.
        _owner: te
      };
      return V._store = {}, Object.defineProperty(V._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(V, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: N
      }), Object.defineProperty(V, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: Y
      }), Object.freeze && (Object.freeze(V.props), Object.freeze(V)), V;
    };
    function dr(c, C, k, N, Y) {
      {
        var te, B = {}, V = null, ye = null;
        k !== void 0 && (Do(k), V = "" + k), rr(C) && (Do(C.key), V = "" + C.key), ir(C) && (ye = C.ref, ar(C, Y));
        for (te in C)
          Oe.call(C, te) && !nr.hasOwnProperty(te) && (B[te] = C[te]);
        if (c && c.defaultProps) {
          var ae = c.defaultProps;
          for (te in ae)
            B[te] === void 0 && (B[te] = ae[te]);
        }
        if (V || ye) {
          var se = typeof c == "function" ? c.displayName || c.name || "Unknown" : c;
          V && sr(B, se), ye && lr(B, se);
        }
        return cr(c, V, ye, Y, N, ut.current, B);
      }
    }
    var Qt = b.ReactCurrentOwner, Mo = b.ReactDebugCurrentFrame;
    function et(c) {
      if (c) {
        var C = c._owner, k = Re(c.type, c._source, C ? C.type : null);
        Mo.setExtraStackFrame(k);
      } else
        Mo.setExtraStackFrame(null);
    }
    var eo;
    eo = !1;
    function to(c) {
      return typeof c == "object" && c !== null && c.$$typeof === t;
    }
    function Fo() {
      {
        if (Qt.current) {
          var c = j(Qt.current.type);
          if (c)
            return `

Check the render method of \`` + c + "`.";
        }
        return "";
      }
    }
    function ur(c) {
      {
        if (c !== void 0) {
          var C = c.fileName.replace(/^.*[\\\/]/, ""), k = c.lineNumber;
          return `

Check your code at ` + C + ":" + k + ".";
        }
        return "";
      }
    }
    var Ho = {};
    function fr(c) {
      {
        var C = Fo();
        if (!C) {
          var k = typeof c == "string" ? c : c.displayName || c.name;
          k && (C = `

Check the top-level render call using <` + k + ">.");
        }
        return C;
      }
    }
    function Vo(c, C) {
      {
        if (!c._store || c._store.validated || c.key != null)
          return;
        c._store.validated = !0;
        var k = fr(C);
        if (Ho[k])
          return;
        Ho[k] = !0;
        var N = "";
        c && c._owner && c._owner !== Qt.current && (N = " It was passed a child from " + j(c._owner.type) + "."), et(c), y('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', k, N), et(null);
      }
    }
    function Wo(c, C) {
      {
        if (typeof c != "object")
          return;
        if (Zt(c))
          for (var k = 0; k < c.length; k++) {
            var N = c[k];
            to(N) && Vo(N, C);
          }
        else if (to(c))
          c._store && (c._store.validated = !0);
        else if (c) {
          var Y = h(c);
          if (typeof Y == "function" && Y !== c.entries)
            for (var te = Y.call(c), B; !(B = te.next()).done; )
              to(B.value) && Vo(B.value, C);
        }
      }
    }
    function gr(c) {
      {
        var C = c.type;
        if (C == null || typeof C == "string")
          return;
        var k;
        if (typeof C == "function")
          k = C.propTypes;
        else if (typeof C == "object" && (C.$$typeof === l || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        C.$$typeof === u))
          k = C.propTypes;
        else
          return;
        if (k) {
          var N = j(C);
          Qe(k, c.props, "prop", N, c);
        } else if (C.PropTypes !== void 0 && !eo) {
          eo = !0;
          var Y = j(C);
          y("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", Y || "Unknown");
        }
        typeof C.getDefaultProps == "function" && !C.getDefaultProps.isReactClassApproved && y("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function pr(c) {
      {
        for (var C = Object.keys(c.props), k = 0; k < C.length; k++) {
          var N = C[k];
          if (N !== "children" && N !== "key") {
            et(c), y("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", N), et(null);
            break;
          }
        }
        c.ref !== null && (et(c), y("Invalid attribute `ref` supplied to `React.Fragment`."), et(null));
      }
    }
    function Bo(c, C, k, N, Y, te) {
      {
        var B = X(c);
        if (!B) {
          var V = "";
          (c === void 0 || typeof c == "object" && c !== null && Object.keys(c).length === 0) && (V += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var ye = ur(Y);
          ye ? V += ye : V += Fo();
          var ae;
          c === null ? ae = "null" : Zt(c) ? ae = "array" : c !== void 0 && c.$$typeof === t ? (ae = "<" + (j(c.type) || "Unknown") + " />", V = " Did you accidentally export a JSX literal instead of a component?") : ae = typeof c, y("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", ae, V);
        }
        var se = dr(c, C, k, Y, te);
        if (se == null)
          return se;
        if (B) {
          var Pe = C.children;
          if (Pe !== void 0)
            if (N)
              if (Zt(Pe)) {
                for (var tt = 0; tt < Pe.length; tt++)
                  Wo(Pe[tt], c);
                Object.freeze && Object.freeze(Pe);
              } else
                y("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              Wo(Pe, c);
        }
        return c === n ? pr(se) : gr(se), se;
      }
    }
    function vr(c, C, k) {
      return Bo(c, C, k, !0);
    }
    function mr(c, C, k) {
      return Bo(c, C, k, !1);
    }
    var hr = mr, yr = vr;
    gt.Fragment = n, gt.jsx = hr, gt.jsxs = yr;
  }()), gt;
}
process.env.NODE_ENV === "production" ? fo.exports = $r() : fo.exports = kr();
var w = fo.exports;
function Sr(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Pr(e) {
  var t = Sr(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function Er(e, t, o) {
  return t = Pr(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function Yo(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function Go(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Yo(Object(o), !0).forEach(function(n) {
      Er(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : Yo(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var Tr = (e, t, o) => {
  for (var n of Object.keys(e)) {
    var i;
    if (e[n] !== ((i = t[n]) !== null && i !== void 0 ? i : o[n]))
      return !1;
  }
  return !0;
}, be = (e) => {
  var t = (o) => {
    var n = e.defaultClassName, i = Go(Go({}, e.defaultVariants), o);
    for (var r in i) {
      var s, a = (s = i[r]) !== null && s !== void 0 ? s : e.defaultVariants[r];
      if (a != null) {
        var l = a;
        typeof l == "boolean" && (l = l === !0 ? "true" : "false");
        var d = (
          // @ts-expect-error
          e.variantClassNames[r][l]
        );
        d && (n += " " + d);
      }
    }
    for (var [f, u] of e.compoundVariants)
      Tr(f, i, e.defaultVariants) && (n += " " + u);
    return n;
  };
  return t.variants = () => Object.keys(e.variantClassNames), t;
}, Ar = be({ defaultClassName: "_1bycfvg2i", variantClassNames: { size: { xs: "_1bycfvg2", sm: "_1bycfvg3", md: "_1bycfvg4", lg: "_1bycfvg5" }, shape: { circle: "_1bycfvg6", square: "_1bycfvg7", rounded: "_1bycfvg8" }, variant: { transparent: "_1bycfvg9", current: "_1bycfvga", white: "_1bycfvgb", black: "_1bycfvgc", gray100: "_1bycfvgd", gray200: "_1bycfvge", gray300: "_1bycfvgf", pale100: "_1bycfvgg", pale200: "_1bycfvgh", pale300: "_1bycfvgi", pale400: "_1bycfvgj", pale500: "_1bycfvgk", hyper0: "_1bycfvgl", hyper1: "_1bycfvgm", hyper2: "_1bycfvgn", hyper3: "_1bycfvgo", hyper4: "_1bycfvgp", hyper5: "_1bycfvgq", hyper6: "_1bycfvgr", hyper7: "_1bycfvgs", hyper8: "_1bycfvgt", hyper9: "_1bycfvgu", hyper10: "_1bycfvgv", hyper11: "_1bycfvgw", hyper12: "_1bycfvgx", hyper13: "_1bycfvgy", lemon0: "_1bycfvgz", lemon1: "_1bycfvg10", lemon2: "_1bycfvg11", lemon3: "_1bycfvg12", lemon4: "_1bycfvg13", lemon5: "_1bycfvg14", lemon6: "_1bycfvg15", lemon7: "_1bycfvg16", lemon8: "_1bycfvg17", lemon9: "_1bycfvg18", lemon10: "_1bycfvg19", lemon11: "_1bycfvg1a", lemon12: "_1bycfvg1b", lemon13: "_1bycfvg1c", slate1: "_1bycfvg1d", slate2: "_1bycfvg1e", slate3: "_1bycfvg1f", slate4: "_1bycfvg1g", slate5: "_1bycfvg1h", slate6: "_1bycfvg1i", slate7: "_1bycfvg1j", slate8: "_1bycfvg1k", slate9: "_1bycfvg1l", slate10: "_1bycfvg1m", slate11: "_1bycfvg1n", slate12: "_1bycfvg1o", slate13: "_1bycfvg1p", sapphire0: "_1bycfvg1q", sapphire1: "_1bycfvg1r", sapphire2: "_1bycfvg1s", sapphire3: "_1bycfvg1t", sapphire4: "_1bycfvg1u", sapphire5: "_1bycfvg1v", sapphire6: "_1bycfvg1w", sapphire7: "_1bycfvg1x", sapphire8: "_1bycfvg1y", sapphire9: "_1bycfvg1z", sapphire10: "_1bycfvg20", sapphire11: "_1bycfvg21", sapphire12: "_1bycfvg22", sapphire13: "_1bycfvg23", volt0: "_1bycfvg24", volt1: "_1bycfvg25", volt2: "_1bycfvg26", volt3: "_1bycfvg27", volt4: "_1bycfvg28", volt5: "_1bycfvg29", volt6: "_1bycfvg2a", volt7: "_1bycfvg2b", volt8: "_1bycfvg2c", volt9: "_1bycfvg2d", volt10: "_1bycfvg2e", volt11: "_1bycfvg2f", volt12: "_1bycfvg2g", volt13: "_1bycfvg2h" } }, defaultVariants: { size: "sm", shape: "rounded" }, compoundVariants: [] }), Nn = "_1bycfvg0", Rr = "_1bycfvg1";
function qn(e) {
  var t, o, n = "";
  if (typeof e == "string" || typeof e == "number")
    n += e;
  else if (typeof e == "object")
    if (Array.isArray(e))
      for (t = 0; t < e.length; t++)
        e[t] && (o = qn(e[t])) && (n && (n += " "), n += o);
    else
      for (t in e)
        e[t] && (n && (n += " "), n += t);
  return n;
}
function z() {
  for (var e, t, o = 0, n = ""; o < arguments.length; )
    (e = arguments[o++]) && (t = qn(e)) && (n && (n += " "), n += t);
  return n;
}
const jn = $o.Image, Or = $o.Fallback, Nr = H.forwardRef(
  ({ className: e, size: t = "xs", shape: o = "rounded", ...n }, i) => /* @__PURE__ */ w.jsx(
    $o.Root,
    {
      ...n,
      ref: i,
      className: z(Ar({ size: t, shape: o }), e)
    }
  )
), zn = H.forwardRef(
  ({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    Or,
    {
      ...t,
      ref: o,
      className: z(Rr, e)
    }
  )
), Dn = H.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
  jn,
  {
    ...t,
    ref: o,
    className: z(Nn, e)
  }
)), qr = "https://cdn.atlrdsgn.com/assets/github/atlrdsgn/A2.jpg", In = H.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
  jn,
  {
    ...t,
    ref: o,
    src: qr,
    className: z(Nn, e)
  }
)), Ke = (e) => /* @__PURE__ */ w.jsx(Nr, { ...e });
Ke.Fallback = zn;
Ke.Image = Dn;
Ke.Demo = In;
Ke.displayName = "Avi";
Ke.Fallback.displayName = "AviFallback";
Ke.Image.displayName = "AviImage";
Ke.Demo.displayName = "AviDemoImage";
zn.displayName = "AviFallback";
Dn.displayName = "AviImage";
In.displayName = "AviDemoImage";
var jr = be({ defaultClassName: "aefdx68", variantClassNames: { size: { xs: "aefdx60", sm: "aefdx61", md: "aefdx62", lg: "aefdx63" }, variant: { slate: "aefdx64", jade: "aefdx65", hyper: "aefdx66", neon: "aefdx67" } }, defaultVariants: { size: "sm", variant: "slate" }, compoundVariants: [] });
const zr = ({
  children: e,
  type: t = "button",
  as: o = "a",
  onClick: n = () => {
  },
  href: i,
  target: r = "_self",
  rel: s = "noopener noreferrer",
  size: a = "sm",
  variant: l = "hyper",
  ...d
}) => {
  const f = (u) => {
    i ? (u.preventDefault(), window.open(i, r, s)) : u.preventDefault(), n(u);
  };
  return /* @__PURE__ */ w.jsx(
    "button",
    {
      ...d,
      type: t,
      className: jr({ size: a, variant: l }),
      onClick: f,
      children: e
    }
  );
};
zr.displayName = "Button";
var Dr = "_1dqe6mp0", Ir = "_1dqe6mp1";
const Lr = H.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: o,
      className: z(Dr),
      ...t,
      children: e
    }
  )
), Mr = H.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: o,
      className: z(Ir),
      ...t,
      children: e
    }
  )
);
Lr.displayName = "Canvas";
Mr.displayName = "Blurred-Canvas";
var Fr = be({ defaultClassName: "_1yx7lz87", variantClassNames: { size: { xsmall: "_1yx7lz80", small: "_1yx7lz81", medium: "_1yx7lz82" }, shape: { rounded: "_1yx7lz83", pill: "_1yx7lz84" }, variant: { slate: "_1yx7lz85", hyper: "_1yx7lz86" } }, defaultVariants: { size: "small", shape: "pill", variant: "slate" }, compoundVariants: [] });
const Hr = ({
  children: e,
  className: t,
  size: o = "small",
  shape: n = "pill",
  variant: i = "slate",
  ...r
}) => /* @__PURE__ */ w.jsx(
  "span",
  {
    ...r,
    className: z(t, Fr({ size: o, shape: n, variant: i })),
    children: e
  }
);
Hr.displayName = "Chip";
var Vr = be({ defaultClassName: "zhlr5ea", variantClassNames: { align: { start: "zhlr5e6", center: "zhlr5e7", end: "zhlr5e8" }, width: { small: "zhlr5e0", medium: "zhlr5e1", large: "zhlr5e2", xlarge: "zhlr5e3", max: "zhlr5e4", full: "zhlr5e5" }, border: { true: "zhlr5e9" } }, defaultVariants: { align: "start", width: "max", border: !1 }, compoundVariants: [] });
const Wr = ({
  children: e,
  className: t,
  width: o = "max",
  align: n = "start",
  border: i = !1,
  ...r
}) => /* @__PURE__ */ w.jsx(
  "div",
  {
    ...r,
    className: z(t, Vr({ width: o, align: n, border: i })),
    children: e
  }
);
Wr.displayName = "Container";
var Br = be({ defaultClassName: "_18w0vmkl", variantClassNames: { direction: { row: "_18w0vmk0", column: "_18w0vmk1", rowReverse: "_18w0vmk2", columnReverse: "_18w0vmk3" }, align: { start: "_18w0vmk4", center: "_18w0vmk5", end: "_18w0vmk6", stretch: "_18w0vmk7", baseline: "_18w0vmk8" }, justify: { start: "_18w0vmk9", center: "_18w0vmka", end: "_18w0vmkb", between: "_18w0vmkc" }, gap: { xs: "_18w0vmkd", sm: "_18w0vmke", md: "_18w0vmkf", lg: "_18w0vmkg", xl: "_18w0vmkh" }, wrap: { wrap: "_18w0vmki", nowrap: "_18w0vmkj", wrapReverse: "_18w0vmkk" } }, defaultVariants: { direction: "row", align: "start", justify: "start", gap: "sm", wrap: "wrap" }, compoundVariants: [] });
const Ur = H.forwardRef(
  ({
    children: e,
    direction: t = "row",
    align: o = "center",
    justify: n = "center",
    gap: i = "sm",
    ...r
    //..
  }, s) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ...r,
      ref: s,
      className: Br({ direction: t, align: o, justify: n, gap: i }),
      children: e
    }
  )
);
Ur.displayName = "Flex";
var Xr = "_10xm3zb2", Kr = "var(--_10xm3zb0)", Yr = "var(--_10xm3zb1)";
function Zo(e) {
  var t = e.match(/^var\((.*)\)$/);
  return t ? t[1] : e;
}
function Gr(e, t) {
  var o = e;
  for (var n of t) {
    if (!(n in o))
      throw new Error("Path ".concat(t.join(" -> "), " does not exist in object"));
    o = o[n];
  }
  return o;
}
function Ln(e, t) {
  var o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [], n = e.constructor();
  for (var i in e) {
    var r = e[i], s = [...o, i];
    typeof r == "string" || typeof r == "number" || r == null ? n[i] = t(r, s) : typeof r == "object" && !Array.isArray(r) ? n[i] = Ln(r, t, s) : console.warn('Skipping invalid key "'.concat(s.join("."), '". Should be a string, number, null or object. Received: "').concat(Array.isArray(r) ? "Array" : typeof r, '"'));
  }
  return n;
}
function Zr(e, t) {
  var o = {};
  if (typeof t == "object") {
    var n = e;
    Ln(t, (s, a) => {
      var l = Gr(n, a);
      o[Zo(l)] = String(s);
    });
  } else {
    var i = e;
    for (var r in i)
      o[Zo(r)] = i[r];
  }
  return Object.defineProperty(o, "toString", {
    value: function() {
      return Object.keys(this).map((a) => "".concat(a, ":").concat(this[a])).join(";");
    },
    writable: !1
  }), o;
}
var Jr = "ltqw8z0", Qr = { article: "ltqw8z1", aside: "ltqw8z1", details: "ltqw8z1", figcaption: "ltqw8z1", figure: "ltqw8z1", footer: "ltqw8z1", header: "ltqw8z1", hgroup: "ltqw8z1", menu: "ltqw8z1", nav: "ltqw8z1", section: "ltqw8z1", ul: "ltqw8z3", ol: "ltqw8z3", blockquote: "ltqw8z4", q: "ltqw8z4", body: "ltqw8z2", a: "ltqw8zg", table: "ltqw8z5", mark: "ltqw8za ltqw8z7", select: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zb", button: "ltqw8z7", textarea: "ltqw8z1 ltqw8z6 ltqw8z8", input: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zd" };
function ea(e, t) {
  return Object.defineProperty(e, "__recipe__", {
    value: t,
    writable: !1
  }), e;
}
var Mn = ea;
function ta(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  function o(n) {
    if (typeof n == "string" || typeof n == "number" || typeof n == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return {
        [t.defaultCondition]: n
      };
    }
    if (Array.isArray(n)) {
      if (!("responsiveArray" in t))
        throw new Error("Responsive arrays are not supported");
      var i = {};
      for (var r in t.responsiveArray)
        n[r] != null && (i[t.responsiveArray[r]] = n[r]);
      return i;
    }
    return n;
  }
  return Mn(o, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createNormalizeValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function Fn(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  var o = ta(e);
  function n(i, r) {
    if (typeof i == "string" || typeof i == "number" || typeof i == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return r(i, t.defaultCondition);
    }
    var s = Array.isArray(i) ? o(i) : i, a = {};
    for (var l in s)
      s[l] != null && (a[l] = r(s[l], l));
    return a;
  }
  return Mn(n, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createMapValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function oa(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function na(e) {
  var t = oa(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function ia(e, t, o) {
  return t = na(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function Jo(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function oo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Jo(Object(o), !0).forEach(function(n) {
      ia(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : Jo(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var ra = (e) => function() {
  for (var t = arguments.length, o = new Array(t), n = 0; n < t; n++)
    o[n] = arguments[n];
  var i = Object.assign({}, ...o.map((l) => l.styles)), r = Object.keys(i), s = r.filter((l) => "mappings" in i[l]), a = (l) => {
    var d = [], f = {}, u = oo({}, l), m = !1;
    for (var p of s) {
      var v = l[p];
      if (v != null) {
        var g = i[p];
        m = !0;
        for (var h of g.mappings)
          f[h] = v, u[h] == null && delete u[h];
      }
    }
    var b = m ? oo(oo({}, f), u) : l, y = function() {
      var E = b[x], P = i[x];
      try {
        if (P.mappings)
          return "continue";
        if (typeof E == "string" || typeof E == "number") {
          if (process.env.NODE_ENV !== "production" && !P.values[E].defaultClass)
            throw new Error();
          d.push(P.values[E].defaultClass);
        } else if (Array.isArray(E))
          for (var T = 0; T < E.length; T++) {
            var F = E[T];
            if (F != null) {
              var X = P.responsiveArray[T];
              if (process.env.NODE_ENV !== "production" && !P.values[F].conditions[X])
                throw new Error();
              d.push(P.values[F].conditions[X]);
            }
          }
        else
          for (var q in E) {
            var W = E[q];
            if (W != null) {
              if (process.env.NODE_ENV !== "production" && !P.values[W].conditions[q])
                throw new Error();
              d.push(P.values[W].conditions[q]);
            }
          }
      } catch (pe) {
        if (process.env.NODE_ENV !== "production") {
          class re extends Error {
            constructor(me) {
              super(me), this.name = "SprinklesError";
            }
          }
          var j = (ue) => typeof ue == "string" ? '"'.concat(ue, '"') : ue, L = (ue, me, ke) => {
            throw new re('"'.concat(ue, '" has no value ').concat(j(me), ". Possible values are ").concat(Object.keys(ke).map(j).join(", ")));
          };
          if (!P)
            throw new re('"'.concat(x, '" is not a valid sprinkle'));
          if ((typeof E == "string" || typeof E == "number") && (E in P.values || L(x, E, P.values), !P.values[E].defaultClass))
            throw new re('"'.concat(x, '" has no default condition. You must specify which conditions to target explicitly. Possible options are ').concat(Object.keys(P.values[E].conditions).map(j).join(", ")));
          if (typeof E == "object") {
            if (!("conditions" in P.values[Object.keys(P.values)[0]]))
              throw new re('"'.concat(x, '" is not a conditional property'));
            if (Array.isArray(E)) {
              if (!("responsiveArray" in P))
                throw new re('"'.concat(x, '" does not support responsive arrays'));
              var I = P.responsiveArray.length;
              if (I < E.length)
                throw new re('"'.concat(x, '" only supports up to ').concat(I, " breakpoints. You passed ").concat(E.length));
              for (var R of E)
                P.values[R] || L(x, R, P.values);
            } else
              for (var Q in E) {
                var ee = E[Q];
                if (ee != null && (P.values[ee] || L(x, ee, P.values), !P.values[ee].conditions[Q]))
                  throw new re('"'.concat(x, '" has no condition named ').concat(j(Q), ". Possible values are ").concat(Object.keys(P.values[ee].conditions).map(j).join(", ")));
              }
          }
        }
        throw pe;
      }
    };
    for (var x in b)
      var _ = y();
    return e(d.join(" "));
  };
  return Object.assign(a, {
    properties: new Set(r)
  });
}, aa = (e) => e, sa = function() {
  return ra(aa)(...arguments);
}, Td = Fn({ conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 } }), Hn = Fn({ conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] } }), Vn = sa(function() {
  var e = { conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] }, styles: { all: { values: { unset: { conditions: { small: "i77g9o0", medium: "i77g9o1", large: "i77g9o2", xlarge: "i77g9o3" }, defaultClass: "i77g9o0" } }, responsiveArray: void 0 }, boxSizing: { values: { "border-box": { conditions: { small: "i77g9o4", medium: "i77g9o5", large: "i77g9o6", xlarge: "i77g9o7" }, defaultClass: "i77g9o4" } }, responsiveArray: void 0 }, appearance: { values: { none: { conditions: { small: "i77g9o8", medium: "i77g9o9", large: "i77g9oa", xlarge: "i77g9ob" }, defaultClass: "i77g9o8" } }, responsiveArray: void 0 }, outline: { values: { none: { conditions: { small: "i77g9oc", medium: "i77g9od", large: "i77g9oe", xlarge: "i77g9of" }, defaultClass: "i77g9oc" } }, responsiveArray: void 0 }, userSelect: { values: { none: { conditions: { small: "i77g9og", medium: "i77g9oh", large: "i77g9oi", xlarge: "i77g9oj" }, defaultClass: "i77g9og" }, auto: { conditions: { small: "i77g9ok", medium: "i77g9ol", large: "i77g9om", xlarge: "i77g9on" }, defaultClass: "i77g9ok" } }, responsiveArray: void 0 }, fontVariantNumeric: { values: { "tabular-nums": { conditions: { small: "i77g9oo", medium: "i77g9op", large: "i77g9oq", xlarge: "i77g9or" }, defaultClass: "i77g9oo" } }, responsiveArray: void 0 }, WebkitTapHighlightColor: { values: { "rgba(0,0,0,0)": { conditions: { small: "i77g9os", medium: "i77g9ot", large: "i77g9ou", xlarge: "i77g9ov" }, defaultClass: "i77g9os" } }, responsiveArray: void 0 }, display: { values: { none: { conditions: { small: "i77g9ow", medium: "i77g9ox", large: "i77g9oy", xlarge: "i77g9oz" }, defaultClass: "i77g9ow" }, flex: { conditions: { small: "i77g9o10", medium: "i77g9o11", large: "i77g9o12", xlarge: "i77g9o13" }, defaultClass: "i77g9o10" }, block: { conditions: { small: "i77g9o14", medium: "i77g9o15", large: "i77g9o16", xlarge: "i77g9o17" }, defaultClass: "i77g9o14" }, "inline-block": { conditions: { small: "i77g9o18", medium: "i77g9o19", large: "i77g9o1a", xlarge: "i77g9o1b" }, defaultClass: "i77g9o18" }, "inline-flex": { conditions: { small: "i77g9o1c", medium: "i77g9o1d", large: "i77g9o1e", xlarge: "i77g9o1f" }, defaultClass: "i77g9o1c" }, inline: { conditions: { small: "i77g9o1g", medium: "i77g9o1h", large: "i77g9o1i", xlarge: "i77g9o1j" }, defaultClass: "i77g9o1g" } }, responsiveArray: void 0 }, flex: { values: { 1: { conditions: { small: "i77g9o1k", medium: "i77g9o1l", large: "i77g9o1m", xlarge: "i77g9o1n" }, defaultClass: "i77g9o1k" }, auto: { conditions: { small: "i77g9o1o", medium: "i77g9o1p", large: "i77g9o1q", xlarge: "i77g9o1r" }, defaultClass: "i77g9o1o" }, initial: { conditions: { small: "i77g9o1s", medium: "i77g9o1t", large: "i77g9o1u", xlarge: "i77g9o1v" }, defaultClass: "i77g9o1s" }, none: { conditions: { small: "i77g9o1w", medium: "i77g9o1x", large: "i77g9o1y", xlarge: "i77g9o1z" }, defaultClass: "i77g9o1w" } }, responsiveArray: void 0 }, flexDirection: { values: { row: { conditions: { small: "i77g9o20", medium: "i77g9o21", large: "i77g9o22", xlarge: "i77g9o23" }, defaultClass: "i77g9o20" }, column: { conditions: { small: "i77g9o24", medium: "i77g9o25", large: "i77g9o26", xlarge: "i77g9o27" }, defaultClass: "i77g9o24" }, "row-reverse": { conditions: { small: "i77g9o28", medium: "i77g9o29", large: "i77g9o2a", xlarge: "i77g9o2b" }, defaultClass: "i77g9o28" }, "column-reverse": { conditions: { small: "i77g9o2c", medium: "i77g9o2d", large: "i77g9o2e", xlarge: "i77g9o2f" }, defaultClass: "i77g9o2c" } }, responsiveArray: void 0 }, flexWrap: { values: { nowrap: { conditions: { small: "i77g9o2g", medium: "i77g9o2h", large: "i77g9o2i", xlarge: "i77g9o2j" }, defaultClass: "i77g9o2g" }, wrap: { conditions: { small: "i77g9o2k", medium: "i77g9o2l", large: "i77g9o2m", xlarge: "i77g9o2n" }, defaultClass: "i77g9o2k" }, "wrap-reverse": { conditions: { small: "i77g9o2o", medium: "i77g9o2p", large: "i77g9o2q", xlarge: "i77g9o2r" }, defaultClass: "i77g9o2o" } }, responsiveArray: void 0 }, justifyContent: { values: { "flex-start": { conditions: { small: "i77g9o2s", medium: "i77g9o2t", large: "i77g9o2u", xlarge: "i77g9o2v" }, defaultClass: "i77g9o2s" }, center: { conditions: { small: "i77g9o2w", medium: "i77g9o2x", large: "i77g9o2y", xlarge: "i77g9o2z" }, defaultClass: "i77g9o2w" }, "flex-end": { conditions: { small: "i77g9o30", medium: "i77g9o31", large: "i77g9o32", xlarge: "i77g9o33" }, defaultClass: "i77g9o30" }, stretch: { conditions: { small: "i77g9o34", medium: "i77g9o35", large: "i77g9o36", xlarge: "i77g9o37" }, defaultClass: "i77g9o34" }, "space-between": { conditions: { small: "i77g9o38", medium: "i77g9o39", large: "i77g9o3a", xlarge: "i77g9o3b" }, defaultClass: "i77g9o38" }, "space-around": { conditions: { small: "i77g9o3c", medium: "i77g9o3d", large: "i77g9o3e", xlarge: "i77g9o3f" }, defaultClass: "i77g9o3c" } }, responsiveArray: void 0 }, alignItems: { values: { "flex-start": { conditions: { small: "i77g9o3g", medium: "i77g9o3h", large: "i77g9o3i", xlarge: "i77g9o3j" }, defaultClass: "i77g9o3g" }, center: { conditions: { small: "i77g9o3k", medium: "i77g9o3l", large: "i77g9o3m", xlarge: "i77g9o3n" }, defaultClass: "i77g9o3k" }, "flex-end": { conditions: { small: "i77g9o3o", medium: "i77g9o3p", large: "i77g9o3q", xlarge: "i77g9o3r" }, defaultClass: "i77g9o3o" }, stretch: { conditions: { small: "i77g9o3s", medium: "i77g9o3t", large: "i77g9o3u", xlarge: "i77g9o3v" }, defaultClass: "i77g9o3s" }, baseline: { conditions: { small: "i77g9o3w", medium: "i77g9o3x", large: "i77g9o3y", xlarge: "i77g9o3z" }, defaultClass: "i77g9o3w" } }, responsiveArray: void 0 }, alignContent: { values: { "flex-start": { conditions: { small: "i77g9o40", medium: "i77g9o41", large: "i77g9o42", xlarge: "i77g9o43" }, defaultClass: "i77g9o40" }, center: { conditions: { small: "i77g9o44", medium: "i77g9o45", large: "i77g9o46", xlarge: "i77g9o47" }, defaultClass: "i77g9o44" }, "flex-end": { conditions: { small: "i77g9o48", medium: "i77g9o49", large: "i77g9o4a", xlarge: "i77g9o4b" }, defaultClass: "i77g9o48" }, stretch: { conditions: { small: "i77g9o4c", medium: "i77g9o4d", large: "i77g9o4e", xlarge: "i77g9o4f" }, defaultClass: "i77g9o4c" } }, responsiveArray: void 0 }, verticalAlign: { values: { top: { conditions: { small: "i77g9o4g", medium: "i77g9o4h", large: "i77g9o4i", xlarge: "i77g9o4j" }, defaultClass: "i77g9o4g" }, middle: { conditions: { small: "i77g9o4k", medium: "i77g9o4l", large: "i77g9o4m", xlarge: "i77g9o4n" }, defaultClass: "i77g9o4k" }, bottom: { conditions: { small: "i77g9o4o", medium: "i77g9o4p", large: "i77g9o4q", xlarge: "i77g9o4r" }, defaultClass: "i77g9o4o" }, baseline: { conditions: { small: "i77g9o4s", medium: "i77g9o4t", large: "i77g9o4u", xlarge: "i77g9o4v" }, defaultClass: "i77g9o4s" }, "text-top": { conditions: { small: "i77g9o4w", medium: "i77g9o4x", large: "i77g9o4y", xlarge: "i77g9o4z" }, defaultClass: "i77g9o4w" }, "text-bottom": { conditions: { small: "i77g9o50", medium: "i77g9o51", large: "i77g9o52", xlarge: "i77g9o53" }, defaultClass: "i77g9o50" } }, responsiveArray: void 0 }, position: { values: { initial: { conditions: { small: "i77g9o54", medium: "i77g9o55", large: "i77g9o56", xlarge: "i77g9o57" }, defaultClass: "i77g9o54" }, inherit: { conditions: { small: "i77g9o58", medium: "i77g9o59", large: "i77g9o5a", xlarge: "i77g9o5b" }, defaultClass: "i77g9o58" }, unset: { conditions: { small: "i77g9o5c", medium: "i77g9o5d", large: "i77g9o5e", xlarge: "i77g9o5f" }, defaultClass: "i77g9o5c" }, relative: { conditions: { small: "i77g9o5g", medium: "i77g9o5h", large: "i77g9o5i", xlarge: "i77g9o5j" }, defaultClass: "i77g9o5g" }, absolute: { conditions: { small: "i77g9o5k", medium: "i77g9o5l", large: "i77g9o5m", xlarge: "i77g9o5n" }, defaultClass: "i77g9o5k" }, fixed: { conditions: { small: "i77g9o5o", medium: "i77g9o5p", large: "i77g9o5q", xlarge: "i77g9o5r" }, defaultClass: "i77g9o5o" }, sticky: { conditions: { small: "i77g9o5s", medium: "i77g9o5t", large: "i77g9o5u", xlarge: "i77g9o5v" }, defaultClass: "i77g9o5s" } }, responsiveArray: void 0 }, margin: { values: { 0: { conditions: { small: "i77g9o68", medium: "i77g9o69", large: "i77g9o6a", xlarge: "i77g9o6b" }, defaultClass: "i77g9o68" }, initial: { conditions: { small: "i77g9o5w", medium: "i77g9o5x", large: "i77g9o5y", xlarge: "i77g9o5z" }, defaultClass: "i77g9o5w" }, inherit: { conditions: { small: "i77g9o60", medium: "i77g9o61", large: "i77g9o62", xlarge: "i77g9o63" }, defaultClass: "i77g9o60" }, unset: { conditions: { small: "i77g9o64", medium: "i77g9o65", large: "i77g9o66", xlarge: "i77g9o67" }, defaultClass: "i77g9o64" }, auto: { conditions: { small: "i77g9o6c", medium: "i77g9o6d", large: "i77g9o6e", xlarge: "i77g9o6f" }, defaultClass: "i77g9o6c" }, none: { conditions: { small: "i77g9o6g", medium: "i77g9o6h", large: "i77g9o6i", xlarge: "i77g9o6j" }, defaultClass: "i77g9o6g" } }, responsiveArray: void 0 }, padding: { values: { 0: { conditions: { small: "i77g9o6w", medium: "i77g9o6x", large: "i77g9o6y", xlarge: "i77g9o6z" }, defaultClass: "i77g9o6w" }, initial: { conditions: { small: "i77g9o6k", medium: "i77g9o6l", large: "i77g9o6m", xlarge: "i77g9o6n" }, defaultClass: "i77g9o6k" }, inherit: { conditions: { small: "i77g9o6o", medium: "i77g9o6p", large: "i77g9o6q", xlarge: "i77g9o6r" }, defaultClass: "i77g9o6o" }, unset: { conditions: { small: "i77g9o6s", medium: "i77g9o6t", large: "i77g9o6u", xlarge: "i77g9o6v" }, defaultClass: "i77g9o6s" }, none: { conditions: { small: "i77g9o70", medium: "i77g9o71", large: "i77g9o72", xlarge: "i77g9o73" }, defaultClass: "i77g9o70" }, auto: { conditions: { small: "i77g9o74", medium: "i77g9o75", large: "i77g9o76", xlarge: "i77g9o77" }, defaultClass: "i77g9o74" }, "4px": { conditions: { small: "i77g9o78", medium: "i77g9o79", large: "i77g9o7a", xlarge: "i77g9o7b" }, defaultClass: "i77g9o78" }, "8px": { conditions: { small: "i77g9o7c", medium: "i77g9o7d", large: "i77g9o7e", xlarge: "i77g9o7f" }, defaultClass: "i77g9o7c" }, "10px": { conditions: { small: "i77g9o7g", medium: "i77g9o7h", large: "i77g9o7i", xlarge: "i77g9o7j" }, defaultClass: "i77g9o7g" }, "12px": { conditions: { small: "i77g9o7k", medium: "i77g9o7l", large: "i77g9o7m", xlarge: "i77g9o7n" }, defaultClass: "i77g9o7k" }, "16px": { conditions: { small: "i77g9o7o", medium: "i77g9o7p", large: "i77g9o7q", xlarge: "i77g9o7r" }, defaultClass: "i77g9o7o" }, "20px": { conditions: { small: "i77g9o7s", medium: "i77g9o7t", large: "i77g9o7u", xlarge: "i77g9o7v" }, defaultClass: "i77g9o7s" } }, responsiveArray: void 0 }, width: { values: { auto: { conditions: { small: "i77g9o7w", medium: "i77g9o7x", large: "i77g9o7y", xlarge: "i77g9o7z" }, defaultClass: "i77g9o7w" }, "100%": { conditions: { small: "i77g9o80", medium: "i77g9o81", large: "i77g9o82", xlarge: "i77g9o83" }, defaultClass: "i77g9o80" } }, responsiveArray: void 0 }, height: { values: { auto: { conditions: { small: "i77g9o84", medium: "i77g9o85", large: "i77g9o86", xlarge: "i77g9o87" }, defaultClass: "i77g9o84" }, "100%": { conditions: { small: "i77g9o88", medium: "i77g9o89", large: "i77g9o8a", xlarge: "i77g9o8b" }, defaultClass: "i77g9o88" } }, responsiveArray: void 0 }, gap: { values: { 0: { conditions: { small: "i77g9o8c", medium: "i77g9o8d", large: "i77g9o8e", xlarge: "i77g9o8f" }, defaultClass: "i77g9o8c" }, "4px 4px": { conditions: { small: "i77g9o8g", medium: "i77g9o8h", large: "i77g9o8i", xlarge: "i77g9o8j" }, defaultClass: "i77g9o8g" }, "8px 8px": { conditions: { small: "i77g9o8k", medium: "i77g9o8l", large: "i77g9o8m", xlarge: "i77g9o8n" }, defaultClass: "i77g9o8k" }, "10px 10px": { conditions: { small: "i77g9o8o", medium: "i77g9o8p", large: "i77g9o8q", xlarge: "i77g9o8r" }, defaultClass: "i77g9o8o" }, "12px 12px": { conditions: { small: "i77g9o8s", medium: "i77g9o8t", large: "i77g9o8u", xlarge: "i77g9o8v" }, defaultClass: "i77g9o8s" }, "16px 16px": { conditions: { small: "i77g9o8w", medium: "i77g9o8x", large: "i77g9o8y", xlarge: "i77g9o8z" }, defaultClass: "i77g9o8w" }, "20px 20px": { conditions: { small: "i77g9o90", medium: "i77g9o91", large: "i77g9o92", xlarge: "i77g9o93" }, defaultClass: "i77g9o90" } }, responsiveArray: void 0 }, mixBlendMode: { values: { initial: { conditions: { small: "i77g9o94", medium: "i77g9o95", large: "i77g9o96", xlarge: "i77g9o97" }, defaultClass: "i77g9o94" }, inherit: { conditions: { small: "i77g9o98", medium: "i77g9o99", large: "i77g9o9a", xlarge: "i77g9o9b" }, defaultClass: "i77g9o98" }, unset: { conditions: { small: "i77g9o9c", medium: "i77g9o9d", large: "i77g9o9e", xlarge: "i77g9o9f" }, defaultClass: "i77g9o9c" }, difference: { conditions: { small: "i77g9o9g", medium: "i77g9o9h", large: "i77g9o9i", xlarge: "i77g9o9j" }, defaultClass: "i77g9o9g" }, multiply: { conditions: { small: "i77g9o9k", medium: "i77g9o9l", large: "i77g9o9m", xlarge: "i77g9o9n" }, defaultClass: "i77g9o9k" }, screen: { conditions: { small: "i77g9o9o", medium: "i77g9o9p", large: "i77g9o9q", xlarge: "i77g9o9r" }, defaultClass: "i77g9o9o" }, overlay: { conditions: { small: "i77g9o9s", medium: "i77g9o9t", large: "i77g9o9u", xlarge: "i77g9o9v" }, defaultClass: "i77g9o9s" } }, responsiveArray: void 0 }, fontWeight: { values: { inherit: { conditions: { small: "i77g9o9w", medium: "i77g9o9x", large: "i77g9o9y", xlarge: "i77g9o9z" }, defaultClass: "i77g9o9w" }, normal: { conditions: { small: "i77g9oa0", medium: "i77g9oa1", large: "i77g9oa2", xlarge: "i77g9oa3" }, defaultClass: "i77g9oa0" }, bold: { conditions: { small: "i77g9oa4", medium: "i77g9oa5", large: "i77g9oa6", xlarge: "i77g9oa7" }, defaultClass: "i77g9oa4" }, strong: { conditions: { small: "i77g9oa8", medium: "i77g9oa9", large: "i77g9oaa", xlarge: "i77g9oab" }, defaultClass: "i77g9oa8" } }, responsiveArray: void 0 }, textTransform: { values: { capitalize: { conditions: { small: "i77g9oac", medium: "i77g9oad", large: "i77g9oae", xlarge: "i77g9oaf" }, defaultClass: "i77g9oac" }, lowercase: { conditions: { small: "i77g9oag", medium: "i77g9oah", large: "i77g9oai", xlarge: "i77g9oaj" }, defaultClass: "i77g9oag" }, uppercase: { conditions: { small: "i77g9oak", medium: "i77g9oal", large: "i77g9oam", xlarge: "i77g9oan" }, defaultClass: "i77g9oak" } }, responsiveArray: void 0 }, transitionProperty: { values: { none: { conditions: { small: "i77g9oao", medium: "i77g9oap", large: "i77g9oaq", xlarge: "i77g9oar" }, defaultClass: "i77g9oao" }, all: { conditions: { small: "i77g9oas", medium: "i77g9oat", large: "i77g9oau", xlarge: "i77g9oav" }, defaultClass: "i77g9oas" }, initial: { conditions: { small: "i77g9oaw", medium: "i77g9oax", large: "i77g9oay", xlarge: "i77g9oaz" }, defaultClass: "i77g9oaw" } }, responsiveArray: void 0 }, transitionTimingFunction: { values: { linear: { conditions: { small: "i77g9ob0", medium: "i77g9ob1", large: "i77g9ob2", xlarge: "i77g9ob3" }, defaultClass: "i77g9ob0" }, "cubic-bezier(0.4, 0, 1, 1)": { conditions: { small: "i77g9ob4", medium: "i77g9ob5", large: "i77g9ob6", xlarge: "i77g9ob7" }, defaultClass: "i77g9ob4" }, "cubic-bezier(0, 0, 0.2, 1)": { conditions: { small: "i77g9ob8", medium: "i77g9ob9", large: "i77g9oba", xlarge: "i77g9obb" }, defaultClass: "i77g9ob8" }, "cubic-bezier(0.42, 0, 0.58, 1)": { conditions: { small: "i77g9obc", medium: "i77g9obd", large: "i77g9obe", xlarge: "i77g9obf" }, defaultClass: "i77g9obc" } }, responsiveArray: void 0 }, transitionDuration: { values: { "150ms": { conditions: { small: "i77g9obg", medium: "i77g9obh", large: "i77g9obi", xlarge: "i77g9obj" }, defaultClass: "i77g9obg" }, "300ms": { conditions: { small: "i77g9obk", medium: "i77g9obl", large: "i77g9obm", xlarge: "i77g9obn" }, defaultClass: "i77g9obk" }, "500ms": { conditions: { small: "i77g9obo", medium: "i77g9obp", large: "i77g9obq", xlarge: "i77g9obr" }, defaultClass: "i77g9obo" }, "700ms": { conditions: { small: "i77g9obs", medium: "i77g9obt", large: "i77g9obu", xlarge: "i77g9obv" }, defaultClass: "i77g9obs" }, "1000ms": { conditions: { small: "i77g9obw", medium: "i77g9obx", large: "i77g9oby", xlarge: "i77g9obz" }, defaultClass: "i77g9obw" } }, responsiveArray: void 0 } } };
  return e.styles.all.responsiveArray = e.conditions.responsiveArray, e.styles.boxSizing.responsiveArray = e.conditions.responsiveArray, e.styles.appearance.responsiveArray = e.conditions.responsiveArray, e.styles.outline.responsiveArray = e.conditions.responsiveArray, e.styles.userSelect.responsiveArray = e.conditions.responsiveArray, e.styles.fontVariantNumeric.responsiveArray = e.conditions.responsiveArray, e.styles.WebkitTapHighlightColor.responsiveArray = e.conditions.responsiveArray, e.styles.display.responsiveArray = e.conditions.responsiveArray, e.styles.flex.responsiveArray = e.conditions.responsiveArray, e.styles.flexDirection.responsiveArray = e.conditions.responsiveArray, e.styles.flexWrap.responsiveArray = e.conditions.responsiveArray, e.styles.justifyContent.responsiveArray = e.conditions.responsiveArray, e.styles.alignItems.responsiveArray = e.conditions.responsiveArray, e.styles.alignContent.responsiveArray = e.conditions.responsiveArray, e.styles.verticalAlign.responsiveArray = e.conditions.responsiveArray, e.styles.position.responsiveArray = e.conditions.responsiveArray, e.styles.margin.responsiveArray = e.conditions.responsiveArray, e.styles.padding.responsiveArray = e.conditions.responsiveArray, e.styles.width.responsiveArray = e.conditions.responsiveArray, e.styles.height.responsiveArray = e.conditions.responsiveArray, e.styles.gap.responsiveArray = e.conditions.responsiveArray, e.styles.mixBlendMode.responsiveArray = e.conditions.responsiveArray, e.styles.fontWeight.responsiveArray = e.conditions.responsiveArray, e.styles.textTransform.responsiveArray = e.conditions.responsiveArray, e.styles.transitionProperty.responsiveArray = e.conditions.responsiveArray, e.styles.transitionTimingFunction.responsiveArray = e.conditions.responsiveArray, e.styles.transitionDuration.responsiveArray = e.conditions.responsiveArray, e;
}(), { conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 }, styles: { color: { values: { transparent: { conditions: { light: "i77g9oc0", dark: "i77g9oc1" }, defaultClass: "i77g9oc0" }, current: { conditions: { light: "i77g9oc2", dark: "i77g9oc3" }, defaultClass: "i77g9oc2" }, white: { conditions: { light: "i77g9oc4", dark: "i77g9oc5" }, defaultClass: "i77g9oc4" }, black: { conditions: { light: "i77g9oc6", dark: "i77g9oc7" }, defaultClass: "i77g9oc6" }, gray100: { conditions: { light: "i77g9oc8", dark: "i77g9oc9" }, defaultClass: "i77g9oc8" }, gray200: { conditions: { light: "i77g9oca", dark: "i77g9ocb" }, defaultClass: "i77g9oca" }, gray300: { conditions: { light: "i77g9occ", dark: "i77g9ocd" }, defaultClass: "i77g9occ" }, pale100: { conditions: { light: "i77g9oce", dark: "i77g9ocf" }, defaultClass: "i77g9oce" }, pale200: { conditions: { light: "i77g9ocg", dark: "i77g9och" }, defaultClass: "i77g9ocg" }, pale300: { conditions: { light: "i77g9oci", dark: "i77g9ocj" }, defaultClass: "i77g9oci" }, pale400: { conditions: { light: "i77g9ock", dark: "i77g9ocl" }, defaultClass: "i77g9ock" }, pale500: { conditions: { light: "i77g9ocm", dark: "i77g9ocn" }, defaultClass: "i77g9ocm" }, hyper0: { conditions: { light: "i77g9oco", dark: "i77g9ocp" }, defaultClass: "i77g9oco" }, hyper1: { conditions: { light: "i77g9ocq", dark: "i77g9ocr" }, defaultClass: "i77g9ocq" }, hyper2: { conditions: { light: "i77g9ocs", dark: "i77g9oct" }, defaultClass: "i77g9ocs" }, hyper3: { conditions: { light: "i77g9ocu", dark: "i77g9ocv" }, defaultClass: "i77g9ocu" }, hyper4: { conditions: { light: "i77g9ocw", dark: "i77g9ocx" }, defaultClass: "i77g9ocw" }, hyper5: { conditions: { light: "i77g9ocy", dark: "i77g9ocz" }, defaultClass: "i77g9ocy" }, hyper6: { conditions: { light: "i77g9od0", dark: "i77g9od1" }, defaultClass: "i77g9od0" }, hyper7: { conditions: { light: "i77g9od2", dark: "i77g9od3" }, defaultClass: "i77g9od2" }, hyper8: { conditions: { light: "i77g9od4", dark: "i77g9od5" }, defaultClass: "i77g9od4" }, hyper9: { conditions: { light: "i77g9od6", dark: "i77g9od7" }, defaultClass: "i77g9od6" }, hyper10: { conditions: { light: "i77g9od8", dark: "i77g9od9" }, defaultClass: "i77g9od8" }, hyper11: { conditions: { light: "i77g9oda", dark: "i77g9odb" }, defaultClass: "i77g9oda" }, hyper12: { conditions: { light: "i77g9odc", dark: "i77g9odd" }, defaultClass: "i77g9odc" }, hyper13: { conditions: { light: "i77g9ode", dark: "i77g9odf" }, defaultClass: "i77g9ode" }, lemon0: { conditions: { light: "i77g9odg", dark: "i77g9odh" }, defaultClass: "i77g9odg" }, lemon1: { conditions: { light: "i77g9odi", dark: "i77g9odj" }, defaultClass: "i77g9odi" }, lemon2: { conditions: { light: "i77g9odk", dark: "i77g9odl" }, defaultClass: "i77g9odk" }, lemon3: { conditions: { light: "i77g9odm", dark: "i77g9odn" }, defaultClass: "i77g9odm" }, lemon4: { conditions: { light: "i77g9odo", dark: "i77g9odp" }, defaultClass: "i77g9odo" }, lemon5: { conditions: { light: "i77g9odq", dark: "i77g9odr" }, defaultClass: "i77g9odq" }, lemon6: { conditions: { light: "i77g9ods", dark: "i77g9odt" }, defaultClass: "i77g9ods" }, lemon7: { conditions: { light: "i77g9odu", dark: "i77g9odv" }, defaultClass: "i77g9odu" }, lemon8: { conditions: { light: "i77g9odw", dark: "i77g9odx" }, defaultClass: "i77g9odw" }, lemon9: { conditions: { light: "i77g9ody", dark: "i77g9odz" }, defaultClass: "i77g9ody" }, lemon10: { conditions: { light: "i77g9oe0", dark: "i77g9oe1" }, defaultClass: "i77g9oe0" }, lemon11: { conditions: { light: "i77g9oe2", dark: "i77g9oe3" }, defaultClass: "i77g9oe2" }, lemon12: { conditions: { light: "i77g9oe4", dark: "i77g9oe5" }, defaultClass: "i77g9oe4" }, lemon13: { conditions: { light: "i77g9oe6", dark: "i77g9oe7" }, defaultClass: "i77g9oe6" }, slate1: { conditions: { light: "i77g9oe8", dark: "i77g9oe9" }, defaultClass: "i77g9oe8" }, slate2: { conditions: { light: "i77g9oea", dark: "i77g9oeb" }, defaultClass: "i77g9oea" }, slate3: { conditions: { light: "i77g9oec", dark: "i77g9oed" }, defaultClass: "i77g9oec" }, slate4: { conditions: { light: "i77g9oee", dark: "i77g9oef" }, defaultClass: "i77g9oee" }, slate5: { conditions: { light: "i77g9oeg", dark: "i77g9oeh" }, defaultClass: "i77g9oeg" }, slate6: { conditions: { light: "i77g9oei", dark: "i77g9oej" }, defaultClass: "i77g9oei" }, slate7: { conditions: { light: "i77g9oek", dark: "i77g9oel" }, defaultClass: "i77g9oek" }, slate8: { conditions: { light: "i77g9oem", dark: "i77g9oen" }, defaultClass: "i77g9oem" }, slate9: { conditions: { light: "i77g9oeo", dark: "i77g9oep" }, defaultClass: "i77g9oeo" }, slate10: { conditions: { light: "i77g9oeq", dark: "i77g9oer" }, defaultClass: "i77g9oeq" }, slate11: { conditions: { light: "i77g9oes", dark: "i77g9oet" }, defaultClass: "i77g9oes" }, slate12: { conditions: { light: "i77g9oeu", dark: "i77g9oev" }, defaultClass: "i77g9oeu" }, slate13: { conditions: { light: "i77g9oew", dark: "i77g9oex" }, defaultClass: "i77g9oew" }, sapphire0: { conditions: { light: "i77g9oey", dark: "i77g9oez" }, defaultClass: "i77g9oey" }, sapphire1: { conditions: { light: "i77g9of0", dark: "i77g9of1" }, defaultClass: "i77g9of0" }, sapphire2: { conditions: { light: "i77g9of2", dark: "i77g9of3" }, defaultClass: "i77g9of2" }, sapphire3: { conditions: { light: "i77g9of4", dark: "i77g9of5" }, defaultClass: "i77g9of4" }, sapphire4: { conditions: { light: "i77g9of6", dark: "i77g9of7" }, defaultClass: "i77g9of6" }, sapphire5: { conditions: { light: "i77g9of8", dark: "i77g9of9" }, defaultClass: "i77g9of8" }, sapphire6: { conditions: { light: "i77g9ofa", dark: "i77g9ofb" }, defaultClass: "i77g9ofa" }, sapphire7: { conditions: { light: "i77g9ofc", dark: "i77g9ofd" }, defaultClass: "i77g9ofc" }, sapphire8: { conditions: { light: "i77g9ofe", dark: "i77g9off" }, defaultClass: "i77g9ofe" }, sapphire9: { conditions: { light: "i77g9ofg", dark: "i77g9ofh" }, defaultClass: "i77g9ofg" }, sapphire10: { conditions: { light: "i77g9ofi", dark: "i77g9ofj" }, defaultClass: "i77g9ofi" }, sapphire11: { conditions: { light: "i77g9ofk", dark: "i77g9ofl" }, defaultClass: "i77g9ofk" }, sapphire12: { conditions: { light: "i77g9ofm", dark: "i77g9ofn" }, defaultClass: "i77g9ofm" }, sapphire13: { conditions: { light: "i77g9ofo", dark: "i77g9ofp" }, defaultClass: "i77g9ofo" }, volt0: { conditions: { light: "i77g9ofq", dark: "i77g9ofr" }, defaultClass: "i77g9ofq" }, volt1: { conditions: { light: "i77g9ofs", dark: "i77g9oft" }, defaultClass: "i77g9ofs" }, volt2: { conditions: { light: "i77g9ofu", dark: "i77g9ofv" }, defaultClass: "i77g9ofu" }, volt3: { conditions: { light: "i77g9ofw", dark: "i77g9ofx" }, defaultClass: "i77g9ofw" }, volt4: { conditions: { light: "i77g9ofy", dark: "i77g9ofz" }, defaultClass: "i77g9ofy" }, volt5: { conditions: { light: "i77g9og0", dark: "i77g9og1" }, defaultClass: "i77g9og0" }, volt6: { conditions: { light: "i77g9og2", dark: "i77g9og3" }, defaultClass: "i77g9og2" }, volt7: { conditions: { light: "i77g9og4", dark: "i77g9og5" }, defaultClass: "i77g9og4" }, volt8: { conditions: { light: "i77g9og6", dark: "i77g9og7" }, defaultClass: "i77g9og6" }, volt9: { conditions: { light: "i77g9og8", dark: "i77g9og9" }, defaultClass: "i77g9og8" }, volt10: { conditions: { light: "i77g9oga", dark: "i77g9ogb" }, defaultClass: "i77g9oga" }, volt11: { conditions: { light: "i77g9ogc", dark: "i77g9ogd" }, defaultClass: "i77g9ogc" }, volt12: { conditions: { light: "i77g9oge", dark: "i77g9ogf" }, defaultClass: "i77g9oge" }, volt13: { conditions: { light: "i77g9ogg", dark: "i77g9ogh" }, defaultClass: "i77g9ogg" } } }, backgroundColor: { values: { transparent: { conditions: { light: "i77g9ogi", dark: "i77g9ogj" }, defaultClass: "i77g9ogi" }, current: { conditions: { light: "i77g9ogk", dark: "i77g9ogl" }, defaultClass: "i77g9ogk" }, white: { conditions: { light: "i77g9ogm", dark: "i77g9ogn" }, defaultClass: "i77g9ogm" }, black: { conditions: { light: "i77g9ogo", dark: "i77g9ogp" }, defaultClass: "i77g9ogo" }, gray100: { conditions: { light: "i77g9ogq", dark: "i77g9ogr" }, defaultClass: "i77g9ogq" }, gray200: { conditions: { light: "i77g9ogs", dark: "i77g9ogt" }, defaultClass: "i77g9ogs" }, gray300: { conditions: { light: "i77g9ogu", dark: "i77g9ogv" }, defaultClass: "i77g9ogu" }, pale100: { conditions: { light: "i77g9ogw", dark: "i77g9ogx" }, defaultClass: "i77g9ogw" }, pale200: { conditions: { light: "i77g9ogy", dark: "i77g9ogz" }, defaultClass: "i77g9ogy" }, pale300: { conditions: { light: "i77g9oh0", dark: "i77g9oh1" }, defaultClass: "i77g9oh0" }, pale400: { conditions: { light: "i77g9oh2", dark: "i77g9oh3" }, defaultClass: "i77g9oh2" }, pale500: { conditions: { light: "i77g9oh4", dark: "i77g9oh5" }, defaultClass: "i77g9oh4" }, hyper0: { conditions: { light: "i77g9oh6", dark: "i77g9oh7" }, defaultClass: "i77g9oh6" }, hyper1: { conditions: { light: "i77g9oh8", dark: "i77g9oh9" }, defaultClass: "i77g9oh8" }, hyper2: { conditions: { light: "i77g9oha", dark: "i77g9ohb" }, defaultClass: "i77g9oha" }, hyper3: { conditions: { light: "i77g9ohc", dark: "i77g9ohd" }, defaultClass: "i77g9ohc" }, hyper4: { conditions: { light: "i77g9ohe", dark: "i77g9ohf" }, defaultClass: "i77g9ohe" }, hyper5: { conditions: { light: "i77g9ohg", dark: "i77g9ohh" }, defaultClass: "i77g9ohg" }, hyper6: { conditions: { light: "i77g9ohi", dark: "i77g9ohj" }, defaultClass: "i77g9ohi" }, hyper7: { conditions: { light: "i77g9ohk", dark: "i77g9ohl" }, defaultClass: "i77g9ohk" }, hyper8: { conditions: { light: "i77g9ohm", dark: "i77g9ohn" }, defaultClass: "i77g9ohm" }, hyper9: { conditions: { light: "i77g9oho", dark: "i77g9ohp" }, defaultClass: "i77g9oho" }, hyper10: { conditions: { light: "i77g9ohq", dark: "i77g9ohr" }, defaultClass: "i77g9ohq" }, hyper11: { conditions: { light: "i77g9ohs", dark: "i77g9oht" }, defaultClass: "i77g9ohs" }, hyper12: { conditions: { light: "i77g9ohu", dark: "i77g9ohv" }, defaultClass: "i77g9ohu" }, hyper13: { conditions: { light: "i77g9ohw", dark: "i77g9ohx" }, defaultClass: "i77g9ohw" }, lemon0: { conditions: { light: "i77g9ohy", dark: "i77g9ohz" }, defaultClass: "i77g9ohy" }, lemon1: { conditions: { light: "i77g9oi0", dark: "i77g9oi1" }, defaultClass: "i77g9oi0" }, lemon2: { conditions: { light: "i77g9oi2", dark: "i77g9oi3" }, defaultClass: "i77g9oi2" }, lemon3: { conditions: { light: "i77g9oi4", dark: "i77g9oi5" }, defaultClass: "i77g9oi4" }, lemon4: { conditions: { light: "i77g9oi6", dark: "i77g9oi7" }, defaultClass: "i77g9oi6" }, lemon5: { conditions: { light: "i77g9oi8", dark: "i77g9oi9" }, defaultClass: "i77g9oi8" }, lemon6: { conditions: { light: "i77g9oia", dark: "i77g9oib" }, defaultClass: "i77g9oia" }, lemon7: { conditions: { light: "i77g9oic", dark: "i77g9oid" }, defaultClass: "i77g9oic" }, lemon8: { conditions: { light: "i77g9oie", dark: "i77g9oif" }, defaultClass: "i77g9oie" }, lemon9: { conditions: { light: "i77g9oig", dark: "i77g9oih" }, defaultClass: "i77g9oig" }, lemon10: { conditions: { light: "i77g9oii", dark: "i77g9oij" }, defaultClass: "i77g9oii" }, lemon11: { conditions: { light: "i77g9oik", dark: "i77g9oil" }, defaultClass: "i77g9oik" }, lemon12: { conditions: { light: "i77g9oim", dark: "i77g9oin" }, defaultClass: "i77g9oim" }, lemon13: { conditions: { light: "i77g9oio", dark: "i77g9oip" }, defaultClass: "i77g9oio" }, slate1: { conditions: { light: "i77g9oiq", dark: "i77g9oir" }, defaultClass: "i77g9oiq" }, slate2: { conditions: { light: "i77g9ois", dark: "i77g9oit" }, defaultClass: "i77g9ois" }, slate3: { conditions: { light: "i77g9oiu", dark: "i77g9oiv" }, defaultClass: "i77g9oiu" }, slate4: { conditions: { light: "i77g9oiw", dark: "i77g9oix" }, defaultClass: "i77g9oiw" }, slate5: { conditions: { light: "i77g9oiy", dark: "i77g9oiz" }, defaultClass: "i77g9oiy" }, slate6: { conditions: { light: "i77g9oj0", dark: "i77g9oj1" }, defaultClass: "i77g9oj0" }, slate7: { conditions: { light: "i77g9oj2", dark: "i77g9oj3" }, defaultClass: "i77g9oj2" }, slate8: { conditions: { light: "i77g9oj4", dark: "i77g9oj5" }, defaultClass: "i77g9oj4" }, slate9: { conditions: { light: "i77g9oj6", dark: "i77g9oj7" }, defaultClass: "i77g9oj6" }, slate10: { conditions: { light: "i77g9oj8", dark: "i77g9oj9" }, defaultClass: "i77g9oj8" }, slate11: { conditions: { light: "i77g9oja", dark: "i77g9ojb" }, defaultClass: "i77g9oja" }, slate12: { conditions: { light: "i77g9ojc", dark: "i77g9ojd" }, defaultClass: "i77g9ojc" }, slate13: { conditions: { light: "i77g9oje", dark: "i77g9ojf" }, defaultClass: "i77g9oje" }, sapphire0: { conditions: { light: "i77g9ojg", dark: "i77g9ojh" }, defaultClass: "i77g9ojg" }, sapphire1: { conditions: { light: "i77g9oji", dark: "i77g9ojj" }, defaultClass: "i77g9oji" }, sapphire2: { conditions: { light: "i77g9ojk", dark: "i77g9ojl" }, defaultClass: "i77g9ojk" }, sapphire3: { conditions: { light: "i77g9ojm", dark: "i77g9ojn" }, defaultClass: "i77g9ojm" }, sapphire4: { conditions: { light: "i77g9ojo", dark: "i77g9ojp" }, defaultClass: "i77g9ojo" }, sapphire5: { conditions: { light: "i77g9ojq", dark: "i77g9ojr" }, defaultClass: "i77g9ojq" }, sapphire6: { conditions: { light: "i77g9ojs", dark: "i77g9ojt" }, defaultClass: "i77g9ojs" }, sapphire7: { conditions: { light: "i77g9oju", dark: "i77g9ojv" }, defaultClass: "i77g9oju" }, sapphire8: { conditions: { light: "i77g9ojw", dark: "i77g9ojx" }, defaultClass: "i77g9ojw" }, sapphire9: { conditions: { light: "i77g9ojy", dark: "i77g9ojz" }, defaultClass: "i77g9ojy" }, sapphire10: { conditions: { light: "i77g9ok0", dark: "i77g9ok1" }, defaultClass: "i77g9ok0" }, sapphire11: { conditions: { light: "i77g9ok2", dark: "i77g9ok3" }, defaultClass: "i77g9ok2" }, sapphire12: { conditions: { light: "i77g9ok4", dark: "i77g9ok5" }, defaultClass: "i77g9ok4" }, sapphire13: { conditions: { light: "i77g9ok6", dark: "i77g9ok7" }, defaultClass: "i77g9ok6" }, volt0: { conditions: { light: "i77g9ok8", dark: "i77g9ok9" }, defaultClass: "i77g9ok8" }, volt1: { conditions: { light: "i77g9oka", dark: "i77g9okb" }, defaultClass: "i77g9oka" }, volt2: { conditions: { light: "i77g9okc", dark: "i77g9okd" }, defaultClass: "i77g9okc" }, volt3: { conditions: { light: "i77g9oke", dark: "i77g9okf" }, defaultClass: "i77g9oke" }, volt4: { conditions: { light: "i77g9okg", dark: "i77g9okh" }, defaultClass: "i77g9okg" }, volt5: { conditions: { light: "i77g9oki", dark: "i77g9okj" }, defaultClass: "i77g9oki" }, volt6: { conditions: { light: "i77g9okk", dark: "i77g9okl" }, defaultClass: "i77g9okk" }, volt7: { conditions: { light: "i77g9okm", dark: "i77g9okn" }, defaultClass: "i77g9okm" }, volt8: { conditions: { light: "i77g9oko", dark: "i77g9okp" }, defaultClass: "i77g9oko" }, volt9: { conditions: { light: "i77g9okq", dark: "i77g9okr" }, defaultClass: "i77g9okq" }, volt10: { conditions: { light: "i77g9oks", dark: "i77g9okt" }, defaultClass: "i77g9oks" }, volt11: { conditions: { light: "i77g9oku", dark: "i77g9okv" }, defaultClass: "i77g9oku" }, volt12: { conditions: { light: "i77g9okw", dark: "i77g9okx" }, defaultClass: "i77g9okw" }, volt13: { conditions: { light: "i77g9oky", dark: "i77g9okz" }, defaultClass: "i77g9oky" } } }, borderColor: { values: { transparent: { conditions: { light: "i77g9ol0", dark: "i77g9ol1" }, defaultClass: "i77g9ol0" }, current: { conditions: { light: "i77g9ol2", dark: "i77g9ol3" }, defaultClass: "i77g9ol2" }, white: { conditions: { light: "i77g9ol4", dark: "i77g9ol5" }, defaultClass: "i77g9ol4" }, black: { conditions: { light: "i77g9ol6", dark: "i77g9ol7" }, defaultClass: "i77g9ol6" }, gray100: { conditions: { light: "i77g9ol8", dark: "i77g9ol9" }, defaultClass: "i77g9ol8" }, gray200: { conditions: { light: "i77g9ola", dark: "i77g9olb" }, defaultClass: "i77g9ola" }, gray300: { conditions: { light: "i77g9olc", dark: "i77g9old" }, defaultClass: "i77g9olc" }, pale100: { conditions: { light: "i77g9ole", dark: "i77g9olf" }, defaultClass: "i77g9ole" }, pale200: { conditions: { light: "i77g9olg", dark: "i77g9olh" }, defaultClass: "i77g9olg" }, pale300: { conditions: { light: "i77g9oli", dark: "i77g9olj" }, defaultClass: "i77g9oli" }, pale400: { conditions: { light: "i77g9olk", dark: "i77g9oll" }, defaultClass: "i77g9olk" }, pale500: { conditions: { light: "i77g9olm", dark: "i77g9oln" }, defaultClass: "i77g9olm" }, hyper0: { conditions: { light: "i77g9olo", dark: "i77g9olp" }, defaultClass: "i77g9olo" }, hyper1: { conditions: { light: "i77g9olq", dark: "i77g9olr" }, defaultClass: "i77g9olq" }, hyper2: { conditions: { light: "i77g9ols", dark: "i77g9olt" }, defaultClass: "i77g9ols" }, hyper3: { conditions: { light: "i77g9olu", dark: "i77g9olv" }, defaultClass: "i77g9olu" }, hyper4: { conditions: { light: "i77g9olw", dark: "i77g9olx" }, defaultClass: "i77g9olw" }, hyper5: { conditions: { light: "i77g9oly", dark: "i77g9olz" }, defaultClass: "i77g9oly" }, hyper6: { conditions: { light: "i77g9om0", dark: "i77g9om1" }, defaultClass: "i77g9om0" }, hyper7: { conditions: { light: "i77g9om2", dark: "i77g9om3" }, defaultClass: "i77g9om2" }, hyper8: { conditions: { light: "i77g9om4", dark: "i77g9om5" }, defaultClass: "i77g9om4" }, hyper9: { conditions: { light: "i77g9om6", dark: "i77g9om7" }, defaultClass: "i77g9om6" }, hyper10: { conditions: { light: "i77g9om8", dark: "i77g9om9" }, defaultClass: "i77g9om8" }, hyper11: { conditions: { light: "i77g9oma", dark: "i77g9omb" }, defaultClass: "i77g9oma" }, hyper12: { conditions: { light: "i77g9omc", dark: "i77g9omd" }, defaultClass: "i77g9omc" }, hyper13: { conditions: { light: "i77g9ome", dark: "i77g9omf" }, defaultClass: "i77g9ome" }, lemon0: { conditions: { light: "i77g9omg", dark: "i77g9omh" }, defaultClass: "i77g9omg" }, lemon1: { conditions: { light: "i77g9omi", dark: "i77g9omj" }, defaultClass: "i77g9omi" }, lemon2: { conditions: { light: "i77g9omk", dark: "i77g9oml" }, defaultClass: "i77g9omk" }, lemon3: { conditions: { light: "i77g9omm", dark: "i77g9omn" }, defaultClass: "i77g9omm" }, lemon4: { conditions: { light: "i77g9omo", dark: "i77g9omp" }, defaultClass: "i77g9omo" }, lemon5: { conditions: { light: "i77g9omq", dark: "i77g9omr" }, defaultClass: "i77g9omq" }, lemon6: { conditions: { light: "i77g9oms", dark: "i77g9omt" }, defaultClass: "i77g9oms" }, lemon7: { conditions: { light: "i77g9omu", dark: "i77g9omv" }, defaultClass: "i77g9omu" }, lemon8: { conditions: { light: "i77g9omw", dark: "i77g9omx" }, defaultClass: "i77g9omw" }, lemon9: { conditions: { light: "i77g9omy", dark: "i77g9omz" }, defaultClass: "i77g9omy" }, lemon10: { conditions: { light: "i77g9on0", dark: "i77g9on1" }, defaultClass: "i77g9on0" }, lemon11: { conditions: { light: "i77g9on2", dark: "i77g9on3" }, defaultClass: "i77g9on2" }, lemon12: { conditions: { light: "i77g9on4", dark: "i77g9on5" }, defaultClass: "i77g9on4" }, lemon13: { conditions: { light: "i77g9on6", dark: "i77g9on7" }, defaultClass: "i77g9on6" }, slate1: { conditions: { light: "i77g9on8", dark: "i77g9on9" }, defaultClass: "i77g9on8" }, slate2: { conditions: { light: "i77g9ona", dark: "i77g9onb" }, defaultClass: "i77g9ona" }, slate3: { conditions: { light: "i77g9onc", dark: "i77g9ond" }, defaultClass: "i77g9onc" }, slate4: { conditions: { light: "i77g9one", dark: "i77g9onf" }, defaultClass: "i77g9one" }, slate5: { conditions: { light: "i77g9ong", dark: "i77g9onh" }, defaultClass: "i77g9ong" }, slate6: { conditions: { light: "i77g9oni", dark: "i77g9onj" }, defaultClass: "i77g9oni" }, slate7: { conditions: { light: "i77g9onk", dark: "i77g9onl" }, defaultClass: "i77g9onk" }, slate8: { conditions: { light: "i77g9onm", dark: "i77g9onn" }, defaultClass: "i77g9onm" }, slate9: { conditions: { light: "i77g9ono", dark: "i77g9onp" }, defaultClass: "i77g9ono" }, slate10: { conditions: { light: "i77g9onq", dark: "i77g9onr" }, defaultClass: "i77g9onq" }, slate11: { conditions: { light: "i77g9ons", dark: "i77g9ont" }, defaultClass: "i77g9ons" }, slate12: { conditions: { light: "i77g9onu", dark: "i77g9onv" }, defaultClass: "i77g9onu" }, slate13: { conditions: { light: "i77g9onw", dark: "i77g9onx" }, defaultClass: "i77g9onw" }, sapphire0: { conditions: { light: "i77g9ony", dark: "i77g9onz" }, defaultClass: "i77g9ony" }, sapphire1: { conditions: { light: "i77g9oo0", dark: "i77g9oo1" }, defaultClass: "i77g9oo0" }, sapphire2: { conditions: { light: "i77g9oo2", dark: "i77g9oo3" }, defaultClass: "i77g9oo2" }, sapphire3: { conditions: { light: "i77g9oo4", dark: "i77g9oo5" }, defaultClass: "i77g9oo4" }, sapphire4: { conditions: { light: "i77g9oo6", dark: "i77g9oo7" }, defaultClass: "i77g9oo6" }, sapphire5: { conditions: { light: "i77g9oo8", dark: "i77g9oo9" }, defaultClass: "i77g9oo8" }, sapphire6: { conditions: { light: "i77g9ooa", dark: "i77g9oob" }, defaultClass: "i77g9ooa" }, sapphire7: { conditions: { light: "i77g9ooc", dark: "i77g9ood" }, defaultClass: "i77g9ooc" }, sapphire8: { conditions: { light: "i77g9ooe", dark: "i77g9oof" }, defaultClass: "i77g9ooe" }, sapphire9: { conditions: { light: "i77g9oog", dark: "i77g9ooh" }, defaultClass: "i77g9oog" }, sapphire10: { conditions: { light: "i77g9ooi", dark: "i77g9ooj" }, defaultClass: "i77g9ooi" }, sapphire11: { conditions: { light: "i77g9ook", dark: "i77g9ool" }, defaultClass: "i77g9ook" }, sapphire12: { conditions: { light: "i77g9oom", dark: "i77g9oon" }, defaultClass: "i77g9oom" }, sapphire13: { conditions: { light: "i77g9ooo", dark: "i77g9oop" }, defaultClass: "i77g9ooo" }, volt0: { conditions: { light: "i77g9ooq", dark: "i77g9oor" }, defaultClass: "i77g9ooq" }, volt1: { conditions: { light: "i77g9oos", dark: "i77g9oot" }, defaultClass: "i77g9oos" }, volt2: { conditions: { light: "i77g9oou", dark: "i77g9oov" }, defaultClass: "i77g9oou" }, volt3: { conditions: { light: "i77g9oow", dark: "i77g9oox" }, defaultClass: "i77g9oow" }, volt4: { conditions: { light: "i77g9ooy", dark: "i77g9ooz" }, defaultClass: "i77g9ooy" }, volt5: { conditions: { light: "i77g9op0", dark: "i77g9op1" }, defaultClass: "i77g9op0" }, volt6: { conditions: { light: "i77g9op2", dark: "i77g9op3" }, defaultClass: "i77g9op2" }, volt7: { conditions: { light: "i77g9op4", dark: "i77g9op5" }, defaultClass: "i77g9op4" }, volt8: { conditions: { light: "i77g9op6", dark: "i77g9op7" }, defaultClass: "i77g9op6" }, volt9: { conditions: { light: "i77g9op8", dark: "i77g9op9" }, defaultClass: "i77g9op8" }, volt10: { conditions: { light: "i77g9opa", dark: "i77g9opb" }, defaultClass: "i77g9opa" }, volt11: { conditions: { light: "i77g9opc", dark: "i77g9opd" }, defaultClass: "i77g9opc" }, volt12: { conditions: { light: "i77g9ope", dark: "i77g9opf" }, defaultClass: "i77g9ope" }, volt13: { conditions: { light: "i77g9opg", dark: "i77g9oph" }, defaultClass: "i77g9opg" } } } } });
const la = ({ reset: e, ...t }) => {
  const o = Vn(t), n = e ? [Jr, Qr[e]] : null;
  return z(n, o);
}, Ad = {
  small: 0,
  medium: 768,
  large: 1200,
  xlarge: 1600
};
var Rd = ca, pt = { base: "_1oxbat10", light: "_1oxbat154", dark: "_1oxbat155" }, ca = { media: { breakpoints: { small: "var(--_1oxbat11)", medium: "var(--_1oxbat12)", large: "var(--_1oxbat13)", xlarge: "var(--_1oxbat14)" }, colorModes: { LIGHT: "var(--_1oxbat15)", DARK: "var(--_1oxbat16)" } }, font: { family: { system: "var(--_1oxbat17)", mono: "var(--_1oxbat18)" }, heading: { H1: "var(--_1oxbat19)", H2: "var(--_1oxbat1a)", H3: "var(--_1oxbat1b)", H4: "var(--_1oxbat1c)", H5: "var(--_1oxbat1d)", H6: "var(--_1oxbat1e)" }, size: { MINI: "var(--_1oxbat1f)", XS: "var(--_1oxbat1g)", SM: "var(--_1oxbat1h)", MD: "var(--_1oxbat1i)", LG: "var(--_1oxbat1j)", XL: "var(--_1oxbat1k)", XXL: "var(--_1oxbat1l)", "3XL": "var(--_1oxbat1m)", "4XL": "var(--_1oxbat1n)", "5XL": "var(--_1oxbat1o)", "6XL": "var(--_1oxbat1p)", "7XL": "var(--_1oxbat1q)", "8XL": "var(--_1oxbat1r)", "9XL": "var(--_1oxbat1s)" }, lineheight: { MINI: "var(--_1oxbat1t)", XS: "var(--_1oxbat1u)", SM: "var(--_1oxbat1v)", MD: "var(--_1oxbat1w)", LG: "var(--_1oxbat1x)", XL: "var(--_1oxbat1y)", XXL: "var(--_1oxbat1z)", "3XL": "var(--_1oxbat110)", "4XL": "var(--_1oxbat111)", "5XL": "var(--_1oxbat112)", "6XL": "var(--_1oxbat113)", "7XL": "var(--_1oxbat114)", "8XL": "var(--_1oxbat115)", "9XL": "var(--_1oxbat116)" }, weight: { SUPRLITE: "var(--_1oxbat117)", ULTRALITE: "var(--_1oxbat118)", LITE: "var(--_1oxbat119)", REGULAR: "var(--_1oxbat11a)", MEDIUM: "var(--_1oxbat11b)", SEMIBOLD: "var(--_1oxbat11c)", BOLD: "var(--_1oxbat11d)", HEAVY: "var(--_1oxbat11e)", BLACK: "var(--_1oxbat11f)" } }, radii: { ZERO: "var(--_1oxbat11g)", NO: "var(--_1oxbat11h)", DF: "var(--_1oxbat11i)", XS: "var(--_1oxbat11j)", SM: "var(--_1oxbat11k)", MD: "var(--_1oxbat11l)", LG: "var(--_1oxbat11m)", XL: "var(--_1oxbat11n)", XXL: "var(--_1oxbat11o)", PILL: "var(--_1oxbat11p)" }, space: { ZERO: "var(--_1oxbat11q)", NO: "var(--_1oxbat11r)", DF: "var(--_1oxbat11s)", APX: "var(--_1oxbat11t)", BPX: "var(--_1oxbat11u)", CPX: "var(--_1oxbat11v)", DPX: "var(--_1oxbat11w)", EPX: "var(--_1oxbat11x)", FPX: "var(--_1oxbat11y)", GPX: "var(--_1oxbat11z)", HPX: "var(--_1oxbat120)", IPX: "var(--_1oxbat121)", JPX: "var(--_1oxbat122)", KPX: "var(--_1oxbat123)", LPX: "var(--_1oxbat124)", MPX: "var(--_1oxbat125)", NPX: "var(--_1oxbat126)", OPX: "var(--_1oxbat127)", PPX: "var(--_1oxbat128)", QPX: "var(--_1oxbat129)", RPX: "var(--_1oxbat12a)", SPX: "var(--_1oxbat12b)", TPX: "var(--_1oxbat12c)", UPX: "var(--_1oxbat12d)", VPX: "var(--_1oxbat12e)", WPX: "var(--_1oxbat12f)", XPX: "var(--_1oxbat12g)", YPX: "var(--_1oxbat12h)", ZPX: "var(--_1oxbat12i)" }, z: { indice: { ZERO: "var(--_1oxbat12j)", DF: "var(--_1oxbat12k)", LOW: "var(--_1oxbat12l)", MED: "var(--_1oxbat12m)", HIGH: "var(--_1oxbat12n)", TOP: "var(--_1oxbat12o)", MAX: "var(--_1oxbat12p)" } }, shadow: { NO: "var(--_1oxbat12q)", DF: "var(--_1oxbat12r)", LOW: "var(--_1oxbat12s)", MED: "var(--_1oxbat12t)", HIGH: "var(--_1oxbat12u)" }, color: { transparent: "var(--_1oxbat12v)", current: "var(--_1oxbat12w)", white: "var(--_1oxbat12x)", black: "var(--_1oxbat12y)", gray100: "var(--_1oxbat12z)", gray200: "var(--_1oxbat130)", gray300: "var(--_1oxbat131)", pale100: "var(--_1oxbat132)", pale200: "var(--_1oxbat133)", pale300: "var(--_1oxbat134)", pale400: "var(--_1oxbat135)", pale500: "var(--_1oxbat136)", hyper0: "var(--_1oxbat137)", hyper1: "var(--_1oxbat138)", hyper2: "var(--_1oxbat139)", hyper3: "var(--_1oxbat13a)", hyper4: "var(--_1oxbat13b)", hyper5: "var(--_1oxbat13c)", hyper6: "var(--_1oxbat13d)", hyper7: "var(--_1oxbat13e)", hyper8: "var(--_1oxbat13f)", hyper9: "var(--_1oxbat13g)", hyper10: "var(--_1oxbat13h)", hyper11: "var(--_1oxbat13i)", hyper12: "var(--_1oxbat13j)", hyper13: "var(--_1oxbat13k)", lemon0: "var(--_1oxbat13l)", lemon1: "var(--_1oxbat13m)", lemon2: "var(--_1oxbat13n)", lemon3: "var(--_1oxbat13o)", lemon4: "var(--_1oxbat13p)", lemon5: "var(--_1oxbat13q)", lemon6: "var(--_1oxbat13r)", lemon7: "var(--_1oxbat13s)", lemon8: "var(--_1oxbat13t)", lemon9: "var(--_1oxbat13u)", lemon10: "var(--_1oxbat13v)", lemon11: "var(--_1oxbat13w)", lemon12: "var(--_1oxbat13x)", lemon13: "var(--_1oxbat13y)", slate1: "var(--_1oxbat13z)", slate2: "var(--_1oxbat140)", slate3: "var(--_1oxbat141)", slate4: "var(--_1oxbat142)", slate5: "var(--_1oxbat143)", slate6: "var(--_1oxbat144)", slate7: "var(--_1oxbat145)", slate8: "var(--_1oxbat146)", slate9: "var(--_1oxbat147)", slate10: "var(--_1oxbat148)", slate11: "var(--_1oxbat149)", slate12: "var(--_1oxbat14a)", slate13: "var(--_1oxbat14b)", sapphire0: "var(--_1oxbat14c)", sapphire1: "var(--_1oxbat14d)", sapphire2: "var(--_1oxbat14e)", sapphire3: "var(--_1oxbat14f)", sapphire4: "var(--_1oxbat14g)", sapphire5: "var(--_1oxbat14h)", sapphire6: "var(--_1oxbat14i)", sapphire7: "var(--_1oxbat14j)", sapphire8: "var(--_1oxbat14k)", sapphire9: "var(--_1oxbat14l)", sapphire10: "var(--_1oxbat14m)", sapphire11: "var(--_1oxbat14n)", sapphire12: "var(--_1oxbat14o)", sapphire13: "var(--_1oxbat14p)", volt0: "var(--_1oxbat14q)", volt1: "var(--_1oxbat14r)", volt2: "var(--_1oxbat14s)", volt3: "var(--_1oxbat14t)", volt4: "var(--_1oxbat14u)", volt5: "var(--_1oxbat14v)", volt6: "var(--_1oxbat14w)", volt7: "var(--_1oxbat14x)", volt8: "var(--_1oxbat14y)", volt9: "var(--_1oxbat14z)", volt10: "var(--_1oxbat150)", volt11: "var(--_1oxbat151)", volt12: "var(--_1oxbat152)", volt13: "var(--_1oxbat153)" } };
const da = {
  light: `html:not(${pt.light}) &`,
  dark: `html${pt.dark} &`
}, Qo = (e, t) => !t || Object.keys(t).length === 0 ? {} : {
  [da[e]]: t
}, Od = ({ lightMode: e, darkMode: t }) => ({
  ...e || t ? {
    selectors: {
      ...Qo("light", e),
      ...Qo("dark", t)
    }
  } : {}
}), Wn = ht({
  theme: "light",
  toggleTheme: null
}), Nd = () => {
  const e = Mt(Wn);
  if (!e)
    throw new Error("Atelier® Kit components must be used within [KitProvider]");
  return e;
}, qd = ({
  children: e
}) => {
  const [t, o] = G("light"), n = () => {
    o((r) => r === "light" ? "dark" : "light");
  }, i = t === "light" ? pt.dark : pt.light;
  return /* @__PURE__ */ w.jsx(Wn.Provider, { value: { theme: t, toggleTheme: n }, children: /* @__PURE__ */ w.jsx("div", { className: `${pt.base} ${i}`, children: e }) });
}, ua = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M12.0916 14.9959C12.2854 14.9802 12.4708 14.902 12.6225 14.7846L16.6417 11.583C16.8439 11.4343 16.9703 11.2151 16.9956 10.9725C17.0209 10.7298 16.9366 10.495 16.7681 10.3149C16.5996 10.1349 16.3552 10.0175 16.1024 10.0096C15.8412 9.99399 15.5884 10.0801 15.3946 10.2366L11.9989 12.945L8.60325 10.2366C8.40945 10.0723 8.15667 9.98616 7.90388 10.0018C7.64268 10.0175 7.39832 10.1271 7.2298 10.3149C7.06128 10.495 6.98545 10.7376 7.0023 10.9725C7.02758 11.2151 7.15397 11.4343 7.35619 11.583L11.3754 14.7846C11.5692 14.9411 11.8304 15.0194 12.0832 14.9959H12.0916Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
), jd = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, {}), fa = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M15.3529 1L8.64709 1C8.08172 1 7.78927 1.71527 8.17595 2.15231L11.2933 5.67559C11.676 6.10814 12.324 6.10814 12.7067 5.67559L15.8241 2.15231C16.2107 1.71527 15.9183 1 15.3529 1Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
) }), ga = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M8.64709 6H15.3529C15.9183 6 16.2107 5.28473 15.8241 4.84769L12.7067 1.32441C12.324 0.891862 11.676 0.891862 11.2933 1.32441L8.17595 4.84769C7.78927 5.28473 8.08172 6 8.64709 6Z",
        fill: e,
        "fill-rule": "evenodd",
        "clip-rule": "evenodd"
      }
    )
  }
) }), _t = {
  background: "#9E9CA6",
  inner: "#F6F4F0"
}, zd = ({
  color: e = _t.background,
  width: t,
  height: o,
  ...n
}) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsxs(
  "svg",
  {
    width: t || "18",
    height: o || "18",
    viewBox: "0 0 18 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...n,
    children: [
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M6.9 16H11.1C14.6 16 16 14.6 16 11.1V6.9C16 3.4 14.6 2 11.1 2H6.9C3.4 2 2 3.4 2 6.9V11.1C2 14.6 3.4 16 6.9 16Z",
          fill: e,
          stroke: e,
          strokeWidth: "1.4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M7.14 6.49999L4 11.5H6.68L7.15 10.7H10.8L11.26 11.5H14L10.86 6.49999H7.14ZM7.82 9.53999L8.98 7.55999L10.12 9.53999H7.82Z",
          fill: _t.inner
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M12.35 8.14999C12.44 8.23999 12.54 8.30999 12.66 8.35999C12.78 8.40999 12.9 8.42999 13.04 8.42999C13.18 8.42999 13.3 8.40999 13.42 8.35999C13.54 8.30999 13.64 8.23999 13.73 8.14999C13.82 8.05999 13.89 7.95999 13.94 7.83999C13.99 7.71999 14.01 7.59999 14.01 7.45999C14.01 7.31999 13.99 7.19999 13.94 7.07999C13.89 6.95999 13.82 6.85999 13.73 6.76999C13.64 6.67999 13.54 6.60999 13.42 6.55999C13.3 6.50999 13.18 6.48999 13.04 6.48999C12.9 6.48999 12.78 6.50999 12.66 6.55999C12.54 6.60999 12.44 6.67999 12.35 6.76999C12.26 6.85999 12.19 6.95999 12.14 7.07999C12.09 7.19999 12.07 7.31999 12.07 7.45999C12.07 7.59999 12.09 7.71999 12.14 7.83999C12.19 7.95999 12.26 8.05999 12.35 8.14999ZM12.4 7.09999C12.47 6.98999 12.55 6.89999 12.66 6.83999C12.77 6.76999 12.89 6.73999 13.03 6.73999C13.17 6.73999 13.29 6.76999 13.39 6.83999C13.5 6.89999 13.59 6.98999 13.65 7.09999C13.72 7.20999 13.75 7.32999 13.75 7.46999C13.75 7.60999 13.72 7.72999 13.65 7.82999C13.59 7.93999 13.5 8.02999 13.39 8.08999C13.28 8.15999 13.16 8.18999 13.03 8.18999C12.9 8.18999 12.77 8.15999 12.66 8.08999C12.55 8.01999 12.46 7.93999 12.4 7.82999C12.33 7.71999 12.3 7.59999 12.3 7.46999C12.3 7.33999 12.33 7.20999 12.4 7.09999Z",
          fill: _t.inner
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M12.9 7.59999H13.08L13.23 7.89999H13.46L13.28 7.54999C13.28 7.54999 13.35 7.49999 13.38 7.45999C13.41 7.40999 13.43 7.35999 13.43 7.29999C13.43 7.23999 13.42 7.17999 13.39 7.13999C13.36 7.09999 13.32 7.05999 13.28 7.03999C13.24 7.01999 13.19 7.00999 13.15 7.00999H12.71V7.89999H12.92V7.59999H12.9ZM13.07 7.15999C13.07 7.15999 13.12 7.15999 13.15 7.18999C13.18 7.20999 13.19 7.23999 13.19 7.29999C13.19 7.35999 13.18 7.38999 13.15 7.40999C13.12 7.42999 13.09 7.44999 13.06 7.44999H12.89V7.16999H13.06L13.07 7.15999Z",
          fill: _t.inner
        }
      )
    ]
  }
) }), ko = D(
  ({ as: e = "div", className: t, ...o }, n) => {
    const i = {}, r = {};
    for (const a in o)
      Vn.properties.has(a) ? i[a] = o[a] : r[a] = o[a];
    const s = la({
      reset: typeof e == "string" ? e : "div",
      ...i
    });
    return $(e, {
      className: z(s, t),
      ...r,
      ref: n
    });
  }
);
ko.displayName = "RectBox";
const Dd = H.forwardRef(function({
  children: t,
  gridItemMinWidth: o = "300px",
  gridMaxRowItems: n,
  style: i = {},
  ...r
}, s) {
  return /* @__PURE__ */ w.jsx(
    ko,
    {
      ...r,
      ref: s,
      className: `${Xr} ${r.className ?? ""}`,
      style: {
        ...i,
        ...Zr({
          [Kr]: o,
          [Yr]: n && String(n) || String(Ue.count(t))
        })
      },
      flexDirection: "row",
      children: t
    }
  );
});
var pa = be({ defaultClassName: "_1n0su94k", variantClassNames: { font: { system: "_1n0su940", mono: "_1n0su941" }, size: { display: "_1n0su942", H1: "_1n0su943", H2: "_1n0su944", H3: "_1n0su945", H4: "_1n0su946", H5: "_1n0su947", H6: "_1n0su948" }, weight: { superlite: "_1n0su949", lite: "_1n0su94a", normal: "_1n0su94b", medium: "_1n0su94c", semibold: "_1n0su94d", bold: "_1n0su94e", heavy: "_1n0su94f", black: "_1n0su94g" }, align: { left: "_1n0su94h", center: "_1n0su94i", right: "_1n0su94j" } }, defaultVariants: { font: "system", size: "H1", weight: "semibold", align: "left" }, compoundVariants: [] });
const va = H.forwardRef(
  ({
    className: e,
    font: t = "system",
    size: o = "H1",
    weight: n = "semibold",
    align: i = "left",
    ...r
  }, s) => /* @__PURE__ */ w.jsx(
    "h1",
    {
      ...r,
      ref: s,
      className: z(e, pa({ font: t, size: o, weight: n, align: i }))
    }
  )
);
va.displayName = "Heading";
function M() {
  return M = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var o = arguments[t];
      for (var n in o)
        Object.prototype.hasOwnProperty.call(o, n) && (e[n] = o[n]);
    }
    return e;
  }, M.apply(this, arguments);
}
function oe(e, t, { checkForDefaultPrevented: o = !0 } = {}) {
  return function(i) {
    if (e == null || e(i), o === !1 || !i.defaultPrevented)
      return t == null ? void 0 : t(i);
  };
}
function Ft(e, t = []) {
  let o = [];
  function n(r, s) {
    const a = /* @__PURE__ */ ht(s), l = o.length;
    o = [
      ...o,
      s
    ];
    function d(u) {
      const { scope: m, children: p, ...v } = u, g = (m == null ? void 0 : m[e][l]) || a, h = at(
        () => v,
        Object.values(v)
      );
      return /* @__PURE__ */ $(g.Provider, {
        value: h
      }, p);
    }
    function f(u, m) {
      const p = (m == null ? void 0 : m[e][l]) || a, v = Mt(p);
      if (v)
        return v;
      if (s !== void 0)
        return s;
      throw new Error(`\`${u}\` must be used within \`${r}\``);
    }
    return d.displayName = r + "Provider", [
      d,
      f
    ];
  }
  const i = () => {
    const r = o.map((s) => /* @__PURE__ */ ht(s));
    return function(a) {
      const l = (a == null ? void 0 : a[e]) || r;
      return at(
        () => ({
          [`__scope${e}`]: {
            ...a,
            [e]: l
          }
        }),
        [
          a,
          l
        ]
      );
    };
  };
  return i.scopeName = e, [
    n,
    ma(i, ...t)
  ];
}
function ma(...e) {
  const t = e[0];
  if (e.length === 1)
    return t;
  const o = () => {
    const n = e.map(
      (i) => ({
        useScope: i(),
        scopeName: i.scopeName
      })
    );
    return function(r) {
      const s = n.reduce((a, { useScope: l, scopeName: d }) => {
        const u = l(r)[`__scope${d}`];
        return {
          ...a,
          ...u
        };
      }, {});
      return at(
        () => ({
          [`__scope${t.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return o.scopeName = t.scopeName, o;
}
function De(e) {
  const t = ne(e);
  return ie(() => {
    t.current = e;
  }), at(
    () => (...o) => {
      var n;
      return (n = t.current) === null || n === void 0 ? void 0 : n.call(t, ...o);
    },
    []
  );
}
function go({ prop: e, defaultProp: t, onChange: o = () => {
} }) {
  const [n, i] = ha({
    defaultProp: t,
    onChange: o
  }), r = e !== void 0, s = r ? e : n, a = De(o), l = le((d) => {
    if (r) {
      const u = typeof d == "function" ? d(e) : d;
      u !== e && a(u);
    } else
      i(d);
  }, [
    r,
    e,
    i,
    a
  ]);
  return [
    s,
    l
  ];
}
function ha({ defaultProp: e, onChange: t }) {
  const o = G(e), [n] = o, i = ne(n), r = De(t);
  return ie(() => {
    i.current !== n && (r(n), i.current = n);
  }, [
    n,
    i,
    r
  ]), o;
}
function ya(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Bn(...e) {
  return (t) => e.forEach(
    (o) => ya(o, t)
  );
}
function ge(...e) {
  return le(Bn(...e), e);
}
function ct(e) {
  return e.split("-")[1];
}
function So(e) {
  return e === "y" ? "height" : "width";
}
function ze(e) {
  return e.split("-")[0];
}
function Ye(e) {
  return ["top", "bottom"].includes(ze(e)) ? "x" : "y";
}
function en(e, t, o) {
  let { reference: n, floating: i } = e;
  const r = n.x + n.width / 2 - i.width / 2, s = n.y + n.height / 2 - i.height / 2, a = Ye(t), l = So(a), d = n[l] / 2 - i[l] / 2, f = a === "x";
  let u;
  switch (ze(t)) {
    case "top":
      u = { x: r, y: n.y - i.height };
      break;
    case "bottom":
      u = { x: r, y: n.y + n.height };
      break;
    case "right":
      u = { x: n.x + n.width, y: s };
      break;
    case "left":
      u = { x: n.x - i.width, y: s };
      break;
    default:
      u = { x: n.x, y: n.y };
  }
  switch (ct(t)) {
    case "start":
      u[a] -= d * (o && f ? -1 : 1);
      break;
    case "end":
      u[a] += d * (o && f ? -1 : 1);
  }
  return u;
}
const ba = async (e, t, o) => {
  const { placement: n = "bottom", strategy: i = "absolute", middleware: r = [], platform: s } = o, a = r.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let d = await s.getElementRects({ reference: e, floating: t, strategy: i }), { x: f, y: u } = en(d, n, l), m = n, p = {}, v = 0;
  for (let g = 0; g < a.length; g++) {
    const { name: h, fn: b } = a[g], { x: y, y: x, data: _, reset: S } = await b({ x: f, y: u, initialPlacement: n, placement: m, strategy: i, middlewareData: p, rects: d, platform: s, elements: { reference: e, floating: t } });
    f = y ?? f, u = x ?? u, p = { ...p, [h]: { ...p[h], ..._ } }, S && v <= 50 && (v++, typeof S == "object" && (S.placement && (m = S.placement), S.rects && (d = S.rects === !0 ? await s.getElementRects({ reference: e, floating: t, strategy: i }) : S.rects), { x: f, y: u } = en(d, m, l)), g = -1);
  }
  return { x: f, y: u, placement: m, strategy: i, middlewareData: p };
};
function Un(e) {
  return typeof e != "number" ? function(t) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...t };
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function jt(e) {
  return { ...e, top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height };
}
async function yt(e, t) {
  var o;
  t === void 0 && (t = {});
  const { x: n, y: i, platform: r, rects: s, elements: a, strategy: l } = e, { boundary: d = "clippingAncestors", rootBoundary: f = "viewport", elementContext: u = "floating", altBoundary: m = !1, padding: p = 0 } = t, v = Un(p), g = a[m ? u === "floating" ? "reference" : "floating" : u], h = jt(await r.getClippingRect({ element: (o = await (r.isElement == null ? void 0 : r.isElement(g))) == null || o ? g : g.contextElement || await (r.getDocumentElement == null ? void 0 : r.getDocumentElement(a.floating)), boundary: d, rootBoundary: f, strategy: l })), b = u === "floating" ? { ...s.floating, x: n, y: i } : s.reference, y = await (r.getOffsetParent == null ? void 0 : r.getOffsetParent(a.floating)), x = await (r.isElement == null ? void 0 : r.isElement(y)) && await (r.getScale == null ? void 0 : r.getScale(y)) || { x: 1, y: 1 }, _ = jt(r.convertOffsetParentRelativeRectToViewportRelativeRect ? await r.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: b, offsetParent: y, strategy: l }) : b);
  return { top: (h.top - _.top + v.top) / x.y, bottom: (_.bottom - h.bottom + v.bottom) / x.y, left: (h.left - _.left + v.left) / x.x, right: (_.right - h.right + v.right) / x.x };
}
const po = Math.min, Be = Math.max;
function vo(e, t, o) {
  return Be(e, po(t, o));
}
const tn = (e) => ({ name: "arrow", options: e, async fn(t) {
  const { element: o, padding: n = 0 } = e || {}, { x: i, y: r, placement: s, rects: a, platform: l, elements: d } = t;
  if (o == null)
    return {};
  const f = Un(n), u = { x: i, y: r }, m = Ye(s), p = So(m), v = await l.getDimensions(o), g = m === "y", h = g ? "top" : "left", b = g ? "bottom" : "right", y = g ? "clientHeight" : "clientWidth", x = a.reference[p] + a.reference[m] - u[m] - a.floating[p], _ = u[m] - a.reference[m], S = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(o));
  let E = S ? S[y] : 0;
  E && await (l.isElement == null ? void 0 : l.isElement(S)) || (E = d.floating[y] || a.floating[p]);
  const P = x / 2 - _ / 2, T = f[h], F = E - v[p] - f[b], X = E / 2 - v[p] / 2 + P, q = vo(T, X, F), W = ct(s) != null && X != q && a.reference[p] / 2 - (X < T ? f[h] : f[b]) - v[p] / 2 < 0;
  return { [m]: u[m] - (W ? X < T ? T - X : F - X : 0), data: { [m]: q, centerOffset: X - q } };
} }), Xn = ["top", "right", "bottom", "left"];
Xn.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
const xa = { left: "right", right: "left", bottom: "top", top: "bottom" };
function zt(e) {
  return e.replace(/left|right|bottom|top/g, (t) => xa[t]);
}
function Ca(e, t, o) {
  o === void 0 && (o = !1);
  const n = ct(e), i = Ye(e), r = So(i);
  let s = i === "x" ? n === (o ? "end" : "start") ? "right" : "left" : n === "start" ? "bottom" : "top";
  return t.reference[r] > t.floating[r] && (s = zt(s)), { main: s, cross: zt(s) };
}
const wa = { start: "end", end: "start" };
function no(e) {
  return e.replace(/start|end/g, (t) => wa[t]);
}
const _a = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
    var o;
    const { placement: n, middlewareData: i, rects: r, initialPlacement: s, platform: a, elements: l } = t, { mainAxis: d = !0, crossAxis: f = !0, fallbackPlacements: u, fallbackStrategy: m = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: v = !0, ...g } = e, h = ze(n), b = ze(s) === s, y = await (a.isRTL == null ? void 0 : a.isRTL(l.floating)), x = u || (b || !v ? [zt(s)] : function(q) {
      const W = zt(q);
      return [no(q), W, no(W)];
    }(s));
    u || p === "none" || x.push(...function(q, W, j, L) {
      const I = ct(q);
      let R = function(Q, ee, pe) {
        const re = ["left", "right"], ue = ["right", "left"], me = ["top", "bottom"], ke = ["bottom", "top"];
        switch (Q) {
          case "top":
          case "bottom":
            return pe ? ee ? ue : re : ee ? re : ue;
          case "left":
          case "right":
            return ee ? me : ke;
          default:
            return [];
        }
      }(ze(q), j === "start", L);
      return I && (R = R.map((Q) => Q + "-" + I), W && (R = R.concat(R.map(no)))), R;
    }(s, v, p, y));
    const _ = [s, ...x], S = await yt(t, g), E = [];
    let P = ((o = i.flip) == null ? void 0 : o.overflows) || [];
    if (d && E.push(S[h]), f) {
      const { main: q, cross: W } = Ca(n, r, y);
      E.push(S[q], S[W]);
    }
    if (P = [...P, { placement: n, overflows: E }], !E.every((q) => q <= 0)) {
      var T, F;
      const q = (((T = i.flip) == null ? void 0 : T.index) || 0) + 1, W = _[q];
      if (W)
        return { data: { index: q, overflows: P }, reset: { placement: W } };
      let j = (F = P.filter((L) => L.overflows[0] <= 0).sort((L, I) => L.overflows[1] - I.overflows[1])[0]) == null ? void 0 : F.placement;
      if (!j)
        switch (m) {
          case "bestFit": {
            var X;
            const L = (X = P.map((I) => [I.placement, I.overflows.filter((R) => R > 0).reduce((R, Q) => R + Q, 0)]).sort((I, R) => I[1] - R[1])[0]) == null ? void 0 : X[0];
            L && (j = L);
            break;
          }
          case "initialPlacement":
            j = s;
        }
      if (n !== j)
        return { reset: { placement: j } };
    }
    return {};
  } };
};
function on(e, t) {
  return { top: e.top - t.height, right: e.right - t.width, bottom: e.bottom - t.height, left: e.left - t.width };
}
function nn(e) {
  return Xn.some((t) => e[t] >= 0);
}
const $a = function(e) {
  return e === void 0 && (e = {}), { name: "hide", options: e, async fn(t) {
    const { strategy: o = "referenceHidden", ...n } = e, { rects: i } = t;
    switch (o) {
      case "referenceHidden": {
        const r = on(await yt(t, { ...n, elementContext: "reference" }), i.reference);
        return { data: { referenceHiddenOffsets: r, referenceHidden: nn(r) } };
      }
      case "escaped": {
        const r = on(await yt(t, { ...n, altBoundary: !0 }), i.floating);
        return { data: { escapedOffsets: r, escaped: nn(r) } };
      }
      default:
        return {};
    }
  } };
}, ka = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
    const { x: o, y: n } = t, i = await async function(r, s) {
      const { placement: a, platform: l, elements: d } = r, f = await (l.isRTL == null ? void 0 : l.isRTL(d.floating)), u = ze(a), m = ct(a), p = Ye(a) === "x", v = ["left", "top"].includes(u) ? -1 : 1, g = f && p ? -1 : 1, h = typeof s == "function" ? s(r) : s;
      let { mainAxis: b, crossAxis: y, alignmentAxis: x } = typeof h == "number" ? { mainAxis: h, crossAxis: 0, alignmentAxis: null } : { mainAxis: 0, crossAxis: 0, alignmentAxis: null, ...h };
      return m && typeof x == "number" && (y = m === "end" ? -1 * x : x), p ? { x: y * g, y: b * v } : { x: b * v, y: y * g };
    }(t, e);
    return { x: o + i.x, y: n + i.y, data: i };
  } };
};
function Kn(e) {
  return e === "x" ? "y" : "x";
}
const Sa = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
    const { x: o, y: n, placement: i } = t, { mainAxis: r = !0, crossAxis: s = !1, limiter: a = { fn: (h) => {
      let { x: b, y } = h;
      return { x: b, y };
    } }, ...l } = e, d = { x: o, y: n }, f = await yt(t, l), u = Ye(ze(i)), m = Kn(u);
    let p = d[u], v = d[m];
    if (r) {
      const h = u === "y" ? "bottom" : "right";
      p = vo(p + f[u === "y" ? "top" : "left"], p, p - f[h]);
    }
    if (s) {
      const h = m === "y" ? "bottom" : "right";
      v = vo(v + f[m === "y" ? "top" : "left"], v, v - f[h]);
    }
    const g = a.fn({ ...t, [u]: p, [m]: v });
    return { ...g, data: { x: g.x - o, y: g.y - n } };
  } };
}, Pa = function(e) {
  return e === void 0 && (e = {}), { options: e, fn(t) {
    const { x: o, y: n, placement: i, rects: r, middlewareData: s } = t, { offset: a = 0, mainAxis: l = !0, crossAxis: d = !0 } = e, f = { x: o, y: n }, u = Ye(i), m = Kn(u);
    let p = f[u], v = f[m];
    const g = typeof a == "function" ? a(t) : a, h = typeof g == "number" ? { mainAxis: g, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...g };
    if (l) {
      const x = u === "y" ? "height" : "width", _ = r.reference[u] - r.floating[x] + h.mainAxis, S = r.reference[u] + r.reference[x] - h.mainAxis;
      p < _ ? p = _ : p > S && (p = S);
    }
    if (d) {
      var b, y;
      const x = u === "y" ? "width" : "height", _ = ["top", "left"].includes(ze(i)), S = r.reference[m] - r.floating[x] + (_ && ((b = s.offset) == null ? void 0 : b[m]) || 0) + (_ ? 0 : h.crossAxis), E = r.reference[m] + r.reference[x] + (_ ? 0 : ((y = s.offset) == null ? void 0 : y[m]) || 0) - (_ ? h.crossAxis : 0);
      v < S ? v = S : v > E && (v = E);
    }
    return { [u]: p, [m]: v };
  } };
}, Ea = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
    const { placement: o, rects: n, platform: i, elements: r } = t, { apply: s = () => {
    }, ...a } = e, l = await yt(t, a), d = ze(o), f = ct(o), u = Ye(o) === "x", { width: m, height: p } = n.floating;
    let v, g;
    d === "top" || d === "bottom" ? (v = d, g = f === (await (i.isRTL == null ? void 0 : i.isRTL(r.floating)) ? "start" : "end") ? "left" : "right") : (g = d, v = f === "end" ? "top" : "bottom");
    const h = p - l[v], b = m - l[g], y = !t.middlewareData.shift;
    let x = h, _ = b;
    if (u) {
      const E = m - l.left - l.right;
      _ = f || y ? po(b, E) : E;
    } else {
      const E = p - l.top - l.bottom;
      x = f || y ? po(h, E) : E;
    }
    if (y && !f) {
      const E = Be(l.left, 0), P = Be(l.right, 0), T = Be(l.top, 0), F = Be(l.bottom, 0);
      u ? _ = m - 2 * (E !== 0 || P !== 0 ? E + P : Be(l.left, l.right)) : x = p - 2 * (T !== 0 || F !== 0 ? T + F : Be(l.top, l.bottom));
    }
    await s({ ...t, availableWidth: _, availableHeight: x });
    const S = await i.getDimensions(r.floating);
    return m !== S.width || p !== S.height ? { reset: { rects: !0 } } : {};
  } };
};
function Ee(e) {
  var t;
  return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Te(e) {
  return Ee(e).getComputedStyle(e);
}
function Yn(e) {
  return e instanceof Ee(e).Node;
}
function We(e) {
  return Yn(e) ? (e.nodeName || "").toLowerCase() : "";
}
function Ae(e) {
  return e instanceof Ee(e).HTMLElement;
}
function _e(e) {
  return e instanceof Ee(e).Element;
}
function rn(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof Ee(e).ShadowRoot || e instanceof ShadowRoot;
}
function bt(e) {
  const { overflow: t, overflowX: o, overflowY: n, display: i } = Te(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + n + o) && !["inline", "contents"].includes(i);
}
function Ta(e) {
  return ["table", "td", "th"].includes(We(e));
}
function mo(e) {
  const t = Po(), o = Te(e);
  return o.transform !== "none" || o.perspective !== "none" || !t && !!o.backdropFilter && o.backdropFilter !== "none" || !t && !!o.filter && o.filter !== "none" || ["transform", "perspective", "filter"].some((n) => (o.willChange || "").includes(n)) || ["paint", "layout", "strict", "content"].some((n) => (o.contain || "").includes(n));
}
function Po() {
  return !(typeof CSS > "u" || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
}
function Ht(e) {
  return ["html", "body", "#document"].includes(We(e));
}
const an = Math.min, vt = Math.max, Dt = Math.round;
function Gn(e) {
  const t = Te(e);
  let o = parseFloat(t.width) || 0, n = parseFloat(t.height) || 0;
  const i = Ae(e), r = i ? e.offsetWidth : o, s = i ? e.offsetHeight : n, a = Dt(o) !== r || Dt(n) !== s;
  return a && (o = r, n = s), { width: o, height: n, fallback: a };
}
function Zn(e) {
  return _e(e) ? e : e.contextElement;
}
const Jn = { x: 1, y: 1 };
function rt(e) {
  const t = Zn(e);
  if (!Ae(t))
    return Jn;
  const o = t.getBoundingClientRect(), { width: n, height: i, fallback: r } = Gn(t);
  let s = (r ? Dt(o.width) : o.width) / n, a = (r ? Dt(o.height) : o.height) / i;
  return s && Number.isFinite(s) || (s = 1), a && Number.isFinite(a) || (a = 1), { x: s, y: a };
}
const sn = { x: 0, y: 0 };
function Qn(e, t, o) {
  var n, i;
  if (t === void 0 && (t = !0), !Po())
    return sn;
  const r = e ? Ee(e) : window;
  return !o || t && o !== r ? sn : { x: ((n = r.visualViewport) == null ? void 0 : n.offsetLeft) || 0, y: ((i = r.visualViewport) == null ? void 0 : i.offsetTop) || 0 };
}
function Xe(e, t, o, n) {
  t === void 0 && (t = !1), o === void 0 && (o = !1);
  const i = e.getBoundingClientRect(), r = Zn(e);
  let s = Jn;
  t && (n ? _e(n) && (s = rt(n)) : s = rt(e));
  const a = Qn(r, o, n);
  let l = (i.left + a.x) / s.x, d = (i.top + a.y) / s.y, f = i.width / s.x, u = i.height / s.y;
  if (r) {
    const m = Ee(r), p = n && _e(n) ? Ee(n) : n;
    let v = m.frameElement;
    for (; v && n && p !== m; ) {
      const g = rt(v), h = v.getBoundingClientRect(), b = getComputedStyle(v);
      h.x += (v.clientLeft + parseFloat(b.paddingLeft)) * g.x, h.y += (v.clientTop + parseFloat(b.paddingTop)) * g.y, l *= g.x, d *= g.y, f *= g.x, u *= g.y, l += h.x, d += h.y, v = Ee(v).frameElement;
    }
  }
  return jt({ width: f, height: u, x: l, y: d });
}
function He(e) {
  return ((Yn(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function Vt(e) {
  return _e(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function ei(e) {
  return Xe(He(e)).left + Vt(e).scrollLeft;
}
function st(e) {
  if (We(e) === "html")
    return e;
  const t = e.assignedSlot || e.parentNode || rn(e) && e.host || He(e);
  return rn(t) ? t.host : t;
}
function ti(e) {
  const t = st(e);
  return Ht(t) ? t.ownerDocument.body : Ae(t) && bt(t) ? t : ti(t);
}
function mt(e, t) {
  var o;
  t === void 0 && (t = []);
  const n = ti(e), i = n === ((o = e.ownerDocument) == null ? void 0 : o.body), r = Ee(n);
  return i ? t.concat(r, r.visualViewport || [], bt(n) ? n : []) : t.concat(n, mt(n));
}
function ln(e, t, o) {
  let n;
  if (t === "viewport")
    n = function(i, r) {
      const s = Ee(i), a = He(i), l = s.visualViewport;
      let d = a.clientWidth, f = a.clientHeight, u = 0, m = 0;
      if (l) {
        d = l.width, f = l.height;
        const p = Po();
        (!p || p && r === "fixed") && (u = l.offsetLeft, m = l.offsetTop);
      }
      return { width: d, height: f, x: u, y: m };
    }(e, o);
  else if (t === "document")
    n = function(i) {
      const r = He(i), s = Vt(i), a = i.ownerDocument.body, l = vt(r.scrollWidth, r.clientWidth, a.scrollWidth, a.clientWidth), d = vt(r.scrollHeight, r.clientHeight, a.scrollHeight, a.clientHeight);
      let f = -s.scrollLeft + ei(i);
      const u = -s.scrollTop;
      return Te(a).direction === "rtl" && (f += vt(r.clientWidth, a.clientWidth) - l), { width: l, height: d, x: f, y: u };
    }(He(e));
  else if (_e(t))
    n = function(i, r) {
      const s = Xe(i, !0, r === "fixed"), a = s.top + i.clientTop, l = s.left + i.clientLeft, d = Ae(i) ? rt(i) : { x: 1, y: 1 };
      return { width: i.clientWidth * d.x, height: i.clientHeight * d.y, x: l * d.x, y: a * d.y };
    }(t, o);
  else {
    const i = Qn(e);
    n = { ...t, x: t.x - i.x, y: t.y - i.y };
  }
  return jt(n);
}
function oi(e, t) {
  const o = st(e);
  return !(o === t || !_e(o) || Ht(o)) && (Te(o).position === "fixed" || oi(o, t));
}
function cn(e, t) {
  return Ae(e) && Te(e).position !== "fixed" ? t ? t(e) : e.offsetParent : null;
}
function dn(e, t) {
  const o = Ee(e);
  if (!Ae(e))
    return o;
  let n = cn(e, t);
  for (; n && Ta(n) && Te(n).position === "static"; )
    n = cn(n, t);
  return n && (We(n) === "html" || We(n) === "body" && Te(n).position === "static" && !mo(n)) ? o : n || function(i) {
    let r = st(i);
    for (; Ae(r) && !Ht(r); ) {
      if (mo(r))
        return r;
      r = st(r);
    }
    return null;
  }(e) || o;
}
function Aa(e, t, o) {
  const n = Ae(t), i = He(t), r = o === "fixed", s = Xe(e, !0, r, t);
  let a = { scrollLeft: 0, scrollTop: 0 };
  const l = { x: 0, y: 0 };
  if (n || !n && !r)
    if ((We(t) !== "body" || bt(i)) && (a = Vt(t)), Ae(t)) {
      const d = Xe(t, !0, r, t);
      l.x = d.x + t.clientLeft, l.y = d.y + t.clientTop;
    } else
      i && (l.x = ei(i));
  return { x: s.left + a.scrollLeft - l.x, y: s.top + a.scrollTop - l.y, width: s.width, height: s.height };
}
const Ra = { getClippingRect: function(e) {
  let { element: t, boundary: o, rootBoundary: n, strategy: i } = e;
  const r = o === "clippingAncestors" ? function(d, f) {
    const u = f.get(d);
    if (u)
      return u;
    let m = mt(d).filter((h) => _e(h) && We(h) !== "body"), p = null;
    const v = Te(d).position === "fixed";
    let g = v ? st(d) : d;
    for (; _e(g) && !Ht(g); ) {
      const h = Te(g), b = mo(g);
      b || h.position !== "fixed" || (p = null), (v ? !b && !p : !b && h.position === "static" && p && ["absolute", "fixed"].includes(p.position) || bt(g) && !b && oi(d, g)) ? m = m.filter((y) => y !== g) : p = h, g = st(g);
    }
    return f.set(d, m), m;
  }(t, this._c) : [].concat(o), s = [...r, n], a = s[0], l = s.reduce((d, f) => {
    const u = ln(t, f, i);
    return d.top = vt(u.top, d.top), d.right = an(u.right, d.right), d.bottom = an(u.bottom, d.bottom), d.left = vt(u.left, d.left), d;
  }, ln(t, a, i));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: t, offsetParent: o, strategy: n } = e;
  const i = Ae(o), r = He(o);
  if (o === r)
    return t;
  let s = { scrollLeft: 0, scrollTop: 0 }, a = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((i || !i && n !== "fixed") && ((We(o) !== "body" || bt(r)) && (s = Vt(o)), Ae(o))) {
    const d = Xe(o);
    a = rt(o), l.x = d.x + o.clientLeft, l.y = d.y + o.clientTop;
  }
  return { width: t.width * a.x, height: t.height * a.y, x: t.x * a.x - s.scrollLeft * a.x + l.x, y: t.y * a.y - s.scrollTop * a.y + l.y };
}, isElement: _e, getDimensions: function(e) {
  return Gn(e);
}, getOffsetParent: dn, getDocumentElement: He, getScale: rt, async getElementRects(e) {
  let { reference: t, floating: o, strategy: n } = e;
  const i = this.getOffsetParent || dn, r = this.getDimensions;
  return { reference: Aa(t, await i(o), n), floating: { x: 0, y: 0, ...await r(o) } };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Te(e).direction === "rtl" };
function Oa(e, t, o, n) {
  n === void 0 && (n = {});
  const { ancestorScroll: i = !0, ancestorResize: r = !0, elementResize: s = !0, animationFrame: a = !1 } = n, l = i || r ? [..._e(e) ? mt(e) : e.contextElement ? mt(e.contextElement) : [], ...mt(t)] : [];
  l.forEach((m) => {
    const p = !_e(m) && m.toString().includes("V");
    !i || a && !p || m.addEventListener("scroll", o, { passive: !0 }), r && m.addEventListener("resize", o);
  });
  let d, f = null;
  s && (f = new ResizeObserver(() => {
    o();
  }), _e(e) && !a && f.observe(e), _e(e) || !e.contextElement || a || f.observe(e.contextElement), f.observe(t));
  let u = a ? Xe(e) : null;
  return a && function m() {
    const p = Xe(e);
    !u || p.x === u.x && p.y === u.y && p.width === u.width && p.height === u.height || o(), u = p, d = requestAnimationFrame(m);
  }(), o(), () => {
    var m;
    l.forEach((p) => {
      i && p.removeEventListener("scroll", o), r && p.removeEventListener("resize", o);
    }), (m = f) == null || m.disconnect(), f = null, a && cancelAnimationFrame(d);
  };
}
const Na = (e, t, o) => {
  const n = /* @__PURE__ */ new Map(), i = { platform: Ra, ...o }, r = { ...i.platform, _c: n };
  return ba(e, t, { ...i, platform: r });
}, qa = (e) => {
  const {
    element: t,
    padding: o
  } = e;
  function n(i) {
    return {}.hasOwnProperty.call(i, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(i) {
      return t && n(t) ? t.current != null ? tn({
        element: t.current,
        padding: o
      }).fn(i) : {} : t ? tn({
        element: t,
        padding: o
      }).fn(i) : {};
    }
  };
};
var At = typeof document < "u" ? An : ie;
function It(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let o, n, i;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (o = e.length, o != t.length)
        return !1;
      for (n = o; n-- !== 0; )
        if (!It(e[n], t[n]))
          return !1;
      return !0;
    }
    if (i = Object.keys(e), o = i.length, o !== Object.keys(t).length)
      return !1;
    for (n = o; n-- !== 0; )
      if (!{}.hasOwnProperty.call(t, i[n]))
        return !1;
    for (n = o; n-- !== 0; ) {
      const r = i[n];
      if (!(r === "_owner" && e.$$typeof) && !It(e[r], t[r]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function ni(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function un(e, t) {
  const o = ni(e);
  return Math.round(t * o) / o;
}
function fn(e) {
  const t = A.useRef(e);
  return At(() => {
    t.current = e;
  }), t;
}
function ja(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: o = "absolute",
    middleware: n = [],
    platform: i,
    elements: {
      reference: r,
      floating: s
    } = {},
    transform: a = !0,
    whileElementsMounted: l,
    open: d
  } = e, [f, u] = A.useState({
    x: 0,
    y: 0,
    strategy: o,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [m, p] = A.useState(n);
  It(m, n) || p(n);
  const [v, g] = A.useState(null), [h, b] = A.useState(null), y = A.useCallback((R) => {
    R != E.current && (E.current = R, g(R));
  }, [g]), x = A.useCallback((R) => {
    R !== P.current && (P.current = R, b(R));
  }, [b]), _ = r || v, S = s || h, E = A.useRef(null), P = A.useRef(null), T = A.useRef(f), F = fn(l), X = fn(i), q = A.useCallback(() => {
    if (!E.current || !P.current)
      return;
    const R = {
      placement: t,
      strategy: o,
      middleware: m
    };
    X.current && (R.platform = X.current), Na(E.current, P.current, R).then((Q) => {
      const ee = {
        ...Q,
        isPositioned: !0
      };
      W.current && !It(T.current, ee) && (T.current = ee, xr.flushSync(() => {
        u(ee);
      }));
    });
  }, [m, t, o, X]);
  At(() => {
    d === !1 && T.current.isPositioned && (T.current.isPositioned = !1, u((R) => ({
      ...R,
      isPositioned: !1
    })));
  }, [d]);
  const W = A.useRef(!1);
  At(() => (W.current = !0, () => {
    W.current = !1;
  }), []), At(() => {
    if (_ && (E.current = _), S && (P.current = S), _ && S) {
      if (F.current)
        return F.current(_, S, q);
      q();
    }
  }, [_, S, q, F]);
  const j = A.useMemo(() => ({
    reference: E,
    floating: P,
    setReference: y,
    setFloating: x
  }), [y, x]), L = A.useMemo(() => ({
    reference: _,
    floating: S
  }), [_, S]), I = A.useMemo(() => {
    const R = {
      position: o,
      left: 0,
      top: 0
    };
    if (!L.floating)
      return R;
    const Q = un(L.floating, f.x), ee = un(L.floating, f.y);
    return a ? {
      ...R,
      transform: "translate(" + Q + "px, " + ee + "px)",
      ...ni(L.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: o,
      left: Q,
      top: ee
    };
  }, [o, a, L.floating, f.x, f.y]);
  return A.useMemo(() => ({
    ...f,
    update: q,
    refs: j,
    elements: L,
    floatingStyles: I
  }), [f, q, j, L, I]);
}
const xt = /* @__PURE__ */ D((e, t) => {
  const { children: o, ...n } = e, i = Ue.toArray(o), r = i.find(Da);
  if (r) {
    const s = r.props.children, a = i.map((l) => l === r ? Ue.count(s) > 1 ? Ue.only(null) : /* @__PURE__ */ Nt(s) ? s.props.children : null : l);
    return /* @__PURE__ */ $(ho, M({}, n, {
      ref: t
    }), /* @__PURE__ */ Nt(s) ? /* @__PURE__ */ wo(s, void 0, a) : null);
  }
  return /* @__PURE__ */ $(ho, M({}, n, {
    ref: t
  }), o);
});
xt.displayName = "Slot";
const ho = /* @__PURE__ */ D((e, t) => {
  const { children: o, ...n } = e;
  return /* @__PURE__ */ Nt(o) ? /* @__PURE__ */ wo(o, {
    ...Ia(n, o.props),
    ref: t ? Bn(t, o.ref) : o.ref
  }) : Ue.count(o) > 1 ? Ue.only(null) : null;
});
ho.displayName = "SlotClone";
const za = ({ children: e }) => /* @__PURE__ */ $(_o, null, e);
function Da(e) {
  return /* @__PURE__ */ Nt(e) && e.type === za;
}
function Ia(e, t) {
  const o = {
    ...t
  };
  for (const n in t) {
    const i = e[n], r = t[n];
    /^on[A-Z]/.test(n) ? i && r ? o[n] = (...a) => {
      r(...a), i(...a);
    } : i && (o[n] = i) : n === "style" ? o[n] = {
      ...i,
      ...r
    } : n === "className" && (o[n] = [
      i,
      r
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...o
  };
}
const La = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], ce = La.reduce((e, t) => {
  const o = /* @__PURE__ */ D((n, i) => {
    const { asChild: r, ...s } = n, a = r ? xt : t;
    return ie(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ $(a, M({}, s, {
      ref: i
    }));
  });
  return o.displayName = `Primitive.${t}`, {
    ...e,
    [t]: o
  };
}, {});
function Ma(e, t) {
  e && Rn(
    () => e.dispatchEvent(t)
  );
}
const Fa = /* @__PURE__ */ D((e, t) => {
  const { children: o, width: n = 10, height: i = 5, ...r } = e;
  return /* @__PURE__ */ $(ce.svg, M({}, r, {
    ref: t,
    width: n,
    height: i,
    viewBox: "0 0 30 10",
    preserveAspectRatio: "none"
  }), e.asChild ? o : /* @__PURE__ */ $("polygon", {
    points: "0,0 30,0 15,10"
  }));
}), Ha = Fa, xe = globalThis != null && globalThis.document ? An : () => {
};
function Va(e) {
  const [t, o] = G(void 0);
  return xe(() => {
    if (e) {
      o({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const n = new ResizeObserver((i) => {
        if (!Array.isArray(i) || !i.length)
          return;
        const r = i[0];
        let s, a;
        if ("borderBoxSize" in r) {
          const l = r.borderBoxSize, d = Array.isArray(l) ? l[0] : l;
          s = d.inlineSize, a = d.blockSize;
        } else
          s = e.offsetWidth, a = e.offsetHeight;
        o({
          width: s,
          height: a
        });
      });
      return n.observe(e, {
        box: "border-box"
      }), () => n.unobserve(e);
    } else
      o(void 0);
  }, [
    e
  ]), t;
}
const ii = "Popper", [ri, Wt] = Ft(ii), [Wa, ai] = ri(ii), Ba = (e) => {
  const { __scopePopper: t, children: o } = e, [n, i] = G(null);
  return /* @__PURE__ */ $(Wa, {
    scope: t,
    anchor: n,
    onAnchorChange: i
  }, o);
}, Ua = "PopperAnchor", Xa = /* @__PURE__ */ D((e, t) => {
  const { __scopePopper: o, virtualRef: n, ...i } = e, r = ai(Ua, o), s = ne(null), a = ge(t, s);
  return ie(() => {
    r.onAnchorChange((n == null ? void 0 : n.current) || s.current);
  }), n ? null : /* @__PURE__ */ $(ce.div, M({}, i, {
    ref: a
  }));
}), si = "PopperContent", [Ka, Ya] = ri(si), Ga = /* @__PURE__ */ D((e, t) => {
  var o, n, i, r, s, a, l, d;
  const { __scopePopper: f, side: u = "bottom", sideOffset: m = 0, align: p = "center", alignOffset: v = 0, arrowPadding: g = 0, collisionBoundary: h = [], collisionPadding: b = 0, sticky: y = "partial", hideWhenDetached: x = !1, avoidCollisions: _ = !0, onPlaced: S, ...E } = e, P = ai(si, f), [T, F] = G(null), X = ge(
    t,
    (ve) => F(ve)
  ), [q, W] = G(null), j = Va(q), L = (o = j == null ? void 0 : j.width) !== null && o !== void 0 ? o : 0, I = (n = j == null ? void 0 : j.height) !== null && n !== void 0 ? n : 0, R = u + (p !== "center" ? "-" + p : ""), Q = typeof b == "number" ? b : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...b
  }, ee = Array.isArray(h) ? h : [
    h
  ], pe = ee.length > 0, re = {
    padding: Q,
    boundary: ee.filter(es),
    // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
    altBoundary: pe
  }, { refs: ue, floatingStyles: me, placement: ke, isPositioned: Ce, middlewareData: we } = ja({
    // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
    strategy: "fixed",
    placement: R,
    whileElementsMounted: Oa,
    elements: {
      reference: P.anchor
    },
    middleware: [
      ka({
        mainAxis: m + I,
        alignmentAxis: v
      }),
      _ && Sa({
        mainAxis: !0,
        crossAxis: !1,
        limiter: y === "partial" ? Pa() : void 0,
        ...re
      }),
      _ && _a({
        ...re
      }),
      Ea({
        ...re,
        apply: ({ elements: ve, rects: Re, availableWidth: Oe, availableHeight: Me }) => {
          const { width: wt, height: Je } = Re.reference, Qe = ve.floating.style;
          Qe.setProperty("--radix-popper-available-width", `${Oe}px`), Qe.setProperty("--radix-popper-available-height", `${Me}px`), Qe.setProperty("--radix-popper-anchor-width", `${wt}px`), Qe.setProperty("--radix-popper-anchor-height", `${Je}px`);
        }
      }),
      q && qa({
        element: q,
        padding: g
      }),
      ts({
        arrowWidth: L,
        arrowHeight: I
      }),
      x && $a({
        strategy: "referenceHidden"
      })
    ]
  }), [Se, O] = li(ke), U = De(S);
  xe(() => {
    Ce && (U == null || U());
  }, [
    Ce,
    U
  ]);
  const fe = (i = we.arrow) === null || i === void 0 ? void 0 : i.x, Z = (r = we.arrow) === null || r === void 0 ? void 0 : r.y, J = ((s = we.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0, [K, he] = G();
  return xe(() => {
    T && he(window.getComputedStyle(T).zIndex);
  }, [
    T
  ]), /* @__PURE__ */ $("div", {
    ref: ue.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...me,
      transform: Ce ? me.transform : "translate(0, -200%)",
      // keep off the page when measuring
      minWidth: "max-content",
      zIndex: K,
      ["--radix-popper-transform-origin"]: [
        (a = we.transformOrigin) === null || a === void 0 ? void 0 : a.x,
        (l = we.transformOrigin) === null || l === void 0 ? void 0 : l.y
      ].join(" ")
    },
    dir: e.dir
  }, /* @__PURE__ */ $(Ka, {
    scope: f,
    placedSide: Se,
    onArrowChange: W,
    arrowX: fe,
    arrowY: Z,
    shouldHideArrow: J
  }, /* @__PURE__ */ $(ce.div, M({
    "data-side": Se,
    "data-align": O
  }, E, {
    ref: X,
    style: {
      ...E.style,
      // if the PopperContent hasn't been placed yet (not all measurements done)
      // we prevent animations so that users's animation don't kick in too early referring wrong sides
      animation: Ce ? void 0 : "none",
      // hide the content if using the hide middleware and should be hidden
      opacity: (d = we.hide) !== null && d !== void 0 && d.referenceHidden ? 0 : void 0
    }
  }))));
}), Za = "PopperArrow", Ja = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, Qa = /* @__PURE__ */ D(function(t, o) {
  const { __scopePopper: n, ...i } = t, r = Ya(Za, n), s = Ja[r.placedSide];
  return (
    // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
    // doesn't report size as we'd expect on SVG elements.
    // it reports their bounding box which is effectively the largest path inside the SVG.
    /* @__PURE__ */ $("span", {
      ref: r.onArrowChange,
      style: {
        position: "absolute",
        left: r.arrowX,
        top: r.arrowY,
        [s]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0"
        }[r.placedSide],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)"
        }[r.placedSide],
        visibility: r.shouldHideArrow ? "hidden" : void 0
      }
    }, /* @__PURE__ */ $(Ha, M({}, i, {
      ref: o,
      style: {
        ...i.style,
        // ensures the element can be measured correctly (mostly for if SVG)
        display: "block"
      }
    })))
  );
});
function es(e) {
  return e !== null;
}
const ts = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var o, n, i, r, s;
    const { placement: a, rects: l, middlewareData: d } = t, u = ((o = d.arrow) === null || o === void 0 ? void 0 : o.centerOffset) !== 0, m = u ? 0 : e.arrowWidth, p = u ? 0 : e.arrowHeight, [v, g] = li(a), h = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[g], b = ((n = (i = d.arrow) === null || i === void 0 ? void 0 : i.x) !== null && n !== void 0 ? n : 0) + m / 2, y = ((r = (s = d.arrow) === null || s === void 0 ? void 0 : s.y) !== null && r !== void 0 ? r : 0) + p / 2;
    let x = "", _ = "";
    return v === "bottom" ? (x = u ? h : `${b}px`, _ = `${-p}px`) : v === "top" ? (x = u ? h : `${b}px`, _ = `${l.floating.height + p}px`) : v === "right" ? (x = `${-p}px`, _ = u ? h : `${y}px`) : v === "left" && (x = `${l.floating.width + p}px`, _ = u ? h : `${y}px`), {
      data: {
        x,
        y: _
      }
    };
  }
});
function li(e) {
  const [t, o = "center"] = e.split("-");
  return [
    t,
    o
  ];
}
const ci = Ba, di = Xa, ui = Ga, os = Qa, fi = /* @__PURE__ */ D((e, t) => {
  var o;
  const { container: n = globalThis == null || (o = globalThis.document) === null || o === void 0 ? void 0 : o.body, ...i } = e;
  return n ? /* @__PURE__ */ Cr.createPortal(/* @__PURE__ */ $(ce.div, M({}, i, {
    ref: t
  })), n) : null;
});
function ns(e, t) {
  return br((o, n) => {
    const i = t[o][n];
    return i ?? o;
  }, e);
}
const Eo = (e) => {
  const { present: t, children: o } = e, n = is(t), i = typeof o == "function" ? o({
    present: n.isPresent
  }) : Ue.only(o), r = ge(n.ref, i.ref);
  return typeof o == "function" || n.isPresent ? /* @__PURE__ */ wo(i, {
    ref: r
  }) : null;
};
Eo.displayName = "Presence";
function is(e) {
  const [t, o] = G(), n = ne({}), i = ne(e), r = ne("none"), s = e ? "mounted" : "unmounted", [a, l] = ns(s, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return ie(() => {
    const d = $t(n.current);
    r.current = a === "mounted" ? d : "none";
  }, [
    a
  ]), xe(() => {
    const d = n.current, f = i.current;
    if (f !== e) {
      const m = r.current, p = $t(d);
      e ? l("MOUNT") : p === "none" || (d == null ? void 0 : d.display) === "none" ? l("UNMOUNT") : l(f && m !== p ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
    }
  }, [
    e,
    l
  ]), xe(() => {
    if (t) {
      const d = (u) => {
        const p = $t(n.current).includes(u.animationName);
        u.target === t && p && Rn(
          () => l("ANIMATION_END")
        );
      }, f = (u) => {
        u.target === t && (r.current = $t(n.current));
      };
      return t.addEventListener("animationstart", f), t.addEventListener("animationcancel", d), t.addEventListener("animationend", d), () => {
        t.removeEventListener("animationstart", f), t.removeEventListener("animationcancel", d), t.removeEventListener("animationend", d);
      };
    } else
      l("ANIMATION_END");
  }, [
    t,
    l
  ]), {
    isPresent: [
      "mounted",
      "unmountSuspended"
    ].includes(a),
    ref: le((d) => {
      d && (n.current = getComputedStyle(d)), o(d);
    }, [])
  };
}
function $t(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function rs(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e);
  ie(() => {
    const n = (i) => {
      i.key === "Escape" && o(i);
    };
    return t.addEventListener("keydown", n), () => t.removeEventListener("keydown", n);
  }, [
    o,
    t
  ]);
}
const yo = "dismissableLayer.update", as = "dismissableLayer.pointerDownOutside", ss = "dismissableLayer.focusOutside";
let gn;
const ls = /* @__PURE__ */ ht({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), gi = /* @__PURE__ */ D((e, t) => {
  var o;
  const { disableOutsidePointerEvents: n = !1, onEscapeKeyDown: i, onPointerDownOutside: r, onFocusOutside: s, onInteractOutside: a, onDismiss: l, ...d } = e, f = Mt(ls), [u, m] = G(null), p = (o = u == null ? void 0 : u.ownerDocument) !== null && o !== void 0 ? o : globalThis == null ? void 0 : globalThis.document, [, v] = G({}), g = ge(
    t,
    (T) => m(T)
  ), h = Array.from(f.layers), [b] = [
    ...f.layersWithOutsidePointerEventsDisabled
  ].slice(-1), y = h.indexOf(b), x = u ? h.indexOf(u) : -1, _ = f.layersWithOutsidePointerEventsDisabled.size > 0, S = x >= y, E = cs((T) => {
    const F = T.target, X = [
      ...f.branches
    ].some(
      (q) => q.contains(F)
    );
    !S || X || (r == null || r(T), a == null || a(T), T.defaultPrevented || l == null || l());
  }, p), P = ds((T) => {
    const F = T.target;
    [
      ...f.branches
    ].some(
      (q) => q.contains(F)
    ) || (s == null || s(T), a == null || a(T), T.defaultPrevented || l == null || l());
  }, p);
  return rs((T) => {
    x === f.layers.size - 1 && (i == null || i(T), !T.defaultPrevented && l && (T.preventDefault(), l()));
  }, p), ie(() => {
    if (u)
      return n && (f.layersWithOutsidePointerEventsDisabled.size === 0 && (gn = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), f.layersWithOutsidePointerEventsDisabled.add(u)), f.layers.add(u), pn(), () => {
        n && f.layersWithOutsidePointerEventsDisabled.size === 1 && (p.body.style.pointerEvents = gn);
      };
  }, [
    u,
    p,
    n,
    f
  ]), ie(() => () => {
    u && (f.layers.delete(u), f.layersWithOutsidePointerEventsDisabled.delete(u), pn());
  }, [
    u,
    f
  ]), ie(() => {
    const T = () => v({});
    return document.addEventListener(yo, T), () => document.removeEventListener(yo, T);
  }, []), /* @__PURE__ */ $(ce.div, M({}, d, {
    ref: g,
    style: {
      pointerEvents: _ ? S ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: oe(e.onFocusCapture, P.onFocusCapture),
    onBlurCapture: oe(e.onBlurCapture, P.onBlurCapture),
    onPointerDownCapture: oe(e.onPointerDownCapture, E.onPointerDownCapture)
  }));
});
function cs(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e), n = ne(!1), i = ne(() => {
  });
  return ie(() => {
    const r = (a) => {
      if (a.target && !n.current) {
        let d = function() {
          pi(as, o, l, {
            discrete: !0
          });
        };
        const l = {
          originalEvent: a
        };
        a.pointerType === "touch" ? (t.removeEventListener("click", i.current), i.current = d, t.addEventListener("click", i.current, {
          once: !0
        })) : d();
      }
      n.current = !1;
    }, s = window.setTimeout(() => {
      t.addEventListener("pointerdown", r);
    }, 0);
    return () => {
      window.clearTimeout(s), t.removeEventListener("pointerdown", r), t.removeEventListener("click", i.current);
    };
  }, [
    t,
    o
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => n.current = !0
  };
}
function ds(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e), n = ne(!1);
  return ie(() => {
    const i = (r) => {
      r.target && !n.current && pi(ss, o, {
        originalEvent: r
      }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", i), () => t.removeEventListener("focusin", i);
  }, [
    t,
    o
  ]), {
    onFocusCapture: () => n.current = !0,
    onBlurCapture: () => n.current = !1
  };
}
function pn() {
  const e = new CustomEvent(yo);
  document.dispatchEvent(e);
}
function pi(e, t, o, { discrete: n }) {
  const i = o.originalEvent.target, r = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: o
  });
  t && i.addEventListener(e, t, {
    once: !0
  }), n ? Ma(i, r) : i.dispatchEvent(r);
}
let io;
const vi = "HoverCard", [mi, Id] = Ft(vi, [
  Wt
]), Bt = Wt(), [us, Ut] = mi(vi), fs = (e) => {
  const { __scopeHoverCard: t, children: o, open: n, defaultOpen: i, onOpenChange: r, openDelay: s = 700, closeDelay: a = 300 } = e, l = Bt(t), d = ne(0), f = ne(0), u = ne(!1), m = ne(!1), [p = !1, v] = go({
    prop: n,
    defaultProp: i,
    onChange: r
  }), g = le(() => {
    clearTimeout(f.current), d.current = window.setTimeout(
      () => v(!0),
      s
    );
  }, [
    s,
    v
  ]), h = le(() => {
    clearTimeout(d.current), !u.current && !m.current && (f.current = window.setTimeout(
      () => v(!1),
      a
    ));
  }, [
    a,
    v
  ]), b = le(
    () => v(!1),
    [
      v
    ]
  );
  return ie(() => () => {
    clearTimeout(d.current), clearTimeout(f.current);
  }, []), /* @__PURE__ */ $(us, {
    scope: t,
    open: p,
    onOpenChange: v,
    onOpen: g,
    onClose: h,
    onDismiss: b,
    hasSelectionRef: u,
    isPointerDownOnContentRef: m
  }, /* @__PURE__ */ $(ci, l, o));
}, gs = "HoverCardTrigger", ps = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, ...n } = e, i = Ut(gs, o), r = Bt(o);
  return /* @__PURE__ */ $(di, M({
    asChild: !0
  }, r), /* @__PURE__ */ $(ce.a, M({
    "data-state": i.open ? "open" : "closed"
  }, n, {
    ref: t,
    onPointerEnter: oe(e.onPointerEnter, Lt(i.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lt(i.onClose)),
    onFocus: oe(e.onFocus, i.onOpen),
    onBlur: oe(e.onBlur, i.onClose),
    onTouchStart: oe(
      e.onTouchStart,
      (s) => s.preventDefault()
    )
  })));
}), hi = "HoverCardPortal", [vs, ms] = mi(hi, {
  forceMount: void 0
}), hs = (e) => {
  const { __scopeHoverCard: t, forceMount: o, children: n, container: i } = e, r = Ut(hi, t);
  return /* @__PURE__ */ $(vs, {
    scope: t,
    forceMount: o
  }, /* @__PURE__ */ $(Eo, {
    present: o || r.open
  }, /* @__PURE__ */ $(fi, {
    asChild: !0,
    container: i
  }, n)));
}, bo = "HoverCardContent", ys = /* @__PURE__ */ D((e, t) => {
  const o = ms(bo, e.__scopeHoverCard), { forceMount: n = o.forceMount, ...i } = e, r = Ut(bo, e.__scopeHoverCard);
  return /* @__PURE__ */ $(Eo, {
    present: n || r.open
  }, /* @__PURE__ */ $(bs, M({
    "data-state": r.open ? "open" : "closed"
  }, i, {
    onPointerEnter: oe(e.onPointerEnter, Lt(r.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lt(r.onClose)),
    ref: t
  })));
}), bs = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, onEscapeKeyDown: n, onPointerDownOutside: i, onFocusOutside: r, onInteractOutside: s, ...a } = e, l = Ut(bo, o), d = Bt(o), f = ne(null), u = ge(t, f), [m, p] = G(!1);
  return ie(() => {
    if (m) {
      const v = document.body;
      return io = v.style.userSelect || v.style.webkitUserSelect, v.style.userSelect = "none", v.style.webkitUserSelect = "none", () => {
        v.style.userSelect = io, v.style.webkitUserSelect = io;
      };
    }
  }, [
    m
  ]), ie(() => {
    if (f.current) {
      const v = () => {
        p(!1), l.isPointerDownOnContentRef.current = !1, setTimeout(() => {
          var g;
          ((g = document.getSelection()) === null || g === void 0 ? void 0 : g.toString()) !== "" && (l.hasSelectionRef.current = !0);
        });
      };
      return document.addEventListener("pointerup", v), () => {
        document.removeEventListener("pointerup", v), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !1;
      };
    }
  }, [
    l.isPointerDownOnContentRef,
    l.hasSelectionRef
  ]), ie(() => {
    f.current && Cs(f.current).forEach(
      (g) => g.setAttribute("tabindex", "-1")
    );
  }), /* @__PURE__ */ $(gi, {
    asChild: !0,
    disableOutsidePointerEvents: !1,
    onInteractOutside: s,
    onEscapeKeyDown: n,
    onPointerDownOutside: i,
    onFocusOutside: oe(r, (v) => {
      v.preventDefault();
    }),
    onDismiss: l.onDismiss
  }, /* @__PURE__ */ $(ui, M({}, d, a, {
    onPointerDown: oe(a.onPointerDown, (v) => {
      v.currentTarget.contains(v.target) && p(!0), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !0;
    }),
    ref: u,
    style: {
      ...a.style,
      userSelect: m ? "text" : void 0,
      // Safari requires prefix
      WebkitUserSelect: m ? "text" : void 0,
      "--radix-hover-card-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-hover-card-content-available-width": "var(--radix-popper-available-width)",
      "--radix-hover-card-content-available-height": "var(--radix-popper-available-height)",
      "--radix-hover-card-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-hover-card-trigger-height": "var(--radix-popper-anchor-height)"
    }
  })));
}), xs = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, ...n } = e, i = Bt(o);
  return /* @__PURE__ */ $(os, M({}, i, n, {
    ref: t
  }));
});
function Lt(e) {
  return (t) => t.pointerType === "touch" ? void 0 : e();
}
function Cs(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
  });
  for (; o.nextNode(); )
    t.push(o.currentNode);
  return t;
}
const ws = fs, _s = ps, $s = hs, ks = ys, Ss = xs;
var Ps = "_1v4ltqn1", Es = "_1v4ltqn0";
const yi = Ss, Ts = ws, To = $s, bi = H.forwardRef((e, t) => /* @__PURE__ */ w.jsx(
  _s,
  {
    ref: t,
    type: "button",
    className: z(Es, e.className),
    ...e,
    children: e.children
  }
)), xi = H.forwardRef((e, t) => /* @__PURE__ */ w.jsx(To, { children: /* @__PURE__ */ w.jsx(
  ks,
  {
    ref: t,
    className: z(Ps, e.className),
    ...e,
    children: e.children
  }
) })), Ct = (e) => /* @__PURE__ */ w.jsx(Ts, { ...e });
Ct.Trigger = bi;
Ct.Content = xi;
Ct.Arrow = yi;
Ct.Portal = To;
Ct.displayName = "HoverCard";
bi.displayName = "HoverCardTrigger";
xi.displayName = "HoverCardContent";
yi.displayName = "HoverCardArrow";
To.displayName = "HoverCardPortal";
var As = be({ defaultClassName: "_44zw2k3", variantClassNames: { font: { inherit: "_44zw2k0", system: "_44zw2k1", mono: "_44zw2k2" }, hover: { true: "i77g9oas i77g9obg i77g9ob0", false: "_44zw2ka" }, strong: { true: "i77g9oa4", false: "_44zw2kc" } }, defaultVariants: { font: "inherit", hover: !1, strong: !1 }, compoundVariants: [] });
const Rs = H.forwardRef(
  ({ children: e, className: t, font: o = "inherit", hover: n = !1, strong: i = !1, ...r }, s) => /* @__PURE__ */ w.jsx(
    "span",
    {
      ref: s,
      className: z(t, As({ font: o, hover: n, strong: i })),
      ...r,
      children: e
    }
  )
);
Rs.displayName = "SpanInline";
var Os = be({ defaultClassName: "_1l37a3c6", variantClassNames: { size: { small: "_1l37a3c2", medium: "_1l37a3c3" }, variant: { slate: "_1l37a3c4", hyper: "_1l37a3c5" } }, defaultVariants: { size: "medium", variant: "slate" }, compoundVariants: [] }), Ns = "_1l37a3c1", qs = "_1l37a3c0";
const Ci = D(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: n,
      className: z(t, qs),
      ...o,
      children: e
    }
  )
), wi = D(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
    "label",
    {
      ref: n,
      className: z(t, Ns),
      ...o,
      children: /* @__PURE__ */ w.jsx("span", { children: e })
    }
  )
), js = D(
  ({ className: e, size: t = "medium", variant: o = "slate", ...n }, i) => /* @__PURE__ */ w.jsx(
    "input",
    {
      ref: i,
      className: z(e, Os({ size: t, variant: o })),
      ...n
    }
  )
), Ao = (e) => /* @__PURE__ */ w.jsx(js, { ...e });
Ao.Flex = Ci;
Ao.Label = wi;
Ao.displayName = "Input";
Ci.displayName = "Input.Flex";
wi.displayName = "Input.Label";
var zs = "d9r7gl3", Ds = "d9r7gl2", Is = "d9r7gl0", Ls = "d9r7gl1", Ms = "d9r7gl5", Fs = "d9r7gl4";
const _i = Ie.Menu, $i = Ie.Sub, ki = Ie.Portal, Hs = H.forwardRef(({ children: e, className: t, loop: o = !0, ...n }, i) => /* @__PURE__ */ w.jsx(
  Ie.Root,
  {
    ...n,
    ref: i,
    className: z(t, Is),
    loop: o,
    children: e
  }
)), Si = H.forwardRef(({ children: e, className: t, side: o = "bottom", sideOffset: n = 10, ...i }, r) => /* @__PURE__ */ w.jsx(
  Ie.Content,
  {
    ...i,
    ref: r,
    className: z(t, zs),
    side: o,
    sideOffset: n,
    children: e
  }
)), Pi = H.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.Item,
  {
    ...o,
    ref: n,
    className: z(t, Ds),
    children: e
  }
)), Ei = H.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.Trigger,
  {
    ...o,
    ref: n,
    className: z(t, Ls),
    children: e
  }
)), Ti = H.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.SubTrigger,
  {
    ...o,
    ref: n,
    className: z(t, Fs),
    children: e
  }
)), Ai = H.forwardRef(({ children: e, className: t, sideOffset: o = 10, ...n }, i) => /* @__PURE__ */ w.jsx(
  Ie.SubContent,
  {
    ...n,
    ref: i,
    className: z(t, Ms),
    sideOffset: o,
    children: e
  }
)), Le = (e) => /* @__PURE__ */ w.jsx(Hs, { ...e });
Le.displayName = "Menubar";
Le.Menu = _i;
Le.Trigger = Ei;
Le.Content = Si;
Le.Item = Pi;
Le.SubMenu = $i;
Le.SubTrigger = Ti;
Le.SubContent = Ai;
Le.Portal = ki;
_i.displayName = "Menubar-Menu";
Ei.displayName = "Menubar-Trigger";
Si.displayName = "Menubar-Content";
Pi.displayName = "Menubar-Item";
$i.displayName = "Menubar-SubMenu";
Ti.displayName = "Menubar-SubTrigger";
Ai.displayName = "Menubar-SubContent";
ki.displayName = "Menubar-Portal";
var Vs = be({ defaultClassName: "qohxgz2s", variantClassNames: { size: { xs: "qohxgz0", sm: "qohxgz1", md: "qohxgz2", lg: "qohxgz3", xl: "qohxgz4" }, color: { transparent: "qohxgz5", current: "qohxgz6", white: "qohxgz7", black: "qohxgz8", gray100: "qohxgz9", gray200: "qohxgza", gray300: "qohxgzb", pale100: "qohxgzc", pale200: "qohxgzd", pale300: "qohxgze", pale400: "qohxgzf", pale500: "qohxgzg", hyper0: "qohxgzh", hyper1: "qohxgzi", hyper2: "qohxgzj", hyper3: "qohxgzk", hyper4: "qohxgzl", hyper5: "qohxgzm", hyper6: "qohxgzn", hyper7: "qohxgzo", hyper8: "qohxgzp", hyper9: "qohxgzq", hyper10: "qohxgzr", hyper11: "qohxgzs", hyper12: "qohxgzt", hyper13: "qohxgzu", lemon0: "qohxgzv", lemon1: "qohxgzw", lemon2: "qohxgzx", lemon3: "qohxgzy", lemon4: "qohxgzz", lemon5: "qohxgz10", lemon6: "qohxgz11", lemon7: "qohxgz12", lemon8: "qohxgz13", lemon9: "qohxgz14", lemon10: "qohxgz15", lemon11: "qohxgz16", lemon12: "qohxgz17", lemon13: "qohxgz18", slate1: "qohxgz19", slate2: "qohxgz1a", slate3: "qohxgz1b", slate4: "qohxgz1c", slate5: "qohxgz1d", slate6: "qohxgz1e", slate7: "qohxgz1f", slate8: "qohxgz1g", slate9: "qohxgz1h", slate10: "qohxgz1i", slate11: "qohxgz1j", slate12: "qohxgz1k", slate13: "qohxgz1l", sapphire0: "qohxgz1m", sapphire1: "qohxgz1n", sapphire2: "qohxgz1o", sapphire3: "qohxgz1p", sapphire4: "qohxgz1q", sapphire5: "qohxgz1r", sapphire6: "qohxgz1s", sapphire7: "qohxgz1t", sapphire8: "qohxgz1u", sapphire9: "qohxgz1v", sapphire10: "qohxgz1w", sapphire11: "qohxgz1x", sapphire12: "qohxgz1y", sapphire13: "qohxgz1z", volt0: "qohxgz20", volt1: "qohxgz21", volt2: "qohxgz22", volt3: "qohxgz23", volt4: "qohxgz24", volt5: "qohxgz25", volt6: "qohxgz26", volt7: "qohxgz27", volt8: "qohxgz28", volt9: "qohxgz29", volt10: "qohxgz2a", volt11: "qohxgz2b", volt12: "qohxgz2c", volt13: "qohxgz2d" }, weight: { superlite: "qohxgz2e", lite: "qohxgz2f", normal: "qohxgz2g", medium: "qohxgz2h", semibold: "qohxgz2i", bold: "qohxgz2j", heavy: "qohxgz2k", black: "qohxgz2l" }, align: { left: "qohxgz2m", center: "qohxgz2n", right: "qohxgz2o" }, font: { system: "qohxgz2p", inter: "qohxgz2q", mono: "qohxgz2r" } }, defaultVariants: { size: "sm", color: "slate12", weight: "normal", align: "left", font: "system" }, compoundVariants: [] });
const Ws = D(
  ({ children: e, className: t, size: o, color: n, weight: i, align: r, font: s, ...a }, l) => /* @__PURE__ */ w.jsx(
    "p",
    {
      ref: l,
      className: z(t, Vs({ size: o, color: n, weight: i, align: r, font: s })),
      ...a,
      children: e
    }
  )
);
Ws.displayName = "Paragraph";
var Bs = be({ defaultClassName: "_1g4z5m4c", variantClassNames: { size: { xs: "_1g4z5m40", sm: "_1g4z5m41", md: "_1g4z5m42", lg: "_1g4z5m43", xl: "_1g4z5m44", xxl: "_1g4z5m45" }, variant: { inherit: "_1g4z5m46", primary: "_1g4z5m47", secondary: "_1g4z5m48" }, font: { inherit: "_1g4z5m49", system: "_1g4z5m4a", mono: "_1g4z5m4b" } }, defaultVariants: { size: "sm", variant: "primary" }, compoundVariants: [] });
const Us = D(
  ({
    children: e,
    className: t,
    href: o,
    variant: n,
    target: i = "_self",
    size: r = "sm",
    font: s = "inherit",
    ...a
  }, l) => /* @__PURE__ */ w.jsx(
    "a",
    {
      ref: l,
      href: o,
      target: i,
      className: z(Bs({ size: r, variant: n }), t),
      ...a,
      children: e
    }
  )
);
Us.displayName = "PassLink";
var Xs = "_1k7gvp51";
const Ks = Ve.Portal, Ys = Ve.Root, Gs = Ve.Trigger, Zs = H.forwardRef(
  ({ className: e, align: t = "center", sideOffset: o = 6, side: n = "bottom", ...i }, r) => /* @__PURE__ */ w.jsx(Ve.Portal, { children: /* @__PURE__ */ w.jsx(
    Ve.Content,
    {
      ref: r,
      align: t,
      sideOffset: o,
      side: n,
      className: z(Xs, e),
      ...i
    }
  ) })
), $e = (e) => /* @__PURE__ */ w.jsx(Ys, { ...e });
$e.Trigger = Gs;
$e.Content = Zs;
$e.Portal = Ks;
$e.Anchor = Ve.Anchor;
$e.Arrow = Ve.Arrow;
$e.Close = Ve.Close;
$e.displayName = "Popover";
$e.Trigger.displayName = "PopoverTrigger";
$e.Content.displayName = "PopoverContent";
$e.Portal.displayName = "PopoverPortal";
$e.Anchor.displayName = "PopoverAnchor";
$e.Arrow.displayName = "PopoverArrow";
$e.Close.displayName = "PopoverClose";
var Js = be({ defaultClassName: "ti68jl4", variantClassNames: { size: { sm: "ti68jl0", md: "ti68jl1", lg: "ti68jl2", vw: "ti68jl3" } }, defaultVariants: { size: "vw" }, compoundVariants: [] });
const Qs = ({
  children: e,
  className: t,
  size: o = "vw",
  ...n
}) => /* @__PURE__ */ w.jsx(
  "div",
  {
    ...n,
    className: z(t, Js({ size: o })),
    children: e
  }
);
Qs.displayName = "Section";
function vn(e, [t, o]) {
  return Math.min(o, Math.max(t, e));
}
function el(e) {
  const t = e + "CollectionProvider", [o, n] = Ft(t), [i, r] = o(t, {
    collectionRef: {
      current: null
    },
    itemMap: /* @__PURE__ */ new Map()
  }), s = (p) => {
    const { scope: v, children: g } = p, h = H.useRef(null), b = H.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ H.createElement(i, {
      scope: v,
      itemMap: b,
      collectionRef: h
    }, g);
  }, a = e + "CollectionSlot", l = /* @__PURE__ */ H.forwardRef((p, v) => {
    const { scope: g, children: h } = p, b = r(a, g), y = ge(v, b.collectionRef);
    return /* @__PURE__ */ H.createElement(xt, {
      ref: y
    }, h);
  }), d = e + "CollectionItemSlot", f = "data-radix-collection-item", u = /* @__PURE__ */ H.forwardRef((p, v) => {
    const { scope: g, children: h, ...b } = p, y = H.useRef(null), x = ge(v, y), _ = r(d, g);
    return H.useEffect(() => (_.itemMap.set(y, {
      ref: y,
      ...b
    }), () => void _.itemMap.delete(y))), /* @__PURE__ */ H.createElement(xt, {
      [f]: "",
      ref: x
    }, h);
  });
  function m(p) {
    const v = r(e + "CollectionConsumer", p);
    return H.useCallback(() => {
      const h = v.collectionRef.current;
      if (!h)
        return [];
      const b = Array.from(h.querySelectorAll(`[${f}]`));
      return Array.from(v.itemMap.values()).sort(
        (_, S) => b.indexOf(_.ref.current) - b.indexOf(S.ref.current)
      );
    }, [
      v.collectionRef,
      v.itemMap
    ]);
  }
  return [
    {
      Provider: s,
      Slot: l,
      ItemSlot: u
    },
    m,
    n
  ];
}
const tl = /* @__PURE__ */ ht(void 0);
function ol(e) {
  const t = Mt(tl);
  return e || t || "ltr";
}
let ro = 0;
function nl() {
  ie(() => {
    var e, t;
    const o = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = o[0]) !== null && e !== void 0 ? e : mn()), document.body.insertAdjacentElement("beforeend", (t = o[1]) !== null && t !== void 0 ? t : mn()), ro++, () => {
      ro === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (n) => n.remove()
      ), ro--;
    };
  }, []);
}
function mn() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
const ao = "focusScope.autoFocusOnMount", so = "focusScope.autoFocusOnUnmount", hn = {
  bubbles: !1,
  cancelable: !0
}, il = /* @__PURE__ */ D((e, t) => {
  const { loop: o = !1, trapped: n = !1, onMountAutoFocus: i, onUnmountAutoFocus: r, ...s } = e, [a, l] = G(null), d = De(i), f = De(r), u = ne(null), m = ge(
    t,
    (g) => l(g)
  ), p = ne({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  ie(() => {
    if (n) {
      let g = function(x) {
        if (p.paused || !a)
          return;
        const _ = x.target;
        a.contains(_) ? u.current = _ : Fe(u.current, {
          select: !0
        });
      }, h = function(x) {
        if (p.paused || !a)
          return;
        const _ = x.relatedTarget;
        _ !== null && (a.contains(_) || Fe(u.current, {
          select: !0
        }));
      }, b = function(x) {
        const _ = document.activeElement;
        for (const S of x)
          S.removedNodes.length > 0 && (a != null && a.contains(_) || Fe(a));
      };
      document.addEventListener("focusin", g), document.addEventListener("focusout", h);
      const y = new MutationObserver(b);
      return a && y.observe(a, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", g), document.removeEventListener("focusout", h), y.disconnect();
      };
    }
  }, [
    n,
    a,
    p.paused
  ]), ie(() => {
    if (a) {
      bn.add(p);
      const g = document.activeElement;
      if (!a.contains(g)) {
        const b = new CustomEvent(ao, hn);
        a.addEventListener(ao, d), a.dispatchEvent(b), b.defaultPrevented || (rl(dl(Ri(a)), {
          select: !0
        }), document.activeElement === g && Fe(a));
      }
      return () => {
        a.removeEventListener(ao, d), setTimeout(() => {
          const b = new CustomEvent(so, hn);
          a.addEventListener(so, f), a.dispatchEvent(b), b.defaultPrevented || Fe(g ?? document.body, {
            select: !0
          }), a.removeEventListener(so, f), bn.remove(p);
        }, 0);
      };
    }
  }, [
    a,
    d,
    f,
    p
  ]);
  const v = le((g) => {
    if (!o && !n || p.paused)
      return;
    const h = g.key === "Tab" && !g.altKey && !g.ctrlKey && !g.metaKey, b = document.activeElement;
    if (h && b) {
      const y = g.currentTarget, [x, _] = al(y);
      x && _ ? !g.shiftKey && b === _ ? (g.preventDefault(), o && Fe(x, {
        select: !0
      })) : g.shiftKey && b === x && (g.preventDefault(), o && Fe(_, {
        select: !0
      })) : b === y && g.preventDefault();
    }
  }, [
    o,
    n,
    p.paused
  ]);
  return /* @__PURE__ */ $(ce.div, M({
    tabIndex: -1
  }, s, {
    ref: m,
    onKeyDown: v
  }));
});
function rl(e, { select: t = !1 } = {}) {
  const o = document.activeElement;
  for (const n of e)
    if (Fe(n, {
      select: t
    }), document.activeElement !== o)
      return;
}
function al(e) {
  const t = Ri(e), o = yn(t, e), n = yn(t.reverse(), e);
  return [
    o,
    n
  ];
}
function Ri(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => {
      const i = n.tagName === "INPUT" && n.type === "hidden";
      return n.disabled || n.hidden || i ? NodeFilter.FILTER_SKIP : n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; o.nextNode(); )
    t.push(o.currentNode);
  return t;
}
function yn(e, t) {
  for (const o of e)
    if (!sl(o, {
      upTo: t
    }))
      return o;
}
function sl(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t !== void 0 && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function ll(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Fe(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const o = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== o && ll(e) && t && e.select();
  }
}
const bn = cl();
function cl() {
  let e = [];
  return {
    add(t) {
      const o = e[0];
      t !== o && (o == null || o.pause()), e = xn(e, t), e.unshift(t);
    },
    remove(t) {
      var o;
      e = xn(e, t), (o = e[0]) === null || o === void 0 || o.resume();
    }
  };
}
function xn(e, t) {
  const o = [
    ...e
  ], n = o.indexOf(t);
  return n !== -1 && o.splice(n, 1), o;
}
function dl(e) {
  return e.filter(
    (t) => t.tagName !== "A"
  );
}
const ul = A["useId".toString()] || (() => {
});
let fl = 0;
function Ro(e) {
  const [t, o] = A.useState(ul());
  return xe(() => {
    e || o(
      (n) => n ?? String(fl++)
    );
  }, [
    e
  ]), e || (t ? `radix-${t}` : "");
}
function gl(e) {
  const t = ne({
    value: e,
    previous: e
  });
  return at(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [
    e
  ]);
}
const pl = /* @__PURE__ */ D((e, t) => /* @__PURE__ */ $(ce.span, M({}, e, {
  ref: t,
  style: {
    // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
})));
var vl = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, ot = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), St = {}, lo = 0, Oi = function(e) {
  return e && (e.host || Oi(e.parentNode));
}, ml = function(e, t) {
  return t.map(function(o) {
    if (e.contains(o))
      return o;
    var n = Oi(o);
    return n && e.contains(n) ? n : (console.error("aria-hidden", o, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(o) {
    return !!o;
  });
}, hl = function(e, t, o, n) {
  var i = ml(t, Array.isArray(e) ? e : [e]);
  St[o] || (St[o] = /* @__PURE__ */ new WeakMap());
  var r = St[o], s = [], a = /* @__PURE__ */ new Set(), l = new Set(i), d = function(u) {
    !u || a.has(u) || (a.add(u), d(u.parentNode));
  };
  i.forEach(d);
  var f = function(u) {
    !u || l.has(u) || Array.prototype.forEach.call(u.children, function(m) {
      if (a.has(m))
        f(m);
      else {
        var p = m.getAttribute(n), v = p !== null && p !== "false", g = (ot.get(m) || 0) + 1, h = (r.get(m) || 0) + 1;
        ot.set(m, g), r.set(m, h), s.push(m), g === 1 && v && kt.set(m, !0), h === 1 && m.setAttribute(o, "true"), v || m.setAttribute(n, "true");
      }
    });
  };
  return f(t), a.clear(), lo++, function() {
    s.forEach(function(u) {
      var m = ot.get(u) - 1, p = r.get(u) - 1;
      ot.set(u, m), r.set(u, p), m || (kt.has(u) || u.removeAttribute(n), kt.delete(u)), p || u.removeAttribute(o);
    }), lo--, lo || (ot = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), St = {});
  };
}, yl = function(e, t, o) {
  o === void 0 && (o = "data-aria-hidden");
  var n = Array.from(Array.isArray(e) ? e : [e]), i = t || vl(e);
  return i ? (n.push.apply(n, Array.from(i.querySelectorAll("[aria-live]"))), hl(n, i, o, "aria-hidden")) : function() {
    return null;
  };
}, Ne = function() {
  return Ne = Object.assign || function(t) {
    for (var o, n = 1, i = arguments.length; n < i; n++) {
      o = arguments[n];
      for (var r in o)
        Object.prototype.hasOwnProperty.call(o, r) && (t[r] = o[r]);
    }
    return t;
  }, Ne.apply(this, arguments);
};
function Ni(e, t) {
  var o = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (o[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++)
      t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (o[n[i]] = e[n[i]]);
  return o;
}
function bl(e, t, o) {
  if (o || arguments.length === 2)
    for (var n = 0, i = t.length, r; n < i; n++)
      (r || !(n in t)) && (r || (r = Array.prototype.slice.call(t, 0, n)), r[n] = t[n]);
  return e.concat(r || Array.prototype.slice.call(t));
}
var Rt = "right-scroll-bar-position", Ot = "width-before-scroll-bar", xl = "with-scroll-bars-hidden", Cl = "--removed-body-scroll-bar-size";
function wl(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function _l(e, t) {
  var o = G(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return o.value;
        },
        set current(n) {
          var i = o.value;
          i !== n && (o.value = n, o.callback(n, i));
        }
      }
    };
  })[0];
  return o.callback = t, o.facade;
}
function $l(e, t) {
  return _l(t || null, function(o) {
    return e.forEach(function(n) {
      return wl(n, o);
    });
  });
}
function kl(e) {
  return e;
}
function Sl(e, t) {
  t === void 0 && (t = kl);
  var o = [], n = !1, i = {
    read: function() {
      if (n)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return o.length ? o[o.length - 1] : e;
    },
    useMedium: function(r) {
      var s = t(r, n);
      return o.push(s), function() {
        o = o.filter(function(a) {
          return a !== s;
        });
      };
    },
    assignSyncMedium: function(r) {
      for (n = !0; o.length; ) {
        var s = o;
        o = [], s.forEach(r);
      }
      o = {
        push: function(a) {
          return r(a);
        },
        filter: function() {
          return o;
        }
      };
    },
    assignMedium: function(r) {
      n = !0;
      var s = [];
      if (o.length) {
        var a = o;
        o = [], a.forEach(r), s = o;
      }
      var l = function() {
        var f = s;
        s = [], f.forEach(r);
      }, d = function() {
        return Promise.resolve().then(l);
      };
      d(), o = {
        push: function(f) {
          s.push(f), d();
        },
        filter: function(f) {
          return s = s.filter(f), o;
        }
      };
    }
  };
  return i;
}
function Pl(e) {
  e === void 0 && (e = {});
  var t = Sl(null);
  return t.options = Ne({ async: !0, ssr: !1 }, e), t;
}
var qi = function(e) {
  var t = e.sideCar, o = Ni(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var n = t.read();
  if (!n)
    throw new Error("Sidecar medium not found");
  return A.createElement(n, Ne({}, o));
};
qi.isSideCarExport = !0;
function El(e, t) {
  return e.useMedium(t), qi;
}
var ji = Pl(), co = function() {
}, Xt = A.forwardRef(function(e, t) {
  var o = A.useRef(null), n = A.useState({
    onScrollCapture: co,
    onWheelCapture: co,
    onTouchMoveCapture: co
  }), i = n[0], r = n[1], s = e.forwardProps, a = e.children, l = e.className, d = e.removeScrollBar, f = e.enabled, u = e.shards, m = e.sideCar, p = e.noIsolation, v = e.inert, g = e.allowPinchZoom, h = e.as, b = h === void 0 ? "div" : h, y = Ni(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), x = m, _ = $l([o, t]), S = Ne(Ne({}, y), i);
  return A.createElement(
    A.Fragment,
    null,
    f && A.createElement(x, { sideCar: ji, removeScrollBar: d, shards: u, noIsolation: p, inert: v, setCallbacks: r, allowPinchZoom: !!g, lockRef: o }),
    s ? A.cloneElement(A.Children.only(a), Ne(Ne({}, S), { ref: _ })) : A.createElement(b, Ne({}, S, { className: l, ref: _ }), a)
  );
});
Xt.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
Xt.classNames = {
  fullWidth: Ot,
  zeroRight: Rt
};
var Cn, Tl = function() {
  if (Cn)
    return Cn;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function Al() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = Tl();
  return t && e.setAttribute("nonce", t), e;
}
function Rl(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Ol(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var Nl = function() {
  var e = 0, t = null;
  return {
    add: function(o) {
      e == 0 && (t = Al()) && (Rl(t, o), Ol(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, ql = function() {
  var e = Nl();
  return function(t, o) {
    A.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && o]);
  };
}, zi = function() {
  var e = ql(), t = function(o) {
    var n = o.styles, i = o.dynamic;
    return e(n, i), null;
  };
  return t;
}, jl = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, uo = function(e) {
  return parseInt(e || "", 10) || 0;
}, zl = function(e) {
  var t = window.getComputedStyle(document.body), o = t[e === "padding" ? "paddingLeft" : "marginLeft"], n = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [uo(o), uo(n), uo(i)];
}, Dl = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return jl;
  var t = zl(e), o = document.documentElement.clientWidth, n = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, n - o + t[2] - t[0])
  };
}, Il = zi(), Ll = function(e, t, o, n) {
  var i = e.left, r = e.top, s = e.right, a = e.gap;
  return o === void 0 && (o = "margin"), `
  .`.concat(xl, ` {
   overflow: hidden `).concat(n, `;
   padding-right: `).concat(a, "px ").concat(n, `;
  }
  body {
    overflow: hidden `).concat(n, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(n, ";"),
    o === "margin" && `
    padding-left: `.concat(i, `px;
    padding-top: `).concat(r, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(a, "px ").concat(n, `;
    `),
    o === "padding" && "padding-right: ".concat(a, "px ").concat(n, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Rt, ` {
    right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(Ot, ` {
    margin-right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(Rt, " .").concat(Rt, ` {
    right: 0 `).concat(n, `;
  }
  
  .`).concat(Ot, " .").concat(Ot, ` {
    margin-right: 0 `).concat(n, `;
  }
  
  body {
    `).concat(Cl, ": ").concat(a, `px;
  }
`);
}, Ml = function(e) {
  var t = e.noRelative, o = e.noImportant, n = e.gapMode, i = n === void 0 ? "margin" : n, r = A.useMemo(function() {
    return Dl(i);
  }, [i]);
  return A.createElement(Il, { styles: Ll(r, !t, i, o ? "" : "!important") });
}, xo = !1;
if (typeof window < "u")
  try {
    var Pt = Object.defineProperty({}, "passive", {
      get: function() {
        return xo = !0, !0;
      }
    });
    window.addEventListener("test", Pt, Pt), window.removeEventListener("test", Pt, Pt);
  } catch {
    xo = !1;
  }
var nt = xo ? { passive: !1 } : !1, Fl = function(e) {
  return e.tagName === "TEXTAREA";
}, Di = function(e, t) {
  var o = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    o[t] !== "hidden" && // contains scroll inside self
    !(o.overflowY === o.overflowX && !Fl(e) && o[t] === "visible")
  );
}, Hl = function(e) {
  return Di(e, "overflowY");
}, Vl = function(e) {
  return Di(e, "overflowX");
}, wn = function(e, t) {
  var o = t;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var n = Ii(e, o);
    if (n) {
      var i = Li(e, o), r = i[1], s = i[2];
      if (r > s)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== document.body);
  return !1;
}, Wl = function(e) {
  var t = e.scrollTop, o = e.scrollHeight, n = e.clientHeight;
  return [
    t,
    o,
    n
  ];
}, Bl = function(e) {
  var t = e.scrollLeft, o = e.scrollWidth, n = e.clientWidth;
  return [
    t,
    o,
    n
  ];
}, Ii = function(e, t) {
  return e === "v" ? Hl(t) : Vl(t);
}, Li = function(e, t) {
  return e === "v" ? Wl(t) : Bl(t);
}, Ul = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Xl = function(e, t, o, n, i) {
  var r = Ul(e, window.getComputedStyle(t).direction), s = r * n, a = o.target, l = t.contains(a), d = !1, f = s > 0, u = 0, m = 0;
  do {
    var p = Li(e, a), v = p[0], g = p[1], h = p[2], b = g - h - r * v;
    (v || b) && Ii(e, a) && (u += b, m += v), a = a.parentNode;
  } while (
    // portaled content
    !l && a !== document.body || // self content
    l && (t.contains(a) || t === a)
  );
  return (f && (i && u === 0 || !i && s > u) || !f && (i && m === 0 || !i && -s > m)) && (d = !0), d;
}, Et = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, _n = function(e) {
  return [e.deltaX, e.deltaY];
}, $n = function(e) {
  return e && "current" in e ? e.current : e;
}, Kl = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Yl = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Gl = 0, it = [];
function Zl(e) {
  var t = A.useRef([]), o = A.useRef([0, 0]), n = A.useRef(), i = A.useState(Gl++)[0], r = A.useState(function() {
    return zi();
  })[0], s = A.useRef(e);
  A.useEffect(function() {
    s.current = e;
  }, [e]), A.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(i));
      var g = bl([e.lockRef.current], (e.shards || []).map($n), !0).filter(Boolean);
      return g.forEach(function(h) {
        return h.classList.add("allow-interactivity-".concat(i));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(i)), g.forEach(function(h) {
          return h.classList.remove("allow-interactivity-".concat(i));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var a = A.useCallback(function(g, h) {
    if ("touches" in g && g.touches.length === 2)
      return !s.current.allowPinchZoom;
    var b = Et(g), y = o.current, x = "deltaX" in g ? g.deltaX : y[0] - b[0], _ = "deltaY" in g ? g.deltaY : y[1] - b[1], S, E = g.target, P = Math.abs(x) > Math.abs(_) ? "h" : "v";
    if ("touches" in g && P === "h" && E.type === "range")
      return !1;
    var T = wn(P, E);
    if (!T)
      return !0;
    if (T ? S = P : (S = P === "v" ? "h" : "v", T = wn(P, E)), !T)
      return !1;
    if (!n.current && "changedTouches" in g && (x || _) && (n.current = S), !S)
      return !0;
    var F = n.current || S;
    return Xl(F, h, g, F === "h" ? x : _, !0);
  }, []), l = A.useCallback(function(g) {
    var h = g;
    if (!(!it.length || it[it.length - 1] !== r)) {
      var b = "deltaY" in h ? _n(h) : Et(h), y = t.current.filter(function(S) {
        return S.name === h.type && S.target === h.target && Kl(S.delta, b);
      })[0];
      if (y && y.should) {
        h.cancelable && h.preventDefault();
        return;
      }
      if (!y) {
        var x = (s.current.shards || []).map($n).filter(Boolean).filter(function(S) {
          return S.contains(h.target);
        }), _ = x.length > 0 ? a(h, x[0]) : !s.current.noIsolation;
        _ && h.cancelable && h.preventDefault();
      }
    }
  }, []), d = A.useCallback(function(g, h, b, y) {
    var x = { name: g, delta: h, target: b, should: y };
    t.current.push(x), setTimeout(function() {
      t.current = t.current.filter(function(_) {
        return _ !== x;
      });
    }, 1);
  }, []), f = A.useCallback(function(g) {
    o.current = Et(g), n.current = void 0;
  }, []), u = A.useCallback(function(g) {
    d(g.type, _n(g), g.target, a(g, e.lockRef.current));
  }, []), m = A.useCallback(function(g) {
    d(g.type, Et(g), g.target, a(g, e.lockRef.current));
  }, []);
  A.useEffect(function() {
    return it.push(r), e.setCallbacks({
      onScrollCapture: u,
      onWheelCapture: u,
      onTouchMoveCapture: m
    }), document.addEventListener("wheel", l, nt), document.addEventListener("touchmove", l, nt), document.addEventListener("touchstart", f, nt), function() {
      it = it.filter(function(g) {
        return g !== r;
      }), document.removeEventListener("wheel", l, nt), document.removeEventListener("touchmove", l, nt), document.removeEventListener("touchstart", f, nt);
    };
  }, []);
  var p = e.removeScrollBar, v = e.inert;
  return A.createElement(
    A.Fragment,
    null,
    v ? A.createElement(r, { styles: Yl(i) }) : null,
    p ? A.createElement(Ml, { gapMode: "margin" }) : null
  );
}
const Jl = El(ji, Zl);
var Mi = A.forwardRef(function(e, t) {
  return A.createElement(Xt, Ne({}, e, { ref: t, sideCar: Jl }));
});
Mi.classNames = Xt.classNames;
const Ql = Mi, ec = [
  " ",
  "Enter",
  "ArrowUp",
  "ArrowDown"
], tc = [
  " ",
  "Enter"
], Kt = "Select", [Yt, Gt, oc] = el(Kt), [dt, Ld] = Ft(Kt, [
  oc,
  Wt
]), Oo = Wt(), [nc, Ge] = dt(Kt), [ic, rc] = dt(Kt), ac = (e) => {
  const { __scopeSelect: t, children: o, open: n, defaultOpen: i, onOpenChange: r, value: s, defaultValue: a, onValueChange: l, dir: d, name: f, autoComplete: u, disabled: m, required: p } = e, v = Oo(t), [g, h] = G(null), [b, y] = G(null), [x, _] = G(!1), S = ol(d), [E = !1, P] = go({
    prop: n,
    defaultProp: i,
    onChange: r
  }), [T, F] = go({
    prop: s,
    defaultProp: a,
    onChange: l
  }), X = ne(null), q = g ? !!g.closest("form") : !0, [W, j] = G(/* @__PURE__ */ new Set()), L = Array.from(W).map(
    (I) => I.props.value
  ).join(";");
  return /* @__PURE__ */ $(ci, v, /* @__PURE__ */ $(nc, {
    required: p,
    scope: t,
    trigger: g,
    onTriggerChange: h,
    valueNode: b,
    onValueNodeChange: y,
    valueNodeHasChildren: x,
    onValueNodeHasChildrenChange: _,
    contentId: Ro(),
    value: T,
    onValueChange: F,
    open: E,
    onOpenChange: P,
    dir: S,
    triggerPointerDownPosRef: X,
    disabled: m
  }, /* @__PURE__ */ $(Yt.Provider, {
    scope: t
  }, /* @__PURE__ */ $(ic, {
    scope: e.__scopeSelect,
    onNativeOptionAdd: le((I) => {
      j(
        (R) => new Set(R).add(I)
      );
    }, []),
    onNativeOptionRemove: le((I) => {
      j((R) => {
        const Q = new Set(R);
        return Q.delete(I), Q;
      });
    }, [])
  }, o)), q ? /* @__PURE__ */ $(Wi, {
    key: L,
    "aria-hidden": !0,
    required: p,
    tabIndex: -1,
    name: f,
    autoComplete: u,
    value: T,
    onChange: (I) => F(I.target.value),
    disabled: m
  }, T === void 0 ? /* @__PURE__ */ $("option", {
    value: ""
  }) : null, Array.from(W)) : null));
}, sc = "SelectTrigger", lc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, disabled: n = !1, ...i } = e, r = Oo(o), s = Ge(sc, o), a = s.disabled || n, l = ge(t, s.onTriggerChange), d = Gt(o), [f, u, m] = Bi((v) => {
    const g = d().filter(
      (y) => !y.disabled
    ), h = g.find(
      (y) => y.value === s.value
    ), b = Ui(g, v, h);
    b !== void 0 && s.onValueChange(b.value);
  }), p = () => {
    a || (s.onOpenChange(!0), m());
  };
  return /* @__PURE__ */ $(di, M({
    asChild: !0
  }, r), /* @__PURE__ */ $(ce.button, M({
    type: "button",
    role: "combobox",
    "aria-controls": s.contentId,
    "aria-expanded": s.open,
    "aria-required": s.required,
    "aria-autocomplete": "none",
    dir: s.dir,
    "data-state": s.open ? "open" : "closed",
    disabled: a,
    "data-disabled": a ? "" : void 0,
    "data-placeholder": s.value === void 0 ? "" : void 0
  }, i, {
    ref: l,
    onClick: oe(i.onClick, (v) => {
      v.currentTarget.focus();
    }),
    onPointerDown: oe(i.onPointerDown, (v) => {
      const g = v.target;
      g.hasPointerCapture(v.pointerId) && g.releasePointerCapture(v.pointerId), v.button === 0 && v.ctrlKey === !1 && (p(), s.triggerPointerDownPosRef.current = {
        x: Math.round(v.pageX),
        y: Math.round(v.pageY)
      }, v.preventDefault());
    }),
    onKeyDown: oe(i.onKeyDown, (v) => {
      const g = f.current !== "";
      !(v.ctrlKey || v.altKey || v.metaKey) && v.key.length === 1 && u(v.key), !(g && v.key === " ") && ec.includes(v.key) && (p(), v.preventDefault());
    })
  })));
}), cc = "SelectValue", dc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, className: n, style: i, children: r, placeholder: s, ...a } = e, l = Ge(cc, o), { onValueNodeHasChildrenChange: d } = l, f = r !== void 0, u = ge(t, l.onValueNodeChange);
  return xe(() => {
    d(f);
  }, [
    d,
    f
  ]), /* @__PURE__ */ $(ce.span, M({}, a, {
    ref: u,
    style: {
      pointerEvents: "none"
    }
  }), l.value === void 0 && s !== void 0 ? s : r);
}), uc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, children: n, ...i } = e;
  return /* @__PURE__ */ $(ce.span, M({
    "aria-hidden": !0
  }, i, {
    ref: t
  }), n || "▼");
}), fc = (e) => /* @__PURE__ */ $(fi, M({
  asChild: !0
}, e)), lt = "SelectContent", gc = /* @__PURE__ */ D((e, t) => {
  const o = Ge(lt, e.__scopeSelect), [n, i] = G();
  if (xe(() => {
    i(new DocumentFragment());
  }, []), !o.open) {
    const r = n;
    return r ? /* @__PURE__ */ On(/* @__PURE__ */ $(Fi, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ $(Yt.Slot, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ $("div", null, e.children))), r) : null;
  }
  return /* @__PURE__ */ $(pc, M({}, e, {
    ref: t
  }));
}), je = 10, [Fi, Ze] = dt(lt), pc = /* @__PURE__ */ D((e, t) => {
  const {
    __scopeSelect: o,
    position: n = "item-aligned",
    onCloseAutoFocus: i,
    onEscapeKeyDown: r,
    onPointerDownOutside: s,
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: m,
    collisionPadding: p,
    sticky: v,
    hideWhenDetached: g,
    avoidCollisions: h,
    //
    ...b
  } = e, y = Ge(lt, o), [x, _] = G(null), [S, E] = G(null), P = ge(
    t,
    (O) => _(O)
  ), [T, F] = G(null), [X, q] = G(null), W = Gt(o), [j, L] = G(!1), I = ne(!1);
  ie(() => {
    if (x)
      return yl(x);
  }, [
    x
  ]), nl();
  const R = le((O) => {
    const [U, ...fe] = W().map(
      (K) => K.ref.current
    ), [Z] = fe.slice(-1), J = document.activeElement;
    for (const K of O)
      if (K === J || (K == null || K.scrollIntoView({
        block: "nearest"
      }), K === U && S && (S.scrollTop = 0), K === Z && S && (S.scrollTop = S.scrollHeight), K == null || K.focus(), document.activeElement !== J))
        return;
  }, [
    W,
    S
  ]), Q = le(
    () => R([
      T,
      x
    ]),
    [
      R,
      T,
      x
    ]
  );
  ie(() => {
    j && Q();
  }, [
    j,
    Q
  ]);
  const { onOpenChange: ee, triggerPointerDownPosRef: pe } = y;
  ie(() => {
    if (x) {
      let O = {
        x: 0,
        y: 0
      };
      const U = (Z) => {
        var J, K, he, ve;
        O = {
          x: Math.abs(Math.round(Z.pageX) - ((J = (K = pe.current) === null || K === void 0 ? void 0 : K.x) !== null && J !== void 0 ? J : 0)),
          y: Math.abs(Math.round(Z.pageY) - ((he = (ve = pe.current) === null || ve === void 0 ? void 0 : ve.y) !== null && he !== void 0 ? he : 0))
        };
      }, fe = (Z) => {
        O.x <= 10 && O.y <= 10 ? Z.preventDefault() : x.contains(Z.target) || ee(!1), document.removeEventListener("pointermove", U), pe.current = null;
      };
      return pe.current !== null && (document.addEventListener("pointermove", U), document.addEventListener("pointerup", fe, {
        capture: !0,
        once: !0
      })), () => {
        document.removeEventListener("pointermove", U), document.removeEventListener("pointerup", fe, {
          capture: !0
        });
      };
    }
  }, [
    x,
    ee,
    pe
  ]), ie(() => {
    const O = () => ee(!1);
    return window.addEventListener("blur", O), window.addEventListener("resize", O), () => {
      window.removeEventListener("blur", O), window.removeEventListener("resize", O);
    };
  }, [
    ee
  ]);
  const [re, ue] = Bi((O) => {
    const U = W().filter(
      (J) => !J.disabled
    ), fe = U.find(
      (J) => J.ref.current === document.activeElement
    ), Z = Ui(U, O, fe);
    Z && setTimeout(
      () => Z.ref.current.focus()
    );
  }), me = le((O, U, fe) => {
    const Z = !I.current && !fe;
    (y.value !== void 0 && y.value === U || Z) && (F(O), Z && (I.current = !0));
  }, [
    y.value
  ]), ke = le(
    () => x == null ? void 0 : x.focus(),
    [
      x
    ]
  ), Ce = le((O, U, fe) => {
    const Z = !I.current && !fe;
    (y.value !== void 0 && y.value === U || Z) && q(O);
  }, [
    y.value
  ]), we = n === "popper" ? kn : vc, Se = we === kn ? {
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: m,
    collisionPadding: p,
    sticky: v,
    hideWhenDetached: g,
    avoidCollisions: h
  } : {};
  return /* @__PURE__ */ $(Fi, {
    scope: o,
    content: x,
    viewport: S,
    onViewportChange: E,
    itemRefCallback: me,
    selectedItem: T,
    onItemLeave: ke,
    itemTextRefCallback: Ce,
    focusSelectedItem: Q,
    selectedItemText: X,
    position: n,
    isPositioned: j,
    searchRef: re
  }, /* @__PURE__ */ $(Ql, {
    as: xt,
    allowPinchZoom: !0
  }, /* @__PURE__ */ $(il, {
    asChild: !0,
    trapped: y.open,
    onMountAutoFocus: (O) => {
      O.preventDefault();
    },
    onUnmountAutoFocus: oe(i, (O) => {
      var U;
      (U = y.trigger) === null || U === void 0 || U.focus({
        preventScroll: !0
      }), O.preventDefault();
    })
  }, /* @__PURE__ */ $(gi, {
    asChild: !0,
    disableOutsidePointerEvents: !0,
    onEscapeKeyDown: r,
    onPointerDownOutside: s,
    onFocusOutside: (O) => O.preventDefault(),
    onDismiss: () => y.onOpenChange(!1)
  }, /* @__PURE__ */ $(we, M({
    role: "listbox",
    id: y.contentId,
    "data-state": y.open ? "open" : "closed",
    dir: y.dir,
    onContextMenu: (O) => O.preventDefault()
  }, b, Se, {
    onPlaced: () => L(!0),
    ref: P,
    style: {
      // flex layout so we can place the scroll buttons properly
      display: "flex",
      flexDirection: "column",
      // reset the outline by default as the content MAY get focused
      outline: "none",
      ...b.style
    },
    onKeyDown: oe(b.onKeyDown, (O) => {
      const U = O.ctrlKey || O.altKey || O.metaKey;
      if (O.key === "Tab" && O.preventDefault(), !U && O.key.length === 1 && ue(O.key), [
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End"
      ].includes(O.key)) {
        let Z = W().filter(
          (J) => !J.disabled
        ).map(
          (J) => J.ref.current
        );
        if ([
          "ArrowUp",
          "End"
        ].includes(O.key) && (Z = Z.slice().reverse()), [
          "ArrowUp",
          "ArrowDown"
        ].includes(O.key)) {
          const J = O.target, K = Z.indexOf(J);
          Z = Z.slice(K + 1);
        }
        setTimeout(
          () => R(Z)
        ), O.preventDefault();
      }
    })
  }))))));
}), vc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, onPlaced: n, ...i } = e, r = Ge(lt, o), s = Ze(lt, o), [a, l] = G(null), [d, f] = G(null), u = ge(
    t,
    (P) => f(P)
  ), m = Gt(o), p = ne(!1), v = ne(!0), { viewport: g, selectedItem: h, selectedItemText: b, focusSelectedItem: y } = s, x = le(() => {
    if (r.trigger && r.valueNode && a && d && g && h && b) {
      const P = r.trigger.getBoundingClientRect(), T = d.getBoundingClientRect(), F = r.valueNode.getBoundingClientRect(), X = b.getBoundingClientRect();
      if (r.dir !== "rtl") {
        const J = X.left - T.left, K = F.left - J, he = P.left - K, ve = P.width + he, Re = Math.max(ve, T.width), Oe = window.innerWidth - je, Me = vn(K, [
          je,
          Oe - Re
        ]);
        a.style.minWidth = ve + "px", a.style.left = Me + "px";
      } else {
        const J = T.right - X.right, K = window.innerWidth - F.right - J, he = window.innerWidth - P.right - K, ve = P.width + he, Re = Math.max(ve, T.width), Oe = window.innerWidth - je, Me = vn(K, [
          je,
          Oe - Re
        ]);
        a.style.minWidth = ve + "px", a.style.right = Me + "px";
      }
      const q = m(), W = window.innerHeight - je * 2, j = g.scrollHeight, L = window.getComputedStyle(d), I = parseInt(L.borderTopWidth, 10), R = parseInt(L.paddingTop, 10), Q = parseInt(L.borderBottomWidth, 10), ee = parseInt(L.paddingBottom, 10), pe = I + R + j + ee + Q, re = Math.min(h.offsetHeight * 5, pe), ue = window.getComputedStyle(g), me = parseInt(ue.paddingTop, 10), ke = parseInt(ue.paddingBottom, 10), Ce = P.top + P.height / 2 - je, we = W - Ce, Se = h.offsetHeight / 2, O = h.offsetTop + Se, U = I + R + O, fe = pe - U;
      if (U <= Ce) {
        const J = h === q[q.length - 1].ref.current;
        a.style.bottom = "0px";
        const K = d.clientHeight - g.offsetTop - g.offsetHeight, he = Math.max(we, Se + (J ? ke : 0) + K + Q), ve = U + he;
        a.style.height = ve + "px";
      } else {
        const J = h === q[0].ref.current;
        a.style.top = "0px";
        const he = Math.max(Ce, I + g.offsetTop + (J ? me : 0) + Se) + fe;
        a.style.height = he + "px", g.scrollTop = U - Ce + g.offsetTop;
      }
      a.style.margin = `${je}px 0`, a.style.minHeight = re + "px", a.style.maxHeight = W + "px", n == null || n(), requestAnimationFrame(
        () => p.current = !0
      );
    }
  }, [
    m,
    r.trigger,
    r.valueNode,
    a,
    d,
    g,
    h,
    b,
    r.dir,
    n
  ]);
  xe(
    () => x(),
    [
      x
    ]
  );
  const [_, S] = G();
  xe(() => {
    d && S(window.getComputedStyle(d).zIndex);
  }, [
    d
  ]);
  const E = le((P) => {
    P && v.current === !0 && (x(), y == null || y(), v.current = !1);
  }, [
    x,
    y
  ]);
  return /* @__PURE__ */ $(mc, {
    scope: o,
    contentWrapper: a,
    shouldExpandOnScrollRef: p,
    onScrollButtonChange: E
  }, /* @__PURE__ */ $("div", {
    ref: l,
    style: {
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      zIndex: _
    }
  }, /* @__PURE__ */ $(ce.div, M({}, i, {
    ref: u,
    style: {
      // When we get the height of the content, it includes borders. If we were to set
      // the height without having `boxSizing: 'border-box'` it would be too big.
      boxSizing: "border-box",
      // We need to ensure the content doesn't get taller than the wrapper
      maxHeight: "100%",
      ...i.style
    }
  }))));
}), kn = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, align: n = "start", collisionPadding: i = je, ...r } = e, s = Oo(o);
  return /* @__PURE__ */ $(ui, M({}, s, r, {
    ref: t,
    align: n,
    collisionPadding: i,
    style: {
      // Ensure border-box for floating-ui calculations
      boxSizing: "border-box",
      ...r.style,
      "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-select-content-available-width": "var(--radix-popper-available-width)",
      "--radix-select-content-available-height": "var(--radix-popper-available-height)",
      "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
    }
  }));
}), [mc, No] = dt(lt, {}), Sn = "SelectViewport", hc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = Ze(Sn, o), r = No(Sn, o), s = ge(t, i.onViewportChange), a = ne(0);
  return /* @__PURE__ */ $(_o, null, /* @__PURE__ */ $("style", {
    dangerouslySetInnerHTML: {
      __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
    }
  }), /* @__PURE__ */ $(Yt.Slot, {
    scope: o
  }, /* @__PURE__ */ $(ce.div, M({
    "data-radix-select-viewport": "",
    role: "presentation"
  }, n, {
    ref: s,
    style: {
      // we use position: 'relative' here on the `viewport` so that when we call
      // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
      // (independent of the scrollUpButton).
      position: "relative",
      flex: 1,
      overflow: "auto",
      ...n.style
    },
    onScroll: oe(n.onScroll, (l) => {
      const d = l.currentTarget, { contentWrapper: f, shouldExpandOnScrollRef: u } = r;
      if (u != null && u.current && f) {
        const m = Math.abs(a.current - d.scrollTop);
        if (m > 0) {
          const p = window.innerHeight - je * 2, v = parseFloat(f.style.minHeight), g = parseFloat(f.style.height), h = Math.max(v, g);
          if (h < p) {
            const b = h + m, y = Math.min(p, b), x = b - y;
            f.style.height = y + "px", f.style.bottom === "0px" && (d.scrollTop = x > 0 ? x : 0, f.style.justifyContent = "flex-end");
          }
        }
      }
      a.current = d.scrollTop;
    })
  }))));
}), yc = "SelectGroup", [bc, xc] = dt(yc), Cc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = Ro();
  return /* @__PURE__ */ $(bc, {
    scope: o,
    id: i
  }, /* @__PURE__ */ $(ce.div, M({
    role: "group",
    "aria-labelledby": i
  }, n, {
    ref: t
  })));
}), wc = "SelectLabel", _c = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = xc(wc, o);
  return /* @__PURE__ */ $(ce.div, M({
    id: i.id
  }, n, {
    ref: t
  }));
}), Co = "SelectItem", [$c, Hi] = dt(Co), kc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, value: n, disabled: i = !1, textValue: r, ...s } = e, a = Ge(Co, o), l = Ze(Co, o), d = a.value === n, [f, u] = G(r ?? ""), [m, p] = G(!1), v = ge(t, (b) => {
    var y;
    return (y = l.itemRefCallback) === null || y === void 0 ? void 0 : y.call(l, b, n, i);
  }), g = Ro(), h = () => {
    i || (a.onValueChange(n), a.onOpenChange(!1));
  };
  return /* @__PURE__ */ $($c, {
    scope: o,
    value: n,
    disabled: i,
    textId: g,
    isSelected: d,
    onItemTextChange: le((b) => {
      u((y) => {
        var x;
        return y || ((x = b == null ? void 0 : b.textContent) !== null && x !== void 0 ? x : "").trim();
      });
    }, [])
  }, /* @__PURE__ */ $(Yt.ItemSlot, {
    scope: o,
    value: n,
    disabled: i,
    textValue: f
  }, /* @__PURE__ */ $(ce.div, M({
    role: "option",
    "aria-labelledby": g,
    "data-highlighted": m ? "" : void 0,
    "aria-selected": d && m,
    "data-state": d ? "checked" : "unchecked",
    "aria-disabled": i || void 0,
    "data-disabled": i ? "" : void 0,
    tabIndex: i ? void 0 : -1
  }, s, {
    ref: v,
    onFocus: oe(
      s.onFocus,
      () => p(!0)
    ),
    onBlur: oe(
      s.onBlur,
      () => p(!1)
    ),
    onPointerUp: oe(s.onPointerUp, h),
    onPointerMove: oe(s.onPointerMove, (b) => {
      if (i) {
        var y;
        (y = l.onItemLeave) === null || y === void 0 || y.call(l);
      } else
        b.currentTarget.focus({
          preventScroll: !0
        });
    }),
    onPointerLeave: oe(s.onPointerLeave, (b) => {
      if (b.currentTarget === document.activeElement) {
        var y;
        (y = l.onItemLeave) === null || y === void 0 || y.call(l);
      }
    }),
    onKeyDown: oe(s.onKeyDown, (b) => {
      var y;
      ((y = l.searchRef) === null || y === void 0 ? void 0 : y.current) !== "" && b.key === " " || (tc.includes(b.key) && h(), b.key === " " && b.preventDefault());
    })
  }))));
}), Tt = "SelectItemText", Sc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, className: n, style: i, ...r } = e, s = Ge(Tt, o), a = Ze(Tt, o), l = Hi(Tt, o), d = rc(Tt, o), [f, u] = G(null), m = ge(
    t,
    (b) => u(b),
    l.onItemTextChange,
    (b) => {
      var y;
      return (y = a.itemTextRefCallback) === null || y === void 0 ? void 0 : y.call(a, b, l.value, l.disabled);
    }
  ), p = f == null ? void 0 : f.textContent, v = at(
    () => /* @__PURE__ */ $("option", {
      key: l.value,
      value: l.value,
      disabled: l.disabled
    }, p),
    [
      l.disabled,
      l.value,
      p
    ]
  ), { onNativeOptionAdd: g, onNativeOptionRemove: h } = d;
  return xe(() => (g(v), () => h(v)), [
    g,
    h,
    v
  ]), /* @__PURE__ */ $(_o, null, /* @__PURE__ */ $(ce.span, M({
    id: l.textId
  }, r, {
    ref: m
  })), l.isSelected && s.valueNode && !s.valueNodeHasChildren ? /* @__PURE__ */ On(r.children, s.valueNode) : null);
}), Pc = "SelectItemIndicator", Ec = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return Hi(Pc, o).isSelected ? /* @__PURE__ */ $(ce.span, M({
    "aria-hidden": !0
  }, n, {
    ref: t
  })) : null;
}), Pn = "SelectScrollUpButton", Tc = /* @__PURE__ */ D((e, t) => {
  const o = Ze(Pn, e.__scopeSelect), n = No(Pn, e.__scopeSelect), [i, r] = G(!1), s = ge(t, n.onScrollButtonChange);
  return xe(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollTop > 0;
        r(d);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ $(Vi, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop - l.offsetHeight);
    }
  })) : null;
}), En = "SelectScrollDownButton", Ac = /* @__PURE__ */ D((e, t) => {
  const o = Ze(En, e.__scopeSelect), n = No(En, e.__scopeSelect), [i, r] = G(!1), s = ge(t, n.onScrollButtonChange);
  return xe(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollHeight - a.clientHeight, f = Math.ceil(a.scrollTop) < d;
        r(f);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ $(Vi, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop + l.offsetHeight);
    }
  })) : null;
}), Vi = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, onAutoScroll: n, ...i } = e, r = Ze("SelectScrollButton", o), s = ne(null), a = Gt(o), l = le(() => {
    s.current !== null && (window.clearInterval(s.current), s.current = null);
  }, []);
  return ie(() => () => l(), [
    l
  ]), xe(() => {
    var d;
    const f = a().find(
      (u) => u.ref.current === document.activeElement
    );
    f == null || (d = f.ref.current) === null || d === void 0 || d.scrollIntoView({
      block: "nearest"
    });
  }, [
    a
  ]), /* @__PURE__ */ $(ce.div, M({
    "aria-hidden": !0
  }, i, {
    ref: t,
    style: {
      flexShrink: 0,
      ...i.style
    },
    onPointerDown: oe(i.onPointerDown, () => {
      s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerMove: oe(i.onPointerMove, () => {
      var d;
      (d = r.onItemLeave) === null || d === void 0 || d.call(r), s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerLeave: oe(i.onPointerLeave, () => {
      l();
    })
  }));
}), Rc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return /* @__PURE__ */ $(ce.div, M({
    "aria-hidden": !0
  }, n, {
    ref: t
  }));
}), Wi = /* @__PURE__ */ D((e, t) => {
  const { value: o, ...n } = e, i = ne(null), r = ge(t, i), s = gl(o);
  return ie(() => {
    const a = i.current, l = window.HTMLSelectElement.prototype, f = Object.getOwnPropertyDescriptor(l, "value").set;
    if (s !== o && f) {
      const u = new Event("change", {
        bubbles: !0
      });
      f.call(a, o), a.dispatchEvent(u);
    }
  }, [
    s,
    o
  ]), /* @__PURE__ */ $(pl, {
    asChild: !0
  }, /* @__PURE__ */ $("select", M({}, n, {
    ref: r,
    defaultValue: o
  })));
});
Wi.displayName = "BubbleSelect";
function Bi(e) {
  const t = De(e), o = ne(""), n = ne(0), i = le((s) => {
    const a = o.current + s;
    t(a), function l(d) {
      o.current = d, window.clearTimeout(n.current), d !== "" && (n.current = window.setTimeout(
        () => l(""),
        1e3
      ));
    }(a);
  }, [
    t
  ]), r = le(() => {
    o.current = "", window.clearTimeout(n.current);
  }, []);
  return ie(() => () => window.clearTimeout(n.current), []), [
    o,
    i,
    r
  ];
}
function Ui(e, t, o) {
  const i = t.length > 1 && Array.from(t).every(
    (d) => d === t[0]
  ) ? t[0] : t, r = o ? e.indexOf(o) : -1;
  let s = Oc(e, Math.max(r, 0));
  i.length === 1 && (s = s.filter(
    (d) => d !== o
  ));
  const l = s.find(
    (d) => d.textValue.toLowerCase().startsWith(i.toLowerCase())
  );
  return l !== o ? l : void 0;
}
function Oc(e, t) {
  return e.map(
    (o, n) => e[(t + n) % e.length]
  );
}
const Nc = ac, qc = lc, jc = dc, zc = uc, Dc = fc, Ic = gc, Xi = hc, Lc = Cc, Mc = _c, Fc = kc, Hc = Sc, Vc = Ec, Ki = Tc, Yi = Ac, Wc = Rc;
var Bc = "ibaddl9", Uc = "ibaddla", Xc = "ibaddl2", Kc = "ibaddl8", Yc = "ibaddl7", Gc = "ibaddl3", Zc = "ibaddl4", Jc = "ibaddl5", Qc = "ibaddl6", ed = "ibaddl1";
const td = Nc, od = H.forwardRef(({ children: e, placeholder: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  jc,
  {
    ...o,
    ref: n,
    placeholder: t
  }
)), nd = H.forwardRef(({ className: e, asChild: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  zc,
  {
    ...o,
    ref: n,
    asChild: t,
    className: z(Yc, e),
    children: /* @__PURE__ */ w.jsx(ua, {})
  }
)), id = ({
  children: e,
  asChild: t,
  className: o,
  ...n
}) => /* @__PURE__ */ w.jsx(
  qc,
  {
    ...n,
    asChild: t,
    className: z(o, ed),
    children: e
  }
), rd = ({
  children: e,
  className: t,
  position: o = "popper",
  side: n = "bottom",
  sideOffset: i,
  align: r,
  alignOffset: s = 0,
  avoidCollisions: a = !0,
  sticky: l = "partial",
  hideWhenDetached: d = !1,
  ...f
}) => /* @__PURE__ */ w.jsxs(
  Ic,
  {
    ...f,
    className: z(Xc, t),
    position: o,
    side: n,
    sideOffset: i,
    align: r,
    alignOffset: s,
    avoidCollisions: a,
    sticky: l,
    hideWhenDetached: d,
    children: [
      /* @__PURE__ */ w.jsx(Ki, { className: z(Uc, t), children: /* @__PURE__ */ w.jsx(ga, {}) }),
      /* @__PURE__ */ w.jsx(Xi, { children: e }),
      /* @__PURE__ */ w.jsx(Yi, { className: z(Bc, t), children: /* @__PURE__ */ w.jsx(fa, {}) })
    ]
  }
), ad = H.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsxs(
  Fc,
  {
    ...o,
    ref: n,
    className: z(Gc, t),
    children: [
      /* @__PURE__ */ w.jsx(Hc, { children: e }),
      /* @__PURE__ */ w.jsx(Gi, {})
    ]
  }
)), Gi = ({
  className: e,
  ...t
}) => /* @__PURE__ */ w.jsx(
  Vc,
  {
    ...t,
    className: z(Zc, e)
  }
), sd = ({ className: e, ...t }) => /* @__PURE__ */ w.jsx(
  Wc,
  {
    ...t,
    className: z(Qc, e)
  }
), ld = ({ children: e, className: t, ...o }) => /* @__PURE__ */ w.jsx(
  Mc,
  {
    ...o,
    className: z(Jc, t),
    children: e
  }
), cd = ({ children: e, className: t, ...o }) => /* @__PURE__ */ w.jsx(
  Lc,
  {
    ...o,
    className: z(Kc, t),
    children: e
  }
), de = (e) => /* @__PURE__ */ w.jsx(td, { ...e });
de.Trigger = id;
de.Value = od;
de.Content = rd;
de.Item = ad;
de.Viewport = Xi;
de.Portal = Dc;
de.Icon = nd;
de.Indicator = Gi;
de.Separator = sd;
de.Label = ld;
de.Group = cd;
de.ScrollUpButton = Ki;
de.ScrollDownButton = Yi;
de.displayName = "Select";
de.Value.displayName = "Select.Value";
de.Item.displayName = "Select.Item";
de.Viewport.displayName = "Select.Viewport";
de.Portal.displayName = "Select.Portal";
de.ScrollUpButton.displayName = "Select.ScrollUpButton";
de.ScrollDownButton.displayName = "Select.ScrollDownButton";
var dd = be({ defaultClassName: "_1yr5zenb", variantClassNames: { size: { xs: "_1yr5zen0", sm: "_1yr5zen1", md: "_1yr5zen2", lg: "_1yr5zen3", xl: "_1yr5zen4", xxl: "_1yr5zen5", "3xl": "_1yr5zen6", "4xl": "_1yr5zen7", "5xl": "_1yr5zen8", "6xl": "_1yr5zen9", "7xl": "_1yr5zena" } }, defaultVariants: { size: "sm" }, compoundVariants: [] });
const ud = D(
  ({ size: e = "sm", className: t, ...o }, n) => {
    const i = dd({ size: e });
    return /* @__PURE__ */ w.jsx(
      "div",
      {
        ...o,
        ref: n,
        className: t ? `${t} ${i}` : i
      }
    );
  }
);
ud.displayName = "Space";
const Tn = {
  1: "wrap",
  0: "nowrap"
}, fd = {
  horizontal: "row",
  vertical: "column"
}, gd = (e) => e ? Hn(e, (t) => fd[t]) : void 0, pd = (e) => e ? typeof e == "boolean" ? Tn[1] : Hn(
  e,
  // Hack to convert boolean to number since Sprinkles does not support
  // boolean responsive keys
  (t) => Tn[+t]
) : void 0, Md = [
  "a",
  "article",
  "div",
  "form",
  "header",
  "label",
  "li",
  "main",
  "section",
  "span"
], Fd = ({
  as: e = "div",
  align: t,
  children: o,
  justify: n,
  flex: i,
  direction: r = "vertical",
  space: s = "4px 4px",
  wrap: a
}) => {
  const l = gd(r), d = pd(a);
  return /* @__PURE__ */ w.jsx(
    ko,
    {
      alignItems: t,
      as: e,
      display: "flex",
      flex: i,
      flexDirection: l,
      flexWrap: d,
      gap: s,
      justifyContent: n,
      children: o
    }
  );
};
var vd = be({ defaultClassName: "_17w677g0", variantClassNames: { size: { small: "_17w677g2", medium: "_17w677g3" } }, defaultVariants: { size: "small" }, compoundVariants: [] }), md = be({ defaultClassName: "_17w677g1", variantClassNames: { size: { small: "_17w677g4", medium: "_17w677g5" } }, defaultVariants: { size: "small" }, compoundVariants: [] });
const hd = ({
  className: e,
  asChild: t,
  defaultChecked: o,
  checked: n,
  onCheckedChange: i,
  disabled: r,
  required: s,
  name: a,
  value: l,
  size: d = "small",
  ...f
}) => /* @__PURE__ */ w.jsx(
  _r,
  {
    ...f,
    asChild: t,
    className: z(e, vd({ size: d })),
    defaultChecked: o,
    checked: n,
    onCheckedChange: i,
    disabled: r,
    required: s,
    name: a,
    value: l
  }
), Zi = D((e, t) => {
  const { className: o, size: n = "small", asChild: i = !1, ...r } = e;
  return /* @__PURE__ */ w.jsx(
    wr,
    {
      ...r,
      ref: t,
      asChild: i,
      className: z(o, md({ size: n }))
    }
  );
}), qo = (e) => /* @__PURE__ */ w.jsx(hd, { ...e });
qo.Toggle = Zi;
qo.displayName = "Switch";
qo.Toggle.displayName = "Switch.Toggle";
Zi.displayName = "Switch.Toggle";
var yd = be({ defaultClassName: "fpsfqv34", variantClassNames: { font: { system: "fpsfqv0", inter: "fpsfqv1", mono: "fpsfqv2" }, size: { xs: "fpsfqv3", sm: "fpsfqv4", md: "fpsfqv5", lg: "fpsfqv6", xl: "fpsfqv7", xxl: "fpsfqv8", "3xl": "fpsfqv9", "4xl": "fpsfqva", "5xl": "fpsfqvb", "6xl": "fpsfqvc", "7xl": "fpsfqvd", "8xl": "fpsfqve", "9xl": "fpsfqvf" }, weight: { superlite: "fpsfqvg", lite: "fpsfqvh", normal: "fpsfqvi", medium: "fpsfqvj", semibold: "fpsfqvk", bold: "fpsfqvl", heavy: "fpsfqvm", black: "fpsfqvn" }, color: { transparent: "fpsfqvo", current: "fpsfqvp", white: "fpsfqvq", black: "fpsfqvr", gray100: "fpsfqvs", gray200: "fpsfqvt", gray300: "fpsfqvu", pale100: "fpsfqvv", pale200: "fpsfqvw", pale300: "fpsfqvx", pale400: "fpsfqvy", pale500: "fpsfqvz", hyper0: "fpsfqv10", hyper1: "fpsfqv11", hyper2: "fpsfqv12", hyper3: "fpsfqv13", hyper4: "fpsfqv14", hyper5: "fpsfqv15", hyper6: "fpsfqv16", hyper7: "fpsfqv17", hyper8: "fpsfqv18", hyper9: "fpsfqv19", hyper10: "fpsfqv1a", hyper11: "fpsfqv1b", hyper12: "fpsfqv1c", hyper13: "fpsfqv1d", lemon0: "fpsfqv1e", lemon1: "fpsfqv1f", lemon2: "fpsfqv1g", lemon3: "fpsfqv1h", lemon4: "fpsfqv1i", lemon5: "fpsfqv1j", lemon6: "fpsfqv1k", lemon7: "fpsfqv1l", lemon8: "fpsfqv1m", lemon9: "fpsfqv1n", lemon10: "fpsfqv1o", lemon11: "fpsfqv1p", lemon12: "fpsfqv1q", lemon13: "fpsfqv1r", slate1: "fpsfqv1s", slate2: "fpsfqv1t", slate3: "fpsfqv1u", slate4: "fpsfqv1v", slate5: "fpsfqv1w", slate6: "fpsfqv1x", slate7: "fpsfqv1y", slate8: "fpsfqv1z", slate9: "fpsfqv20", slate10: "fpsfqv21", slate11: "fpsfqv22", slate12: "fpsfqv23", slate13: "fpsfqv24", sapphire0: "fpsfqv25", sapphire1: "fpsfqv26", sapphire2: "fpsfqv27", sapphire3: "fpsfqv28", sapphire4: "fpsfqv29", sapphire5: "fpsfqv2a", sapphire6: "fpsfqv2b", sapphire7: "fpsfqv2c", sapphire8: "fpsfqv2d", sapphire9: "fpsfqv2e", sapphire10: "fpsfqv2f", sapphire11: "fpsfqv2g", sapphire12: "fpsfqv2h", sapphire13: "fpsfqv2i", volt0: "fpsfqv2j", volt1: "fpsfqv2k", volt2: "fpsfqv2l", volt3: "fpsfqv2m", volt4: "fpsfqv2n", volt5: "fpsfqv2o", volt6: "fpsfqv2p", volt7: "fpsfqv2q", volt8: "fpsfqv2r", volt9: "fpsfqv2s", volt10: "fpsfqv2t", volt11: "fpsfqv2u", volt12: "fpsfqv2v", volt13: "fpsfqv2w" }, align: { left: "fpsfqv2x", center: "fpsfqv2y", right: "fpsfqv2z" }, casing: { none: "fpsfqv30", uppercase: "fpsfqv31", lowercase: "fpsfqv32", capitalize: "fpsfqv33" } }, defaultVariants: { font: "system", size: "md", weight: "medium", color: "slate5", align: "left", casing: "none" }, compoundVariants: [] });
const bd = H.forwardRef(
  ({
    children: e,
    className: t,
    font: o = "inter",
    size: n = "md",
    align: i = "left",
    color: r = "slate5",
    weight: s = "medium",
    casing: a,
    ...l
  }, d) => /* @__PURE__ */ w.jsx(
    "p",
    {
      ref: d,
      className: z(t, yd({ font: o, size: n, align: i, color: r, weight: s, casing: a })),
      ...l,
      children: e
    }
  )
);
bd.displayName = "Text";
var xd = "fgg2xl1", Cd = "fgg2xl0";
const wd = 500, _d = 300, $d = !1, kd = ({ children: e, ...t }) => /* @__PURE__ */ w.jsx(
  qt.Provider,
  {
    delayDuration: wd,
    skipDelayDuration: _d,
    disableHoverableContent: $d,
    children: /* @__PURE__ */ w.jsx(qt.Root, { ...t, children: e })
  }
), Ji = H.forwardRef(
  ({
    children: e,
    className: t,
    onEscapeKeyDown: o,
    onPointerDownOutside: n,
    forceMount: i,
    side: r = "right",
    sideOffset: s = 10,
    align: a = "center",
    alignOffset: l = 0,
    avoidCollisions: d = !0,
    sticky: f = "always",
    hideWhenDetached: u = !1,
    //..
    ...m
  }, p) => /* @__PURE__ */ w.jsx(
    qt.Content,
    {
      ...m,
      ref: p,
      "aria-label": "atelier-tip",
      side: r,
      sideOffset: s,
      align: a,
      alignOffset: l,
      avoidCollisions: d,
      sticky: f,
      hideWhenDetached: u,
      className: z(t, xd),
      children: e
    }
  )
), Qi = H.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    qt.Trigger,
    {
      ...t,
      ref: o,
      className: Cd,
      children: e
    }
  )
), jo = (e) => /* @__PURE__ */ w.jsx(kd, { ...e });
jo.Trigger = Qi;
jo.Content = Ji;
jo.displayName = "Tip";
Qi.displayName = "TipTrigger";
Ji.displayName = "TipContent";
export {
  ua as ArrowDownIcon,
  jd as ArrowUpIcon,
  Ke as Avi,
  zr as Button,
  Lr as Canvas,
  Mr as CanvasBlur,
  Hr as Chip,
  Wr as Container,
  Ur as Flex,
  Dd as Grid,
  va as Heading,
  Ct as HoverCard,
  Rs as Inline,
  Ao as Input,
  Wn as KitContext,
  qd as KitProvider,
  zd as LogoIcon,
  Le as Menubar,
  Ws as Paragraph,
  Us as PassLink,
  $e as Popover,
  ko as Rect,
  Qs as Section,
  de as Select,
  fa as SmallArrowDownIcon,
  ga as SmallArrowUpIcon,
  ud as Space,
  Fd as Stack,
  qo as Switch,
  bd as Text,
  jo as Tip,
  la as atoms,
  Jr as base,
  Ad as breakpoints,
  Od as colorModeStyle,
  gd as directionToFlexDirection,
  Qr as element,
  Rd as kit,
  Td as mapColorValue,
  Hn as mapResponsiveValue,
  Vn as sprinkles,
  Nd as useTheme,
  Md as validStackComponents,
  pd as wrapToFlexWrap
};
//# sourceMappingURL=index.js.map
