/*! 
    atelierkit© v0.3.2. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
     */
import * as R from "react";
import B, { createContext as ht, useMemo as at, createElement as $, useContext as Mt, useRef as ne, useEffect as re, useCallback as le, useState as G, useLayoutEffect as En, forwardRef as D, Children as rt, isValidElement as Nt, cloneElement as wo, Fragment as _o, useReducer as hi } from "react";
import * as $o from "@radix-ui/react-avatar";
import * as bi from "react-dom";
import yi, { flushSync as Tn, createPortal as Rn } from "react-dom";
import * as Ie from "@radix-ui/react-menubar";
import * as Ve from "@radix-ui/react-popover";
import { Thumb as xi, Root as Ci } from "@radix-ui/react-switch";
import * as qt from "@radix-ui/react-tooltip";
var fo = { exports: {} }, ft = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Uo;
function wi() {
  if (Uo)
    return ft;
  Uo = 1;
  var e = B, t = Symbol.for("react.element"), o = Symbol.for("react.fragment"), n = Object.prototype.hasOwnProperty, r = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, i = { key: !0, ref: !0, __self: !0, __source: !0 };
  function s(a, l, d) {
    var f, u = {}, m = null, p = null;
    d !== void 0 && (m = "" + d), l.key !== void 0 && (m = "" + l.key), l.ref !== void 0 && (p = l.ref);
    for (f in l)
      n.call(l, f) && !i.hasOwnProperty(f) && (u[f] = l[f]);
    if (a && a.defaultProps)
      for (f in l = a.defaultProps, l)
        u[f] === void 0 && (u[f] = l[f]);
    return { $$typeof: t, type: a, key: m, ref: p, props: u, _owner: r.current };
  }
  return ft.Fragment = o, ft.jsx = s, ft.jsxs = s, ft;
}
var gt = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Xo;
function _i() {
  return Xo || (Xo = 1, process.env.NODE_ENV !== "production" && function() {
    var e = B, t = Symbol.for("react.element"), o = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), r = Symbol.for("react.strict_mode"), i = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), a = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), d = Symbol.for("react.suspense"), f = Symbol.for("react.suspense_list"), u = Symbol.for("react.memo"), m = Symbol.for("react.lazy"), p = Symbol.for("react.offscreen"), v = Symbol.iterator, g = "@@iterator";
    function h(c) {
      if (c === null || typeof c != "object")
        return null;
      var C = v && c[v] || c[g];
      return typeof C == "function" ? C : null;
    }
    var y = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function b(c) {
      {
        for (var C = arguments.length, k = new Array(C > 1 ? C - 1 : 0), N = 1; N < C; N++)
          k[N - 1] = arguments[N];
        x("error", c, k);
      }
    }
    function x(c, C, k) {
      {
        var N = y.ReactDebugCurrentFrame, Y = N.getStackAddendum();
        Y !== "" && (C += "%s", k = k.concat([Y]));
        var te = k.map(function(W) {
          return String(W);
        });
        te.unshift("Warning: " + C), Function.prototype.apply.call(console[c], console, te);
      }
    }
    var _ = !1, S = !1, E = !1, P = !1, T = !1, F;
    F = Symbol.for("react.module.reference");
    function X(c) {
      return !!(typeof c == "string" || typeof c == "function" || c === n || c === i || T || c === r || c === d || c === f || P || c === p || _ || S || E || typeof c == "object" && c !== null && (c.$$typeof === m || c.$$typeof === u || c.$$typeof === s || c.$$typeof === a || c.$$typeof === l || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      c.$$typeof === F || c.getModuleId !== void 0));
    }
    function q(c, C, k) {
      var N = c.displayName;
      if (N)
        return N;
      var Y = C.displayName || C.name || "";
      return Y !== "" ? k + "(" + Y + ")" : k;
    }
    function V(c) {
      return c.displayName || "Context";
    }
    function j(c) {
      if (c == null)
        return null;
      if (typeof c.tag == "number" && b("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof c == "function")
        return c.displayName || c.name || null;
      if (typeof c == "string")
        return c;
      switch (c) {
        case n:
          return "Fragment";
        case o:
          return "Portal";
        case i:
          return "Profiler";
        case r:
          return "StrictMode";
        case d:
          return "Suspense";
        case f:
          return "SuspenseList";
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case a:
            var C = c;
            return V(C) + ".Consumer";
          case s:
            var k = c;
            return V(k._context) + ".Provider";
          case l:
            return q(c, c.render, "ForwardRef");
          case u:
            var N = c.displayName || null;
            return N !== null ? N : j(c.type) || "Memo";
          case m: {
            var Y = c, te = Y._payload, W = Y._init;
            try {
              return j(W(te));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var L = Object.assign, I = 0, A, Q, ee, pe, ie, ue, me;
    function ke() {
    }
    ke.__reactDisabledLog = !0;
    function xe() {
      {
        if (I === 0) {
          A = console.log, Q = console.info, ee = console.warn, pe = console.error, ie = console.group, ue = console.groupCollapsed, me = console.groupEnd;
          var c = {
            configurable: !0,
            enumerable: !0,
            value: ke,
            writable: !0
          };
          Object.defineProperties(console, {
            info: c,
            log: c,
            warn: c,
            error: c,
            group: c,
            groupCollapsed: c,
            groupEnd: c
          });
        }
        I++;
      }
    }
    function Ce() {
      {
        if (I--, I === 0) {
          var c = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: L({}, c, {
              value: A
            }),
            info: L({}, c, {
              value: Q
            }),
            warn: L({}, c, {
              value: ee
            }),
            error: L({}, c, {
              value: pe
            }),
            group: L({}, c, {
              value: ie
            }),
            groupCollapsed: L({}, c, {
              value: ue
            }),
            groupEnd: L({}, c, {
              value: me
            })
          });
        }
        I < 0 && b("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Se = y.ReactCurrentDispatcher, O;
    function U(c, C, k) {
      {
        if (O === void 0)
          try {
            throw Error();
          } catch (Y) {
            var N = Y.stack.trim().match(/\n( *(at )?)/);
            O = N && N[1] || "";
          }
        return `
` + O + c;
      }
    }
    var fe = !1, Z;
    {
      var J = typeof WeakMap == "function" ? WeakMap : Map;
      Z = new J();
    }
    function K(c, C) {
      if (!c || fe)
        return "";
      {
        var k = Z.get(c);
        if (k !== void 0)
          return k;
      }
      var N;
      fe = !0;
      var Y = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var te;
      te = Se.current, Se.current = null, xe();
      try {
        if (C) {
          var W = function() {
            throw Error();
          };
          if (Object.defineProperty(W.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(W, []);
            } catch (qe) {
              N = qe;
            }
            Reflect.construct(c, [], W);
          } else {
            try {
              W.call();
            } catch (qe) {
              N = qe;
            }
            c.call(W.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (qe) {
            N = qe;
          }
          c();
        }
      } catch (qe) {
        if (qe && N && typeof qe.stack == "string") {
          for (var H = qe.stack.split(`
`), be = N.stack.split(`
`), ae = H.length - 1, se = be.length - 1; ae >= 1 && se >= 0 && H[ae] !== be[se]; )
            se--;
          for (; ae >= 1 && se >= 0; ae--, se--)
            if (H[ae] !== be[se]) {
              if (ae !== 1 || se !== 1)
                do
                  if (ae--, se--, se < 0 || H[ae] !== be[se]) {
                    var Pe = `
` + H[ae].replace(" at new ", " at ");
                    return c.displayName && Pe.includes("<anonymous>") && (Pe = Pe.replace("<anonymous>", c.displayName)), typeof c == "function" && Z.set(c, Pe), Pe;
                  }
                while (ae >= 1 && se >= 0);
              break;
            }
        }
      } finally {
        fe = !1, Se.current = te, Ce(), Error.prepareStackTrace = Y;
      }
      var et = c ? c.displayName || c.name : "", Wo = et ? U(et) : "";
      return typeof c == "function" && Z.set(c, Wo), Wo;
    }
    function he(c, C, k) {
      return K(c, !1);
    }
    function ve(c) {
      var C = c.prototype;
      return !!(C && C.isReactComponent);
    }
    function Ae(c, C, k) {
      if (c == null)
        return "";
      if (typeof c == "function")
        return K(c, ve(c));
      if (typeof c == "string")
        return U(c);
      switch (c) {
        case d:
          return U("Suspense");
        case f:
          return U("SuspenseList");
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case l:
            return he(c.render);
          case u:
            return Ae(c.type, C, k);
          case m: {
            var N = c, Y = N._payload, te = N._init;
            try {
              return Ae(te(Y), C, k);
            } catch {
            }
          }
        }
      return "";
    }
    var Oe = Object.prototype.hasOwnProperty, Me = {}, wt = y.ReactDebugCurrentFrame;
    function Ze(c) {
      if (c) {
        var C = c._owner, k = Ae(c.type, c._source, C ? C.type : null);
        wt.setExtraStackFrame(k);
      } else
        wt.setExtraStackFrame(null);
    }
    function Je(c, C, k, N, Y) {
      {
        var te = Function.call.bind(Oe);
        for (var W in c)
          if (te(c, W)) {
            var H = void 0;
            try {
              if (typeof c[W] != "function") {
                var be = Error((N || "React class") + ": " + k + " type `" + W + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof c[W] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw be.name = "Invariant Violation", be;
              }
              H = c[W](C, W, N, k, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (ae) {
              H = ae;
            }
            H && !(H instanceof Error) && (Ze(Y), b("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", N || "React class", k, W, typeof H), Ze(null)), H instanceof Error && !(H.message in Me) && (Me[H.message] = !0, Ze(Y), b("Failed %s type: %s", k, H.message), Ze(null));
          }
      }
    }
    var Jr = Array.isArray;
    function Zt(c) {
      return Jr(c);
    }
    function Qr(c) {
      {
        var C = typeof Symbol == "function" && Symbol.toStringTag, k = C && c[Symbol.toStringTag] || c.constructor.name || "Object";
        return k;
      }
    }
    function ei(c) {
      try {
        return jo(c), !1;
      } catch {
        return !0;
      }
    }
    function jo(c) {
      return "" + c;
    }
    function zo(c) {
      if (ei(c))
        return b("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Qr(c)), jo(c);
    }
    var ut = y.ReactCurrentOwner, ti = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, Do, Io, Jt;
    Jt = {};
    function oi(c) {
      if (Oe.call(c, "ref")) {
        var C = Object.getOwnPropertyDescriptor(c, "ref").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.ref !== void 0;
    }
    function ni(c) {
      if (Oe.call(c, "key")) {
        var C = Object.getOwnPropertyDescriptor(c, "key").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.key !== void 0;
    }
    function ri(c, C) {
      if (typeof c.ref == "string" && ut.current && C && ut.current.stateNode !== C) {
        var k = j(ut.current.type);
        Jt[k] || (b('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', j(ut.current.type), c.ref), Jt[k] = !0);
      }
    }
    function ii(c, C) {
      {
        var k = function() {
          Do || (Do = !0, b("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "key", {
          get: k,
          configurable: !0
        });
      }
    }
    function ai(c, C) {
      {
        var k = function() {
          Io || (Io = !0, b("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "ref", {
          get: k,
          configurable: !0
        });
      }
    }
    var si = function(c, C, k, N, Y, te, W) {
      var H = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: t,
        // Built-in properties that belong on the element
        type: c,
        key: C,
        ref: k,
        props: W,
        // Record the component responsible for creating this element.
        _owner: te
      };
      return H._store = {}, Object.defineProperty(H._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(H, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: N
      }), Object.defineProperty(H, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: Y
      }), Object.freeze && (Object.freeze(H.props), Object.freeze(H)), H;
    };
    function li(c, C, k, N, Y) {
      {
        var te, W = {}, H = null, be = null;
        k !== void 0 && (zo(k), H = "" + k), ni(C) && (zo(C.key), H = "" + C.key), oi(C) && (be = C.ref, ri(C, Y));
        for (te in C)
          Oe.call(C, te) && !ti.hasOwnProperty(te) && (W[te] = C[te]);
        if (c && c.defaultProps) {
          var ae = c.defaultProps;
          for (te in ae)
            W[te] === void 0 && (W[te] = ae[te]);
        }
        if (H || be) {
          var se = typeof c == "function" ? c.displayName || c.name || "Unknown" : c;
          H && ii(W, se), be && ai(W, se);
        }
        return si(c, H, be, Y, N, ut.current, W);
      }
    }
    var Qt = y.ReactCurrentOwner, Lo = y.ReactDebugCurrentFrame;
    function Qe(c) {
      if (c) {
        var C = c._owner, k = Ae(c.type, c._source, C ? C.type : null);
        Lo.setExtraStackFrame(k);
      } else
        Lo.setExtraStackFrame(null);
    }
    var eo;
    eo = !1;
    function to(c) {
      return typeof c == "object" && c !== null && c.$$typeof === t;
    }
    function Mo() {
      {
        if (Qt.current) {
          var c = j(Qt.current.type);
          if (c)
            return `

Check the render method of \`` + c + "`.";
        }
        return "";
      }
    }
    function ci(c) {
      {
        if (c !== void 0) {
          var C = c.fileName.replace(/^.*[\\\/]/, ""), k = c.lineNumber;
          return `

Check your code at ` + C + ":" + k + ".";
        }
        return "";
      }
    }
    var Fo = {};
    function di(c) {
      {
        var C = Mo();
        if (!C) {
          var k = typeof c == "string" ? c : c.displayName || c.name;
          k && (C = `

Check the top-level render call using <` + k + ">.");
        }
        return C;
      }
    }
    function Ho(c, C) {
      {
        if (!c._store || c._store.validated || c.key != null)
          return;
        c._store.validated = !0;
        var k = di(C);
        if (Fo[k])
          return;
        Fo[k] = !0;
        var N = "";
        c && c._owner && c._owner !== Qt.current && (N = " It was passed a child from " + j(c._owner.type) + "."), Qe(c), b('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', k, N), Qe(null);
      }
    }
    function Vo(c, C) {
      {
        if (typeof c != "object")
          return;
        if (Zt(c))
          for (var k = 0; k < c.length; k++) {
            var N = c[k];
            to(N) && Ho(N, C);
          }
        else if (to(c))
          c._store && (c._store.validated = !0);
        else if (c) {
          var Y = h(c);
          if (typeof Y == "function" && Y !== c.entries)
            for (var te = Y.call(c), W; !(W = te.next()).done; )
              to(W.value) && Ho(W.value, C);
        }
      }
    }
    function ui(c) {
      {
        var C = c.type;
        if (C == null || typeof C == "string")
          return;
        var k;
        if (typeof C == "function")
          k = C.propTypes;
        else if (typeof C == "object" && (C.$$typeof === l || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        C.$$typeof === u))
          k = C.propTypes;
        else
          return;
        if (k) {
          var N = j(C);
          Je(k, c.props, "prop", N, c);
        } else if (C.PropTypes !== void 0 && !eo) {
          eo = !0;
          var Y = j(C);
          b("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", Y || "Unknown");
        }
        typeof C.getDefaultProps == "function" && !C.getDefaultProps.isReactClassApproved && b("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function fi(c) {
      {
        for (var C = Object.keys(c.props), k = 0; k < C.length; k++) {
          var N = C[k];
          if (N !== "children" && N !== "key") {
            Qe(c), b("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", N), Qe(null);
            break;
          }
        }
        c.ref !== null && (Qe(c), b("Invalid attribute `ref` supplied to `React.Fragment`."), Qe(null));
      }
    }
    function Bo(c, C, k, N, Y, te) {
      {
        var W = X(c);
        if (!W) {
          var H = "";
          (c === void 0 || typeof c == "object" && c !== null && Object.keys(c).length === 0) && (H += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var be = ci(Y);
          be ? H += be : H += Mo();
          var ae;
          c === null ? ae = "null" : Zt(c) ? ae = "array" : c !== void 0 && c.$$typeof === t ? (ae = "<" + (j(c.type) || "Unknown") + " />", H = " Did you accidentally export a JSX literal instead of a component?") : ae = typeof c, b("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", ae, H);
        }
        var se = li(c, C, k, Y, te);
        if (se == null)
          return se;
        if (W) {
          var Pe = C.children;
          if (Pe !== void 0)
            if (N)
              if (Zt(Pe)) {
                for (var et = 0; et < Pe.length; et++)
                  Vo(Pe[et], c);
                Object.freeze && Object.freeze(Pe);
              } else
                b("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              Vo(Pe, c);
        }
        return c === n ? fi(se) : ui(se), se;
      }
    }
    function gi(c, C, k) {
      return Bo(c, C, k, !0);
    }
    function pi(c, C, k) {
      return Bo(c, C, k, !1);
    }
    var vi = pi, mi = gi;
    gt.Fragment = n, gt.jsx = vi, gt.jsxs = mi;
  }()), gt;
}
process.env.NODE_ENV === "production" ? fo.exports = wi() : fo.exports = _i();
var w = fo.exports;
function $i(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function ki(e) {
  var t = $i(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function Si(e, t, o) {
  return t = ki(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function Ko(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function Yo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Ko(Object(o), !0).forEach(function(n) {
      Si(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : Ko(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var Pi = (e, t, o) => {
  for (var n of Object.keys(e)) {
    var r;
    if (e[n] !== ((r = t[n]) !== null && r !== void 0 ? r : o[n]))
      return !1;
  }
  return !0;
}, _e = (e) => {
  var t = (o) => {
    var n = e.defaultClassName, r = Yo(Yo({}, e.defaultVariants), o);
    for (var i in r) {
      var s, a = (s = r[i]) !== null && s !== void 0 ? s : e.defaultVariants[i];
      if (a != null) {
        var l = a;
        typeof l == "boolean" && (l = l === !0 ? "true" : "false");
        var d = (
          // @ts-expect-error
          e.variantClassNames[i][l]
        );
        d && (n += " " + d);
      }
    }
    for (var [f, u] of e.compoundVariants)
      Pi(f, r, e.defaultVariants) && (n += " " + u);
    return n;
  };
  return t.variants = () => Object.keys(e.variantClassNames), t;
}, Ei = _e({ defaultClassName: "_1bycfvg2i", variantClassNames: { size: { xs: "_1bycfvg2", sm: "_1bycfvg3", md: "_1bycfvg4", lg: "_1bycfvg5" }, shape: { circle: "_1bycfvg6", square: "_1bycfvg7", rounded: "_1bycfvg8" }, variant: { transparent: "_1bycfvg9", current: "_1bycfvga", white: "_1bycfvgb", black: "_1bycfvgc", gray100: "_1bycfvgd", gray200: "_1bycfvge", gray300: "_1bycfvgf", pale100: "_1bycfvgg", pale200: "_1bycfvgh", pale300: "_1bycfvgi", pale400: "_1bycfvgj", pale500: "_1bycfvgk", hyper0: "_1bycfvgl", hyper1: "_1bycfvgm", hyper2: "_1bycfvgn", hyper3: "_1bycfvgo", hyper4: "_1bycfvgp", hyper5: "_1bycfvgq", hyper6: "_1bycfvgr", hyper7: "_1bycfvgs", hyper8: "_1bycfvgt", hyper9: "_1bycfvgu", hyper10: "_1bycfvgv", hyper11: "_1bycfvgw", hyper12: "_1bycfvgx", hyper13: "_1bycfvgy", lemon0: "_1bycfvgz", lemon1: "_1bycfvg10", lemon2: "_1bycfvg11", lemon3: "_1bycfvg12", lemon4: "_1bycfvg13", lemon5: "_1bycfvg14", lemon6: "_1bycfvg15", lemon7: "_1bycfvg16", lemon8: "_1bycfvg17", lemon9: "_1bycfvg18", lemon10: "_1bycfvg19", lemon11: "_1bycfvg1a", lemon12: "_1bycfvg1b", lemon13: "_1bycfvg1c", slate1: "_1bycfvg1d", slate2: "_1bycfvg1e", slate3: "_1bycfvg1f", slate4: "_1bycfvg1g", slate5: "_1bycfvg1h", slate6: "_1bycfvg1i", slate7: "_1bycfvg1j", slate8: "_1bycfvg1k", slate9: "_1bycfvg1l", slate10: "_1bycfvg1m", slate11: "_1bycfvg1n", slate12: "_1bycfvg1o", slate13: "_1bycfvg1p", sapphire0: "_1bycfvg1q", sapphire1: "_1bycfvg1r", sapphire2: "_1bycfvg1s", sapphire3: "_1bycfvg1t", sapphire4: "_1bycfvg1u", sapphire5: "_1bycfvg1v", sapphire6: "_1bycfvg1w", sapphire7: "_1bycfvg1x", sapphire8: "_1bycfvg1y", sapphire9: "_1bycfvg1z", sapphire10: "_1bycfvg20", sapphire11: "_1bycfvg21", sapphire12: "_1bycfvg22", sapphire13: "_1bycfvg23", volt0: "_1bycfvg24", volt1: "_1bycfvg25", volt2: "_1bycfvg26", volt3: "_1bycfvg27", volt4: "_1bycfvg28", volt5: "_1bycfvg29", volt6: "_1bycfvg2a", volt7: "_1bycfvg2b", volt8: "_1bycfvg2c", volt9: "_1bycfvg2d", volt10: "_1bycfvg2e", volt11: "_1bycfvg2f", volt12: "_1bycfvg2g", volt13: "_1bycfvg2h" } }, defaultVariants: { size: "sm", shape: "rounded" }, compoundVariants: [] }), An = "_1bycfvg0", Ti = "_1bycfvg1";
function On(e) {
  var t, o, n = "";
  if (typeof e == "string" || typeof e == "number")
    n += e;
  else if (typeof e == "object")
    if (Array.isArray(e))
      for (t = 0; t < e.length; t++)
        e[t] && (o = On(e[t])) && (n && (n += " "), n += o);
    else
      for (t in e)
        e[t] && (n && (n += " "), n += t);
  return n;
}
function z() {
  for (var e, t, o = 0, n = ""; o < arguments.length; )
    (e = arguments[o++]) && (t = On(e)) && (n && (n += " "), n += t);
  return n;
}
const Nn = $o.Image, Ri = $o.Fallback, Ai = B.forwardRef(
  ({ className: e, size: t = "xs", shape: o = "rounded", ...n }, r) => /* @__PURE__ */ w.jsx(
    $o.Root,
    {
      ...n,
      ref: r,
      className: z(Ei({ size: t, shape: o }), e)
    }
  )
), qn = B.forwardRef(
  ({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    Ri,
    {
      ...t,
      ref: o,
      className: z(Ti, e)
    }
  )
), jn = B.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
  Nn,
  {
    ...t,
    ref: o,
    className: z(An, e)
  }
)), Oi = "https://cdn.atlrdsgn.com/assets/github/atlrdsgn/A2.jpg", zn = B.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ w.jsx(
  Nn,
  {
    ...t,
    ref: o,
    src: Oi,
    className: z(An, e)
  }
)), Xe = (e) => /* @__PURE__ */ w.jsx(Ai, { ...e });
Xe.Fallback = qn;
Xe.Image = jn;
Xe.Demo = zn;
Xe.displayName = "Avi";
Xe.Fallback.displayName = "AviFallback";
Xe.Image.displayName = "AviImage";
Xe.Demo.displayName = "AviDemoImage";
qn.displayName = "AviFallback";
jn.displayName = "AviImage";
zn.displayName = "AviDemoImage";
var Ni = _e({ defaultClassName: "aefdx68", variantClassNames: { size: { xs: "aefdx60", sm: "aefdx61", md: "aefdx62", lg: "aefdx63" }, variant: { slate: "aefdx64", jade: "aefdx65", hyper: "aefdx66", neon: "aefdx67" } }, defaultVariants: { size: "sm", variant: "slate" }, compoundVariants: [] });
const qi = ({
  children: e,
  type: t = "button",
  as: o = "a",
  onClick: n = () => {
  },
  href: r,
  target: i = "_self",
  rel: s = "noopener noreferrer",
  size: a = "sm",
  variant: l = "hyper",
  ...d
}) => {
  const f = (u) => {
    r ? (u.preventDefault(), window.open(r, i, s)) : u.preventDefault(), n(u);
  };
  return /* @__PURE__ */ w.jsx(
    "button",
    {
      ...d,
      type: t,
      className: Ni({ size: a, variant: l }),
      onClick: f,
      children: e
    }
  );
};
qi.displayName = "Button";
var ji = "_1dqe6mp0", zi = "_1dqe6mp1";
const Di = B.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: o,
      className: z(ji),
      ...t,
      children: e
    }
  )
), Ii = B.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: o,
      className: z(zi),
      ...t,
      children: e
    }
  )
);
Di.displayName = "Canvas";
Ii.displayName = "Blurred-Canvas";
var Li = _e({ defaultClassName: "_1yx7lz87", variantClassNames: { size: { xsmall: "_1yx7lz80", small: "_1yx7lz81", medium: "_1yx7lz82" }, shape: { rounded: "_1yx7lz83", pill: "_1yx7lz84" }, variant: { slate: "_1yx7lz85", hyper: "_1yx7lz86" } }, defaultVariants: { size: "small", shape: "pill", variant: "slate" }, compoundVariants: [] });
const Mi = ({
  children: e,
  className: t,
  size: o = "small",
  shape: n = "pill",
  variant: r = "slate",
  ...i
}) => /* @__PURE__ */ w.jsx(
  "span",
  {
    ...i,
    className: z(t, Li({ size: o, shape: n, variant: r })),
    children: e
  }
);
Mi.displayName = "Chip";
var Fi = _e({ defaultClassName: "zhlr5ea", variantClassNames: { align: { start: "zhlr5e6", center: "zhlr5e7", end: "zhlr5e8" }, width: { small: "zhlr5e0", medium: "zhlr5e1", large: "zhlr5e2", xlarge: "zhlr5e3", max: "zhlr5e4", full: "zhlr5e5" }, border: { true: "zhlr5e9" } }, defaultVariants: { align: "start", width: "max", border: !1 }, compoundVariants: [] });
const Hi = ({
  children: e,
  className: t,
  width: o = "max",
  align: n = "start",
  border: r = !1,
  ...i
}) => /* @__PURE__ */ w.jsx(
  "div",
  {
    ...i,
    className: z(t, Fi({ width: o, align: n, border: r })),
    children: e
  }
);
Hi.displayName = "Container";
var Vi = _e({ defaultClassName: "_18w0vmkl", variantClassNames: { direction: { row: "_18w0vmk0", column: "_18w0vmk1", rowReverse: "_18w0vmk2", columnReverse: "_18w0vmk3" }, align: { start: "_18w0vmk4", center: "_18w0vmk5", end: "_18w0vmk6", stretch: "_18w0vmk7", baseline: "_18w0vmk8" }, justify: { start: "_18w0vmk9", center: "_18w0vmka", end: "_18w0vmkb", between: "_18w0vmkc" }, gap: { xs: "_18w0vmkd", sm: "_18w0vmke", md: "_18w0vmkf", lg: "_18w0vmkg", xl: "_18w0vmkh" }, wrap: { wrap: "_18w0vmki", nowrap: "_18w0vmkj", wrapReverse: "_18w0vmkk" } }, defaultVariants: { direction: "row", align: "start", justify: "start", gap: "sm", wrap: "wrap" }, compoundVariants: [] });
const Bi = B.forwardRef(
  ({
    children: e,
    direction: t = "row",
    align: o = "center",
    justify: n = "center",
    gap: r = "sm",
    ...i
    //..
  }, s) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ...i,
      ref: s,
      className: Vi({ direction: t, align: o, justify: n, gap: r }),
      children: e
    }
  )
);
Bi.displayName = "Flex";
var Wi = _e({ defaultClassName: "_1n0su94k", variantClassNames: { font: { system: "_1n0su940", mono: "_1n0su941" }, size: { display: "_1n0su942", H1: "_1n0su943", H2: "_1n0su944", H3: "_1n0su945", H4: "_1n0su946", H5: "_1n0su947", H6: "_1n0su948" }, weight: { superlite: "_1n0su949", lite: "_1n0su94a", normal: "_1n0su94b", medium: "_1n0su94c", semibold: "_1n0su94d", bold: "_1n0su94e", heavy: "_1n0su94f", black: "_1n0su94g" }, align: { left: "_1n0su94h", center: "_1n0su94i", right: "_1n0su94j" } }, defaultVariants: { font: "system", size: "H1", weight: "semibold", align: "left" }, compoundVariants: [] });
const Ui = B.forwardRef(
  ({
    className: e,
    font: t = "system",
    size: o = "H1",
    weight: n = "semibold",
    align: r = "left",
    ...i
  }, s) => /* @__PURE__ */ w.jsx(
    "h1",
    {
      ...i,
      ref: s,
      className: z(e, Wi({ font: t, size: o, weight: n, align: r }))
    }
  )
);
Ui.displayName = "Heading";
function M() {
  return M = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var o = arguments[t];
      for (var n in o)
        Object.prototype.hasOwnProperty.call(o, n) && (e[n] = o[n]);
    }
    return e;
  }, M.apply(this, arguments);
}
function oe(e, t, { checkForDefaultPrevented: o = !0 } = {}) {
  return function(r) {
    if (e == null || e(r), o === !1 || !r.defaultPrevented)
      return t == null ? void 0 : t(r);
  };
}
function Ft(e, t = []) {
  let o = [];
  function n(i, s) {
    const a = /* @__PURE__ */ ht(s), l = o.length;
    o = [
      ...o,
      s
    ];
    function d(u) {
      const { scope: m, children: p, ...v } = u, g = (m == null ? void 0 : m[e][l]) || a, h = at(
        () => v,
        Object.values(v)
      );
      return /* @__PURE__ */ $(g.Provider, {
        value: h
      }, p);
    }
    function f(u, m) {
      const p = (m == null ? void 0 : m[e][l]) || a, v = Mt(p);
      if (v)
        return v;
      if (s !== void 0)
        return s;
      throw new Error(`\`${u}\` must be used within \`${i}\``);
    }
    return d.displayName = i + "Provider", [
      d,
      f
    ];
  }
  const r = () => {
    const i = o.map((s) => /* @__PURE__ */ ht(s));
    return function(a) {
      const l = (a == null ? void 0 : a[e]) || i;
      return at(
        () => ({
          [`__scope${e}`]: {
            ...a,
            [e]: l
          }
        }),
        [
          a,
          l
        ]
      );
    };
  };
  return r.scopeName = e, [
    n,
    Xi(r, ...t)
  ];
}
function Xi(...e) {
  const t = e[0];
  if (e.length === 1)
    return t;
  const o = () => {
    const n = e.map(
      (r) => ({
        useScope: r(),
        scopeName: r.scopeName
      })
    );
    return function(i) {
      const s = n.reduce((a, { useScope: l, scopeName: d }) => {
        const u = l(i)[`__scope${d}`];
        return {
          ...a,
          ...u
        };
      }, {});
      return at(
        () => ({
          [`__scope${t.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return o.scopeName = t.scopeName, o;
}
function De(e) {
  const t = ne(e);
  return re(() => {
    t.current = e;
  }), at(
    () => (...o) => {
      var n;
      return (n = t.current) === null || n === void 0 ? void 0 : n.call(t, ...o);
    },
    []
  );
}
function go({ prop: e, defaultProp: t, onChange: o = () => {
} }) {
  const [n, r] = Ki({
    defaultProp: t,
    onChange: o
  }), i = e !== void 0, s = i ? e : n, a = De(o), l = le((d) => {
    if (i) {
      const u = typeof d == "function" ? d(e) : d;
      u !== e && a(u);
    } else
      r(d);
  }, [
    i,
    e,
    r,
    a
  ]);
  return [
    s,
    l
  ];
}
function Ki({ defaultProp: e, onChange: t }) {
  const o = G(e), [n] = o, r = ne(n), i = De(t);
  return re(() => {
    r.current !== n && (i(n), r.current = n);
  }, [
    n,
    r,
    i
  ]), o;
}
function Yi(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Dn(...e) {
  return (t) => e.forEach(
    (o) => Yi(o, t)
  );
}
function ge(...e) {
  return le(Dn(...e), e);
}
function ct(e) {
  return e.split("-")[1];
}
function ko(e) {
  return e === "y" ? "height" : "width";
}
function ze(e) {
  return e.split("-")[0];
}
function Ke(e) {
  return ["top", "bottom"].includes(ze(e)) ? "x" : "y";
}
function Go(e, t, o) {
  let { reference: n, floating: r } = e;
  const i = n.x + n.width / 2 - r.width / 2, s = n.y + n.height / 2 - r.height / 2, a = Ke(t), l = ko(a), d = n[l] / 2 - r[l] / 2, f = a === "x";
  let u;
  switch (ze(t)) {
    case "top":
      u = { x: i, y: n.y - r.height };
      break;
    case "bottom":
      u = { x: i, y: n.y + n.height };
      break;
    case "right":
      u = { x: n.x + n.width, y: s };
      break;
    case "left":
      u = { x: n.x - r.width, y: s };
      break;
    default:
      u = { x: n.x, y: n.y };
  }
  switch (ct(t)) {
    case "start":
      u[a] -= d * (o && f ? -1 : 1);
      break;
    case "end":
      u[a] += d * (o && f ? -1 : 1);
  }
  return u;
}
const Gi = async (e, t, o) => {
  const { placement: n = "bottom", strategy: r = "absolute", middleware: i = [], platform: s } = o, a = i.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let d = await s.getElementRects({ reference: e, floating: t, strategy: r }), { x: f, y: u } = Go(d, n, l), m = n, p = {}, v = 0;
  for (let g = 0; g < a.length; g++) {
    const { name: h, fn: y } = a[g], { x: b, y: x, data: _, reset: S } = await y({ x: f, y: u, initialPlacement: n, placement: m, strategy: r, middlewareData: p, rects: d, platform: s, elements: { reference: e, floating: t } });
    f = b ?? f, u = x ?? u, p = { ...p, [h]: { ...p[h], ..._ } }, S && v <= 50 && (v++, typeof S == "object" && (S.placement && (m = S.placement), S.rects && (d = S.rects === !0 ? await s.getElementRects({ reference: e, floating: t, strategy: r }) : S.rects), { x: f, y: u } = Go(d, m, l)), g = -1);
  }
  return { x: f, y: u, placement: m, strategy: r, middlewareData: p };
};
function In(e) {
  return typeof e != "number" ? function(t) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...t };
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function jt(e) {
  return { ...e, top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height };
}
async function bt(e, t) {
  var o;
  t === void 0 && (t = {});
  const { x: n, y: r, platform: i, rects: s, elements: a, strategy: l } = e, { boundary: d = "clippingAncestors", rootBoundary: f = "viewport", elementContext: u = "floating", altBoundary: m = !1, padding: p = 0 } = t, v = In(p), g = a[m ? u === "floating" ? "reference" : "floating" : u], h = jt(await i.getClippingRect({ element: (o = await (i.isElement == null ? void 0 : i.isElement(g))) == null || o ? g : g.contextElement || await (i.getDocumentElement == null ? void 0 : i.getDocumentElement(a.floating)), boundary: d, rootBoundary: f, strategy: l })), y = u === "floating" ? { ...s.floating, x: n, y: r } : s.reference, b = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(a.floating)), x = await (i.isElement == null ? void 0 : i.isElement(b)) && await (i.getScale == null ? void 0 : i.getScale(b)) || { x: 1, y: 1 }, _ = jt(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: y, offsetParent: b, strategy: l }) : y);
  return { top: (h.top - _.top + v.top) / x.y, bottom: (_.bottom - h.bottom + v.bottom) / x.y, left: (h.left - _.left + v.left) / x.x, right: (_.right - h.right + v.right) / x.x };
}
const po = Math.min, We = Math.max;
function vo(e, t, o) {
  return We(e, po(t, o));
}
const Zo = (e) => ({ name: "arrow", options: e, async fn(t) {
  const { element: o, padding: n = 0 } = e || {}, { x: r, y: i, placement: s, rects: a, platform: l, elements: d } = t;
  if (o == null)
    return {};
  const f = In(n), u = { x: r, y: i }, m = Ke(s), p = ko(m), v = await l.getDimensions(o), g = m === "y", h = g ? "top" : "left", y = g ? "bottom" : "right", b = g ? "clientHeight" : "clientWidth", x = a.reference[p] + a.reference[m] - u[m] - a.floating[p], _ = u[m] - a.reference[m], S = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(o));
  let E = S ? S[b] : 0;
  E && await (l.isElement == null ? void 0 : l.isElement(S)) || (E = d.floating[b] || a.floating[p]);
  const P = x / 2 - _ / 2, T = f[h], F = E - v[p] - f[y], X = E / 2 - v[p] / 2 + P, q = vo(T, X, F), V = ct(s) != null && X != q && a.reference[p] / 2 - (X < T ? f[h] : f[y]) - v[p] / 2 < 0;
  return { [m]: u[m] - (V ? X < T ? T - X : F - X : 0), data: { [m]: q, centerOffset: X - q } };
} }), Ln = ["top", "right", "bottom", "left"];
Ln.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
const Zi = { left: "right", right: "left", bottom: "top", top: "bottom" };
function zt(e) {
  return e.replace(/left|right|bottom|top/g, (t) => Zi[t]);
}
function Ji(e, t, o) {
  o === void 0 && (o = !1);
  const n = ct(e), r = Ke(e), i = ko(r);
  let s = r === "x" ? n === (o ? "end" : "start") ? "right" : "left" : n === "start" ? "bottom" : "top";
  return t.reference[i] > t.floating[i] && (s = zt(s)), { main: s, cross: zt(s) };
}
const Qi = { start: "end", end: "start" };
function oo(e) {
  return e.replace(/start|end/g, (t) => Qi[t]);
}
const ea = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
    var o;
    const { placement: n, middlewareData: r, rects: i, initialPlacement: s, platform: a, elements: l } = t, { mainAxis: d = !0, crossAxis: f = !0, fallbackPlacements: u, fallbackStrategy: m = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: v = !0, ...g } = e, h = ze(n), y = ze(s) === s, b = await (a.isRTL == null ? void 0 : a.isRTL(l.floating)), x = u || (y || !v ? [zt(s)] : function(q) {
      const V = zt(q);
      return [oo(q), V, oo(V)];
    }(s));
    u || p === "none" || x.push(...function(q, V, j, L) {
      const I = ct(q);
      let A = function(Q, ee, pe) {
        const ie = ["left", "right"], ue = ["right", "left"], me = ["top", "bottom"], ke = ["bottom", "top"];
        switch (Q) {
          case "top":
          case "bottom":
            return pe ? ee ? ue : ie : ee ? ie : ue;
          case "left":
          case "right":
            return ee ? me : ke;
          default:
            return [];
        }
      }(ze(q), j === "start", L);
      return I && (A = A.map((Q) => Q + "-" + I), V && (A = A.concat(A.map(oo)))), A;
    }(s, v, p, b));
    const _ = [s, ...x], S = await bt(t, g), E = [];
    let P = ((o = r.flip) == null ? void 0 : o.overflows) || [];
    if (d && E.push(S[h]), f) {
      const { main: q, cross: V } = Ji(n, i, b);
      E.push(S[q], S[V]);
    }
    if (P = [...P, { placement: n, overflows: E }], !E.every((q) => q <= 0)) {
      var T, F;
      const q = (((T = r.flip) == null ? void 0 : T.index) || 0) + 1, V = _[q];
      if (V)
        return { data: { index: q, overflows: P }, reset: { placement: V } };
      let j = (F = P.filter((L) => L.overflows[0] <= 0).sort((L, I) => L.overflows[1] - I.overflows[1])[0]) == null ? void 0 : F.placement;
      if (!j)
        switch (m) {
          case "bestFit": {
            var X;
            const L = (X = P.map((I) => [I.placement, I.overflows.filter((A) => A > 0).reduce((A, Q) => A + Q, 0)]).sort((I, A) => I[1] - A[1])[0]) == null ? void 0 : X[0];
            L && (j = L);
            break;
          }
          case "initialPlacement":
            j = s;
        }
      if (n !== j)
        return { reset: { placement: j } };
    }
    return {};
  } };
};
function Jo(e, t) {
  return { top: e.top - t.height, right: e.right - t.width, bottom: e.bottom - t.height, left: e.left - t.width };
}
function Qo(e) {
  return Ln.some((t) => e[t] >= 0);
}
const ta = function(e) {
  return e === void 0 && (e = {}), { name: "hide", options: e, async fn(t) {
    const { strategy: o = "referenceHidden", ...n } = e, { rects: r } = t;
    switch (o) {
      case "referenceHidden": {
        const i = Jo(await bt(t, { ...n, elementContext: "reference" }), r.reference);
        return { data: { referenceHiddenOffsets: i, referenceHidden: Qo(i) } };
      }
      case "escaped": {
        const i = Jo(await bt(t, { ...n, altBoundary: !0 }), r.floating);
        return { data: { escapedOffsets: i, escaped: Qo(i) } };
      }
      default:
        return {};
    }
  } };
}, oa = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
    const { x: o, y: n } = t, r = await async function(i, s) {
      const { placement: a, platform: l, elements: d } = i, f = await (l.isRTL == null ? void 0 : l.isRTL(d.floating)), u = ze(a), m = ct(a), p = Ke(a) === "x", v = ["left", "top"].includes(u) ? -1 : 1, g = f && p ? -1 : 1, h = typeof s == "function" ? s(i) : s;
      let { mainAxis: y, crossAxis: b, alignmentAxis: x } = typeof h == "number" ? { mainAxis: h, crossAxis: 0, alignmentAxis: null } : { mainAxis: 0, crossAxis: 0, alignmentAxis: null, ...h };
      return m && typeof x == "number" && (b = m === "end" ? -1 * x : x), p ? { x: b * g, y: y * v } : { x: y * v, y: b * g };
    }(t, e);
    return { x: o + r.x, y: n + r.y, data: r };
  } };
};
function Mn(e) {
  return e === "x" ? "y" : "x";
}
const na = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
    const { x: o, y: n, placement: r } = t, { mainAxis: i = !0, crossAxis: s = !1, limiter: a = { fn: (h) => {
      let { x: y, y: b } = h;
      return { x: y, y: b };
    } }, ...l } = e, d = { x: o, y: n }, f = await bt(t, l), u = Ke(ze(r)), m = Mn(u);
    let p = d[u], v = d[m];
    if (i) {
      const h = u === "y" ? "bottom" : "right";
      p = vo(p + f[u === "y" ? "top" : "left"], p, p - f[h]);
    }
    if (s) {
      const h = m === "y" ? "bottom" : "right";
      v = vo(v + f[m === "y" ? "top" : "left"], v, v - f[h]);
    }
    const g = a.fn({ ...t, [u]: p, [m]: v });
    return { ...g, data: { x: g.x - o, y: g.y - n } };
  } };
}, ra = function(e) {
  return e === void 0 && (e = {}), { options: e, fn(t) {
    const { x: o, y: n, placement: r, rects: i, middlewareData: s } = t, { offset: a = 0, mainAxis: l = !0, crossAxis: d = !0 } = e, f = { x: o, y: n }, u = Ke(r), m = Mn(u);
    let p = f[u], v = f[m];
    const g = typeof a == "function" ? a(t) : a, h = typeof g == "number" ? { mainAxis: g, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...g };
    if (l) {
      const x = u === "y" ? "height" : "width", _ = i.reference[u] - i.floating[x] + h.mainAxis, S = i.reference[u] + i.reference[x] - h.mainAxis;
      p < _ ? p = _ : p > S && (p = S);
    }
    if (d) {
      var y, b;
      const x = u === "y" ? "width" : "height", _ = ["top", "left"].includes(ze(r)), S = i.reference[m] - i.floating[x] + (_ && ((y = s.offset) == null ? void 0 : y[m]) || 0) + (_ ? 0 : h.crossAxis), E = i.reference[m] + i.reference[x] + (_ ? 0 : ((b = s.offset) == null ? void 0 : b[m]) || 0) - (_ ? h.crossAxis : 0);
      v < S ? v = S : v > E && (v = E);
    }
    return { [u]: p, [m]: v };
  } };
}, ia = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
    const { placement: o, rects: n, platform: r, elements: i } = t, { apply: s = () => {
    }, ...a } = e, l = await bt(t, a), d = ze(o), f = ct(o), u = Ke(o) === "x", { width: m, height: p } = n.floating;
    let v, g;
    d === "top" || d === "bottom" ? (v = d, g = f === (await (r.isRTL == null ? void 0 : r.isRTL(i.floating)) ? "start" : "end") ? "left" : "right") : (g = d, v = f === "end" ? "top" : "bottom");
    const h = p - l[v], y = m - l[g], b = !t.middlewareData.shift;
    let x = h, _ = y;
    if (u) {
      const E = m - l.left - l.right;
      _ = f || b ? po(y, E) : E;
    } else {
      const E = p - l.top - l.bottom;
      x = f || b ? po(h, E) : E;
    }
    if (b && !f) {
      const E = We(l.left, 0), P = We(l.right, 0), T = We(l.top, 0), F = We(l.bottom, 0);
      u ? _ = m - 2 * (E !== 0 || P !== 0 ? E + P : We(l.left, l.right)) : x = p - 2 * (T !== 0 || F !== 0 ? T + F : We(l.top, l.bottom));
    }
    await s({ ...t, availableWidth: _, availableHeight: x });
    const S = await r.getDimensions(i.floating);
    return m !== S.width || p !== S.height ? { reset: { rects: !0 } } : {};
  } };
};
function Ee(e) {
  var t;
  return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Te(e) {
  return Ee(e).getComputedStyle(e);
}
function Fn(e) {
  return e instanceof Ee(e).Node;
}
function Be(e) {
  return Fn(e) ? (e.nodeName || "").toLowerCase() : "";
}
function Re(e) {
  return e instanceof Ee(e).HTMLElement;
}
function we(e) {
  return e instanceof Ee(e).Element;
}
function en(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof Ee(e).ShadowRoot || e instanceof ShadowRoot;
}
function yt(e) {
  const { overflow: t, overflowX: o, overflowY: n, display: r } = Te(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + n + o) && !["inline", "contents"].includes(r);
}
function aa(e) {
  return ["table", "td", "th"].includes(Be(e));
}
function mo(e) {
  const t = So(), o = Te(e);
  return o.transform !== "none" || o.perspective !== "none" || !t && !!o.backdropFilter && o.backdropFilter !== "none" || !t && !!o.filter && o.filter !== "none" || ["transform", "perspective", "filter"].some((n) => (o.willChange || "").includes(n)) || ["paint", "layout", "strict", "content"].some((n) => (o.contain || "").includes(n));
}
function So() {
  return !(typeof CSS > "u" || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
}
function Ht(e) {
  return ["html", "body", "#document"].includes(Be(e));
}
const tn = Math.min, pt = Math.max, Dt = Math.round;
function Hn(e) {
  const t = Te(e);
  let o = parseFloat(t.width) || 0, n = parseFloat(t.height) || 0;
  const r = Re(e), i = r ? e.offsetWidth : o, s = r ? e.offsetHeight : n, a = Dt(o) !== i || Dt(n) !== s;
  return a && (o = i, n = s), { width: o, height: n, fallback: a };
}
function Vn(e) {
  return we(e) ? e : e.contextElement;
}
const Bn = { x: 1, y: 1 };
function it(e) {
  const t = Vn(e);
  if (!Re(t))
    return Bn;
  const o = t.getBoundingClientRect(), { width: n, height: r, fallback: i } = Hn(t);
  let s = (i ? Dt(o.width) : o.width) / n, a = (i ? Dt(o.height) : o.height) / r;
  return s && Number.isFinite(s) || (s = 1), a && Number.isFinite(a) || (a = 1), { x: s, y: a };
}
const on = { x: 0, y: 0 };
function Wn(e, t, o) {
  var n, r;
  if (t === void 0 && (t = !0), !So())
    return on;
  const i = e ? Ee(e) : window;
  return !o || t && o !== i ? on : { x: ((n = i.visualViewport) == null ? void 0 : n.offsetLeft) || 0, y: ((r = i.visualViewport) == null ? void 0 : r.offsetTop) || 0 };
}
function Ue(e, t, o, n) {
  t === void 0 && (t = !1), o === void 0 && (o = !1);
  const r = e.getBoundingClientRect(), i = Vn(e);
  let s = Bn;
  t && (n ? we(n) && (s = it(n)) : s = it(e));
  const a = Wn(i, o, n);
  let l = (r.left + a.x) / s.x, d = (r.top + a.y) / s.y, f = r.width / s.x, u = r.height / s.y;
  if (i) {
    const m = Ee(i), p = n && we(n) ? Ee(n) : n;
    let v = m.frameElement;
    for (; v && n && p !== m; ) {
      const g = it(v), h = v.getBoundingClientRect(), y = getComputedStyle(v);
      h.x += (v.clientLeft + parseFloat(y.paddingLeft)) * g.x, h.y += (v.clientTop + parseFloat(y.paddingTop)) * g.y, l *= g.x, d *= g.y, f *= g.x, u *= g.y, l += h.x, d += h.y, v = Ee(v).frameElement;
    }
  }
  return jt({ width: f, height: u, x: l, y: d });
}
function He(e) {
  return ((Fn(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function Vt(e) {
  return we(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function Un(e) {
  return Ue(He(e)).left + Vt(e).scrollLeft;
}
function st(e) {
  if (Be(e) === "html")
    return e;
  const t = e.assignedSlot || e.parentNode || en(e) && e.host || He(e);
  return en(t) ? t.host : t;
}
function Xn(e) {
  const t = st(e);
  return Ht(t) ? t.ownerDocument.body : Re(t) && yt(t) ? t : Xn(t);
}
function vt(e, t) {
  var o;
  t === void 0 && (t = []);
  const n = Xn(e), r = n === ((o = e.ownerDocument) == null ? void 0 : o.body), i = Ee(n);
  return r ? t.concat(i, i.visualViewport || [], yt(n) ? n : []) : t.concat(n, vt(n));
}
function nn(e, t, o) {
  let n;
  if (t === "viewport")
    n = function(r, i) {
      const s = Ee(r), a = He(r), l = s.visualViewport;
      let d = a.clientWidth, f = a.clientHeight, u = 0, m = 0;
      if (l) {
        d = l.width, f = l.height;
        const p = So();
        (!p || p && i === "fixed") && (u = l.offsetLeft, m = l.offsetTop);
      }
      return { width: d, height: f, x: u, y: m };
    }(e, o);
  else if (t === "document")
    n = function(r) {
      const i = He(r), s = Vt(r), a = r.ownerDocument.body, l = pt(i.scrollWidth, i.clientWidth, a.scrollWidth, a.clientWidth), d = pt(i.scrollHeight, i.clientHeight, a.scrollHeight, a.clientHeight);
      let f = -s.scrollLeft + Un(r);
      const u = -s.scrollTop;
      return Te(a).direction === "rtl" && (f += pt(i.clientWidth, a.clientWidth) - l), { width: l, height: d, x: f, y: u };
    }(He(e));
  else if (we(t))
    n = function(r, i) {
      const s = Ue(r, !0, i === "fixed"), a = s.top + r.clientTop, l = s.left + r.clientLeft, d = Re(r) ? it(r) : { x: 1, y: 1 };
      return { width: r.clientWidth * d.x, height: r.clientHeight * d.y, x: l * d.x, y: a * d.y };
    }(t, o);
  else {
    const r = Wn(e);
    n = { ...t, x: t.x - r.x, y: t.y - r.y };
  }
  return jt(n);
}
function Kn(e, t) {
  const o = st(e);
  return !(o === t || !we(o) || Ht(o)) && (Te(o).position === "fixed" || Kn(o, t));
}
function rn(e, t) {
  return Re(e) && Te(e).position !== "fixed" ? t ? t(e) : e.offsetParent : null;
}
function an(e, t) {
  const o = Ee(e);
  if (!Re(e))
    return o;
  let n = rn(e, t);
  for (; n && aa(n) && Te(n).position === "static"; )
    n = rn(n, t);
  return n && (Be(n) === "html" || Be(n) === "body" && Te(n).position === "static" && !mo(n)) ? o : n || function(r) {
    let i = st(r);
    for (; Re(i) && !Ht(i); ) {
      if (mo(i))
        return i;
      i = st(i);
    }
    return null;
  }(e) || o;
}
function sa(e, t, o) {
  const n = Re(t), r = He(t), i = o === "fixed", s = Ue(e, !0, i, t);
  let a = { scrollLeft: 0, scrollTop: 0 };
  const l = { x: 0, y: 0 };
  if (n || !n && !i)
    if ((Be(t) !== "body" || yt(r)) && (a = Vt(t)), Re(t)) {
      const d = Ue(t, !0, i, t);
      l.x = d.x + t.clientLeft, l.y = d.y + t.clientTop;
    } else
      r && (l.x = Un(r));
  return { x: s.left + a.scrollLeft - l.x, y: s.top + a.scrollTop - l.y, width: s.width, height: s.height };
}
const la = { getClippingRect: function(e) {
  let { element: t, boundary: o, rootBoundary: n, strategy: r } = e;
  const i = o === "clippingAncestors" ? function(d, f) {
    const u = f.get(d);
    if (u)
      return u;
    let m = vt(d).filter((h) => we(h) && Be(h) !== "body"), p = null;
    const v = Te(d).position === "fixed";
    let g = v ? st(d) : d;
    for (; we(g) && !Ht(g); ) {
      const h = Te(g), y = mo(g);
      y || h.position !== "fixed" || (p = null), (v ? !y && !p : !y && h.position === "static" && p && ["absolute", "fixed"].includes(p.position) || yt(g) && !y && Kn(d, g)) ? m = m.filter((b) => b !== g) : p = h, g = st(g);
    }
    return f.set(d, m), m;
  }(t, this._c) : [].concat(o), s = [...i, n], a = s[0], l = s.reduce((d, f) => {
    const u = nn(t, f, r);
    return d.top = pt(u.top, d.top), d.right = tn(u.right, d.right), d.bottom = tn(u.bottom, d.bottom), d.left = pt(u.left, d.left), d;
  }, nn(t, a, r));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: t, offsetParent: o, strategy: n } = e;
  const r = Re(o), i = He(o);
  if (o === i)
    return t;
  let s = { scrollLeft: 0, scrollTop: 0 }, a = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((r || !r && n !== "fixed") && ((Be(o) !== "body" || yt(i)) && (s = Vt(o)), Re(o))) {
    const d = Ue(o);
    a = it(o), l.x = d.x + o.clientLeft, l.y = d.y + o.clientTop;
  }
  return { width: t.width * a.x, height: t.height * a.y, x: t.x * a.x - s.scrollLeft * a.x + l.x, y: t.y * a.y - s.scrollTop * a.y + l.y };
}, isElement: we, getDimensions: function(e) {
  return Hn(e);
}, getOffsetParent: an, getDocumentElement: He, getScale: it, async getElementRects(e) {
  let { reference: t, floating: o, strategy: n } = e;
  const r = this.getOffsetParent || an, i = this.getDimensions;
  return { reference: sa(t, await r(o), n), floating: { x: 0, y: 0, ...await i(o) } };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Te(e).direction === "rtl" };
function ca(e, t, o, n) {
  n === void 0 && (n = {});
  const { ancestorScroll: r = !0, ancestorResize: i = !0, elementResize: s = !0, animationFrame: a = !1 } = n, l = r || i ? [...we(e) ? vt(e) : e.contextElement ? vt(e.contextElement) : [], ...vt(t)] : [];
  l.forEach((m) => {
    const p = !we(m) && m.toString().includes("V");
    !r || a && !p || m.addEventListener("scroll", o, { passive: !0 }), i && m.addEventListener("resize", o);
  });
  let d, f = null;
  s && (f = new ResizeObserver(() => {
    o();
  }), we(e) && !a && f.observe(e), we(e) || !e.contextElement || a || f.observe(e.contextElement), f.observe(t));
  let u = a ? Ue(e) : null;
  return a && function m() {
    const p = Ue(e);
    !u || p.x === u.x && p.y === u.y && p.width === u.width && p.height === u.height || o(), u = p, d = requestAnimationFrame(m);
  }(), o(), () => {
    var m;
    l.forEach((p) => {
      r && p.removeEventListener("scroll", o), i && p.removeEventListener("resize", o);
    }), (m = f) == null || m.disconnect(), f = null, a && cancelAnimationFrame(d);
  };
}
const da = (e, t, o) => {
  const n = /* @__PURE__ */ new Map(), r = { platform: la, ...o }, i = { ...r.platform, _c: n };
  return Gi(e, t, { ...r, platform: i });
}, ua = (e) => {
  const {
    element: t,
    padding: o
  } = e;
  function n(r) {
    return {}.hasOwnProperty.call(r, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(r) {
      return t && n(t) ? t.current != null ? Zo({
        element: t.current,
        padding: o
      }).fn(r) : {} : t ? Zo({
        element: t,
        padding: o
      }).fn(r) : {};
    }
  };
};
var Rt = typeof document < "u" ? En : re;
function It(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let o, n, r;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (o = e.length, o != t.length)
        return !1;
      for (n = o; n-- !== 0; )
        if (!It(e[n], t[n]))
          return !1;
      return !0;
    }
    if (r = Object.keys(e), o = r.length, o !== Object.keys(t).length)
      return !1;
    for (n = o; n-- !== 0; )
      if (!{}.hasOwnProperty.call(t, r[n]))
        return !1;
    for (n = o; n-- !== 0; ) {
      const i = r[n];
      if (!(i === "_owner" && e.$$typeof) && !It(e[i], t[i]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function Yn(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function sn(e, t) {
  const o = Yn(e);
  return Math.round(t * o) / o;
}
function ln(e) {
  const t = R.useRef(e);
  return Rt(() => {
    t.current = e;
  }), t;
}
function fa(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: o = "absolute",
    middleware: n = [],
    platform: r,
    elements: {
      reference: i,
      floating: s
    } = {},
    transform: a = !0,
    whileElementsMounted: l,
    open: d
  } = e, [f, u] = R.useState({
    x: 0,
    y: 0,
    strategy: o,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [m, p] = R.useState(n);
  It(m, n) || p(n);
  const [v, g] = R.useState(null), [h, y] = R.useState(null), b = R.useCallback((A) => {
    A != E.current && (E.current = A, g(A));
  }, [g]), x = R.useCallback((A) => {
    A !== P.current && (P.current = A, y(A));
  }, [y]), _ = i || v, S = s || h, E = R.useRef(null), P = R.useRef(null), T = R.useRef(f), F = ln(l), X = ln(r), q = R.useCallback(() => {
    if (!E.current || !P.current)
      return;
    const A = {
      placement: t,
      strategy: o,
      middleware: m
    };
    X.current && (A.platform = X.current), da(E.current, P.current, A).then((Q) => {
      const ee = {
        ...Q,
        isPositioned: !0
      };
      V.current && !It(T.current, ee) && (T.current = ee, bi.flushSync(() => {
        u(ee);
      }));
    });
  }, [m, t, o, X]);
  Rt(() => {
    d === !1 && T.current.isPositioned && (T.current.isPositioned = !1, u((A) => ({
      ...A,
      isPositioned: !1
    })));
  }, [d]);
  const V = R.useRef(!1);
  Rt(() => (V.current = !0, () => {
    V.current = !1;
  }), []), Rt(() => {
    if (_ && (E.current = _), S && (P.current = S), _ && S) {
      if (F.current)
        return F.current(_, S, q);
      q();
    }
  }, [_, S, q, F]);
  const j = R.useMemo(() => ({
    reference: E,
    floating: P,
    setReference: b,
    setFloating: x
  }), [b, x]), L = R.useMemo(() => ({
    reference: _,
    floating: S
  }), [_, S]), I = R.useMemo(() => {
    const A = {
      position: o,
      left: 0,
      top: 0
    };
    if (!L.floating)
      return A;
    const Q = sn(L.floating, f.x), ee = sn(L.floating, f.y);
    return a ? {
      ...A,
      transform: "translate(" + Q + "px, " + ee + "px)",
      ...Yn(L.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: o,
      left: Q,
      top: ee
    };
  }, [o, a, L.floating, f.x, f.y]);
  return R.useMemo(() => ({
    ...f,
    update: q,
    refs: j,
    elements: L,
    floatingStyles: I
  }), [f, q, j, L, I]);
}
const xt = /* @__PURE__ */ D((e, t) => {
  const { children: o, ...n } = e, r = rt.toArray(o), i = r.find(pa);
  if (i) {
    const s = i.props.children, a = r.map((l) => l === i ? rt.count(s) > 1 ? rt.only(null) : /* @__PURE__ */ Nt(s) ? s.props.children : null : l);
    return /* @__PURE__ */ $(ho, M({}, n, {
      ref: t
    }), /* @__PURE__ */ Nt(s) ? /* @__PURE__ */ wo(s, void 0, a) : null);
  }
  return /* @__PURE__ */ $(ho, M({}, n, {
    ref: t
  }), o);
});
xt.displayName = "Slot";
const ho = /* @__PURE__ */ D((e, t) => {
  const { children: o, ...n } = e;
  return /* @__PURE__ */ Nt(o) ? /* @__PURE__ */ wo(o, {
    ...va(n, o.props),
    ref: t ? Dn(t, o.ref) : o.ref
  }) : rt.count(o) > 1 ? rt.only(null) : null;
});
ho.displayName = "SlotClone";
const ga = ({ children: e }) => /* @__PURE__ */ $(_o, null, e);
function pa(e) {
  return /* @__PURE__ */ Nt(e) && e.type === ga;
}
function va(e, t) {
  const o = {
    ...t
  };
  for (const n in t) {
    const r = e[n], i = t[n];
    /^on[A-Z]/.test(n) ? r && i ? o[n] = (...a) => {
      i(...a), r(...a);
    } : r && (o[n] = r) : n === "style" ? o[n] = {
      ...r,
      ...i
    } : n === "className" && (o[n] = [
      r,
      i
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...o
  };
}
const ma = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], ce = ma.reduce((e, t) => {
  const o = /* @__PURE__ */ D((n, r) => {
    const { asChild: i, ...s } = n, a = i ? xt : t;
    return re(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ $(a, M({}, s, {
      ref: r
    }));
  });
  return o.displayName = `Primitive.${t}`, {
    ...e,
    [t]: o
  };
}, {});
function ha(e, t) {
  e && Tn(
    () => e.dispatchEvent(t)
  );
}
const ba = /* @__PURE__ */ D((e, t) => {
  const { children: o, width: n = 10, height: r = 5, ...i } = e;
  return /* @__PURE__ */ $(ce.svg, M({}, i, {
    ref: t,
    width: n,
    height: r,
    viewBox: "0 0 30 10",
    preserveAspectRatio: "none"
  }), e.asChild ? o : /* @__PURE__ */ $("polygon", {
    points: "0,0 30,0 15,10"
  }));
}), ya = ba, ye = globalThis != null && globalThis.document ? En : () => {
};
function xa(e) {
  const [t, o] = G(void 0);
  return ye(() => {
    if (e) {
      o({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const n = new ResizeObserver((r) => {
        if (!Array.isArray(r) || !r.length)
          return;
        const i = r[0];
        let s, a;
        if ("borderBoxSize" in i) {
          const l = i.borderBoxSize, d = Array.isArray(l) ? l[0] : l;
          s = d.inlineSize, a = d.blockSize;
        } else
          s = e.offsetWidth, a = e.offsetHeight;
        o({
          width: s,
          height: a
        });
      });
      return n.observe(e, {
        box: "border-box"
      }), () => n.unobserve(e);
    } else
      o(void 0);
  }, [
    e
  ]), t;
}
const Gn = "Popper", [Zn, Bt] = Ft(Gn), [Ca, Jn] = Zn(Gn), wa = (e) => {
  const { __scopePopper: t, children: o } = e, [n, r] = G(null);
  return /* @__PURE__ */ $(Ca, {
    scope: t,
    anchor: n,
    onAnchorChange: r
  }, o);
}, _a = "PopperAnchor", $a = /* @__PURE__ */ D((e, t) => {
  const { __scopePopper: o, virtualRef: n, ...r } = e, i = Jn(_a, o), s = ne(null), a = ge(t, s);
  return re(() => {
    i.onAnchorChange((n == null ? void 0 : n.current) || s.current);
  }), n ? null : /* @__PURE__ */ $(ce.div, M({}, r, {
    ref: a
  }));
}), Qn = "PopperContent", [ka, Sa] = Zn(Qn), Pa = /* @__PURE__ */ D((e, t) => {
  var o, n, r, i, s, a, l, d;
  const { __scopePopper: f, side: u = "bottom", sideOffset: m = 0, align: p = "center", alignOffset: v = 0, arrowPadding: g = 0, collisionBoundary: h = [], collisionPadding: y = 0, sticky: b = "partial", hideWhenDetached: x = !1, avoidCollisions: _ = !0, onPlaced: S, ...E } = e, P = Jn(Qn, f), [T, F] = G(null), X = ge(
    t,
    (ve) => F(ve)
  ), [q, V] = G(null), j = xa(q), L = (o = j == null ? void 0 : j.width) !== null && o !== void 0 ? o : 0, I = (n = j == null ? void 0 : j.height) !== null && n !== void 0 ? n : 0, A = u + (p !== "center" ? "-" + p : ""), Q = typeof y == "number" ? y : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...y
  }, ee = Array.isArray(h) ? h : [
    h
  ], pe = ee.length > 0, ie = {
    padding: Q,
    boundary: ee.filter(Aa),
    // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
    altBoundary: pe
  }, { refs: ue, floatingStyles: me, placement: ke, isPositioned: xe, middlewareData: Ce } = fa({
    // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
    strategy: "fixed",
    placement: A,
    whileElementsMounted: ca,
    elements: {
      reference: P.anchor
    },
    middleware: [
      oa({
        mainAxis: m + I,
        alignmentAxis: v
      }),
      _ && na({
        mainAxis: !0,
        crossAxis: !1,
        limiter: b === "partial" ? ra() : void 0,
        ...ie
      }),
      _ && ea({
        ...ie
      }),
      ia({
        ...ie,
        apply: ({ elements: ve, rects: Ae, availableWidth: Oe, availableHeight: Me }) => {
          const { width: wt, height: Ze } = Ae.reference, Je = ve.floating.style;
          Je.setProperty("--radix-popper-available-width", `${Oe}px`), Je.setProperty("--radix-popper-available-height", `${Me}px`), Je.setProperty("--radix-popper-anchor-width", `${wt}px`), Je.setProperty("--radix-popper-anchor-height", `${Ze}px`);
        }
      }),
      q && ua({
        element: q,
        padding: g
      }),
      Oa({
        arrowWidth: L,
        arrowHeight: I
      }),
      x && ta({
        strategy: "referenceHidden"
      })
    ]
  }), [Se, O] = er(ke), U = De(S);
  ye(() => {
    xe && (U == null || U());
  }, [
    xe,
    U
  ]);
  const fe = (r = Ce.arrow) === null || r === void 0 ? void 0 : r.x, Z = (i = Ce.arrow) === null || i === void 0 ? void 0 : i.y, J = ((s = Ce.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0, [K, he] = G();
  return ye(() => {
    T && he(window.getComputedStyle(T).zIndex);
  }, [
    T
  ]), /* @__PURE__ */ $("div", {
    ref: ue.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...me,
      transform: xe ? me.transform : "translate(0, -200%)",
      // keep off the page when measuring
      minWidth: "max-content",
      zIndex: K,
      ["--radix-popper-transform-origin"]: [
        (a = Ce.transformOrigin) === null || a === void 0 ? void 0 : a.x,
        (l = Ce.transformOrigin) === null || l === void 0 ? void 0 : l.y
      ].join(" ")
    },
    dir: e.dir
  }, /* @__PURE__ */ $(ka, {
    scope: f,
    placedSide: Se,
    onArrowChange: V,
    arrowX: fe,
    arrowY: Z,
    shouldHideArrow: J
  }, /* @__PURE__ */ $(ce.div, M({
    "data-side": Se,
    "data-align": O
  }, E, {
    ref: X,
    style: {
      ...E.style,
      // if the PopperContent hasn't been placed yet (not all measurements done)
      // we prevent animations so that users's animation don't kick in too early referring wrong sides
      animation: xe ? void 0 : "none",
      // hide the content if using the hide middleware and should be hidden
      opacity: (d = Ce.hide) !== null && d !== void 0 && d.referenceHidden ? 0 : void 0
    }
  }))));
}), Ea = "PopperArrow", Ta = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, Ra = /* @__PURE__ */ D(function(t, o) {
  const { __scopePopper: n, ...r } = t, i = Sa(Ea, n), s = Ta[i.placedSide];
  return (
    // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
    // doesn't report size as we'd expect on SVG elements.
    // it reports their bounding box which is effectively the largest path inside the SVG.
    /* @__PURE__ */ $("span", {
      ref: i.onArrowChange,
      style: {
        position: "absolute",
        left: i.arrowX,
        top: i.arrowY,
        [s]: 0,
        transformOrigin: {
          top: "",
          right: "0 0",
          bottom: "center 0",
          left: "100% 0"
        }[i.placedSide],
        transform: {
          top: "translateY(100%)",
          right: "translateY(50%) rotate(90deg) translateX(-50%)",
          bottom: "rotate(180deg)",
          left: "translateY(50%) rotate(-90deg) translateX(50%)"
        }[i.placedSide],
        visibility: i.shouldHideArrow ? "hidden" : void 0
      }
    }, /* @__PURE__ */ $(ya, M({}, r, {
      ref: o,
      style: {
        ...r.style,
        // ensures the element can be measured correctly (mostly for if SVG)
        display: "block"
      }
    })))
  );
});
function Aa(e) {
  return e !== null;
}
const Oa = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var o, n, r, i, s;
    const { placement: a, rects: l, middlewareData: d } = t, u = ((o = d.arrow) === null || o === void 0 ? void 0 : o.centerOffset) !== 0, m = u ? 0 : e.arrowWidth, p = u ? 0 : e.arrowHeight, [v, g] = er(a), h = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[g], y = ((n = (r = d.arrow) === null || r === void 0 ? void 0 : r.x) !== null && n !== void 0 ? n : 0) + m / 2, b = ((i = (s = d.arrow) === null || s === void 0 ? void 0 : s.y) !== null && i !== void 0 ? i : 0) + p / 2;
    let x = "", _ = "";
    return v === "bottom" ? (x = u ? h : `${y}px`, _ = `${-p}px`) : v === "top" ? (x = u ? h : `${y}px`, _ = `${l.floating.height + p}px`) : v === "right" ? (x = `${-p}px`, _ = u ? h : `${b}px`) : v === "left" && (x = `${l.floating.width + p}px`, _ = u ? h : `${b}px`), {
      data: {
        x,
        y: _
      }
    };
  }
});
function er(e) {
  const [t, o = "center"] = e.split("-");
  return [
    t,
    o
  ];
}
const tr = wa, or = $a, nr = Pa, Na = Ra, rr = /* @__PURE__ */ D((e, t) => {
  var o;
  const { container: n = globalThis == null || (o = globalThis.document) === null || o === void 0 ? void 0 : o.body, ...r } = e;
  return n ? /* @__PURE__ */ yi.createPortal(/* @__PURE__ */ $(ce.div, M({}, r, {
    ref: t
  })), n) : null;
});
function qa(e, t) {
  return hi((o, n) => {
    const r = t[o][n];
    return r ?? o;
  }, e);
}
const Po = (e) => {
  const { present: t, children: o } = e, n = ja(t), r = typeof o == "function" ? o({
    present: n.isPresent
  }) : rt.only(o), i = ge(n.ref, r.ref);
  return typeof o == "function" || n.isPresent ? /* @__PURE__ */ wo(r, {
    ref: i
  }) : null;
};
Po.displayName = "Presence";
function ja(e) {
  const [t, o] = G(), n = ne({}), r = ne(e), i = ne("none"), s = e ? "mounted" : "unmounted", [a, l] = qa(s, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return re(() => {
    const d = _t(n.current);
    i.current = a === "mounted" ? d : "none";
  }, [
    a
  ]), ye(() => {
    const d = n.current, f = r.current;
    if (f !== e) {
      const m = i.current, p = _t(d);
      e ? l("MOUNT") : p === "none" || (d == null ? void 0 : d.display) === "none" ? l("UNMOUNT") : l(f && m !== p ? "ANIMATION_OUT" : "UNMOUNT"), r.current = e;
    }
  }, [
    e,
    l
  ]), ye(() => {
    if (t) {
      const d = (u) => {
        const p = _t(n.current).includes(u.animationName);
        u.target === t && p && Tn(
          () => l("ANIMATION_END")
        );
      }, f = (u) => {
        u.target === t && (i.current = _t(n.current));
      };
      return t.addEventListener("animationstart", f), t.addEventListener("animationcancel", d), t.addEventListener("animationend", d), () => {
        t.removeEventListener("animationstart", f), t.removeEventListener("animationcancel", d), t.removeEventListener("animationend", d);
      };
    } else
      l("ANIMATION_END");
  }, [
    t,
    l
  ]), {
    isPresent: [
      "mounted",
      "unmountSuspended"
    ].includes(a),
    ref: le((d) => {
      d && (n.current = getComputedStyle(d)), o(d);
    }, [])
  };
}
function _t(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function za(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e);
  re(() => {
    const n = (r) => {
      r.key === "Escape" && o(r);
    };
    return t.addEventListener("keydown", n), () => t.removeEventListener("keydown", n);
  }, [
    o,
    t
  ]);
}
const bo = "dismissableLayer.update", Da = "dismissableLayer.pointerDownOutside", Ia = "dismissableLayer.focusOutside";
let cn;
const La = /* @__PURE__ */ ht({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), ir = /* @__PURE__ */ D((e, t) => {
  var o;
  const { disableOutsidePointerEvents: n = !1, onEscapeKeyDown: r, onPointerDownOutside: i, onFocusOutside: s, onInteractOutside: a, onDismiss: l, ...d } = e, f = Mt(La), [u, m] = G(null), p = (o = u == null ? void 0 : u.ownerDocument) !== null && o !== void 0 ? o : globalThis == null ? void 0 : globalThis.document, [, v] = G({}), g = ge(
    t,
    (T) => m(T)
  ), h = Array.from(f.layers), [y] = [
    ...f.layersWithOutsidePointerEventsDisabled
  ].slice(-1), b = h.indexOf(y), x = u ? h.indexOf(u) : -1, _ = f.layersWithOutsidePointerEventsDisabled.size > 0, S = x >= b, E = Ma((T) => {
    const F = T.target, X = [
      ...f.branches
    ].some(
      (q) => q.contains(F)
    );
    !S || X || (i == null || i(T), a == null || a(T), T.defaultPrevented || l == null || l());
  }, p), P = Fa((T) => {
    const F = T.target;
    [
      ...f.branches
    ].some(
      (q) => q.contains(F)
    ) || (s == null || s(T), a == null || a(T), T.defaultPrevented || l == null || l());
  }, p);
  return za((T) => {
    x === f.layers.size - 1 && (r == null || r(T), !T.defaultPrevented && l && (T.preventDefault(), l()));
  }, p), re(() => {
    if (u)
      return n && (f.layersWithOutsidePointerEventsDisabled.size === 0 && (cn = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), f.layersWithOutsidePointerEventsDisabled.add(u)), f.layers.add(u), dn(), () => {
        n && f.layersWithOutsidePointerEventsDisabled.size === 1 && (p.body.style.pointerEvents = cn);
      };
  }, [
    u,
    p,
    n,
    f
  ]), re(() => () => {
    u && (f.layers.delete(u), f.layersWithOutsidePointerEventsDisabled.delete(u), dn());
  }, [
    u,
    f
  ]), re(() => {
    const T = () => v({});
    return document.addEventListener(bo, T), () => document.removeEventListener(bo, T);
  }, []), /* @__PURE__ */ $(ce.div, M({}, d, {
    ref: g,
    style: {
      pointerEvents: _ ? S ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: oe(e.onFocusCapture, P.onFocusCapture),
    onBlurCapture: oe(e.onBlurCapture, P.onBlurCapture),
    onPointerDownCapture: oe(e.onPointerDownCapture, E.onPointerDownCapture)
  }));
});
function Ma(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e), n = ne(!1), r = ne(() => {
  });
  return re(() => {
    const i = (a) => {
      if (a.target && !n.current) {
        let d = function() {
          ar(Da, o, l, {
            discrete: !0
          });
        };
        const l = {
          originalEvent: a
        };
        a.pointerType === "touch" ? (t.removeEventListener("click", r.current), r.current = d, t.addEventListener("click", r.current, {
          once: !0
        })) : d();
      }
      n.current = !1;
    }, s = window.setTimeout(() => {
      t.addEventListener("pointerdown", i);
    }, 0);
    return () => {
      window.clearTimeout(s), t.removeEventListener("pointerdown", i), t.removeEventListener("click", r.current);
    };
  }, [
    t,
    o
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => n.current = !0
  };
}
function Fa(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = De(e), n = ne(!1);
  return re(() => {
    const r = (i) => {
      i.target && !n.current && ar(Ia, o, {
        originalEvent: i
      }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", r), () => t.removeEventListener("focusin", r);
  }, [
    t,
    o
  ]), {
    onFocusCapture: () => n.current = !0,
    onBlurCapture: () => n.current = !1
  };
}
function dn() {
  const e = new CustomEvent(bo);
  document.dispatchEvent(e);
}
function ar(e, t, o, { discrete: n }) {
  const r = o.originalEvent.target, i = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: o
  });
  t && r.addEventListener(e, t, {
    once: !0
  }), n ? ha(r, i) : r.dispatchEvent(i);
}
let no;
const sr = "HoverCard", [lr, wd] = Ft(sr, [
  Bt
]), Wt = Bt(), [Ha, Ut] = lr(sr), Va = (e) => {
  const { __scopeHoverCard: t, children: o, open: n, defaultOpen: r, onOpenChange: i, openDelay: s = 700, closeDelay: a = 300 } = e, l = Wt(t), d = ne(0), f = ne(0), u = ne(!1), m = ne(!1), [p = !1, v] = go({
    prop: n,
    defaultProp: r,
    onChange: i
  }), g = le(() => {
    clearTimeout(f.current), d.current = window.setTimeout(
      () => v(!0),
      s
    );
  }, [
    s,
    v
  ]), h = le(() => {
    clearTimeout(d.current), !u.current && !m.current && (f.current = window.setTimeout(
      () => v(!1),
      a
    ));
  }, [
    a,
    v
  ]), y = le(
    () => v(!1),
    [
      v
    ]
  );
  return re(() => () => {
    clearTimeout(d.current), clearTimeout(f.current);
  }, []), /* @__PURE__ */ $(Ha, {
    scope: t,
    open: p,
    onOpenChange: v,
    onOpen: g,
    onClose: h,
    onDismiss: y,
    hasSelectionRef: u,
    isPointerDownOnContentRef: m
  }, /* @__PURE__ */ $(tr, l, o));
}, Ba = "HoverCardTrigger", Wa = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, ...n } = e, r = Ut(Ba, o), i = Wt(o);
  return /* @__PURE__ */ $(or, M({
    asChild: !0
  }, i), /* @__PURE__ */ $(ce.a, M({
    "data-state": r.open ? "open" : "closed"
  }, n, {
    ref: t,
    onPointerEnter: oe(e.onPointerEnter, Lt(r.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lt(r.onClose)),
    onFocus: oe(e.onFocus, r.onOpen),
    onBlur: oe(e.onBlur, r.onClose),
    onTouchStart: oe(
      e.onTouchStart,
      (s) => s.preventDefault()
    )
  })));
}), cr = "HoverCardPortal", [Ua, Xa] = lr(cr, {
  forceMount: void 0
}), Ka = (e) => {
  const { __scopeHoverCard: t, forceMount: o, children: n, container: r } = e, i = Ut(cr, t);
  return /* @__PURE__ */ $(Ua, {
    scope: t,
    forceMount: o
  }, /* @__PURE__ */ $(Po, {
    present: o || i.open
  }, /* @__PURE__ */ $(rr, {
    asChild: !0,
    container: r
  }, n)));
}, yo = "HoverCardContent", Ya = /* @__PURE__ */ D((e, t) => {
  const o = Xa(yo, e.__scopeHoverCard), { forceMount: n = o.forceMount, ...r } = e, i = Ut(yo, e.__scopeHoverCard);
  return /* @__PURE__ */ $(Po, {
    present: n || i.open
  }, /* @__PURE__ */ $(Ga, M({
    "data-state": i.open ? "open" : "closed"
  }, r, {
    onPointerEnter: oe(e.onPointerEnter, Lt(i.onOpen)),
    onPointerLeave: oe(e.onPointerLeave, Lt(i.onClose)),
    ref: t
  })));
}), Ga = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, onEscapeKeyDown: n, onPointerDownOutside: r, onFocusOutside: i, onInteractOutside: s, ...a } = e, l = Ut(yo, o), d = Wt(o), f = ne(null), u = ge(t, f), [m, p] = G(!1);
  return re(() => {
    if (m) {
      const v = document.body;
      return no = v.style.userSelect || v.style.webkitUserSelect, v.style.userSelect = "none", v.style.webkitUserSelect = "none", () => {
        v.style.userSelect = no, v.style.webkitUserSelect = no;
      };
    }
  }, [
    m
  ]), re(() => {
    if (f.current) {
      const v = () => {
        p(!1), l.isPointerDownOnContentRef.current = !1, setTimeout(() => {
          var g;
          ((g = document.getSelection()) === null || g === void 0 ? void 0 : g.toString()) !== "" && (l.hasSelectionRef.current = !0);
        });
      };
      return document.addEventListener("pointerup", v), () => {
        document.removeEventListener("pointerup", v), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !1;
      };
    }
  }, [
    l.isPointerDownOnContentRef,
    l.hasSelectionRef
  ]), re(() => {
    f.current && Ja(f.current).forEach(
      (g) => g.setAttribute("tabindex", "-1")
    );
  }), /* @__PURE__ */ $(ir, {
    asChild: !0,
    disableOutsidePointerEvents: !1,
    onInteractOutside: s,
    onEscapeKeyDown: n,
    onPointerDownOutside: r,
    onFocusOutside: oe(i, (v) => {
      v.preventDefault();
    }),
    onDismiss: l.onDismiss
  }, /* @__PURE__ */ $(nr, M({}, d, a, {
    onPointerDown: oe(a.onPointerDown, (v) => {
      v.currentTarget.contains(v.target) && p(!0), l.hasSelectionRef.current = !1, l.isPointerDownOnContentRef.current = !0;
    }),
    ref: u,
    style: {
      ...a.style,
      userSelect: m ? "text" : void 0,
      // Safari requires prefix
      WebkitUserSelect: m ? "text" : void 0,
      "--radix-hover-card-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-hover-card-content-available-width": "var(--radix-popper-available-width)",
      "--radix-hover-card-content-available-height": "var(--radix-popper-available-height)",
      "--radix-hover-card-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-hover-card-trigger-height": "var(--radix-popper-anchor-height)"
    }
  })));
}), Za = /* @__PURE__ */ D((e, t) => {
  const { __scopeHoverCard: o, ...n } = e, r = Wt(o);
  return /* @__PURE__ */ $(Na, M({}, r, n, {
    ref: t
  }));
});
function Lt(e) {
  return (t) => t.pointerType === "touch" ? void 0 : e();
}
function Ja(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
  });
  for (; o.nextNode(); )
    t.push(o.currentNode);
  return t;
}
const Qa = Va, es = Wa, ts = Ka, os = Ya, ns = Za;
var rs = "_1v4ltqn1", is = "_1v4ltqn0";
const dr = ns, as = Qa, Eo = ts, ur = B.forwardRef((e, t) => /* @__PURE__ */ w.jsx(
  es,
  {
    ref: t,
    type: "button",
    className: z(is, e.className),
    ...e,
    children: e.children
  }
)), fr = B.forwardRef((e, t) => /* @__PURE__ */ w.jsx(Eo, { children: /* @__PURE__ */ w.jsx(
  os,
  {
    ref: t,
    className: z(rs, e.className),
    ...e,
    children: e.children
  }
) })), Ct = (e) => /* @__PURE__ */ w.jsx(as, { ...e });
Ct.Trigger = ur;
Ct.Content = fr;
Ct.Arrow = dr;
Ct.Portal = Eo;
Ct.displayName = "HoverCard";
ur.displayName = "HoverCardTrigger";
fr.displayName = "HoverCardContent";
dr.displayName = "HoverCardArrow";
Eo.displayName = "HoverCardPortal";
var ss = _e({ defaultClassName: "_1l37a3c6", variantClassNames: { size: { small: "_1l37a3c2", medium: "_1l37a3c3" }, variant: { slate: "_1l37a3c4", hyper: "_1l37a3c5" } }, defaultVariants: { size: "medium", variant: "slate" }, compoundVariants: [] }), ls = "_1l37a3c1", cs = "_1l37a3c0";
const gr = D(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
    "div",
    {
      ref: n,
      className: z(t, cs),
      ...o,
      children: e
    }
  )
), pr = D(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
    "label",
    {
      ref: n,
      className: z(t, ls),
      ...o,
      children: /* @__PURE__ */ w.jsx("span", { children: e })
    }
  )
), ds = D(
  ({ className: e, size: t = "medium", variant: o = "slate", ...n }, r) => /* @__PURE__ */ w.jsx(
    "input",
    {
      ref: r,
      className: z(e, ss({ size: t, variant: o })),
      ...n
    }
  )
), To = (e) => /* @__PURE__ */ w.jsx(ds, { ...e });
To.Flex = gr;
To.Label = pr;
To.displayName = "Input";
gr.displayName = "Input.Flex";
pr.displayName = "Input.Label";
var us = "d9r7gl3", fs = "d9r7gl2", gs = "d9r7gl0", ps = "d9r7gl1", vs = "d9r7gl5", ms = "d9r7gl4";
const vr = Ie.Menu, mr = Ie.Sub, hr = Ie.Portal, hs = B.forwardRef(({ children: e, className: t, loop: o = !0, ...n }, r) => /* @__PURE__ */ w.jsx(
  Ie.Root,
  {
    ...n,
    ref: r,
    className: z(t, gs),
    loop: o,
    children: e
  }
)), br = B.forwardRef(({ children: e, className: t, side: o = "bottom", sideOffset: n = 10, ...r }, i) => /* @__PURE__ */ w.jsx(
  Ie.Content,
  {
    ...r,
    ref: i,
    className: z(t, us),
    side: o,
    sideOffset: n,
    children: e
  }
)), yr = B.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.Item,
  {
    ...o,
    ref: n,
    className: z(t, fs),
    children: e
  }
)), xr = B.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.Trigger,
  {
    ...o,
    ref: n,
    className: z(t, ps),
    children: e
  }
)), Cr = B.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Ie.SubTrigger,
  {
    ...o,
    ref: n,
    className: z(t, ms),
    children: e
  }
)), wr = B.forwardRef(({ children: e, className: t, sideOffset: o = 10, ...n }, r) => /* @__PURE__ */ w.jsx(
  Ie.SubContent,
  {
    ...n,
    ref: r,
    className: z(t, vs),
    sideOffset: o,
    children: e
  }
)), Le = (e) => /* @__PURE__ */ w.jsx(hs, { ...e });
Le.displayName = "Menubar";
Le.Menu = vr;
Le.Trigger = xr;
Le.Content = br;
Le.Item = yr;
Le.SubMenu = mr;
Le.SubTrigger = Cr;
Le.SubContent = wr;
Le.Portal = hr;
vr.displayName = "Menubar-Menu";
xr.displayName = "Menubar-Trigger";
br.displayName = "Menubar-Content";
yr.displayName = "Menubar-Item";
mr.displayName = "Menubar-SubMenu";
Cr.displayName = "Menubar-SubTrigger";
wr.displayName = "Menubar-SubContent";
hr.displayName = "Menubar-Portal";
var bs = _e({ defaultClassName: "qohxgz2s", variantClassNames: { size: { xs: "qohxgz0", sm: "qohxgz1", md: "qohxgz2", lg: "qohxgz3", xl: "qohxgz4" }, color: { transparent: "qohxgz5", current: "qohxgz6", white: "qohxgz7", black: "qohxgz8", gray100: "qohxgz9", gray200: "qohxgza", gray300: "qohxgzb", pale100: "qohxgzc", pale200: "qohxgzd", pale300: "qohxgze", pale400: "qohxgzf", pale500: "qohxgzg", hyper0: "qohxgzh", hyper1: "qohxgzi", hyper2: "qohxgzj", hyper3: "qohxgzk", hyper4: "qohxgzl", hyper5: "qohxgzm", hyper6: "qohxgzn", hyper7: "qohxgzo", hyper8: "qohxgzp", hyper9: "qohxgzq", hyper10: "qohxgzr", hyper11: "qohxgzs", hyper12: "qohxgzt", hyper13: "qohxgzu", lemon0: "qohxgzv", lemon1: "qohxgzw", lemon2: "qohxgzx", lemon3: "qohxgzy", lemon4: "qohxgzz", lemon5: "qohxgz10", lemon6: "qohxgz11", lemon7: "qohxgz12", lemon8: "qohxgz13", lemon9: "qohxgz14", lemon10: "qohxgz15", lemon11: "qohxgz16", lemon12: "qohxgz17", lemon13: "qohxgz18", slate1: "qohxgz19", slate2: "qohxgz1a", slate3: "qohxgz1b", slate4: "qohxgz1c", slate5: "qohxgz1d", slate6: "qohxgz1e", slate7: "qohxgz1f", slate8: "qohxgz1g", slate9: "qohxgz1h", slate10: "qohxgz1i", slate11: "qohxgz1j", slate12: "qohxgz1k", slate13: "qohxgz1l", sapphire0: "qohxgz1m", sapphire1: "qohxgz1n", sapphire2: "qohxgz1o", sapphire3: "qohxgz1p", sapphire4: "qohxgz1q", sapphire5: "qohxgz1r", sapphire6: "qohxgz1s", sapphire7: "qohxgz1t", sapphire8: "qohxgz1u", sapphire9: "qohxgz1v", sapphire10: "qohxgz1w", sapphire11: "qohxgz1x", sapphire12: "qohxgz1y", sapphire13: "qohxgz1z", volt0: "qohxgz20", volt1: "qohxgz21", volt2: "qohxgz22", volt3: "qohxgz23", volt4: "qohxgz24", volt5: "qohxgz25", volt6: "qohxgz26", volt7: "qohxgz27", volt8: "qohxgz28", volt9: "qohxgz29", volt10: "qohxgz2a", volt11: "qohxgz2b", volt12: "qohxgz2c", volt13: "qohxgz2d" }, weight: { superlite: "qohxgz2e", lite: "qohxgz2f", normal: "qohxgz2g", medium: "qohxgz2h", semibold: "qohxgz2i", bold: "qohxgz2j", heavy: "qohxgz2k", black: "qohxgz2l" }, align: { left: "qohxgz2m", center: "qohxgz2n", right: "qohxgz2o" }, font: { system: "qohxgz2p", inter: "qohxgz2q", mono: "qohxgz2r" } }, defaultVariants: { size: "sm", color: "slate12", weight: "normal", align: "left", font: "system" }, compoundVariants: [] });
const ys = D(
  ({ children: e, className: t, size: o, color: n, weight: r, align: i, font: s, ...a }, l) => /* @__PURE__ */ w.jsx(
    "p",
    {
      ref: l,
      className: z(t, bs({ size: o, color: n, weight: r, align: i, font: s })),
      ...a,
      children: e
    }
  )
);
ys.displayName = "Paragraph";
var xs = _e({ defaultClassName: "_1g4z5m4c", variantClassNames: { size: { xs: "_1g4z5m40", sm: "_1g4z5m41", md: "_1g4z5m42", lg: "_1g4z5m43", xl: "_1g4z5m44", xxl: "_1g4z5m45" }, variant: { inherit: "_1g4z5m46", primary: "_1g4z5m47", secondary: "_1g4z5m48" }, font: { inherit: "_1g4z5m49", system: "_1g4z5m4a", mono: "_1g4z5m4b" } }, defaultVariants: { size: "sm", variant: "primary" }, compoundVariants: [] });
const Cs = D(
  ({
    children: e,
    className: t,
    href: o,
    variant: n,
    target: r = "_self",
    size: i = "sm",
    font: s = "inherit",
    ...a
  }, l) => /* @__PURE__ */ w.jsx(
    "a",
    {
      ref: l,
      href: o,
      target: r,
      className: z(xs({ size: i, variant: n }), t),
      ...a,
      children: e
    }
  )
);
Cs.displayName = "PassLink";
var ws = "_1k7gvp52";
const _s = Ve.Portal, $s = Ve.Root, ks = Ve.Trigger, Ss = B.forwardRef(({ className: e, align: t = "center", sideOffset: o = 4, ...n }, r) => /* @__PURE__ */ w.jsx(Ve.Portal, { children: /* @__PURE__ */ w.jsx(
  Ve.Content,
  {
    ref: r,
    align: t,
    sideOffset: o,
    className: z(ws, e),
    ...n
  }
) })), $e = (e) => /* @__PURE__ */ w.jsx($s, { ...e });
$e.Trigger = ks;
$e.Content = Ss;
$e.Portal = _s;
$e.Anchor = Ve.Anchor;
$e.Arrow = Ve.Arrow;
$e.Close = Ve.Close;
$e.displayName = "Popover";
$e.Trigger.displayName = "PopoverTrigger";
$e.Content.displayName = "PopoverContent";
$e.Portal.displayName = "PopoverPortal";
$e.Anchor.displayName = "PopoverAnchor";
$e.Arrow.displayName = "PopoverArrow";
$e.Close.displayName = "PopoverClose";
var Ps = "ltqw8z0", Es = { article: "ltqw8z1", aside: "ltqw8z1", details: "ltqw8z1", figcaption: "ltqw8z1", figure: "ltqw8z1", footer: "ltqw8z1", header: "ltqw8z1", hgroup: "ltqw8z1", menu: "ltqw8z1", nav: "ltqw8z1", section: "ltqw8z1", ul: "ltqw8z3", ol: "ltqw8z3", blockquote: "ltqw8z4", q: "ltqw8z4", body: "ltqw8z2", a: "ltqw8zg", table: "ltqw8z5", mark: "ltqw8za ltqw8z7", select: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zb", button: "ltqw8z7", textarea: "ltqw8z1 ltqw8z6 ltqw8z8", input: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zd" };
function Ts(e, t) {
  return Object.defineProperty(e, "__recipe__", {
    value: t,
    writable: !1
  }), e;
}
var _r = Ts;
function Rs(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  function o(n) {
    if (typeof n == "string" || typeof n == "number" || typeof n == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return {
        [t.defaultCondition]: n
      };
    }
    if (Array.isArray(n)) {
      if (!("responsiveArray" in t))
        throw new Error("Responsive arrays are not supported");
      var r = {};
      for (var i in t.responsiveArray)
        n[i] != null && (r[t.responsiveArray[i]] = n[i]);
      return r;
    }
    return n;
  }
  return _r(o, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createNormalizeValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function $r(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  var o = Rs(e);
  function n(r, i) {
    if (typeof r == "string" || typeof r == "number" || typeof r == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return i(r, t.defaultCondition);
    }
    var s = Array.isArray(r) ? o(r) : r, a = {};
    for (var l in s)
      s[l] != null && (a[l] = i(s[l], l));
    return a;
  }
  return _r(n, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createMapValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function As(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Os(e) {
  var t = As(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function Ns(e, t, o) {
  return t = Os(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function un(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function ro(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? un(Object(o), !0).forEach(function(n) {
      Ns(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : un(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var qs = (e) => function() {
  for (var t = arguments.length, o = new Array(t), n = 0; n < t; n++)
    o[n] = arguments[n];
  var r = Object.assign({}, ...o.map((l) => l.styles)), i = Object.keys(r), s = i.filter((l) => "mappings" in r[l]), a = (l) => {
    var d = [], f = {}, u = ro({}, l), m = !1;
    for (var p of s) {
      var v = l[p];
      if (v != null) {
        var g = r[p];
        m = !0;
        for (var h of g.mappings)
          f[h] = v, u[h] == null && delete u[h];
      }
    }
    var y = m ? ro(ro({}, f), u) : l, b = function() {
      var E = y[x], P = r[x];
      try {
        if (P.mappings)
          return "continue";
        if (typeof E == "string" || typeof E == "number") {
          if (process.env.NODE_ENV !== "production" && !P.values[E].defaultClass)
            throw new Error();
          d.push(P.values[E].defaultClass);
        } else if (Array.isArray(E))
          for (var T = 0; T < E.length; T++) {
            var F = E[T];
            if (F != null) {
              var X = P.responsiveArray[T];
              if (process.env.NODE_ENV !== "production" && !P.values[F].conditions[X])
                throw new Error();
              d.push(P.values[F].conditions[X]);
            }
          }
        else
          for (var q in E) {
            var V = E[q];
            if (V != null) {
              if (process.env.NODE_ENV !== "production" && !P.values[V].conditions[q])
                throw new Error();
              d.push(P.values[V].conditions[q]);
            }
          }
      } catch (pe) {
        if (process.env.NODE_ENV !== "production") {
          class ie extends Error {
            constructor(me) {
              super(me), this.name = "SprinklesError";
            }
          }
          var j = (ue) => typeof ue == "string" ? '"'.concat(ue, '"') : ue, L = (ue, me, ke) => {
            throw new ie('"'.concat(ue, '" has no value ').concat(j(me), ". Possible values are ").concat(Object.keys(ke).map(j).join(", ")));
          };
          if (!P)
            throw new ie('"'.concat(x, '" is not a valid sprinkle'));
          if ((typeof E == "string" || typeof E == "number") && (E in P.values || L(x, E, P.values), !P.values[E].defaultClass))
            throw new ie('"'.concat(x, '" has no default condition. You must specify which conditions to target explicitly. Possible options are ').concat(Object.keys(P.values[E].conditions).map(j).join(", ")));
          if (typeof E == "object") {
            if (!("conditions" in P.values[Object.keys(P.values)[0]]))
              throw new ie('"'.concat(x, '" is not a conditional property'));
            if (Array.isArray(E)) {
              if (!("responsiveArray" in P))
                throw new ie('"'.concat(x, '" does not support responsive arrays'));
              var I = P.responsiveArray.length;
              if (I < E.length)
                throw new ie('"'.concat(x, '" only supports up to ').concat(I, " breakpoints. You passed ").concat(E.length));
              for (var A of E)
                P.values[A] || L(x, A, P.values);
            } else
              for (var Q in E) {
                var ee = E[Q];
                if (ee != null && (P.values[ee] || L(x, ee, P.values), !P.values[ee].conditions[Q]))
                  throw new ie('"'.concat(x, '" has no condition named ').concat(j(Q), ". Possible values are ").concat(Object.keys(P.values[ee].conditions).map(j).join(", ")));
              }
          }
        }
        throw pe;
      }
    };
    for (var x in y)
      var _ = b();
    return e(d.join(" "));
  };
  return Object.assign(a, {
    properties: new Set(i)
  });
}, js = (e) => e, zs = function() {
  return qs(js)(...arguments);
}, _d = $r({ conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 } }), kr = $r({ conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] } }), Sr = zs(function() {
  var e = { conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] }, styles: { all: { values: { unset: { conditions: { small: "i77g9o0", medium: "i77g9o1", large: "i77g9o2", xlarge: "i77g9o3" }, defaultClass: "i77g9o0" } }, responsiveArray: void 0 }, boxSizing: { values: { "border-box": { conditions: { small: "i77g9o4", medium: "i77g9o5", large: "i77g9o6", xlarge: "i77g9o7" }, defaultClass: "i77g9o4" } }, responsiveArray: void 0 }, appearance: { values: { none: { conditions: { small: "i77g9o8", medium: "i77g9o9", large: "i77g9oa", xlarge: "i77g9ob" }, defaultClass: "i77g9o8" } }, responsiveArray: void 0 }, outline: { values: { none: { conditions: { small: "i77g9oc", medium: "i77g9od", large: "i77g9oe", xlarge: "i77g9of" }, defaultClass: "i77g9oc" } }, responsiveArray: void 0 }, userSelect: { values: { none: { conditions: { small: "i77g9og", medium: "i77g9oh", large: "i77g9oi", xlarge: "i77g9oj" }, defaultClass: "i77g9og" }, auto: { conditions: { small: "i77g9ok", medium: "i77g9ol", large: "i77g9om", xlarge: "i77g9on" }, defaultClass: "i77g9ok" } }, responsiveArray: void 0 }, fontVariantNumeric: { values: { "tabular-nums": { conditions: { small: "i77g9oo", medium: "i77g9op", large: "i77g9oq", xlarge: "i77g9or" }, defaultClass: "i77g9oo" } }, responsiveArray: void 0 }, WebkitTapHighlightColor: { values: { "rgba(0,0,0,0)": { conditions: { small: "i77g9os", medium: "i77g9ot", large: "i77g9ou", xlarge: "i77g9ov" }, defaultClass: "i77g9os" } }, responsiveArray: void 0 }, display: { values: { none: { conditions: { small: "i77g9ow", medium: "i77g9ox", large: "i77g9oy", xlarge: "i77g9oz" }, defaultClass: "i77g9ow" }, flex: { conditions: { small: "i77g9o10", medium: "i77g9o11", large: "i77g9o12", xlarge: "i77g9o13" }, defaultClass: "i77g9o10" }, block: { conditions: { small: "i77g9o14", medium: "i77g9o15", large: "i77g9o16", xlarge: "i77g9o17" }, defaultClass: "i77g9o14" }, "inline-block": { conditions: { small: "i77g9o18", medium: "i77g9o19", large: "i77g9o1a", xlarge: "i77g9o1b" }, defaultClass: "i77g9o18" }, "inline-flex": { conditions: { small: "i77g9o1c", medium: "i77g9o1d", large: "i77g9o1e", xlarge: "i77g9o1f" }, defaultClass: "i77g9o1c" }, inline: { conditions: { small: "i77g9o1g", medium: "i77g9o1h", large: "i77g9o1i", xlarge: "i77g9o1j" }, defaultClass: "i77g9o1g" } }, responsiveArray: void 0 }, flex: { values: { 1: { conditions: { small: "i77g9o1k", medium: "i77g9o1l", large: "i77g9o1m", xlarge: "i77g9o1n" }, defaultClass: "i77g9o1k" }, auto: { conditions: { small: "i77g9o1o", medium: "i77g9o1p", large: "i77g9o1q", xlarge: "i77g9o1r" }, defaultClass: "i77g9o1o" }, initial: { conditions: { small: "i77g9o1s", medium: "i77g9o1t", large: "i77g9o1u", xlarge: "i77g9o1v" }, defaultClass: "i77g9o1s" }, none: { conditions: { small: "i77g9o1w", medium: "i77g9o1x", large: "i77g9o1y", xlarge: "i77g9o1z" }, defaultClass: "i77g9o1w" } }, responsiveArray: void 0 }, flexDirection: { values: { row: { conditions: { small: "i77g9o20", medium: "i77g9o21", large: "i77g9o22", xlarge: "i77g9o23" }, defaultClass: "i77g9o20" }, column: { conditions: { small: "i77g9o24", medium: "i77g9o25", large: "i77g9o26", xlarge: "i77g9o27" }, defaultClass: "i77g9o24" }, "row-reverse": { conditions: { small: "i77g9o28", medium: "i77g9o29", large: "i77g9o2a", xlarge: "i77g9o2b" }, defaultClass: "i77g9o28" }, "column-reverse": { conditions: { small: "i77g9o2c", medium: "i77g9o2d", large: "i77g9o2e", xlarge: "i77g9o2f" }, defaultClass: "i77g9o2c" } }, responsiveArray: void 0 }, flexWrap: { values: { nowrap: { conditions: { small: "i77g9o2g", medium: "i77g9o2h", large: "i77g9o2i", xlarge: "i77g9o2j" }, defaultClass: "i77g9o2g" }, wrap: { conditions: { small: "i77g9o2k", medium: "i77g9o2l", large: "i77g9o2m", xlarge: "i77g9o2n" }, defaultClass: "i77g9o2k" }, "wrap-reverse": { conditions: { small: "i77g9o2o", medium: "i77g9o2p", large: "i77g9o2q", xlarge: "i77g9o2r" }, defaultClass: "i77g9o2o" } }, responsiveArray: void 0 }, justifyContent: { values: { "flex-start": { conditions: { small: "i77g9o2s", medium: "i77g9o2t", large: "i77g9o2u", xlarge: "i77g9o2v" }, defaultClass: "i77g9o2s" }, center: { conditions: { small: "i77g9o2w", medium: "i77g9o2x", large: "i77g9o2y", xlarge: "i77g9o2z" }, defaultClass: "i77g9o2w" }, "flex-end": { conditions: { small: "i77g9o30", medium: "i77g9o31", large: "i77g9o32", xlarge: "i77g9o33" }, defaultClass: "i77g9o30" }, stretch: { conditions: { small: "i77g9o34", medium: "i77g9o35", large: "i77g9o36", xlarge: "i77g9o37" }, defaultClass: "i77g9o34" }, "space-between": { conditions: { small: "i77g9o38", medium: "i77g9o39", large: "i77g9o3a", xlarge: "i77g9o3b" }, defaultClass: "i77g9o38" }, "space-around": { conditions: { small: "i77g9o3c", medium: "i77g9o3d", large: "i77g9o3e", xlarge: "i77g9o3f" }, defaultClass: "i77g9o3c" } }, responsiveArray: void 0 }, alignItems: { values: { "flex-start": { conditions: { small: "i77g9o3g", medium: "i77g9o3h", large: "i77g9o3i", xlarge: "i77g9o3j" }, defaultClass: "i77g9o3g" }, center: { conditions: { small: "i77g9o3k", medium: "i77g9o3l", large: "i77g9o3m", xlarge: "i77g9o3n" }, defaultClass: "i77g9o3k" }, "flex-end": { conditions: { small: "i77g9o3o", medium: "i77g9o3p", large: "i77g9o3q", xlarge: "i77g9o3r" }, defaultClass: "i77g9o3o" }, stretch: { conditions: { small: "i77g9o3s", medium: "i77g9o3t", large: "i77g9o3u", xlarge: "i77g9o3v" }, defaultClass: "i77g9o3s" }, baseline: { conditions: { small: "i77g9o3w", medium: "i77g9o3x", large: "i77g9o3y", xlarge: "i77g9o3z" }, defaultClass: "i77g9o3w" } }, responsiveArray: void 0 }, alignContent: { values: { "flex-start": { conditions: { small: "i77g9o40", medium: "i77g9o41", large: "i77g9o42", xlarge: "i77g9o43" }, defaultClass: "i77g9o40" }, center: { conditions: { small: "i77g9o44", medium: "i77g9o45", large: "i77g9o46", xlarge: "i77g9o47" }, defaultClass: "i77g9o44" }, "flex-end": { conditions: { small: "i77g9o48", medium: "i77g9o49", large: "i77g9o4a", xlarge: "i77g9o4b" }, defaultClass: "i77g9o48" }, stretch: { conditions: { small: "i77g9o4c", medium: "i77g9o4d", large: "i77g9o4e", xlarge: "i77g9o4f" }, defaultClass: "i77g9o4c" } }, responsiveArray: void 0 }, verticalAlign: { values: { top: { conditions: { small: "i77g9o4g", medium: "i77g9o4h", large: "i77g9o4i", xlarge: "i77g9o4j" }, defaultClass: "i77g9o4g" }, middle: { conditions: { small: "i77g9o4k", medium: "i77g9o4l", large: "i77g9o4m", xlarge: "i77g9o4n" }, defaultClass: "i77g9o4k" }, bottom: { conditions: { small: "i77g9o4o", medium: "i77g9o4p", large: "i77g9o4q", xlarge: "i77g9o4r" }, defaultClass: "i77g9o4o" }, baseline: { conditions: { small: "i77g9o4s", medium: "i77g9o4t", large: "i77g9o4u", xlarge: "i77g9o4v" }, defaultClass: "i77g9o4s" }, "text-top": { conditions: { small: "i77g9o4w", medium: "i77g9o4x", large: "i77g9o4y", xlarge: "i77g9o4z" }, defaultClass: "i77g9o4w" }, "text-bottom": { conditions: { small: "i77g9o50", medium: "i77g9o51", large: "i77g9o52", xlarge: "i77g9o53" }, defaultClass: "i77g9o50" } }, responsiveArray: void 0 }, position: { values: { initial: { conditions: { small: "i77g9o54", medium: "i77g9o55", large: "i77g9o56", xlarge: "i77g9o57" }, defaultClass: "i77g9o54" }, inherit: { conditions: { small: "i77g9o58", medium: "i77g9o59", large: "i77g9o5a", xlarge: "i77g9o5b" }, defaultClass: "i77g9o58" }, unset: { conditions: { small: "i77g9o5c", medium: "i77g9o5d", large: "i77g9o5e", xlarge: "i77g9o5f" }, defaultClass: "i77g9o5c" }, relative: { conditions: { small: "i77g9o5g", medium: "i77g9o5h", large: "i77g9o5i", xlarge: "i77g9o5j" }, defaultClass: "i77g9o5g" }, absolute: { conditions: { small: "i77g9o5k", medium: "i77g9o5l", large: "i77g9o5m", xlarge: "i77g9o5n" }, defaultClass: "i77g9o5k" }, fixed: { conditions: { small: "i77g9o5o", medium: "i77g9o5p", large: "i77g9o5q", xlarge: "i77g9o5r" }, defaultClass: "i77g9o5o" }, sticky: { conditions: { small: "i77g9o5s", medium: "i77g9o5t", large: "i77g9o5u", xlarge: "i77g9o5v" }, defaultClass: "i77g9o5s" } }, responsiveArray: void 0 }, margin: { values: { 0: { conditions: { small: "i77g9o68", medium: "i77g9o69", large: "i77g9o6a", xlarge: "i77g9o6b" }, defaultClass: "i77g9o68" }, initial: { conditions: { small: "i77g9o5w", medium: "i77g9o5x", large: "i77g9o5y", xlarge: "i77g9o5z" }, defaultClass: "i77g9o5w" }, inherit: { conditions: { small: "i77g9o60", medium: "i77g9o61", large: "i77g9o62", xlarge: "i77g9o63" }, defaultClass: "i77g9o60" }, unset: { conditions: { small: "i77g9o64", medium: "i77g9o65", large: "i77g9o66", xlarge: "i77g9o67" }, defaultClass: "i77g9o64" }, auto: { conditions: { small: "i77g9o6c", medium: "i77g9o6d", large: "i77g9o6e", xlarge: "i77g9o6f" }, defaultClass: "i77g9o6c" }, none: { conditions: { small: "i77g9o6g", medium: "i77g9o6h", large: "i77g9o6i", xlarge: "i77g9o6j" }, defaultClass: "i77g9o6g" } }, responsiveArray: void 0 }, padding: { values: { 0: { conditions: { small: "i77g9o6w", medium: "i77g9o6x", large: "i77g9o6y", xlarge: "i77g9o6z" }, defaultClass: "i77g9o6w" }, initial: { conditions: { small: "i77g9o6k", medium: "i77g9o6l", large: "i77g9o6m", xlarge: "i77g9o6n" }, defaultClass: "i77g9o6k" }, inherit: { conditions: { small: "i77g9o6o", medium: "i77g9o6p", large: "i77g9o6q", xlarge: "i77g9o6r" }, defaultClass: "i77g9o6o" }, unset: { conditions: { small: "i77g9o6s", medium: "i77g9o6t", large: "i77g9o6u", xlarge: "i77g9o6v" }, defaultClass: "i77g9o6s" }, none: { conditions: { small: "i77g9o70", medium: "i77g9o71", large: "i77g9o72", xlarge: "i77g9o73" }, defaultClass: "i77g9o70" }, auto: { conditions: { small: "i77g9o74", medium: "i77g9o75", large: "i77g9o76", xlarge: "i77g9o77" }, defaultClass: "i77g9o74" }, "4px": { conditions: { small: "i77g9o78", medium: "i77g9o79", large: "i77g9o7a", xlarge: "i77g9o7b" }, defaultClass: "i77g9o78" }, "8px": { conditions: { small: "i77g9o7c", medium: "i77g9o7d", large: "i77g9o7e", xlarge: "i77g9o7f" }, defaultClass: "i77g9o7c" }, "10px": { conditions: { small: "i77g9o7g", medium: "i77g9o7h", large: "i77g9o7i", xlarge: "i77g9o7j" }, defaultClass: "i77g9o7g" }, "12px": { conditions: { small: "i77g9o7k", medium: "i77g9o7l", large: "i77g9o7m", xlarge: "i77g9o7n" }, defaultClass: "i77g9o7k" }, "16px": { conditions: { small: "i77g9o7o", medium: "i77g9o7p", large: "i77g9o7q", xlarge: "i77g9o7r" }, defaultClass: "i77g9o7o" }, "20px": { conditions: { small: "i77g9o7s", medium: "i77g9o7t", large: "i77g9o7u", xlarge: "i77g9o7v" }, defaultClass: "i77g9o7s" } }, responsiveArray: void 0 }, width: { values: { auto: { conditions: { small: "i77g9o7w", medium: "i77g9o7x", large: "i77g9o7y", xlarge: "i77g9o7z" }, defaultClass: "i77g9o7w" }, "100%": { conditions: { small: "i77g9o80", medium: "i77g9o81", large: "i77g9o82", xlarge: "i77g9o83" }, defaultClass: "i77g9o80" } }, responsiveArray: void 0 }, height: { values: { auto: { conditions: { small: "i77g9o84", medium: "i77g9o85", large: "i77g9o86", xlarge: "i77g9o87" }, defaultClass: "i77g9o84" }, "100%": { conditions: { small: "i77g9o88", medium: "i77g9o89", large: "i77g9o8a", xlarge: "i77g9o8b" }, defaultClass: "i77g9o88" } }, responsiveArray: void 0 }, gap: { values: { 0: { conditions: { small: "i77g9o8c", medium: "i77g9o8d", large: "i77g9o8e", xlarge: "i77g9o8f" }, defaultClass: "i77g9o8c" }, "4px 4px": { conditions: { small: "i77g9o8g", medium: "i77g9o8h", large: "i77g9o8i", xlarge: "i77g9o8j" }, defaultClass: "i77g9o8g" }, "8px 8px": { conditions: { small: "i77g9o8k", medium: "i77g9o8l", large: "i77g9o8m", xlarge: "i77g9o8n" }, defaultClass: "i77g9o8k" }, "10px 10px": { conditions: { small: "i77g9o8o", medium: "i77g9o8p", large: "i77g9o8q", xlarge: "i77g9o8r" }, defaultClass: "i77g9o8o" }, "12px 12px": { conditions: { small: "i77g9o8s", medium: "i77g9o8t", large: "i77g9o8u", xlarge: "i77g9o8v" }, defaultClass: "i77g9o8s" }, "16px 16px": { conditions: { small: "i77g9o8w", medium: "i77g9o8x", large: "i77g9o8y", xlarge: "i77g9o8z" }, defaultClass: "i77g9o8w" }, "20px 20px": { conditions: { small: "i77g9o90", medium: "i77g9o91", large: "i77g9o92", xlarge: "i77g9o93" }, defaultClass: "i77g9o90" } }, responsiveArray: void 0 }, mixBlendMode: { values: { initial: { conditions: { small: "i77g9o94", medium: "i77g9o95", large: "i77g9o96", xlarge: "i77g9o97" }, defaultClass: "i77g9o94" }, inherit: { conditions: { small: "i77g9o98", medium: "i77g9o99", large: "i77g9o9a", xlarge: "i77g9o9b" }, defaultClass: "i77g9o98" }, unset: { conditions: { small: "i77g9o9c", medium: "i77g9o9d", large: "i77g9o9e", xlarge: "i77g9o9f" }, defaultClass: "i77g9o9c" }, difference: { conditions: { small: "i77g9o9g", medium: "i77g9o9h", large: "i77g9o9i", xlarge: "i77g9o9j" }, defaultClass: "i77g9o9g" }, multiply: { conditions: { small: "i77g9o9k", medium: "i77g9o9l", large: "i77g9o9m", xlarge: "i77g9o9n" }, defaultClass: "i77g9o9k" }, screen: { conditions: { small: "i77g9o9o", medium: "i77g9o9p", large: "i77g9o9q", xlarge: "i77g9o9r" }, defaultClass: "i77g9o9o" }, overlay: { conditions: { small: "i77g9o9s", medium: "i77g9o9t", large: "i77g9o9u", xlarge: "i77g9o9v" }, defaultClass: "i77g9o9s" } }, responsiveArray: void 0 } } };
  return e.styles.all.responsiveArray = e.conditions.responsiveArray, e.styles.boxSizing.responsiveArray = e.conditions.responsiveArray, e.styles.appearance.responsiveArray = e.conditions.responsiveArray, e.styles.outline.responsiveArray = e.conditions.responsiveArray, e.styles.userSelect.responsiveArray = e.conditions.responsiveArray, e.styles.fontVariantNumeric.responsiveArray = e.conditions.responsiveArray, e.styles.WebkitTapHighlightColor.responsiveArray = e.conditions.responsiveArray, e.styles.display.responsiveArray = e.conditions.responsiveArray, e.styles.flex.responsiveArray = e.conditions.responsiveArray, e.styles.flexDirection.responsiveArray = e.conditions.responsiveArray, e.styles.flexWrap.responsiveArray = e.conditions.responsiveArray, e.styles.justifyContent.responsiveArray = e.conditions.responsiveArray, e.styles.alignItems.responsiveArray = e.conditions.responsiveArray, e.styles.alignContent.responsiveArray = e.conditions.responsiveArray, e.styles.verticalAlign.responsiveArray = e.conditions.responsiveArray, e.styles.position.responsiveArray = e.conditions.responsiveArray, e.styles.margin.responsiveArray = e.conditions.responsiveArray, e.styles.padding.responsiveArray = e.conditions.responsiveArray, e.styles.width.responsiveArray = e.conditions.responsiveArray, e.styles.height.responsiveArray = e.conditions.responsiveArray, e.styles.gap.responsiveArray = e.conditions.responsiveArray, e.styles.mixBlendMode.responsiveArray = e.conditions.responsiveArray, e;
}(), { conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 }, styles: { color: { values: { transparent: { conditions: { light: "i77g9o9w", dark: "i77g9o9x" }, defaultClass: "i77g9o9w" }, current: { conditions: { light: "i77g9o9y", dark: "i77g9o9z" }, defaultClass: "i77g9o9y" }, white: { conditions: { light: "i77g9oa0", dark: "i77g9oa1" }, defaultClass: "i77g9oa0" }, black: { conditions: { light: "i77g9oa2", dark: "i77g9oa3" }, defaultClass: "i77g9oa2" }, gray100: { conditions: { light: "i77g9oa4", dark: "i77g9oa5" }, defaultClass: "i77g9oa4" }, gray200: { conditions: { light: "i77g9oa6", dark: "i77g9oa7" }, defaultClass: "i77g9oa6" }, gray300: { conditions: { light: "i77g9oa8", dark: "i77g9oa9" }, defaultClass: "i77g9oa8" }, pale100: { conditions: { light: "i77g9oaa", dark: "i77g9oab" }, defaultClass: "i77g9oaa" }, pale200: { conditions: { light: "i77g9oac", dark: "i77g9oad" }, defaultClass: "i77g9oac" }, pale300: { conditions: { light: "i77g9oae", dark: "i77g9oaf" }, defaultClass: "i77g9oae" }, pale400: { conditions: { light: "i77g9oag", dark: "i77g9oah" }, defaultClass: "i77g9oag" }, pale500: { conditions: { light: "i77g9oai", dark: "i77g9oaj" }, defaultClass: "i77g9oai" }, hyper0: { conditions: { light: "i77g9oak", dark: "i77g9oal" }, defaultClass: "i77g9oak" }, hyper1: { conditions: { light: "i77g9oam", dark: "i77g9oan" }, defaultClass: "i77g9oam" }, hyper2: { conditions: { light: "i77g9oao", dark: "i77g9oap" }, defaultClass: "i77g9oao" }, hyper3: { conditions: { light: "i77g9oaq", dark: "i77g9oar" }, defaultClass: "i77g9oaq" }, hyper4: { conditions: { light: "i77g9oas", dark: "i77g9oat" }, defaultClass: "i77g9oas" }, hyper5: { conditions: { light: "i77g9oau", dark: "i77g9oav" }, defaultClass: "i77g9oau" }, hyper6: { conditions: { light: "i77g9oaw", dark: "i77g9oax" }, defaultClass: "i77g9oaw" }, hyper7: { conditions: { light: "i77g9oay", dark: "i77g9oaz" }, defaultClass: "i77g9oay" }, hyper8: { conditions: { light: "i77g9ob0", dark: "i77g9ob1" }, defaultClass: "i77g9ob0" }, hyper9: { conditions: { light: "i77g9ob2", dark: "i77g9ob3" }, defaultClass: "i77g9ob2" }, hyper10: { conditions: { light: "i77g9ob4", dark: "i77g9ob5" }, defaultClass: "i77g9ob4" }, hyper11: { conditions: { light: "i77g9ob6", dark: "i77g9ob7" }, defaultClass: "i77g9ob6" }, hyper12: { conditions: { light: "i77g9ob8", dark: "i77g9ob9" }, defaultClass: "i77g9ob8" }, hyper13: { conditions: { light: "i77g9oba", dark: "i77g9obb" }, defaultClass: "i77g9oba" }, lemon0: { conditions: { light: "i77g9obc", dark: "i77g9obd" }, defaultClass: "i77g9obc" }, lemon1: { conditions: { light: "i77g9obe", dark: "i77g9obf" }, defaultClass: "i77g9obe" }, lemon2: { conditions: { light: "i77g9obg", dark: "i77g9obh" }, defaultClass: "i77g9obg" }, lemon3: { conditions: { light: "i77g9obi", dark: "i77g9obj" }, defaultClass: "i77g9obi" }, lemon4: { conditions: { light: "i77g9obk", dark: "i77g9obl" }, defaultClass: "i77g9obk" }, lemon5: { conditions: { light: "i77g9obm", dark: "i77g9obn" }, defaultClass: "i77g9obm" }, lemon6: { conditions: { light: "i77g9obo", dark: "i77g9obp" }, defaultClass: "i77g9obo" }, lemon7: { conditions: { light: "i77g9obq", dark: "i77g9obr" }, defaultClass: "i77g9obq" }, lemon8: { conditions: { light: "i77g9obs", dark: "i77g9obt" }, defaultClass: "i77g9obs" }, lemon9: { conditions: { light: "i77g9obu", dark: "i77g9obv" }, defaultClass: "i77g9obu" }, lemon10: { conditions: { light: "i77g9obw", dark: "i77g9obx" }, defaultClass: "i77g9obw" }, lemon11: { conditions: { light: "i77g9oby", dark: "i77g9obz" }, defaultClass: "i77g9oby" }, lemon12: { conditions: { light: "i77g9oc0", dark: "i77g9oc1" }, defaultClass: "i77g9oc0" }, lemon13: { conditions: { light: "i77g9oc2", dark: "i77g9oc3" }, defaultClass: "i77g9oc2" }, slate1: { conditions: { light: "i77g9oc4", dark: "i77g9oc5" }, defaultClass: "i77g9oc4" }, slate2: { conditions: { light: "i77g9oc6", dark: "i77g9oc7" }, defaultClass: "i77g9oc6" }, slate3: { conditions: { light: "i77g9oc8", dark: "i77g9oc9" }, defaultClass: "i77g9oc8" }, slate4: { conditions: { light: "i77g9oca", dark: "i77g9ocb" }, defaultClass: "i77g9oca" }, slate5: { conditions: { light: "i77g9occ", dark: "i77g9ocd" }, defaultClass: "i77g9occ" }, slate6: { conditions: { light: "i77g9oce", dark: "i77g9ocf" }, defaultClass: "i77g9oce" }, slate7: { conditions: { light: "i77g9ocg", dark: "i77g9och" }, defaultClass: "i77g9ocg" }, slate8: { conditions: { light: "i77g9oci", dark: "i77g9ocj" }, defaultClass: "i77g9oci" }, slate9: { conditions: { light: "i77g9ock", dark: "i77g9ocl" }, defaultClass: "i77g9ock" }, slate10: { conditions: { light: "i77g9ocm", dark: "i77g9ocn" }, defaultClass: "i77g9ocm" }, slate11: { conditions: { light: "i77g9oco", dark: "i77g9ocp" }, defaultClass: "i77g9oco" }, slate12: { conditions: { light: "i77g9ocq", dark: "i77g9ocr" }, defaultClass: "i77g9ocq" }, slate13: { conditions: { light: "i77g9ocs", dark: "i77g9oct" }, defaultClass: "i77g9ocs" }, sapphire0: { conditions: { light: "i77g9ocu", dark: "i77g9ocv" }, defaultClass: "i77g9ocu" }, sapphire1: { conditions: { light: "i77g9ocw", dark: "i77g9ocx" }, defaultClass: "i77g9ocw" }, sapphire2: { conditions: { light: "i77g9ocy", dark: "i77g9ocz" }, defaultClass: "i77g9ocy" }, sapphire3: { conditions: { light: "i77g9od0", dark: "i77g9od1" }, defaultClass: "i77g9od0" }, sapphire4: { conditions: { light: "i77g9od2", dark: "i77g9od3" }, defaultClass: "i77g9od2" }, sapphire5: { conditions: { light: "i77g9od4", dark: "i77g9od5" }, defaultClass: "i77g9od4" }, sapphire6: { conditions: { light: "i77g9od6", dark: "i77g9od7" }, defaultClass: "i77g9od6" }, sapphire7: { conditions: { light: "i77g9od8", dark: "i77g9od9" }, defaultClass: "i77g9od8" }, sapphire8: { conditions: { light: "i77g9oda", dark: "i77g9odb" }, defaultClass: "i77g9oda" }, sapphire9: { conditions: { light: "i77g9odc", dark: "i77g9odd" }, defaultClass: "i77g9odc" }, sapphire10: { conditions: { light: "i77g9ode", dark: "i77g9odf" }, defaultClass: "i77g9ode" }, sapphire11: { conditions: { light: "i77g9odg", dark: "i77g9odh" }, defaultClass: "i77g9odg" }, sapphire12: { conditions: { light: "i77g9odi", dark: "i77g9odj" }, defaultClass: "i77g9odi" }, sapphire13: { conditions: { light: "i77g9odk", dark: "i77g9odl" }, defaultClass: "i77g9odk" }, volt0: { conditions: { light: "i77g9odm", dark: "i77g9odn" }, defaultClass: "i77g9odm" }, volt1: { conditions: { light: "i77g9odo", dark: "i77g9odp" }, defaultClass: "i77g9odo" }, volt2: { conditions: { light: "i77g9odq", dark: "i77g9odr" }, defaultClass: "i77g9odq" }, volt3: { conditions: { light: "i77g9ods", dark: "i77g9odt" }, defaultClass: "i77g9ods" }, volt4: { conditions: { light: "i77g9odu", dark: "i77g9odv" }, defaultClass: "i77g9odu" }, volt5: { conditions: { light: "i77g9odw", dark: "i77g9odx" }, defaultClass: "i77g9odw" }, volt6: { conditions: { light: "i77g9ody", dark: "i77g9odz" }, defaultClass: "i77g9ody" }, volt7: { conditions: { light: "i77g9oe0", dark: "i77g9oe1" }, defaultClass: "i77g9oe0" }, volt8: { conditions: { light: "i77g9oe2", dark: "i77g9oe3" }, defaultClass: "i77g9oe2" }, volt9: { conditions: { light: "i77g9oe4", dark: "i77g9oe5" }, defaultClass: "i77g9oe4" }, volt10: { conditions: { light: "i77g9oe6", dark: "i77g9oe7" }, defaultClass: "i77g9oe6" }, volt11: { conditions: { light: "i77g9oe8", dark: "i77g9oe9" }, defaultClass: "i77g9oe8" }, volt12: { conditions: { light: "i77g9oea", dark: "i77g9oeb" }, defaultClass: "i77g9oea" }, volt13: { conditions: { light: "i77g9oec", dark: "i77g9oed" }, defaultClass: "i77g9oec" } } }, backgroundColor: { values: { transparent: { conditions: { light: "i77g9oee", dark: "i77g9oef" }, defaultClass: "i77g9oee" }, current: { conditions: { light: "i77g9oeg", dark: "i77g9oeh" }, defaultClass: "i77g9oeg" }, white: { conditions: { light: "i77g9oei", dark: "i77g9oej" }, defaultClass: "i77g9oei" }, black: { conditions: { light: "i77g9oek", dark: "i77g9oel" }, defaultClass: "i77g9oek" }, gray100: { conditions: { light: "i77g9oem", dark: "i77g9oen" }, defaultClass: "i77g9oem" }, gray200: { conditions: { light: "i77g9oeo", dark: "i77g9oep" }, defaultClass: "i77g9oeo" }, gray300: { conditions: { light: "i77g9oeq", dark: "i77g9oer" }, defaultClass: "i77g9oeq" }, pale100: { conditions: { light: "i77g9oes", dark: "i77g9oet" }, defaultClass: "i77g9oes" }, pale200: { conditions: { light: "i77g9oeu", dark: "i77g9oev" }, defaultClass: "i77g9oeu" }, pale300: { conditions: { light: "i77g9oew", dark: "i77g9oex" }, defaultClass: "i77g9oew" }, pale400: { conditions: { light: "i77g9oey", dark: "i77g9oez" }, defaultClass: "i77g9oey" }, pale500: { conditions: { light: "i77g9of0", dark: "i77g9of1" }, defaultClass: "i77g9of0" }, hyper0: { conditions: { light: "i77g9of2", dark: "i77g9of3" }, defaultClass: "i77g9of2" }, hyper1: { conditions: { light: "i77g9of4", dark: "i77g9of5" }, defaultClass: "i77g9of4" }, hyper2: { conditions: { light: "i77g9of6", dark: "i77g9of7" }, defaultClass: "i77g9of6" }, hyper3: { conditions: { light: "i77g9of8", dark: "i77g9of9" }, defaultClass: "i77g9of8" }, hyper4: { conditions: { light: "i77g9ofa", dark: "i77g9ofb" }, defaultClass: "i77g9ofa" }, hyper5: { conditions: { light: "i77g9ofc", dark: "i77g9ofd" }, defaultClass: "i77g9ofc" }, hyper6: { conditions: { light: "i77g9ofe", dark: "i77g9off" }, defaultClass: "i77g9ofe" }, hyper7: { conditions: { light: "i77g9ofg", dark: "i77g9ofh" }, defaultClass: "i77g9ofg" }, hyper8: { conditions: { light: "i77g9ofi", dark: "i77g9ofj" }, defaultClass: "i77g9ofi" }, hyper9: { conditions: { light: "i77g9ofk", dark: "i77g9ofl" }, defaultClass: "i77g9ofk" }, hyper10: { conditions: { light: "i77g9ofm", dark: "i77g9ofn" }, defaultClass: "i77g9ofm" }, hyper11: { conditions: { light: "i77g9ofo", dark: "i77g9ofp" }, defaultClass: "i77g9ofo" }, hyper12: { conditions: { light: "i77g9ofq", dark: "i77g9ofr" }, defaultClass: "i77g9ofq" }, hyper13: { conditions: { light: "i77g9ofs", dark: "i77g9oft" }, defaultClass: "i77g9ofs" }, lemon0: { conditions: { light: "i77g9ofu", dark: "i77g9ofv" }, defaultClass: "i77g9ofu" }, lemon1: { conditions: { light: "i77g9ofw", dark: "i77g9ofx" }, defaultClass: "i77g9ofw" }, lemon2: { conditions: { light: "i77g9ofy", dark: "i77g9ofz" }, defaultClass: "i77g9ofy" }, lemon3: { conditions: { light: "i77g9og0", dark: "i77g9og1" }, defaultClass: "i77g9og0" }, lemon4: { conditions: { light: "i77g9og2", dark: "i77g9og3" }, defaultClass: "i77g9og2" }, lemon5: { conditions: { light: "i77g9og4", dark: "i77g9og5" }, defaultClass: "i77g9og4" }, lemon6: { conditions: { light: "i77g9og6", dark: "i77g9og7" }, defaultClass: "i77g9og6" }, lemon7: { conditions: { light: "i77g9og8", dark: "i77g9og9" }, defaultClass: "i77g9og8" }, lemon8: { conditions: { light: "i77g9oga", dark: "i77g9ogb" }, defaultClass: "i77g9oga" }, lemon9: { conditions: { light: "i77g9ogc", dark: "i77g9ogd" }, defaultClass: "i77g9ogc" }, lemon10: { conditions: { light: "i77g9oge", dark: "i77g9ogf" }, defaultClass: "i77g9oge" }, lemon11: { conditions: { light: "i77g9ogg", dark: "i77g9ogh" }, defaultClass: "i77g9ogg" }, lemon12: { conditions: { light: "i77g9ogi", dark: "i77g9ogj" }, defaultClass: "i77g9ogi" }, lemon13: { conditions: { light: "i77g9ogk", dark: "i77g9ogl" }, defaultClass: "i77g9ogk" }, slate1: { conditions: { light: "i77g9ogm", dark: "i77g9ogn" }, defaultClass: "i77g9ogm" }, slate2: { conditions: { light: "i77g9ogo", dark: "i77g9ogp" }, defaultClass: "i77g9ogo" }, slate3: { conditions: { light: "i77g9ogq", dark: "i77g9ogr" }, defaultClass: "i77g9ogq" }, slate4: { conditions: { light: "i77g9ogs", dark: "i77g9ogt" }, defaultClass: "i77g9ogs" }, slate5: { conditions: { light: "i77g9ogu", dark: "i77g9ogv" }, defaultClass: "i77g9ogu" }, slate6: { conditions: { light: "i77g9ogw", dark: "i77g9ogx" }, defaultClass: "i77g9ogw" }, slate7: { conditions: { light: "i77g9ogy", dark: "i77g9ogz" }, defaultClass: "i77g9ogy" }, slate8: { conditions: { light: "i77g9oh0", dark: "i77g9oh1" }, defaultClass: "i77g9oh0" }, slate9: { conditions: { light: "i77g9oh2", dark: "i77g9oh3" }, defaultClass: "i77g9oh2" }, slate10: { conditions: { light: "i77g9oh4", dark: "i77g9oh5" }, defaultClass: "i77g9oh4" }, slate11: { conditions: { light: "i77g9oh6", dark: "i77g9oh7" }, defaultClass: "i77g9oh6" }, slate12: { conditions: { light: "i77g9oh8", dark: "i77g9oh9" }, defaultClass: "i77g9oh8" }, slate13: { conditions: { light: "i77g9oha", dark: "i77g9ohb" }, defaultClass: "i77g9oha" }, sapphire0: { conditions: { light: "i77g9ohc", dark: "i77g9ohd" }, defaultClass: "i77g9ohc" }, sapphire1: { conditions: { light: "i77g9ohe", dark: "i77g9ohf" }, defaultClass: "i77g9ohe" }, sapphire2: { conditions: { light: "i77g9ohg", dark: "i77g9ohh" }, defaultClass: "i77g9ohg" }, sapphire3: { conditions: { light: "i77g9ohi", dark: "i77g9ohj" }, defaultClass: "i77g9ohi" }, sapphire4: { conditions: { light: "i77g9ohk", dark: "i77g9ohl" }, defaultClass: "i77g9ohk" }, sapphire5: { conditions: { light: "i77g9ohm", dark: "i77g9ohn" }, defaultClass: "i77g9ohm" }, sapphire6: { conditions: { light: "i77g9oho", dark: "i77g9ohp" }, defaultClass: "i77g9oho" }, sapphire7: { conditions: { light: "i77g9ohq", dark: "i77g9ohr" }, defaultClass: "i77g9ohq" }, sapphire8: { conditions: { light: "i77g9ohs", dark: "i77g9oht" }, defaultClass: "i77g9ohs" }, sapphire9: { conditions: { light: "i77g9ohu", dark: "i77g9ohv" }, defaultClass: "i77g9ohu" }, sapphire10: { conditions: { light: "i77g9ohw", dark: "i77g9ohx" }, defaultClass: "i77g9ohw" }, sapphire11: { conditions: { light: "i77g9ohy", dark: "i77g9ohz" }, defaultClass: "i77g9ohy" }, sapphire12: { conditions: { light: "i77g9oi0", dark: "i77g9oi1" }, defaultClass: "i77g9oi0" }, sapphire13: { conditions: { light: "i77g9oi2", dark: "i77g9oi3" }, defaultClass: "i77g9oi2" }, volt0: { conditions: { light: "i77g9oi4", dark: "i77g9oi5" }, defaultClass: "i77g9oi4" }, volt1: { conditions: { light: "i77g9oi6", dark: "i77g9oi7" }, defaultClass: "i77g9oi6" }, volt2: { conditions: { light: "i77g9oi8", dark: "i77g9oi9" }, defaultClass: "i77g9oi8" }, volt3: { conditions: { light: "i77g9oia", dark: "i77g9oib" }, defaultClass: "i77g9oia" }, volt4: { conditions: { light: "i77g9oic", dark: "i77g9oid" }, defaultClass: "i77g9oic" }, volt5: { conditions: { light: "i77g9oie", dark: "i77g9oif" }, defaultClass: "i77g9oie" }, volt6: { conditions: { light: "i77g9oig", dark: "i77g9oih" }, defaultClass: "i77g9oig" }, volt7: { conditions: { light: "i77g9oii", dark: "i77g9oij" }, defaultClass: "i77g9oii" }, volt8: { conditions: { light: "i77g9oik", dark: "i77g9oil" }, defaultClass: "i77g9oik" }, volt9: { conditions: { light: "i77g9oim", dark: "i77g9oin" }, defaultClass: "i77g9oim" }, volt10: { conditions: { light: "i77g9oio", dark: "i77g9oip" }, defaultClass: "i77g9oio" }, volt11: { conditions: { light: "i77g9oiq", dark: "i77g9oir" }, defaultClass: "i77g9oiq" }, volt12: { conditions: { light: "i77g9ois", dark: "i77g9oit" }, defaultClass: "i77g9ois" }, volt13: { conditions: { light: "i77g9oiu", dark: "i77g9oiv" }, defaultClass: "i77g9oiu" } } }, borderColor: { values: { transparent: { conditions: { light: "i77g9oiw", dark: "i77g9oix" }, defaultClass: "i77g9oiw" }, current: { conditions: { light: "i77g9oiy", dark: "i77g9oiz" }, defaultClass: "i77g9oiy" }, white: { conditions: { light: "i77g9oj0", dark: "i77g9oj1" }, defaultClass: "i77g9oj0" }, black: { conditions: { light: "i77g9oj2", dark: "i77g9oj3" }, defaultClass: "i77g9oj2" }, gray100: { conditions: { light: "i77g9oj4", dark: "i77g9oj5" }, defaultClass: "i77g9oj4" }, gray200: { conditions: { light: "i77g9oj6", dark: "i77g9oj7" }, defaultClass: "i77g9oj6" }, gray300: { conditions: { light: "i77g9oj8", dark: "i77g9oj9" }, defaultClass: "i77g9oj8" }, pale100: { conditions: { light: "i77g9oja", dark: "i77g9ojb" }, defaultClass: "i77g9oja" }, pale200: { conditions: { light: "i77g9ojc", dark: "i77g9ojd" }, defaultClass: "i77g9ojc" }, pale300: { conditions: { light: "i77g9oje", dark: "i77g9ojf" }, defaultClass: "i77g9oje" }, pale400: { conditions: { light: "i77g9ojg", dark: "i77g9ojh" }, defaultClass: "i77g9ojg" }, pale500: { conditions: { light: "i77g9oji", dark: "i77g9ojj" }, defaultClass: "i77g9oji" }, hyper0: { conditions: { light: "i77g9ojk", dark: "i77g9ojl" }, defaultClass: "i77g9ojk" }, hyper1: { conditions: { light: "i77g9ojm", dark: "i77g9ojn" }, defaultClass: "i77g9ojm" }, hyper2: { conditions: { light: "i77g9ojo", dark: "i77g9ojp" }, defaultClass: "i77g9ojo" }, hyper3: { conditions: { light: "i77g9ojq", dark: "i77g9ojr" }, defaultClass: "i77g9ojq" }, hyper4: { conditions: { light: "i77g9ojs", dark: "i77g9ojt" }, defaultClass: "i77g9ojs" }, hyper5: { conditions: { light: "i77g9oju", dark: "i77g9ojv" }, defaultClass: "i77g9oju" }, hyper6: { conditions: { light: "i77g9ojw", dark: "i77g9ojx" }, defaultClass: "i77g9ojw" }, hyper7: { conditions: { light: "i77g9ojy", dark: "i77g9ojz" }, defaultClass: "i77g9ojy" }, hyper8: { conditions: { light: "i77g9ok0", dark: "i77g9ok1" }, defaultClass: "i77g9ok0" }, hyper9: { conditions: { light: "i77g9ok2", dark: "i77g9ok3" }, defaultClass: "i77g9ok2" }, hyper10: { conditions: { light: "i77g9ok4", dark: "i77g9ok5" }, defaultClass: "i77g9ok4" }, hyper11: { conditions: { light: "i77g9ok6", dark: "i77g9ok7" }, defaultClass: "i77g9ok6" }, hyper12: { conditions: { light: "i77g9ok8", dark: "i77g9ok9" }, defaultClass: "i77g9ok8" }, hyper13: { conditions: { light: "i77g9oka", dark: "i77g9okb" }, defaultClass: "i77g9oka" }, lemon0: { conditions: { light: "i77g9okc", dark: "i77g9okd" }, defaultClass: "i77g9okc" }, lemon1: { conditions: { light: "i77g9oke", dark: "i77g9okf" }, defaultClass: "i77g9oke" }, lemon2: { conditions: { light: "i77g9okg", dark: "i77g9okh" }, defaultClass: "i77g9okg" }, lemon3: { conditions: { light: "i77g9oki", dark: "i77g9okj" }, defaultClass: "i77g9oki" }, lemon4: { conditions: { light: "i77g9okk", dark: "i77g9okl" }, defaultClass: "i77g9okk" }, lemon5: { conditions: { light: "i77g9okm", dark: "i77g9okn" }, defaultClass: "i77g9okm" }, lemon6: { conditions: { light: "i77g9oko", dark: "i77g9okp" }, defaultClass: "i77g9oko" }, lemon7: { conditions: { light: "i77g9okq", dark: "i77g9okr" }, defaultClass: "i77g9okq" }, lemon8: { conditions: { light: "i77g9oks", dark: "i77g9okt" }, defaultClass: "i77g9oks" }, lemon9: { conditions: { light: "i77g9oku", dark: "i77g9okv" }, defaultClass: "i77g9oku" }, lemon10: { conditions: { light: "i77g9okw", dark: "i77g9okx" }, defaultClass: "i77g9okw" }, lemon11: { conditions: { light: "i77g9oky", dark: "i77g9okz" }, defaultClass: "i77g9oky" }, lemon12: { conditions: { light: "i77g9ol0", dark: "i77g9ol1" }, defaultClass: "i77g9ol0" }, lemon13: { conditions: { light: "i77g9ol2", dark: "i77g9ol3" }, defaultClass: "i77g9ol2" }, slate1: { conditions: { light: "i77g9ol4", dark: "i77g9ol5" }, defaultClass: "i77g9ol4" }, slate2: { conditions: { light: "i77g9ol6", dark: "i77g9ol7" }, defaultClass: "i77g9ol6" }, slate3: { conditions: { light: "i77g9ol8", dark: "i77g9ol9" }, defaultClass: "i77g9ol8" }, slate4: { conditions: { light: "i77g9ola", dark: "i77g9olb" }, defaultClass: "i77g9ola" }, slate5: { conditions: { light: "i77g9olc", dark: "i77g9old" }, defaultClass: "i77g9olc" }, slate6: { conditions: { light: "i77g9ole", dark: "i77g9olf" }, defaultClass: "i77g9ole" }, slate7: { conditions: { light: "i77g9olg", dark: "i77g9olh" }, defaultClass: "i77g9olg" }, slate8: { conditions: { light: "i77g9oli", dark: "i77g9olj" }, defaultClass: "i77g9oli" }, slate9: { conditions: { light: "i77g9olk", dark: "i77g9oll" }, defaultClass: "i77g9olk" }, slate10: { conditions: { light: "i77g9olm", dark: "i77g9oln" }, defaultClass: "i77g9olm" }, slate11: { conditions: { light: "i77g9olo", dark: "i77g9olp" }, defaultClass: "i77g9olo" }, slate12: { conditions: { light: "i77g9olq", dark: "i77g9olr" }, defaultClass: "i77g9olq" }, slate13: { conditions: { light: "i77g9ols", dark: "i77g9olt" }, defaultClass: "i77g9ols" }, sapphire0: { conditions: { light: "i77g9olu", dark: "i77g9olv" }, defaultClass: "i77g9olu" }, sapphire1: { conditions: { light: "i77g9olw", dark: "i77g9olx" }, defaultClass: "i77g9olw" }, sapphire2: { conditions: { light: "i77g9oly", dark: "i77g9olz" }, defaultClass: "i77g9oly" }, sapphire3: { conditions: { light: "i77g9om0", dark: "i77g9om1" }, defaultClass: "i77g9om0" }, sapphire4: { conditions: { light: "i77g9om2", dark: "i77g9om3" }, defaultClass: "i77g9om2" }, sapphire5: { conditions: { light: "i77g9om4", dark: "i77g9om5" }, defaultClass: "i77g9om4" }, sapphire6: { conditions: { light: "i77g9om6", dark: "i77g9om7" }, defaultClass: "i77g9om6" }, sapphire7: { conditions: { light: "i77g9om8", dark: "i77g9om9" }, defaultClass: "i77g9om8" }, sapphire8: { conditions: { light: "i77g9oma", dark: "i77g9omb" }, defaultClass: "i77g9oma" }, sapphire9: { conditions: { light: "i77g9omc", dark: "i77g9omd" }, defaultClass: "i77g9omc" }, sapphire10: { conditions: { light: "i77g9ome", dark: "i77g9omf" }, defaultClass: "i77g9ome" }, sapphire11: { conditions: { light: "i77g9omg", dark: "i77g9omh" }, defaultClass: "i77g9omg" }, sapphire12: { conditions: { light: "i77g9omi", dark: "i77g9omj" }, defaultClass: "i77g9omi" }, sapphire13: { conditions: { light: "i77g9omk", dark: "i77g9oml" }, defaultClass: "i77g9omk" }, volt0: { conditions: { light: "i77g9omm", dark: "i77g9omn" }, defaultClass: "i77g9omm" }, volt1: { conditions: { light: "i77g9omo", dark: "i77g9omp" }, defaultClass: "i77g9omo" }, volt2: { conditions: { light: "i77g9omq", dark: "i77g9omr" }, defaultClass: "i77g9omq" }, volt3: { conditions: { light: "i77g9oms", dark: "i77g9omt" }, defaultClass: "i77g9oms" }, volt4: { conditions: { light: "i77g9omu", dark: "i77g9omv" }, defaultClass: "i77g9omu" }, volt5: { conditions: { light: "i77g9omw", dark: "i77g9omx" }, defaultClass: "i77g9omw" }, volt6: { conditions: { light: "i77g9omy", dark: "i77g9omz" }, defaultClass: "i77g9omy" }, volt7: { conditions: { light: "i77g9on0", dark: "i77g9on1" }, defaultClass: "i77g9on0" }, volt8: { conditions: { light: "i77g9on2", dark: "i77g9on3" }, defaultClass: "i77g9on2" }, volt9: { conditions: { light: "i77g9on4", dark: "i77g9on5" }, defaultClass: "i77g9on4" }, volt10: { conditions: { light: "i77g9on6", dark: "i77g9on7" }, defaultClass: "i77g9on6" }, volt11: { conditions: { light: "i77g9on8", dark: "i77g9on9" }, defaultClass: "i77g9on8" }, volt12: { conditions: { light: "i77g9ona", dark: "i77g9onb" }, defaultClass: "i77g9ona" }, volt13: { conditions: { light: "i77g9onc", dark: "i77g9ond" }, defaultClass: "i77g9onc" } } } } });
const Ds = ({ reset: e, ...t }) => {
  const o = Sr(t), n = e ? [Ps, Es[e]] : null;
  return z(n, o);
}, $d = {
  small: 0,
  medium: 768,
  large: 1200,
  xlarge: 1600
};
var Is = Ls, mt = { base: "_1oxbat10", light: "_1oxbat154", dark: "_1oxbat155" }, Ls = { media: { breakpoints: { small: "var(--_1oxbat11)", medium: "var(--_1oxbat12)", large: "var(--_1oxbat13)", xlarge: "var(--_1oxbat14)" }, colorModes: { LIGHT: "var(--_1oxbat15)", DARK: "var(--_1oxbat16)" } }, font: { family: { system: "var(--_1oxbat17)", mono: "var(--_1oxbat18)" }, heading: { H1: "var(--_1oxbat19)", H2: "var(--_1oxbat1a)", H3: "var(--_1oxbat1b)", H4: "var(--_1oxbat1c)", H5: "var(--_1oxbat1d)", H6: "var(--_1oxbat1e)" }, size: { MINI: "var(--_1oxbat1f)", XS: "var(--_1oxbat1g)", SM: "var(--_1oxbat1h)", MD: "var(--_1oxbat1i)", LG: "var(--_1oxbat1j)", XL: "var(--_1oxbat1k)", XXL: "var(--_1oxbat1l)", "3XL": "var(--_1oxbat1m)", "4XL": "var(--_1oxbat1n)", "5XL": "var(--_1oxbat1o)", "6XL": "var(--_1oxbat1p)", "7XL": "var(--_1oxbat1q)", "8XL": "var(--_1oxbat1r)", "9XL": "var(--_1oxbat1s)" }, lineheight: { MINI: "var(--_1oxbat1t)", XS: "var(--_1oxbat1u)", SM: "var(--_1oxbat1v)", MD: "var(--_1oxbat1w)", LG: "var(--_1oxbat1x)", XL: "var(--_1oxbat1y)", XXL: "var(--_1oxbat1z)", "3XL": "var(--_1oxbat110)", "4XL": "var(--_1oxbat111)", "5XL": "var(--_1oxbat112)", "6XL": "var(--_1oxbat113)", "7XL": "var(--_1oxbat114)", "8XL": "var(--_1oxbat115)", "9XL": "var(--_1oxbat116)" }, weight: { SUPRLITE: "var(--_1oxbat117)", ULTRALITE: "var(--_1oxbat118)", LITE: "var(--_1oxbat119)", REGULAR: "var(--_1oxbat11a)", MEDIUM: "var(--_1oxbat11b)", SEMIBOLD: "var(--_1oxbat11c)", BOLD: "var(--_1oxbat11d)", HEAVY: "var(--_1oxbat11e)", BLACK: "var(--_1oxbat11f)" } }, radii: { ZERO: "var(--_1oxbat11g)", NO: "var(--_1oxbat11h)", DF: "var(--_1oxbat11i)", XS: "var(--_1oxbat11j)", SM: "var(--_1oxbat11k)", MD: "var(--_1oxbat11l)", LG: "var(--_1oxbat11m)", XL: "var(--_1oxbat11n)", XXL: "var(--_1oxbat11o)", PILL: "var(--_1oxbat11p)" }, space: { ZERO: "var(--_1oxbat11q)", NO: "var(--_1oxbat11r)", DF: "var(--_1oxbat11s)", APX: "var(--_1oxbat11t)", BPX: "var(--_1oxbat11u)", CPX: "var(--_1oxbat11v)", DPX: "var(--_1oxbat11w)", EPX: "var(--_1oxbat11x)", FPX: "var(--_1oxbat11y)", GPX: "var(--_1oxbat11z)", HPX: "var(--_1oxbat120)", IPX: "var(--_1oxbat121)", JPX: "var(--_1oxbat122)", KPX: "var(--_1oxbat123)", LPX: "var(--_1oxbat124)", MPX: "var(--_1oxbat125)", NPX: "var(--_1oxbat126)", OPX: "var(--_1oxbat127)", PPX: "var(--_1oxbat128)", QPX: "var(--_1oxbat129)", RPX: "var(--_1oxbat12a)", SPX: "var(--_1oxbat12b)", TPX: "var(--_1oxbat12c)", UPX: "var(--_1oxbat12d)", VPX: "var(--_1oxbat12e)", WPX: "var(--_1oxbat12f)", XPX: "var(--_1oxbat12g)", YPX: "var(--_1oxbat12h)", ZPX: "var(--_1oxbat12i)" }, z: { indice: { ZERO: "var(--_1oxbat12j)", DF: "var(--_1oxbat12k)", LOW: "var(--_1oxbat12l)", MED: "var(--_1oxbat12m)", HIGH: "var(--_1oxbat12n)", TOP: "var(--_1oxbat12o)", MAX: "var(--_1oxbat12p)" } }, shadow: { NO: "var(--_1oxbat12q)", DF: "var(--_1oxbat12r)", LOW: "var(--_1oxbat12s)", MED: "var(--_1oxbat12t)", HIGH: "var(--_1oxbat12u)" }, color: { transparent: "var(--_1oxbat12v)", current: "var(--_1oxbat12w)", white: "var(--_1oxbat12x)", black: "var(--_1oxbat12y)", gray100: "var(--_1oxbat12z)", gray200: "var(--_1oxbat130)", gray300: "var(--_1oxbat131)", pale100: "var(--_1oxbat132)", pale200: "var(--_1oxbat133)", pale300: "var(--_1oxbat134)", pale400: "var(--_1oxbat135)", pale500: "var(--_1oxbat136)", hyper0: "var(--_1oxbat137)", hyper1: "var(--_1oxbat138)", hyper2: "var(--_1oxbat139)", hyper3: "var(--_1oxbat13a)", hyper4: "var(--_1oxbat13b)", hyper5: "var(--_1oxbat13c)", hyper6: "var(--_1oxbat13d)", hyper7: "var(--_1oxbat13e)", hyper8: "var(--_1oxbat13f)", hyper9: "var(--_1oxbat13g)", hyper10: "var(--_1oxbat13h)", hyper11: "var(--_1oxbat13i)", hyper12: "var(--_1oxbat13j)", hyper13: "var(--_1oxbat13k)", lemon0: "var(--_1oxbat13l)", lemon1: "var(--_1oxbat13m)", lemon2: "var(--_1oxbat13n)", lemon3: "var(--_1oxbat13o)", lemon4: "var(--_1oxbat13p)", lemon5: "var(--_1oxbat13q)", lemon6: "var(--_1oxbat13r)", lemon7: "var(--_1oxbat13s)", lemon8: "var(--_1oxbat13t)", lemon9: "var(--_1oxbat13u)", lemon10: "var(--_1oxbat13v)", lemon11: "var(--_1oxbat13w)", lemon12: "var(--_1oxbat13x)", lemon13: "var(--_1oxbat13y)", slate1: "var(--_1oxbat13z)", slate2: "var(--_1oxbat140)", slate3: "var(--_1oxbat141)", slate4: "var(--_1oxbat142)", slate5: "var(--_1oxbat143)", slate6: "var(--_1oxbat144)", slate7: "var(--_1oxbat145)", slate8: "var(--_1oxbat146)", slate9: "var(--_1oxbat147)", slate10: "var(--_1oxbat148)", slate11: "var(--_1oxbat149)", slate12: "var(--_1oxbat14a)", slate13: "var(--_1oxbat14b)", sapphire0: "var(--_1oxbat14c)", sapphire1: "var(--_1oxbat14d)", sapphire2: "var(--_1oxbat14e)", sapphire3: "var(--_1oxbat14f)", sapphire4: "var(--_1oxbat14g)", sapphire5: "var(--_1oxbat14h)", sapphire6: "var(--_1oxbat14i)", sapphire7: "var(--_1oxbat14j)", sapphire8: "var(--_1oxbat14k)", sapphire9: "var(--_1oxbat14l)", sapphire10: "var(--_1oxbat14m)", sapphire11: "var(--_1oxbat14n)", sapphire12: "var(--_1oxbat14o)", sapphire13: "var(--_1oxbat14p)", volt0: "var(--_1oxbat14q)", volt1: "var(--_1oxbat14r)", volt2: "var(--_1oxbat14s)", volt3: "var(--_1oxbat14t)", volt4: "var(--_1oxbat14u)", volt5: "var(--_1oxbat14v)", volt6: "var(--_1oxbat14w)", volt7: "var(--_1oxbat14x)", volt8: "var(--_1oxbat14y)", volt9: "var(--_1oxbat14z)", volt10: "var(--_1oxbat150)", volt11: "var(--_1oxbat151)", volt12: "var(--_1oxbat152)", volt13: "var(--_1oxbat153)" } };
const Ms = {
  light: `html:not(${mt.light}) &`,
  dark: `html${mt.dark} &`
}, fn = (e, t) => !t || Object.keys(t).length === 0 ? {} : {
  [Ms[e]]: t
}, kd = ({ lightMode: e, darkMode: t }) => ({
  ...e || t ? {
    selectors: {
      ...fn("light", e),
      ...fn("dark", t)
    }
  } : {}
}), Pr = ht({
  theme: "light",
  toggleTheme: null
}), Sd = () => {
  const e = Mt(Pr);
  if (!e)
    throw new Error("Atelier® Kit components must be used within [KitProvider]");
  return e;
}, Pd = ({
  children: e
}) => {
  const [t, o] = G("light"), n = () => {
    o((i) => i === "light" ? "dark" : "light");
  }, r = t === "light" ? mt.dark : mt.light;
  return /* @__PURE__ */ w.jsx(Pr.Provider, { value: { theme: t, toggleTheme: n }, children: /* @__PURE__ */ w.jsx("div", { className: `${mt.base} ${r}`, children: e }) });
}, Fs = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M12.0916 14.9959C12.2854 14.9802 12.4708 14.902 12.6225 14.7846L16.6417 11.583C16.8439 11.4343 16.9703 11.2151 16.9956 10.9725C17.0209 10.7298 16.9366 10.495 16.7681 10.3149C16.5996 10.1349 16.3552 10.0175 16.1024 10.0096C15.8412 9.99399 15.5884 10.0801 15.3946 10.2366L11.9989 12.945L8.60325 10.2366C8.40945 10.0723 8.15667 9.98616 7.90388 10.0018C7.64268 10.0175 7.39832 10.1271 7.2298 10.3149C7.06128 10.495 6.98545 10.7376 7.0023 10.9725C7.02758 11.2151 7.15397 11.4343 7.35619 11.583L11.3754 14.7846C11.5692 14.9411 11.8304 15.0194 12.0832 14.9959H12.0916Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
), Ed = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, {}), Hs = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M15.3529 1L8.64709 1C8.08172 1 7.78927 1.71527 8.17595 2.15231L11.2933 5.67559C11.676 6.10814 12.324 6.10814 12.7067 5.67559L15.8241 2.15231C16.2107 1.71527 15.9183 1 15.3529 1Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
) }), Vs = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ w.jsx(
      "path",
      {
        d: "M8.64709 6H15.3529C15.9183 6 16.2107 5.28473 15.8241 4.84769L12.7067 1.32441C12.324 0.891862 11.676 0.891862 11.2933 1.32441L8.17595 4.84769C7.78927 5.28473 8.08172 6 8.64709 6Z",
        fill: e,
        "fill-rule": "evenodd",
        "clip-rule": "evenodd"
      }
    )
  }
) }), $t = {
  background: "#9E9CA6",
  inner: "#F6F4F0"
}, Td = ({
  color: e = $t.background,
  width: t,
  height: o,
  ...n
}) => /* @__PURE__ */ w.jsx(w.Fragment, { children: /* @__PURE__ */ w.jsxs(
  "svg",
  {
    width: t || "18",
    height: o || "18",
    viewBox: "0 0 18 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...n,
    children: [
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M6.9 16H11.1C14.6 16 16 14.6 16 11.1V6.9C16 3.4 14.6 2 11.1 2H6.9C3.4 2 2 3.4 2 6.9V11.1C2 14.6 3.4 16 6.9 16Z",
          fill: e,
          stroke: e,
          strokeWidth: "1.4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M7.14 6.49999L4 11.5H6.68L7.15 10.7H10.8L11.26 11.5H14L10.86 6.49999H7.14ZM7.82 9.53999L8.98 7.55999L10.12 9.53999H7.82Z",
          fill: $t.inner
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M12.35 8.14999C12.44 8.23999 12.54 8.30999 12.66 8.35999C12.78 8.40999 12.9 8.42999 13.04 8.42999C13.18 8.42999 13.3 8.40999 13.42 8.35999C13.54 8.30999 13.64 8.23999 13.73 8.14999C13.82 8.05999 13.89 7.95999 13.94 7.83999C13.99 7.71999 14.01 7.59999 14.01 7.45999C14.01 7.31999 13.99 7.19999 13.94 7.07999C13.89 6.95999 13.82 6.85999 13.73 6.76999C13.64 6.67999 13.54 6.60999 13.42 6.55999C13.3 6.50999 13.18 6.48999 13.04 6.48999C12.9 6.48999 12.78 6.50999 12.66 6.55999C12.54 6.60999 12.44 6.67999 12.35 6.76999C12.26 6.85999 12.19 6.95999 12.14 7.07999C12.09 7.19999 12.07 7.31999 12.07 7.45999C12.07 7.59999 12.09 7.71999 12.14 7.83999C12.19 7.95999 12.26 8.05999 12.35 8.14999ZM12.4 7.09999C12.47 6.98999 12.55 6.89999 12.66 6.83999C12.77 6.76999 12.89 6.73999 13.03 6.73999C13.17 6.73999 13.29 6.76999 13.39 6.83999C13.5 6.89999 13.59 6.98999 13.65 7.09999C13.72 7.20999 13.75 7.32999 13.75 7.46999C13.75 7.60999 13.72 7.72999 13.65 7.82999C13.59 7.93999 13.5 8.02999 13.39 8.08999C13.28 8.15999 13.16 8.18999 13.03 8.18999C12.9 8.18999 12.77 8.15999 12.66 8.08999C12.55 8.01999 12.46 7.93999 12.4 7.82999C12.33 7.71999 12.3 7.59999 12.3 7.46999C12.3 7.33999 12.33 7.20999 12.4 7.09999Z",
          fill: $t.inner
        }
      ),
      /* @__PURE__ */ w.jsx(
        "path",
        {
          d: "M12.9 7.59999H13.08L13.23 7.89999H13.46L13.28 7.54999C13.28 7.54999 13.35 7.49999 13.38 7.45999C13.41 7.40999 13.43 7.35999 13.43 7.29999C13.43 7.23999 13.42 7.17999 13.39 7.13999C13.36 7.09999 13.32 7.05999 13.28 7.03999C13.24 7.01999 13.19 7.00999 13.15 7.00999H12.71V7.89999H12.92V7.59999H12.9ZM13.07 7.15999C13.07 7.15999 13.12 7.15999 13.15 7.18999C13.18 7.20999 13.19 7.23999 13.19 7.29999C13.19 7.35999 13.18 7.38999 13.15 7.40999C13.12 7.42999 13.09 7.44999 13.06 7.44999H12.89V7.16999H13.06L13.07 7.15999Z",
          fill: $t.inner
        }
      )
    ]
  }
) }), Er = D(
  ({ as: e = "div", className: t, ...o }, n) => {
    const r = {}, i = {};
    for (const a in o)
      Sr.properties.has(a) ? r[a] = o[a] : i[a] = o[a];
    const s = Ds({
      reset: typeof e == "string" ? e : "div",
      ...r
    });
    return $(e, {
      className: z(s, t),
      ...i,
      ref: n
    });
  }
);
Er.displayName = "RectBox";
var Bs = _e({ defaultClassName: "ti68jl4", variantClassNames: { size: { sm: "ti68jl0", md: "ti68jl1", lg: "ti68jl2", vw: "ti68jl3" } }, defaultVariants: { size: "vw" }, compoundVariants: [] });
const Ws = ({
  children: e,
  className: t,
  size: o = "vw",
  ...n
}) => /* @__PURE__ */ w.jsx(
  "div",
  {
    ...n,
    className: z(t, Bs({ size: o })),
    children: e
  }
);
Ws.displayName = "Section";
function gn(e, [t, o]) {
  return Math.min(o, Math.max(t, e));
}
function Us(e) {
  const t = e + "CollectionProvider", [o, n] = Ft(t), [r, i] = o(t, {
    collectionRef: {
      current: null
    },
    itemMap: /* @__PURE__ */ new Map()
  }), s = (p) => {
    const { scope: v, children: g } = p, h = B.useRef(null), y = B.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ B.createElement(r, {
      scope: v,
      itemMap: y,
      collectionRef: h
    }, g);
  }, a = e + "CollectionSlot", l = /* @__PURE__ */ B.forwardRef((p, v) => {
    const { scope: g, children: h } = p, y = i(a, g), b = ge(v, y.collectionRef);
    return /* @__PURE__ */ B.createElement(xt, {
      ref: b
    }, h);
  }), d = e + "CollectionItemSlot", f = "data-radix-collection-item", u = /* @__PURE__ */ B.forwardRef((p, v) => {
    const { scope: g, children: h, ...y } = p, b = B.useRef(null), x = ge(v, b), _ = i(d, g);
    return B.useEffect(() => (_.itemMap.set(b, {
      ref: b,
      ...y
    }), () => void _.itemMap.delete(b))), /* @__PURE__ */ B.createElement(xt, {
      [f]: "",
      ref: x
    }, h);
  });
  function m(p) {
    const v = i(e + "CollectionConsumer", p);
    return B.useCallback(() => {
      const h = v.collectionRef.current;
      if (!h)
        return [];
      const y = Array.from(h.querySelectorAll(`[${f}]`));
      return Array.from(v.itemMap.values()).sort(
        (_, S) => y.indexOf(_.ref.current) - y.indexOf(S.ref.current)
      );
    }, [
      v.collectionRef,
      v.itemMap
    ]);
  }
  return [
    {
      Provider: s,
      Slot: l,
      ItemSlot: u
    },
    m,
    n
  ];
}
const Xs = /* @__PURE__ */ ht(void 0);
function Ks(e) {
  const t = Mt(Xs);
  return e || t || "ltr";
}
let io = 0;
function Ys() {
  re(() => {
    var e, t;
    const o = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = o[0]) !== null && e !== void 0 ? e : pn()), document.body.insertAdjacentElement("beforeend", (t = o[1]) !== null && t !== void 0 ? t : pn()), io++, () => {
      io === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (n) => n.remove()
      ), io--;
    };
  }, []);
}
function pn() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
const ao = "focusScope.autoFocusOnMount", so = "focusScope.autoFocusOnUnmount", vn = {
  bubbles: !1,
  cancelable: !0
}, Gs = /* @__PURE__ */ D((e, t) => {
  const { loop: o = !1, trapped: n = !1, onMountAutoFocus: r, onUnmountAutoFocus: i, ...s } = e, [a, l] = G(null), d = De(r), f = De(i), u = ne(null), m = ge(
    t,
    (g) => l(g)
  ), p = ne({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  re(() => {
    if (n) {
      let g = function(x) {
        if (p.paused || !a)
          return;
        const _ = x.target;
        a.contains(_) ? u.current = _ : Fe(u.current, {
          select: !0
        });
      }, h = function(x) {
        if (p.paused || !a)
          return;
        const _ = x.relatedTarget;
        _ !== null && (a.contains(_) || Fe(u.current, {
          select: !0
        }));
      }, y = function(x) {
        const _ = document.activeElement;
        for (const S of x)
          S.removedNodes.length > 0 && (a != null && a.contains(_) || Fe(a));
      };
      document.addEventListener("focusin", g), document.addEventListener("focusout", h);
      const b = new MutationObserver(y);
      return a && b.observe(a, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", g), document.removeEventListener("focusout", h), b.disconnect();
      };
    }
  }, [
    n,
    a,
    p.paused
  ]), re(() => {
    if (a) {
      hn.add(p);
      const g = document.activeElement;
      if (!a.contains(g)) {
        const y = new CustomEvent(ao, vn);
        a.addEventListener(ao, d), a.dispatchEvent(y), y.defaultPrevented || (Zs(ol(Tr(a)), {
          select: !0
        }), document.activeElement === g && Fe(a));
      }
      return () => {
        a.removeEventListener(ao, d), setTimeout(() => {
          const y = new CustomEvent(so, vn);
          a.addEventListener(so, f), a.dispatchEvent(y), y.defaultPrevented || Fe(g ?? document.body, {
            select: !0
          }), a.removeEventListener(so, f), hn.remove(p);
        }, 0);
      };
    }
  }, [
    a,
    d,
    f,
    p
  ]);
  const v = le((g) => {
    if (!o && !n || p.paused)
      return;
    const h = g.key === "Tab" && !g.altKey && !g.ctrlKey && !g.metaKey, y = document.activeElement;
    if (h && y) {
      const b = g.currentTarget, [x, _] = Js(b);
      x && _ ? !g.shiftKey && y === _ ? (g.preventDefault(), o && Fe(x, {
        select: !0
      })) : g.shiftKey && y === x && (g.preventDefault(), o && Fe(_, {
        select: !0
      })) : y === b && g.preventDefault();
    }
  }, [
    o,
    n,
    p.paused
  ]);
  return /* @__PURE__ */ $(ce.div, M({
    tabIndex: -1
  }, s, {
    ref: m,
    onKeyDown: v
  }));
});
function Zs(e, { select: t = !1 } = {}) {
  const o = document.activeElement;
  for (const n of e)
    if (Fe(n, {
      select: t
    }), document.activeElement !== o)
      return;
}
function Js(e) {
  const t = Tr(e), o = mn(t, e), n = mn(t.reverse(), e);
  return [
    o,
    n
  ];
}
function Tr(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => {
      const r = n.tagName === "INPUT" && n.type === "hidden";
      return n.disabled || n.hidden || r ? NodeFilter.FILTER_SKIP : n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; o.nextNode(); )
    t.push(o.currentNode);
  return t;
}
function mn(e, t) {
  for (const o of e)
    if (!Qs(o, {
      upTo: t
    }))
      return o;
}
function Qs(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t !== void 0 && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function el(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Fe(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const o = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== o && el(e) && t && e.select();
  }
}
const hn = tl();
function tl() {
  let e = [];
  return {
    add(t) {
      const o = e[0];
      t !== o && (o == null || o.pause()), e = bn(e, t), e.unshift(t);
    },
    remove(t) {
      var o;
      e = bn(e, t), (o = e[0]) === null || o === void 0 || o.resume();
    }
  };
}
function bn(e, t) {
  const o = [
    ...e
  ], n = o.indexOf(t);
  return n !== -1 && o.splice(n, 1), o;
}
function ol(e) {
  return e.filter(
    (t) => t.tagName !== "A"
  );
}
const nl = R["useId".toString()] || (() => {
});
let rl = 0;
function Ro(e) {
  const [t, o] = R.useState(nl());
  return ye(() => {
    e || o(
      (n) => n ?? String(rl++)
    );
  }, [
    e
  ]), e || (t ? `radix-${t}` : "");
}
function il(e) {
  const t = ne({
    value: e,
    previous: e
  });
  return at(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [
    e
  ]);
}
const al = /* @__PURE__ */ D((e, t) => /* @__PURE__ */ $(ce.span, M({}, e, {
  ref: t,
  style: {
    // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
})));
var sl = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, tt = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), St = {}, lo = 0, Rr = function(e) {
  return e && (e.host || Rr(e.parentNode));
}, ll = function(e, t) {
  return t.map(function(o) {
    if (e.contains(o))
      return o;
    var n = Rr(o);
    return n && e.contains(n) ? n : (console.error("aria-hidden", o, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(o) {
    return !!o;
  });
}, cl = function(e, t, o, n) {
  var r = ll(t, Array.isArray(e) ? e : [e]);
  St[o] || (St[o] = /* @__PURE__ */ new WeakMap());
  var i = St[o], s = [], a = /* @__PURE__ */ new Set(), l = new Set(r), d = function(u) {
    !u || a.has(u) || (a.add(u), d(u.parentNode));
  };
  r.forEach(d);
  var f = function(u) {
    !u || l.has(u) || Array.prototype.forEach.call(u.children, function(m) {
      if (a.has(m))
        f(m);
      else {
        var p = m.getAttribute(n), v = p !== null && p !== "false", g = (tt.get(m) || 0) + 1, h = (i.get(m) || 0) + 1;
        tt.set(m, g), i.set(m, h), s.push(m), g === 1 && v && kt.set(m, !0), h === 1 && m.setAttribute(o, "true"), v || m.setAttribute(n, "true");
      }
    });
  };
  return f(t), a.clear(), lo++, function() {
    s.forEach(function(u) {
      var m = tt.get(u) - 1, p = i.get(u) - 1;
      tt.set(u, m), i.set(u, p), m || (kt.has(u) || u.removeAttribute(n), kt.delete(u)), p || u.removeAttribute(o);
    }), lo--, lo || (tt = /* @__PURE__ */ new WeakMap(), tt = /* @__PURE__ */ new WeakMap(), kt = /* @__PURE__ */ new WeakMap(), St = {});
  };
}, dl = function(e, t, o) {
  o === void 0 && (o = "data-aria-hidden");
  var n = Array.from(Array.isArray(e) ? e : [e]), r = t || sl(e);
  return r ? (n.push.apply(n, Array.from(r.querySelectorAll("[aria-live]"))), cl(n, r, o, "aria-hidden")) : function() {
    return null;
  };
}, Ne = function() {
  return Ne = Object.assign || function(t) {
    for (var o, n = 1, r = arguments.length; n < r; n++) {
      o = arguments[n];
      for (var i in o)
        Object.prototype.hasOwnProperty.call(o, i) && (t[i] = o[i]);
    }
    return t;
  }, Ne.apply(this, arguments);
};
function Ar(e, t) {
  var o = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (o[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var r = 0, n = Object.getOwnPropertySymbols(e); r < n.length; r++)
      t.indexOf(n[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[r]) && (o[n[r]] = e[n[r]]);
  return o;
}
function ul(e, t, o) {
  if (o || arguments.length === 2)
    for (var n = 0, r = t.length, i; n < r; n++)
      (i || !(n in t)) && (i || (i = Array.prototype.slice.call(t, 0, n)), i[n] = t[n]);
  return e.concat(i || Array.prototype.slice.call(t));
}
var At = "right-scroll-bar-position", Ot = "width-before-scroll-bar", fl = "with-scroll-bars-hidden", gl = "--removed-body-scroll-bar-size";
function pl(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function vl(e, t) {
  var o = G(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return o.value;
        },
        set current(n) {
          var r = o.value;
          r !== n && (o.value = n, o.callback(n, r));
        }
      }
    };
  })[0];
  return o.callback = t, o.facade;
}
function ml(e, t) {
  return vl(t || null, function(o) {
    return e.forEach(function(n) {
      return pl(n, o);
    });
  });
}
function hl(e) {
  return e;
}
function bl(e, t) {
  t === void 0 && (t = hl);
  var o = [], n = !1, r = {
    read: function() {
      if (n)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return o.length ? o[o.length - 1] : e;
    },
    useMedium: function(i) {
      var s = t(i, n);
      return o.push(s), function() {
        o = o.filter(function(a) {
          return a !== s;
        });
      };
    },
    assignSyncMedium: function(i) {
      for (n = !0; o.length; ) {
        var s = o;
        o = [], s.forEach(i);
      }
      o = {
        push: function(a) {
          return i(a);
        },
        filter: function() {
          return o;
        }
      };
    },
    assignMedium: function(i) {
      n = !0;
      var s = [];
      if (o.length) {
        var a = o;
        o = [], a.forEach(i), s = o;
      }
      var l = function() {
        var f = s;
        s = [], f.forEach(i);
      }, d = function() {
        return Promise.resolve().then(l);
      };
      d(), o = {
        push: function(f) {
          s.push(f), d();
        },
        filter: function(f) {
          return s = s.filter(f), o;
        }
      };
    }
  };
  return r;
}
function yl(e) {
  e === void 0 && (e = {});
  var t = bl(null);
  return t.options = Ne({ async: !0, ssr: !1 }, e), t;
}
var Or = function(e) {
  var t = e.sideCar, o = Ar(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var n = t.read();
  if (!n)
    throw new Error("Sidecar medium not found");
  return R.createElement(n, Ne({}, o));
};
Or.isSideCarExport = !0;
function xl(e, t) {
  return e.useMedium(t), Or;
}
var Nr = yl(), co = function() {
}, Xt = R.forwardRef(function(e, t) {
  var o = R.useRef(null), n = R.useState({
    onScrollCapture: co,
    onWheelCapture: co,
    onTouchMoveCapture: co
  }), r = n[0], i = n[1], s = e.forwardProps, a = e.children, l = e.className, d = e.removeScrollBar, f = e.enabled, u = e.shards, m = e.sideCar, p = e.noIsolation, v = e.inert, g = e.allowPinchZoom, h = e.as, y = h === void 0 ? "div" : h, b = Ar(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), x = m, _ = ml([o, t]), S = Ne(Ne({}, b), r);
  return R.createElement(
    R.Fragment,
    null,
    f && R.createElement(x, { sideCar: Nr, removeScrollBar: d, shards: u, noIsolation: p, inert: v, setCallbacks: i, allowPinchZoom: !!g, lockRef: o }),
    s ? R.cloneElement(R.Children.only(a), Ne(Ne({}, S), { ref: _ })) : R.createElement(y, Ne({}, S, { className: l, ref: _ }), a)
  );
});
Xt.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
Xt.classNames = {
  fullWidth: Ot,
  zeroRight: At
};
var yn, Cl = function() {
  if (yn)
    return yn;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function wl() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = Cl();
  return t && e.setAttribute("nonce", t), e;
}
function _l(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function $l(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var kl = function() {
  var e = 0, t = null;
  return {
    add: function(o) {
      e == 0 && (t = wl()) && (_l(t, o), $l(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, Sl = function() {
  var e = kl();
  return function(t, o) {
    R.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && o]);
  };
}, qr = function() {
  var e = Sl(), t = function(o) {
    var n = o.styles, r = o.dynamic;
    return e(n, r), null;
  };
  return t;
}, Pl = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, uo = function(e) {
  return parseInt(e || "", 10) || 0;
}, El = function(e) {
  var t = window.getComputedStyle(document.body), o = t[e === "padding" ? "paddingLeft" : "marginLeft"], n = t[e === "padding" ? "paddingTop" : "marginTop"], r = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [uo(o), uo(n), uo(r)];
}, Tl = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return Pl;
  var t = El(e), o = document.documentElement.clientWidth, n = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, n - o + t[2] - t[0])
  };
}, Rl = qr(), Al = function(e, t, o, n) {
  var r = e.left, i = e.top, s = e.right, a = e.gap;
  return o === void 0 && (o = "margin"), `
  .`.concat(fl, ` {
   overflow: hidden `).concat(n, `;
   padding-right: `).concat(a, "px ").concat(n, `;
  }
  body {
    overflow: hidden `).concat(n, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(n, ";"),
    o === "margin" && `
    padding-left: `.concat(r, `px;
    padding-top: `).concat(i, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(a, "px ").concat(n, `;
    `),
    o === "padding" && "padding-right: ".concat(a, "px ").concat(n, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(At, ` {
    right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(Ot, ` {
    margin-right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(At, " .").concat(At, ` {
    right: 0 `).concat(n, `;
  }
  
  .`).concat(Ot, " .").concat(Ot, ` {
    margin-right: 0 `).concat(n, `;
  }
  
  body {
    `).concat(gl, ": ").concat(a, `px;
  }
`);
}, Ol = function(e) {
  var t = e.noRelative, o = e.noImportant, n = e.gapMode, r = n === void 0 ? "margin" : n, i = R.useMemo(function() {
    return Tl(r);
  }, [r]);
  return R.createElement(Rl, { styles: Al(i, !t, r, o ? "" : "!important") });
}, xo = !1;
if (typeof window < "u")
  try {
    var Pt = Object.defineProperty({}, "passive", {
      get: function() {
        return xo = !0, !0;
      }
    });
    window.addEventListener("test", Pt, Pt), window.removeEventListener("test", Pt, Pt);
  } catch {
    xo = !1;
  }
var ot = xo ? { passive: !1 } : !1, Nl = function(e) {
  return e.tagName === "TEXTAREA";
}, jr = function(e, t) {
  var o = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    o[t] !== "hidden" && // contains scroll inside self
    !(o.overflowY === o.overflowX && !Nl(e) && o[t] === "visible")
  );
}, ql = function(e) {
  return jr(e, "overflowY");
}, jl = function(e) {
  return jr(e, "overflowX");
}, xn = function(e, t) {
  var o = t;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var n = zr(e, o);
    if (n) {
      var r = Dr(e, o), i = r[1], s = r[2];
      if (i > s)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== document.body);
  return !1;
}, zl = function(e) {
  var t = e.scrollTop, o = e.scrollHeight, n = e.clientHeight;
  return [
    t,
    o,
    n
  ];
}, Dl = function(e) {
  var t = e.scrollLeft, o = e.scrollWidth, n = e.clientWidth;
  return [
    t,
    o,
    n
  ];
}, zr = function(e, t) {
  return e === "v" ? ql(t) : jl(t);
}, Dr = function(e, t) {
  return e === "v" ? zl(t) : Dl(t);
}, Il = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Ll = function(e, t, o, n, r) {
  var i = Il(e, window.getComputedStyle(t).direction), s = i * n, a = o.target, l = t.contains(a), d = !1, f = s > 0, u = 0, m = 0;
  do {
    var p = Dr(e, a), v = p[0], g = p[1], h = p[2], y = g - h - i * v;
    (v || y) && zr(e, a) && (u += y, m += v), a = a.parentNode;
  } while (
    // portaled content
    !l && a !== document.body || // self content
    l && (t.contains(a) || t === a)
  );
  return (f && (r && u === 0 || !r && s > u) || !f && (r && m === 0 || !r && -s > m)) && (d = !0), d;
}, Et = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, Cn = function(e) {
  return [e.deltaX, e.deltaY];
}, wn = function(e) {
  return e && "current" in e ? e.current : e;
}, Ml = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Fl = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Hl = 0, nt = [];
function Vl(e) {
  var t = R.useRef([]), o = R.useRef([0, 0]), n = R.useRef(), r = R.useState(Hl++)[0], i = R.useState(function() {
    return qr();
  })[0], s = R.useRef(e);
  R.useEffect(function() {
    s.current = e;
  }, [e]), R.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(r));
      var g = ul([e.lockRef.current], (e.shards || []).map(wn), !0).filter(Boolean);
      return g.forEach(function(h) {
        return h.classList.add("allow-interactivity-".concat(r));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(r)), g.forEach(function(h) {
          return h.classList.remove("allow-interactivity-".concat(r));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var a = R.useCallback(function(g, h) {
    if ("touches" in g && g.touches.length === 2)
      return !s.current.allowPinchZoom;
    var y = Et(g), b = o.current, x = "deltaX" in g ? g.deltaX : b[0] - y[0], _ = "deltaY" in g ? g.deltaY : b[1] - y[1], S, E = g.target, P = Math.abs(x) > Math.abs(_) ? "h" : "v";
    if ("touches" in g && P === "h" && E.type === "range")
      return !1;
    var T = xn(P, E);
    if (!T)
      return !0;
    if (T ? S = P : (S = P === "v" ? "h" : "v", T = xn(P, E)), !T)
      return !1;
    if (!n.current && "changedTouches" in g && (x || _) && (n.current = S), !S)
      return !0;
    var F = n.current || S;
    return Ll(F, h, g, F === "h" ? x : _, !0);
  }, []), l = R.useCallback(function(g) {
    var h = g;
    if (!(!nt.length || nt[nt.length - 1] !== i)) {
      var y = "deltaY" in h ? Cn(h) : Et(h), b = t.current.filter(function(S) {
        return S.name === h.type && S.target === h.target && Ml(S.delta, y);
      })[0];
      if (b && b.should) {
        h.cancelable && h.preventDefault();
        return;
      }
      if (!b) {
        var x = (s.current.shards || []).map(wn).filter(Boolean).filter(function(S) {
          return S.contains(h.target);
        }), _ = x.length > 0 ? a(h, x[0]) : !s.current.noIsolation;
        _ && h.cancelable && h.preventDefault();
      }
    }
  }, []), d = R.useCallback(function(g, h, y, b) {
    var x = { name: g, delta: h, target: y, should: b };
    t.current.push(x), setTimeout(function() {
      t.current = t.current.filter(function(_) {
        return _ !== x;
      });
    }, 1);
  }, []), f = R.useCallback(function(g) {
    o.current = Et(g), n.current = void 0;
  }, []), u = R.useCallback(function(g) {
    d(g.type, Cn(g), g.target, a(g, e.lockRef.current));
  }, []), m = R.useCallback(function(g) {
    d(g.type, Et(g), g.target, a(g, e.lockRef.current));
  }, []);
  R.useEffect(function() {
    return nt.push(i), e.setCallbacks({
      onScrollCapture: u,
      onWheelCapture: u,
      onTouchMoveCapture: m
    }), document.addEventListener("wheel", l, ot), document.addEventListener("touchmove", l, ot), document.addEventListener("touchstart", f, ot), function() {
      nt = nt.filter(function(g) {
        return g !== i;
      }), document.removeEventListener("wheel", l, ot), document.removeEventListener("touchmove", l, ot), document.removeEventListener("touchstart", f, ot);
    };
  }, []);
  var p = e.removeScrollBar, v = e.inert;
  return R.createElement(
    R.Fragment,
    null,
    v ? R.createElement(i, { styles: Fl(r) }) : null,
    p ? R.createElement(Ol, { gapMode: "margin" }) : null
  );
}
const Bl = xl(Nr, Vl);
var Ir = R.forwardRef(function(e, t) {
  return R.createElement(Xt, Ne({}, e, { ref: t, sideCar: Bl }));
});
Ir.classNames = Xt.classNames;
const Wl = Ir, Ul = [
  " ",
  "Enter",
  "ArrowUp",
  "ArrowDown"
], Xl = [
  " ",
  "Enter"
], Kt = "Select", [Yt, Gt, Kl] = Us(Kt), [dt, Rd] = Ft(Kt, [
  Kl,
  Bt
]), Ao = Bt(), [Yl, Ye] = dt(Kt), [Gl, Zl] = dt(Kt), Jl = (e) => {
  const { __scopeSelect: t, children: o, open: n, defaultOpen: r, onOpenChange: i, value: s, defaultValue: a, onValueChange: l, dir: d, name: f, autoComplete: u, disabled: m, required: p } = e, v = Ao(t), [g, h] = G(null), [y, b] = G(null), [x, _] = G(!1), S = Ks(d), [E = !1, P] = go({
    prop: n,
    defaultProp: r,
    onChange: i
  }), [T, F] = go({
    prop: s,
    defaultProp: a,
    onChange: l
  }), X = ne(null), q = g ? !!g.closest("form") : !0, [V, j] = G(/* @__PURE__ */ new Set()), L = Array.from(V).map(
    (I) => I.props.value
  ).join(";");
  return /* @__PURE__ */ $(tr, v, /* @__PURE__ */ $(Yl, {
    required: p,
    scope: t,
    trigger: g,
    onTriggerChange: h,
    valueNode: y,
    onValueNodeChange: b,
    valueNodeHasChildren: x,
    onValueNodeHasChildrenChange: _,
    contentId: Ro(),
    value: T,
    onValueChange: F,
    open: E,
    onOpenChange: P,
    dir: S,
    triggerPointerDownPosRef: X,
    disabled: m
  }, /* @__PURE__ */ $(Yt.Provider, {
    scope: t
  }, /* @__PURE__ */ $(Gl, {
    scope: e.__scopeSelect,
    onNativeOptionAdd: le((I) => {
      j(
        (A) => new Set(A).add(I)
      );
    }, []),
    onNativeOptionRemove: le((I) => {
      j((A) => {
        const Q = new Set(A);
        return Q.delete(I), Q;
      });
    }, [])
  }, o)), q ? /* @__PURE__ */ $(Hr, {
    key: L,
    "aria-hidden": !0,
    required: p,
    tabIndex: -1,
    name: f,
    autoComplete: u,
    value: T,
    onChange: (I) => F(I.target.value),
    disabled: m
  }, T === void 0 ? /* @__PURE__ */ $("option", {
    value: ""
  }) : null, Array.from(V)) : null));
}, Ql = "SelectTrigger", ec = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, disabled: n = !1, ...r } = e, i = Ao(o), s = Ye(Ql, o), a = s.disabled || n, l = ge(t, s.onTriggerChange), d = Gt(o), [f, u, m] = Vr((v) => {
    const g = d().filter(
      (b) => !b.disabled
    ), h = g.find(
      (b) => b.value === s.value
    ), y = Br(g, v, h);
    y !== void 0 && s.onValueChange(y.value);
  }), p = () => {
    a || (s.onOpenChange(!0), m());
  };
  return /* @__PURE__ */ $(or, M({
    asChild: !0
  }, i), /* @__PURE__ */ $(ce.button, M({
    type: "button",
    role: "combobox",
    "aria-controls": s.contentId,
    "aria-expanded": s.open,
    "aria-required": s.required,
    "aria-autocomplete": "none",
    dir: s.dir,
    "data-state": s.open ? "open" : "closed",
    disabled: a,
    "data-disabled": a ? "" : void 0,
    "data-placeholder": s.value === void 0 ? "" : void 0
  }, r, {
    ref: l,
    onClick: oe(r.onClick, (v) => {
      v.currentTarget.focus();
    }),
    onPointerDown: oe(r.onPointerDown, (v) => {
      const g = v.target;
      g.hasPointerCapture(v.pointerId) && g.releasePointerCapture(v.pointerId), v.button === 0 && v.ctrlKey === !1 && (p(), s.triggerPointerDownPosRef.current = {
        x: Math.round(v.pageX),
        y: Math.round(v.pageY)
      }, v.preventDefault());
    }),
    onKeyDown: oe(r.onKeyDown, (v) => {
      const g = f.current !== "";
      !(v.ctrlKey || v.altKey || v.metaKey) && v.key.length === 1 && u(v.key), !(g && v.key === " ") && Ul.includes(v.key) && (p(), v.preventDefault());
    })
  })));
}), tc = "SelectValue", oc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, className: n, style: r, children: i, placeholder: s, ...a } = e, l = Ye(tc, o), { onValueNodeHasChildrenChange: d } = l, f = i !== void 0, u = ge(t, l.onValueNodeChange);
  return ye(() => {
    d(f);
  }, [
    d,
    f
  ]), /* @__PURE__ */ $(ce.span, M({}, a, {
    ref: u,
    style: {
      pointerEvents: "none"
    }
  }), l.value === void 0 && s !== void 0 ? s : i);
}), nc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, children: n, ...r } = e;
  return /* @__PURE__ */ $(ce.span, M({
    "aria-hidden": !0
  }, r, {
    ref: t
  }), n || "▼");
}), rc = (e) => /* @__PURE__ */ $(rr, M({
  asChild: !0
}, e)), lt = "SelectContent", ic = /* @__PURE__ */ D((e, t) => {
  const o = Ye(lt, e.__scopeSelect), [n, r] = G();
  if (ye(() => {
    r(new DocumentFragment());
  }, []), !o.open) {
    const i = n;
    return i ? /* @__PURE__ */ Rn(/* @__PURE__ */ $(Lr, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ $(Yt.Slot, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ $("div", null, e.children))), i) : null;
  }
  return /* @__PURE__ */ $(ac, M({}, e, {
    ref: t
  }));
}), je = 10, [Lr, Ge] = dt(lt), ac = /* @__PURE__ */ D((e, t) => {
  const {
    __scopeSelect: o,
    position: n = "item-aligned",
    onCloseAutoFocus: r,
    onEscapeKeyDown: i,
    onPointerDownOutside: s,
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: m,
    collisionPadding: p,
    sticky: v,
    hideWhenDetached: g,
    avoidCollisions: h,
    //
    ...y
  } = e, b = Ye(lt, o), [x, _] = G(null), [S, E] = G(null), P = ge(
    t,
    (O) => _(O)
  ), [T, F] = G(null), [X, q] = G(null), V = Gt(o), [j, L] = G(!1), I = ne(!1);
  re(() => {
    if (x)
      return dl(x);
  }, [
    x
  ]), Ys();
  const A = le((O) => {
    const [U, ...fe] = V().map(
      (K) => K.ref.current
    ), [Z] = fe.slice(-1), J = document.activeElement;
    for (const K of O)
      if (K === J || (K == null || K.scrollIntoView({
        block: "nearest"
      }), K === U && S && (S.scrollTop = 0), K === Z && S && (S.scrollTop = S.scrollHeight), K == null || K.focus(), document.activeElement !== J))
        return;
  }, [
    V,
    S
  ]), Q = le(
    () => A([
      T,
      x
    ]),
    [
      A,
      T,
      x
    ]
  );
  re(() => {
    j && Q();
  }, [
    j,
    Q
  ]);
  const { onOpenChange: ee, triggerPointerDownPosRef: pe } = b;
  re(() => {
    if (x) {
      let O = {
        x: 0,
        y: 0
      };
      const U = (Z) => {
        var J, K, he, ve;
        O = {
          x: Math.abs(Math.round(Z.pageX) - ((J = (K = pe.current) === null || K === void 0 ? void 0 : K.x) !== null && J !== void 0 ? J : 0)),
          y: Math.abs(Math.round(Z.pageY) - ((he = (ve = pe.current) === null || ve === void 0 ? void 0 : ve.y) !== null && he !== void 0 ? he : 0))
        };
      }, fe = (Z) => {
        O.x <= 10 && O.y <= 10 ? Z.preventDefault() : x.contains(Z.target) || ee(!1), document.removeEventListener("pointermove", U), pe.current = null;
      };
      return pe.current !== null && (document.addEventListener("pointermove", U), document.addEventListener("pointerup", fe, {
        capture: !0,
        once: !0
      })), () => {
        document.removeEventListener("pointermove", U), document.removeEventListener("pointerup", fe, {
          capture: !0
        });
      };
    }
  }, [
    x,
    ee,
    pe
  ]), re(() => {
    const O = () => ee(!1);
    return window.addEventListener("blur", O), window.addEventListener("resize", O), () => {
      window.removeEventListener("blur", O), window.removeEventListener("resize", O);
    };
  }, [
    ee
  ]);
  const [ie, ue] = Vr((O) => {
    const U = V().filter(
      (J) => !J.disabled
    ), fe = U.find(
      (J) => J.ref.current === document.activeElement
    ), Z = Br(U, O, fe);
    Z && setTimeout(
      () => Z.ref.current.focus()
    );
  }), me = le((O, U, fe) => {
    const Z = !I.current && !fe;
    (b.value !== void 0 && b.value === U || Z) && (F(O), Z && (I.current = !0));
  }, [
    b.value
  ]), ke = le(
    () => x == null ? void 0 : x.focus(),
    [
      x
    ]
  ), xe = le((O, U, fe) => {
    const Z = !I.current && !fe;
    (b.value !== void 0 && b.value === U || Z) && q(O);
  }, [
    b.value
  ]), Ce = n === "popper" ? _n : sc, Se = Ce === _n ? {
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: m,
    collisionPadding: p,
    sticky: v,
    hideWhenDetached: g,
    avoidCollisions: h
  } : {};
  return /* @__PURE__ */ $(Lr, {
    scope: o,
    content: x,
    viewport: S,
    onViewportChange: E,
    itemRefCallback: me,
    selectedItem: T,
    onItemLeave: ke,
    itemTextRefCallback: xe,
    focusSelectedItem: Q,
    selectedItemText: X,
    position: n,
    isPositioned: j,
    searchRef: ie
  }, /* @__PURE__ */ $(Wl, {
    as: xt,
    allowPinchZoom: !0
  }, /* @__PURE__ */ $(Gs, {
    asChild: !0,
    trapped: b.open,
    onMountAutoFocus: (O) => {
      O.preventDefault();
    },
    onUnmountAutoFocus: oe(r, (O) => {
      var U;
      (U = b.trigger) === null || U === void 0 || U.focus({
        preventScroll: !0
      }), O.preventDefault();
    })
  }, /* @__PURE__ */ $(ir, {
    asChild: !0,
    disableOutsidePointerEvents: !0,
    onEscapeKeyDown: i,
    onPointerDownOutside: s,
    onFocusOutside: (O) => O.preventDefault(),
    onDismiss: () => b.onOpenChange(!1)
  }, /* @__PURE__ */ $(Ce, M({
    role: "listbox",
    id: b.contentId,
    "data-state": b.open ? "open" : "closed",
    dir: b.dir,
    onContextMenu: (O) => O.preventDefault()
  }, y, Se, {
    onPlaced: () => L(!0),
    ref: P,
    style: {
      // flex layout so we can place the scroll buttons properly
      display: "flex",
      flexDirection: "column",
      // reset the outline by default as the content MAY get focused
      outline: "none",
      ...y.style
    },
    onKeyDown: oe(y.onKeyDown, (O) => {
      const U = O.ctrlKey || O.altKey || O.metaKey;
      if (O.key === "Tab" && O.preventDefault(), !U && O.key.length === 1 && ue(O.key), [
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End"
      ].includes(O.key)) {
        let Z = V().filter(
          (J) => !J.disabled
        ).map(
          (J) => J.ref.current
        );
        if ([
          "ArrowUp",
          "End"
        ].includes(O.key) && (Z = Z.slice().reverse()), [
          "ArrowUp",
          "ArrowDown"
        ].includes(O.key)) {
          const J = O.target, K = Z.indexOf(J);
          Z = Z.slice(K + 1);
        }
        setTimeout(
          () => A(Z)
        ), O.preventDefault();
      }
    })
  }))))));
}), sc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, onPlaced: n, ...r } = e, i = Ye(lt, o), s = Ge(lt, o), [a, l] = G(null), [d, f] = G(null), u = ge(
    t,
    (P) => f(P)
  ), m = Gt(o), p = ne(!1), v = ne(!0), { viewport: g, selectedItem: h, selectedItemText: y, focusSelectedItem: b } = s, x = le(() => {
    if (i.trigger && i.valueNode && a && d && g && h && y) {
      const P = i.trigger.getBoundingClientRect(), T = d.getBoundingClientRect(), F = i.valueNode.getBoundingClientRect(), X = y.getBoundingClientRect();
      if (i.dir !== "rtl") {
        const J = X.left - T.left, K = F.left - J, he = P.left - K, ve = P.width + he, Ae = Math.max(ve, T.width), Oe = window.innerWidth - je, Me = gn(K, [
          je,
          Oe - Ae
        ]);
        a.style.minWidth = ve + "px", a.style.left = Me + "px";
      } else {
        const J = T.right - X.right, K = window.innerWidth - F.right - J, he = window.innerWidth - P.right - K, ve = P.width + he, Ae = Math.max(ve, T.width), Oe = window.innerWidth - je, Me = gn(K, [
          je,
          Oe - Ae
        ]);
        a.style.minWidth = ve + "px", a.style.right = Me + "px";
      }
      const q = m(), V = window.innerHeight - je * 2, j = g.scrollHeight, L = window.getComputedStyle(d), I = parseInt(L.borderTopWidth, 10), A = parseInt(L.paddingTop, 10), Q = parseInt(L.borderBottomWidth, 10), ee = parseInt(L.paddingBottom, 10), pe = I + A + j + ee + Q, ie = Math.min(h.offsetHeight * 5, pe), ue = window.getComputedStyle(g), me = parseInt(ue.paddingTop, 10), ke = parseInt(ue.paddingBottom, 10), xe = P.top + P.height / 2 - je, Ce = V - xe, Se = h.offsetHeight / 2, O = h.offsetTop + Se, U = I + A + O, fe = pe - U;
      if (U <= xe) {
        const J = h === q[q.length - 1].ref.current;
        a.style.bottom = "0px";
        const K = d.clientHeight - g.offsetTop - g.offsetHeight, he = Math.max(Ce, Se + (J ? ke : 0) + K + Q), ve = U + he;
        a.style.height = ve + "px";
      } else {
        const J = h === q[0].ref.current;
        a.style.top = "0px";
        const he = Math.max(xe, I + g.offsetTop + (J ? me : 0) + Se) + fe;
        a.style.height = he + "px", g.scrollTop = U - xe + g.offsetTop;
      }
      a.style.margin = `${je}px 0`, a.style.minHeight = ie + "px", a.style.maxHeight = V + "px", n == null || n(), requestAnimationFrame(
        () => p.current = !0
      );
    }
  }, [
    m,
    i.trigger,
    i.valueNode,
    a,
    d,
    g,
    h,
    y,
    i.dir,
    n
  ]);
  ye(
    () => x(),
    [
      x
    ]
  );
  const [_, S] = G();
  ye(() => {
    d && S(window.getComputedStyle(d).zIndex);
  }, [
    d
  ]);
  const E = le((P) => {
    P && v.current === !0 && (x(), b == null || b(), v.current = !1);
  }, [
    x,
    b
  ]);
  return /* @__PURE__ */ $(lc, {
    scope: o,
    contentWrapper: a,
    shouldExpandOnScrollRef: p,
    onScrollButtonChange: E
  }, /* @__PURE__ */ $("div", {
    ref: l,
    style: {
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      zIndex: _
    }
  }, /* @__PURE__ */ $(ce.div, M({}, r, {
    ref: u,
    style: {
      // When we get the height of the content, it includes borders. If we were to set
      // the height without having `boxSizing: 'border-box'` it would be too big.
      boxSizing: "border-box",
      // We need to ensure the content doesn't get taller than the wrapper
      maxHeight: "100%",
      ...r.style
    }
  }))));
}), _n = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, align: n = "start", collisionPadding: r = je, ...i } = e, s = Ao(o);
  return /* @__PURE__ */ $(nr, M({}, s, i, {
    ref: t,
    align: n,
    collisionPadding: r,
    style: {
      // Ensure border-box for floating-ui calculations
      boxSizing: "border-box",
      ...i.style,
      "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-select-content-available-width": "var(--radix-popper-available-width)",
      "--radix-select-content-available-height": "var(--radix-popper-available-height)",
      "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
    }
  }));
}), [lc, Oo] = dt(lt, {}), $n = "SelectViewport", cc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, r = Ge($n, o), i = Oo($n, o), s = ge(t, r.onViewportChange), a = ne(0);
  return /* @__PURE__ */ $(_o, null, /* @__PURE__ */ $("style", {
    dangerouslySetInnerHTML: {
      __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
    }
  }), /* @__PURE__ */ $(Yt.Slot, {
    scope: o
  }, /* @__PURE__ */ $(ce.div, M({
    "data-radix-select-viewport": "",
    role: "presentation"
  }, n, {
    ref: s,
    style: {
      // we use position: 'relative' here on the `viewport` so that when we call
      // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
      // (independent of the scrollUpButton).
      position: "relative",
      flex: 1,
      overflow: "auto",
      ...n.style
    },
    onScroll: oe(n.onScroll, (l) => {
      const d = l.currentTarget, { contentWrapper: f, shouldExpandOnScrollRef: u } = i;
      if (u != null && u.current && f) {
        const m = Math.abs(a.current - d.scrollTop);
        if (m > 0) {
          const p = window.innerHeight - je * 2, v = parseFloat(f.style.minHeight), g = parseFloat(f.style.height), h = Math.max(v, g);
          if (h < p) {
            const y = h + m, b = Math.min(p, y), x = y - b;
            f.style.height = b + "px", f.style.bottom === "0px" && (d.scrollTop = x > 0 ? x : 0, f.style.justifyContent = "flex-end");
          }
        }
      }
      a.current = d.scrollTop;
    })
  }))));
}), dc = "SelectGroup", [uc, fc] = dt(dc), gc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, r = Ro();
  return /* @__PURE__ */ $(uc, {
    scope: o,
    id: r
  }, /* @__PURE__ */ $(ce.div, M({
    role: "group",
    "aria-labelledby": r
  }, n, {
    ref: t
  })));
}), pc = "SelectLabel", vc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e, r = fc(pc, o);
  return /* @__PURE__ */ $(ce.div, M({
    id: r.id
  }, n, {
    ref: t
  }));
}), Co = "SelectItem", [mc, Mr] = dt(Co), hc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, value: n, disabled: r = !1, textValue: i, ...s } = e, a = Ye(Co, o), l = Ge(Co, o), d = a.value === n, [f, u] = G(i ?? ""), [m, p] = G(!1), v = ge(t, (y) => {
    var b;
    return (b = l.itemRefCallback) === null || b === void 0 ? void 0 : b.call(l, y, n, r);
  }), g = Ro(), h = () => {
    r || (a.onValueChange(n), a.onOpenChange(!1));
  };
  return /* @__PURE__ */ $(mc, {
    scope: o,
    value: n,
    disabled: r,
    textId: g,
    isSelected: d,
    onItemTextChange: le((y) => {
      u((b) => {
        var x;
        return b || ((x = y == null ? void 0 : y.textContent) !== null && x !== void 0 ? x : "").trim();
      });
    }, [])
  }, /* @__PURE__ */ $(Yt.ItemSlot, {
    scope: o,
    value: n,
    disabled: r,
    textValue: f
  }, /* @__PURE__ */ $(ce.div, M({
    role: "option",
    "aria-labelledby": g,
    "data-highlighted": m ? "" : void 0,
    "aria-selected": d && m,
    "data-state": d ? "checked" : "unchecked",
    "aria-disabled": r || void 0,
    "data-disabled": r ? "" : void 0,
    tabIndex: r ? void 0 : -1
  }, s, {
    ref: v,
    onFocus: oe(
      s.onFocus,
      () => p(!0)
    ),
    onBlur: oe(
      s.onBlur,
      () => p(!1)
    ),
    onPointerUp: oe(s.onPointerUp, h),
    onPointerMove: oe(s.onPointerMove, (y) => {
      if (r) {
        var b;
        (b = l.onItemLeave) === null || b === void 0 || b.call(l);
      } else
        y.currentTarget.focus({
          preventScroll: !0
        });
    }),
    onPointerLeave: oe(s.onPointerLeave, (y) => {
      if (y.currentTarget === document.activeElement) {
        var b;
        (b = l.onItemLeave) === null || b === void 0 || b.call(l);
      }
    }),
    onKeyDown: oe(s.onKeyDown, (y) => {
      var b;
      ((b = l.searchRef) === null || b === void 0 ? void 0 : b.current) !== "" && y.key === " " || (Xl.includes(y.key) && h(), y.key === " " && y.preventDefault());
    })
  }))));
}), Tt = "SelectItemText", bc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, className: n, style: r, ...i } = e, s = Ye(Tt, o), a = Ge(Tt, o), l = Mr(Tt, o), d = Zl(Tt, o), [f, u] = G(null), m = ge(
    t,
    (y) => u(y),
    l.onItemTextChange,
    (y) => {
      var b;
      return (b = a.itemTextRefCallback) === null || b === void 0 ? void 0 : b.call(a, y, l.value, l.disabled);
    }
  ), p = f == null ? void 0 : f.textContent, v = at(
    () => /* @__PURE__ */ $("option", {
      key: l.value,
      value: l.value,
      disabled: l.disabled
    }, p),
    [
      l.disabled,
      l.value,
      p
    ]
  ), { onNativeOptionAdd: g, onNativeOptionRemove: h } = d;
  return ye(() => (g(v), () => h(v)), [
    g,
    h,
    v
  ]), /* @__PURE__ */ $(_o, null, /* @__PURE__ */ $(ce.span, M({
    id: l.textId
  }, i, {
    ref: m
  })), l.isSelected && s.valueNode && !s.valueNodeHasChildren ? /* @__PURE__ */ Rn(i.children, s.valueNode) : null);
}), yc = "SelectItemIndicator", xc = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return Mr(yc, o).isSelected ? /* @__PURE__ */ $(ce.span, M({
    "aria-hidden": !0
  }, n, {
    ref: t
  })) : null;
}), kn = "SelectScrollUpButton", Cc = /* @__PURE__ */ D((e, t) => {
  const o = Ge(kn, e.__scopeSelect), n = Oo(kn, e.__scopeSelect), [r, i] = G(!1), s = ge(t, n.onScrollButtonChange);
  return ye(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollTop > 0;
        i(d);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), r ? /* @__PURE__ */ $(Fr, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop - l.offsetHeight);
    }
  })) : null;
}), Sn = "SelectScrollDownButton", wc = /* @__PURE__ */ D((e, t) => {
  const o = Ge(Sn, e.__scopeSelect), n = Oo(Sn, e.__scopeSelect), [r, i] = G(!1), s = ge(t, n.onScrollButtonChange);
  return ye(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollHeight - a.clientHeight, f = Math.ceil(a.scrollTop) < d;
        i(f);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), r ? /* @__PURE__ */ $(Fr, M({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop + l.offsetHeight);
    }
  })) : null;
}), Fr = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, onAutoScroll: n, ...r } = e, i = Ge("SelectScrollButton", o), s = ne(null), a = Gt(o), l = le(() => {
    s.current !== null && (window.clearInterval(s.current), s.current = null);
  }, []);
  return re(() => () => l(), [
    l
  ]), ye(() => {
    var d;
    const f = a().find(
      (u) => u.ref.current === document.activeElement
    );
    f == null || (d = f.ref.current) === null || d === void 0 || d.scrollIntoView({
      block: "nearest"
    });
  }, [
    a
  ]), /* @__PURE__ */ $(ce.div, M({
    "aria-hidden": !0
  }, r, {
    ref: t,
    style: {
      flexShrink: 0,
      ...r.style
    },
    onPointerDown: oe(r.onPointerDown, () => {
      s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerMove: oe(r.onPointerMove, () => {
      var d;
      (d = i.onItemLeave) === null || d === void 0 || d.call(i), s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerLeave: oe(r.onPointerLeave, () => {
      l();
    })
  }));
}), _c = /* @__PURE__ */ D((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return /* @__PURE__ */ $(ce.div, M({
    "aria-hidden": !0
  }, n, {
    ref: t
  }));
}), Hr = /* @__PURE__ */ D((e, t) => {
  const { value: o, ...n } = e, r = ne(null), i = ge(t, r), s = il(o);
  return re(() => {
    const a = r.current, l = window.HTMLSelectElement.prototype, f = Object.getOwnPropertyDescriptor(l, "value").set;
    if (s !== o && f) {
      const u = new Event("change", {
        bubbles: !0
      });
      f.call(a, o), a.dispatchEvent(u);
    }
  }, [
    s,
    o
  ]), /* @__PURE__ */ $(al, {
    asChild: !0
  }, /* @__PURE__ */ $("select", M({}, n, {
    ref: i,
    defaultValue: o
  })));
});
Hr.displayName = "BubbleSelect";
function Vr(e) {
  const t = De(e), o = ne(""), n = ne(0), r = le((s) => {
    const a = o.current + s;
    t(a), function l(d) {
      o.current = d, window.clearTimeout(n.current), d !== "" && (n.current = window.setTimeout(
        () => l(""),
        1e3
      ));
    }(a);
  }, [
    t
  ]), i = le(() => {
    o.current = "", window.clearTimeout(n.current);
  }, []);
  return re(() => () => window.clearTimeout(n.current), []), [
    o,
    r,
    i
  ];
}
function Br(e, t, o) {
  const r = t.length > 1 && Array.from(t).every(
    (d) => d === t[0]
  ) ? t[0] : t, i = o ? e.indexOf(o) : -1;
  let s = $c(e, Math.max(i, 0));
  r.length === 1 && (s = s.filter(
    (d) => d !== o
  ));
  const l = s.find(
    (d) => d.textValue.toLowerCase().startsWith(r.toLowerCase())
  );
  return l !== o ? l : void 0;
}
function $c(e, t) {
  return e.map(
    (o, n) => e[(t + n) % e.length]
  );
}
const kc = Jl, Sc = ec, Pc = oc, Ec = nc, Tc = rc, Rc = ic, Wr = cc, Ac = gc, Oc = vc, Nc = hc, qc = bc, jc = xc, Ur = Cc, Xr = wc, zc = _c;
var Dc = "ibaddl9", Ic = "ibaddla", Lc = "ibaddl2", Mc = "ibaddl8", Fc = "ibaddl7", Hc = "ibaddl3", Vc = "ibaddl4", Bc = "ibaddl5", Wc = "ibaddl0", Uc = "ibaddl6", Xc = "ibaddl1";
const Kc = ({
  children: e,
  className: t,
  open: o,
  defaultOpen: n,
  disabled: r,
  required: i,
  defaultValue: s,
  value: a,
  onValueChange: l,
  ...d
}) => /* @__PURE__ */ w.jsx(
  kc,
  {
    ...d,
    open: o,
    defaultOpen: n,
    disabled: r,
    required: i,
    defaultValue: s,
    value: a,
    onValueChange: l,
    children: /* @__PURE__ */ w.jsx(
      "div",
      {
        ...d,
        className: z(Wc, t),
        children: e
      }
    )
  }
), Yc = B.forwardRef(({ children: e, placeholder: t, ...o }, n) => /* @__PURE__ */ w.jsx(
  Pc,
  {
    ...o,
    ref: n,
    placeholder: t,
    children: e
  }
)), Gc = B.forwardRef(
  ({ className: e, asChild: t, ...o }, n) => /* @__PURE__ */ w.jsx(
    Ec,
    {
      ...o,
      ref: n,
      asChild: t,
      className: z(Fc, e),
      children: /* @__PURE__ */ w.jsx(Fs, { color: Is.color.slate5 })
    }
  )
), Zc = ({
  children: e,
  asChild: t,
  className: o,
  ...n
}) => /* @__PURE__ */ w.jsx(
  Sc,
  {
    ...n,
    asChild: t,
    className: z(o, Xc),
    children: e
  }
), Jc = ({
  children: e,
  className: t,
  position: o = "popper",
  side: n = "bottom",
  sideOffset: r,
  align: i,
  alignOffset: s = 0,
  avoidCollisions: a = !0,
  sticky: l = "partial",
  hideWhenDetached: d = !1,
  ...f
}) => /* @__PURE__ */ w.jsxs(
  Rc,
  {
    ...f,
    className: z(Lc, t),
    position: o,
    side: n,
    sideOffset: r,
    align: i,
    alignOffset: s,
    avoidCollisions: a,
    sticky: l,
    hideWhenDetached: d,
    children: [
      /* @__PURE__ */ w.jsx(Ur, { className: z(Ic, t), children: /* @__PURE__ */ w.jsx(Vs, {}) }),
      /* @__PURE__ */ w.jsx(Wr, { children: e }),
      /* @__PURE__ */ w.jsx(Xr, { className: z(Dc, t), children: /* @__PURE__ */ w.jsx(Hs, {}) })
    ]
  }
), Qc = B.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ w.jsxs(
  Nc,
  {
    ...o,
    ref: n,
    className: z(Hc, t),
    children: [
      /* @__PURE__ */ w.jsx(qc, { children: e }),
      /* @__PURE__ */ w.jsx(Kr, {})
    ]
  }
)), Kr = ({ className: e, ...t }) => /* @__PURE__ */ w.jsx(
  jc,
  {
    ...t,
    className: z(Vc, e)
  }
), ed = ({ className: e, ...t }) => /* @__PURE__ */ w.jsx(
  zc,
  {
    ...t,
    className: z(Uc, e)
  }
), td = ({ children: e, className: t, ...o }) => /* @__PURE__ */ w.jsx(
  Oc,
  {
    ...o,
    className: z(Bc, t),
    children: e
  }
), od = ({ children: e, className: t, ...o }) => /* @__PURE__ */ w.jsx(
  Ac,
  {
    ...o,
    className: z(Mc, t),
    children: e
  }
), de = (e) => /* @__PURE__ */ w.jsx(Kc, { ...e });
de.Trigger = Zc;
de.Value = Yc;
de.Content = Jc;
de.Item = Qc;
de.Viewport = Wr;
de.Portal = Tc;
de.Icon = Gc;
de.Indicator = Kr;
de.Separator = ed;
de.Label = td;
de.Group = od;
de.ScrollUpButton = Ur;
de.ScrollDownButton = Xr;
de.displayName = "Select";
de.Value.displayName = "Select.Value";
de.Item.displayName = "Select.Item";
de.Viewport.displayName = "Select.Viewport";
de.Portal.displayName = "Select.Portal";
de.ScrollUpButton.displayName = "Select.ScrollUpButton";
de.ScrollDownButton.displayName = "Select.ScrollDownButton";
var nd = _e({ defaultClassName: "_1yr5zenb", variantClassNames: { size: { xs: "_1yr5zen0", sm: "_1yr5zen1", md: "_1yr5zen2", lg: "_1yr5zen3", xl: "_1yr5zen4", xxl: "_1yr5zen5", "3xl": "_1yr5zen6", "4xl": "_1yr5zen7", "5xl": "_1yr5zen8", "6xl": "_1yr5zen9", "7xl": "_1yr5zena" } }, defaultVariants: { size: "sm" }, compoundVariants: [] });
const rd = D(
  ({ size: e = "sm", className: t, ...o }, n) => {
    const r = nd({ size: e });
    return /* @__PURE__ */ w.jsx(
      "div",
      {
        ...o,
        ref: n,
        className: t ? `${t} ${r}` : r
      }
    );
  }
);
rd.displayName = "Space";
const Pn = {
  1: "wrap",
  0: "nowrap"
}, id = {
  horizontal: "row",
  vertical: "column"
}, ad = (e) => e ? kr(e, (t) => id[t]) : void 0, sd = (e) => e ? typeof e == "boolean" ? Pn[1] : kr(
  e,
  // Hack to convert boolean to number since Sprinkles does not support
  // boolean responsive keys
  (t) => Pn[+t]
) : void 0, Ad = [
  "a",
  "article",
  "div",
  "form",
  "header",
  "label",
  "li",
  "main",
  "section",
  "span"
], Od = ({
  as: e = "div",
  align: t,
  children: o,
  justify: n,
  flex: r,
  direction: i = "vertical",
  space: s = "4px 4px",
  wrap: a
}) => {
  const l = ad(i), d = sd(a);
  return /* @__PURE__ */ w.jsx(
    Er,
    {
      alignItems: t,
      as: e,
      display: "flex",
      flex: r,
      flexDirection: l,
      flexWrap: d,
      gap: s,
      justifyContent: n,
      children: o
    }
  );
};
var ld = "_17w677g0", cd = _e({ defaultClassName: "_17w677g7", variantClassNames: { size: { small: "_17w677g1", medium: "_17w677g2", large: "_17w677g3" }, variant: { default: "_17w677g4", hyper: "_17w677g5", volt: "_17w677g6" } }, defaultVariants: { size: "small", variant: "default" }, compoundVariants: [] });
const dd = ({
  className: e,
  asChild: t,
  defaultChecked: o,
  checked: n,
  onCheckedChange: r,
  disabled: i,
  required: s,
  name: a,
  value: l,
  ...d
}) => /* @__PURE__ */ w.jsx(
  Ci,
  {
    ...d,
    className: z(e, ld),
    defaultChecked: o,
    checked: n,
    onCheckedChange: r,
    disabled: i,
    required: s,
    name: a,
    value: l
  }
), Yr = D(
  (e, t) => {
    const {
      className: o,
      size: n = "small",
      variant: r = "default",
      asChild: i = !1,
      ...s
    } = e;
    return /* @__PURE__ */ w.jsx(
      xi,
      {
        ...s,
        ref: t,
        asChild: i,
        className: z(o, cd({ size: n, variant: r }))
      }
    );
  }
), No = (e) => /* @__PURE__ */ w.jsx(dd, { ...e });
No.Toggle = Yr;
No.displayName = "Switch";
No.Toggle.displayName = "Switch.Toggle";
Yr.displayName = "Switch.Toggle";
var ud = _e({ defaultClassName: "fpsfqv34", variantClassNames: { font: { system: "fpsfqv0", inter: "fpsfqv1", mono: "fpsfqv2" }, size: { xs: "fpsfqv3", sm: "fpsfqv4", md: "fpsfqv5", lg: "fpsfqv6", xl: "fpsfqv7", xxl: "fpsfqv8", "3xl": "fpsfqv9", "4xl": "fpsfqva", "5xl": "fpsfqvb", "6xl": "fpsfqvc", "7xl": "fpsfqvd", "8xl": "fpsfqve", "9xl": "fpsfqvf" }, weight: { superlite: "fpsfqvg", lite: "fpsfqvh", normal: "fpsfqvi", medium: "fpsfqvj", semibold: "fpsfqvk", bold: "fpsfqvl", heavy: "fpsfqvm", black: "fpsfqvn" }, color: { transparent: "fpsfqvo", current: "fpsfqvp", white: "fpsfqvq", black: "fpsfqvr", gray100: "fpsfqvs", gray200: "fpsfqvt", gray300: "fpsfqvu", pale100: "fpsfqvv", pale200: "fpsfqvw", pale300: "fpsfqvx", pale400: "fpsfqvy", pale500: "fpsfqvz", hyper0: "fpsfqv10", hyper1: "fpsfqv11", hyper2: "fpsfqv12", hyper3: "fpsfqv13", hyper4: "fpsfqv14", hyper5: "fpsfqv15", hyper6: "fpsfqv16", hyper7: "fpsfqv17", hyper8: "fpsfqv18", hyper9: "fpsfqv19", hyper10: "fpsfqv1a", hyper11: "fpsfqv1b", hyper12: "fpsfqv1c", hyper13: "fpsfqv1d", lemon0: "fpsfqv1e", lemon1: "fpsfqv1f", lemon2: "fpsfqv1g", lemon3: "fpsfqv1h", lemon4: "fpsfqv1i", lemon5: "fpsfqv1j", lemon6: "fpsfqv1k", lemon7: "fpsfqv1l", lemon8: "fpsfqv1m", lemon9: "fpsfqv1n", lemon10: "fpsfqv1o", lemon11: "fpsfqv1p", lemon12: "fpsfqv1q", lemon13: "fpsfqv1r", slate1: "fpsfqv1s", slate2: "fpsfqv1t", slate3: "fpsfqv1u", slate4: "fpsfqv1v", slate5: "fpsfqv1w", slate6: "fpsfqv1x", slate7: "fpsfqv1y", slate8: "fpsfqv1z", slate9: "fpsfqv20", slate10: "fpsfqv21", slate11: "fpsfqv22", slate12: "fpsfqv23", slate13: "fpsfqv24", sapphire0: "fpsfqv25", sapphire1: "fpsfqv26", sapphire2: "fpsfqv27", sapphire3: "fpsfqv28", sapphire4: "fpsfqv29", sapphire5: "fpsfqv2a", sapphire6: "fpsfqv2b", sapphire7: "fpsfqv2c", sapphire8: "fpsfqv2d", sapphire9: "fpsfqv2e", sapphire10: "fpsfqv2f", sapphire11: "fpsfqv2g", sapphire12: "fpsfqv2h", sapphire13: "fpsfqv2i", volt0: "fpsfqv2j", volt1: "fpsfqv2k", volt2: "fpsfqv2l", volt3: "fpsfqv2m", volt4: "fpsfqv2n", volt5: "fpsfqv2o", volt6: "fpsfqv2p", volt7: "fpsfqv2q", volt8: "fpsfqv2r", volt9: "fpsfqv2s", volt10: "fpsfqv2t", volt11: "fpsfqv2u", volt12: "fpsfqv2v", volt13: "fpsfqv2w" }, align: { left: "fpsfqv2x", center: "fpsfqv2y", right: "fpsfqv2z" }, casing: { none: "fpsfqv30", uppercase: "fpsfqv31", lowercase: "fpsfqv32", capitalize: "fpsfqv33" } }, defaultVariants: { font: "system", size: "md", weight: "medium", color: "slate5", align: "left", casing: "none" }, compoundVariants: [] });
const fd = B.forwardRef(
  ({
    children: e,
    className: t,
    font: o = "inter",
    size: n = "md",
    align: r = "left",
    color: i = "slate5",
    weight: s = "medium",
    casing: a,
    ...l
  }, d) => /* @__PURE__ */ w.jsx(
    "p",
    {
      ref: d,
      className: z(t, ud({ font: o, size: n, align: r, color: i, weight: s, casing: a })),
      ...l,
      children: e
    }
  )
);
fd.displayName = "Text";
var gd = "fgg2xl1", pd = "fgg2xl0";
const vd = 500, md = 300, hd = !1, bd = ({ children: e, ...t }) => /* @__PURE__ */ w.jsx(
  qt.Provider,
  {
    delayDuration: vd,
    skipDelayDuration: md,
    disableHoverableContent: hd,
    children: /* @__PURE__ */ w.jsx(qt.Root, { ...t, children: e })
  }
), Gr = B.forwardRef(
  ({
    children: e,
    className: t,
    onEscapeKeyDown: o,
    onPointerDownOutside: n,
    forceMount: r,
    side: i = "right",
    sideOffset: s = 10,
    align: a = "center",
    alignOffset: l = 0,
    avoidCollisions: d = !0,
    sticky: f = "always",
    hideWhenDetached: u = !1,
    //..
    ...m
  }, p) => /* @__PURE__ */ w.jsx(
    qt.Content,
    {
      ...m,
      ref: p,
      "aria-label": "atelier-tip",
      side: i,
      sideOffset: s,
      align: a,
      alignOffset: l,
      avoidCollisions: d,
      sticky: f,
      hideWhenDetached: u,
      className: z(t, gd),
      children: e
    }
  )
), Zr = B.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ w.jsx(
    qt.Trigger,
    {
      ...t,
      ref: o,
      className: pd,
      children: e
    }
  )
), qo = (e) => /* @__PURE__ */ w.jsx(bd, { ...e });
qo.Trigger = Zr;
qo.Content = Gr;
qo.displayName = "Tip";
Zr.displayName = "TipTrigger";
Gr.displayName = "TipContent";
export {
  Fs as ArrowDownIcon,
  Ed as ArrowUpIcon,
  Xe as Avi,
  qi as Button,
  Di as Canvas,
  Ii as CanvasBlur,
  Mi as Chip,
  Hi as Container,
  Bi as Flex,
  Ui as Heading,
  Ct as HoverCard,
  To as Input,
  Pr as KitContext,
  Pd as KitProvider,
  Td as LogoIcon,
  Le as Menubar,
  ys as Paragraph,
  Cs as PassLink,
  $e as Popover,
  Er as Rect,
  Ws as Section,
  de as Select,
  Hs as SmallArrowDownIcon,
  Vs as SmallArrowUpIcon,
  rd as Space,
  Od as Stack,
  No as Switch,
  fd as Text,
  qo as Tip,
  Ds as atoms,
  Ps as base,
  $d as breakpoints,
  kd as colorModeStyle,
  ad as directionToFlexDirection,
  Es as element,
  Is as kit,
  _d as mapColorValue,
  kr as mapResponsiveValue,
  Sr as sprinkles,
  Sd as useTheme,
  Ad as validStackComponents,
  sd as wrapToFlexWrap
};
//# sourceMappingURL=index.js.map
