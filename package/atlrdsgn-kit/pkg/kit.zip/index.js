/*! 
    atelierkit© v0.3.0. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
     */
import * as T from "react";
import W, { forwardRef as V, createContext as vt, useContext as zt, useState as ee, createElement as R, useMemo as nt, useCallback as pe, Children as ut, isValidElement as Rt, cloneElement as vn, Fragment as co, useEffect as ie, useRef as de, useLayoutEffect as mn } from "react";
import * as uo from "@radix-ui/react-avatar";
import * as De from "@radix-ui/react-menubar";
import * as Ki from "react-dom";
import Yi, { flushSync as Gi, createPortal as hn } from "react-dom";
import { Thumb as Zi, Root as Ji } from "@radix-ui/react-switch";
import * as Tt from "@radix-ui/react-tooltip";
var to = { exports: {} }, ct = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Oo;
function Qi() {
  if (Oo)
    return ct;
  Oo = 1;
  var e = W, t = Symbol.for("react.element"), o = Symbol.for("react.fragment"), n = Object.prototype.hasOwnProperty, i = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, r = { key: !0, ref: !0, __self: !0, __source: !0 };
  function s(a, l, d) {
    var f, u = {}, v = null, p = null;
    d !== void 0 && (v = "" + d), l.key !== void 0 && (v = "" + l.key), l.ref !== void 0 && (p = l.ref);
    for (f in l)
      n.call(l, f) && !r.hasOwnProperty(f) && (u[f] = l[f]);
    if (a && a.defaultProps)
      for (f in l = a.defaultProps, l)
        u[f] === void 0 && (u[f] = l[f]);
    return { $$typeof: t, type: a, key: v, ref: p, props: u, _owner: i.current };
  }
  return ct.Fragment = o, ct.jsx = s, ct.jsxs = s, ct;
}
var dt = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var qo;
function er() {
  return qo || (qo = 1, process.env.NODE_ENV !== "production" && function() {
    var e = W, t = Symbol.for("react.element"), o = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), a = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), d = Symbol.for("react.suspense"), f = Symbol.for("react.suspense_list"), u = Symbol.for("react.memo"), v = Symbol.for("react.lazy"), p = Symbol.for("react.offscreen"), x = Symbol.iterator, g = "@@iterator";
    function m(c) {
      if (c === null || typeof c != "object")
        return null;
      var C = x && c[x] || c[g];
      return typeof C == "function" ? C : null;
    }
    var b = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function h(c) {
      {
        for (var C = arguments.length, k = new Array(C > 1 ? C - 1 : 0), q = 1; q < C; q++)
          k[q - 1] = arguments[q];
        y("error", c, k);
      }
    }
    function y(c, C, k) {
      {
        var q = b.ReactDebugCurrentFrame, K = q.getStackAddendum();
        K !== "" && (C += "%s", k = k.concat([K]));
        var te = k.map(function(H) {
          return String(H);
        });
        te.unshift("Warning: " + C), Function.prototype.apply.call(console[c], console, te);
      }
    }
    var w = !1, $ = !1, E = !1, S = !1, P = !1, L;
    L = Symbol.for("react.module.reference");
    function X(c) {
      return !!(typeof c == "string" || typeof c == "function" || c === n || c === r || P || c === i || c === d || c === f || S || c === p || w || $ || E || typeof c == "object" && c !== null && (c.$$typeof === v || c.$$typeof === u || c.$$typeof === s || c.$$typeof === a || c.$$typeof === l || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      c.$$typeof === L || c.getModuleId !== void 0));
    }
    function j(c, C, k) {
      var q = c.displayName;
      if (q)
        return q;
      var K = C.displayName || C.name || "";
      return K !== "" ? k + "(" + K + ")" : k;
    }
    function F(c) {
      return c.displayName || "Context";
    }
    function z(c) {
      if (c == null)
        return null;
      if (typeof c.tag == "number" && h("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof c == "function")
        return c.displayName || c.name || null;
      if (typeof c == "string")
        return c;
      switch (c) {
        case n:
          return "Fragment";
        case o:
          return "Portal";
        case r:
          return "Profiler";
        case i:
          return "StrictMode";
        case d:
          return "Suspense";
        case f:
          return "SuspenseList";
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case a:
            var C = c;
            return F(C) + ".Consumer";
          case s:
            var k = c;
            return F(k._context) + ".Provider";
          case l:
            return j(c, c.render, "ForwardRef");
          case u:
            var q = c.displayName || null;
            return q !== null ? q : z(c.type) || "Memo";
          case v: {
            var K = c, te = K._payload, H = K._init;
            try {
              return z(H(te));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var D = Object.assign, N = 0, A, J, Q, fe, oe, se, me;
    function _e() {
    }
    _e.__reactDisabledLog = !0;
    function be() {
      {
        if (N === 0) {
          A = console.log, J = console.info, Q = console.warn, fe = console.error, oe = console.group, se = console.groupCollapsed, me = console.groupEnd;
          var c = {
            configurable: !0,
            enumerable: !0,
            value: _e,
            writable: !0
          };
          Object.defineProperties(console, {
            info: c,
            log: c,
            warn: c,
            error: c,
            group: c,
            groupCollapsed: c,
            groupEnd: c
          });
        }
        N++;
      }
    }
    function ye() {
      {
        if (N--, N === 0) {
          var c = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: D({}, c, {
              value: A
            }),
            info: D({}, c, {
              value: J
            }),
            warn: D({}, c, {
              value: Q
            }),
            error: D({}, c, {
              value: fe
            }),
            group: D({}, c, {
              value: oe
            }),
            groupCollapsed: D({}, c, {
              value: se
            }),
            groupEnd: D({}, c, {
              value: me
            })
          });
        }
        N < 0 && h("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var ke = b.ReactCurrentDispatcher, O;
    function B(c, C, k) {
      {
        if (O === void 0)
          try {
            throw Error();
          } catch (K) {
            var q = K.stack.trim().match(/\n( *(at )?)/);
            O = q && q[1] || "";
          }
        return `
` + O + c;
      }
    }
    var le = !1, G;
    {
      var Z = typeof WeakMap == "function" ? WeakMap : Map;
      G = new Z();
    }
    function U(c, C) {
      if (!c || le)
        return "";
      {
        var k = G.get(c);
        if (k !== void 0)
          return k;
      }
      var q;
      le = !0;
      var K = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var te;
      te = ke.current, ke.current = null, be();
      try {
        if (C) {
          var H = function() {
            throw Error();
          };
          if (Object.defineProperty(H.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(H, []);
            } catch (qe) {
              q = qe;
            }
            Reflect.construct(c, [], H);
          } else {
            try {
              H.call();
            } catch (qe) {
              q = qe;
            }
            c.call(H.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (qe) {
            q = qe;
          }
          c();
        }
      } catch (qe) {
        if (qe && q && typeof qe.stack == "string") {
          for (var M = qe.stack.split(`
`), xe = q.stack.split(`
`), ne = M.length - 1, re = xe.length - 1; ne >= 1 && re >= 0 && M[ne] !== xe[re]; )
            re--;
          for (; ne >= 1 && re >= 0; ne--, re--)
            if (M[ne] !== xe[re]) {
              if (ne !== 1 || re !== 1)
                do
                  if (ne--, re--, re < 0 || M[ne] !== xe[re]) {
                    var $e = `
` + M[ne].replace(" at new ", " at ");
                    return c.displayName && $e.includes("<anonymous>") && ($e = $e.replace("<anonymous>", c.displayName)), typeof c == "function" && G.set(c, $e), $e;
                  }
                while (ne >= 1 && re >= 0);
              break;
            }
        }
      } finally {
        le = !1, ke.current = te, ye(), Error.prepareStackTrace = K;
      }
      var Je = c ? c.displayName || c.name : "", Ao = Je ? B(Je) : "";
      return typeof c == "function" && G.set(c, Ao), Ao;
    }
    function he(c, C, k) {
      return U(c, !1);
    }
    function ge(c) {
      var C = c.prototype;
      return !!(C && C.isReactComponent);
    }
    function Te(c, C, k) {
      if (c == null)
        return "";
      if (typeof c == "function")
        return U(c, ge(c));
      if (typeof c == "string")
        return B(c);
      switch (c) {
        case d:
          return B("Suspense");
        case f:
          return B("SuspenseList");
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case l:
            return he(c.render);
          case u:
            return Te(c.type, C, k);
          case v: {
            var q = c, K = q._payload, te = q._init;
            try {
              return Te(te(K), C, k);
            } catch {
            }
          }
        }
      return "";
    }
    var Ae = Object.prototype.hasOwnProperty, Le = {}, bt = b.ReactDebugCurrentFrame;
    function Ye(c) {
      if (c) {
        var C = c._owner, k = Te(c.type, c._source, C ? C.type : null);
        bt.setExtraStackFrame(k);
      } else
        bt.setExtraStackFrame(null);
    }
    function Ge(c, C, k, q, K) {
      {
        var te = Function.call.bind(Ae);
        for (var H in c)
          if (te(c, H)) {
            var M = void 0;
            try {
              if (typeof c[H] != "function") {
                var xe = Error((q || "React class") + ": " + k + " type `" + H + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof c[H] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw xe.name = "Invariant Violation", xe;
              }
              M = c[H](C, H, q, k, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (ne) {
              M = ne;
            }
            M && !(M instanceof Error) && (Ye(K), h("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", q || "React class", k, H, typeof M), Ye(null)), M instanceof Error && !(M.message in Le) && (Le[M.message] = !0, Ye(K), h("Failed %s type: %s", k, M.message), Ye(null));
          }
      }
    }
    var Ri = Array.isArray;
    function Vt(c) {
      return Ri(c);
    }
    function Ti(c) {
      {
        var C = typeof Symbol == "function" && Symbol.toStringTag, k = C && c[Symbol.toStringTag] || c.constructor.name || "Object";
        return k;
      }
    }
    function Ai(c) {
      try {
        return Co(c), !1;
      } catch {
        return !0;
      }
    }
    function Co(c) {
      return "" + c;
    }
    function wo(c) {
      if (Ai(c))
        return h("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Ti(c)), Co(c);
    }
    var lt = b.ReactCurrentOwner, Oi = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, _o, ko, Ht;
    Ht = {};
    function qi(c) {
      if (Ae.call(c, "ref")) {
        var C = Object.getOwnPropertyDescriptor(c, "ref").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.ref !== void 0;
    }
    function ji(c) {
      if (Ae.call(c, "key")) {
        var C = Object.getOwnPropertyDescriptor(c, "key").get;
        if (C && C.isReactWarning)
          return !1;
      }
      return c.key !== void 0;
    }
    function zi(c, C) {
      if (typeof c.ref == "string" && lt.current && C && lt.current.stateNode !== C) {
        var k = z(lt.current.type);
        Ht[k] || (h('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', z(lt.current.type), c.ref), Ht[k] = !0);
      }
    }
    function Ni(c, C) {
      {
        var k = function() {
          _o || (_o = !0, h("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "key", {
          get: k,
          configurable: !0
        });
      }
    }
    function Di(c, C) {
      {
        var k = function() {
          ko || (ko = !0, h("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", C));
        };
        k.isReactWarning = !0, Object.defineProperty(c, "ref", {
          get: k,
          configurable: !0
        });
      }
    }
    var Ii = function(c, C, k, q, K, te, H) {
      var M = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: t,
        // Built-in properties that belong on the element
        type: c,
        key: C,
        ref: k,
        props: H,
        // Record the component responsible for creating this element.
        _owner: te
      };
      return M._store = {}, Object.defineProperty(M._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(M, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: q
      }), Object.defineProperty(M, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: K
      }), Object.freeze && (Object.freeze(M.props), Object.freeze(M)), M;
    };
    function Li(c, C, k, q, K) {
      {
        var te, H = {}, M = null, xe = null;
        k !== void 0 && (wo(k), M = "" + k), ji(C) && (wo(C.key), M = "" + C.key), qi(C) && (xe = C.ref, zi(C, K));
        for (te in C)
          Ae.call(C, te) && !Oi.hasOwnProperty(te) && (H[te] = C[te]);
        if (c && c.defaultProps) {
          var ne = c.defaultProps;
          for (te in ne)
            H[te] === void 0 && (H[te] = ne[te]);
        }
        if (M || xe) {
          var re = typeof c == "function" ? c.displayName || c.name || "Unknown" : c;
          M && Ni(H, re), xe && Di(H, re);
        }
        return Ii(c, M, xe, K, q, lt.current, H);
      }
    }
    var Bt = b.ReactCurrentOwner, $o = b.ReactDebugCurrentFrame;
    function Ze(c) {
      if (c) {
        var C = c._owner, k = Te(c.type, c._source, C ? C.type : null);
        $o.setExtraStackFrame(k);
      } else
        $o.setExtraStackFrame(null);
    }
    var Wt;
    Wt = !1;
    function Xt(c) {
      return typeof c == "object" && c !== null && c.$$typeof === t;
    }
    function So() {
      {
        if (Bt.current) {
          var c = z(Bt.current.type);
          if (c)
            return `

Check the render method of \`` + c + "`.";
        }
        return "";
      }
    }
    function Mi(c) {
      {
        if (c !== void 0) {
          var C = c.fileName.replace(/^.*[\\\/]/, ""), k = c.lineNumber;
          return `

Check your code at ` + C + ":" + k + ".";
        }
        return "";
      }
    }
    var Eo = {};
    function Fi(c) {
      {
        var C = So();
        if (!C) {
          var k = typeof c == "string" ? c : c.displayName || c.name;
          k && (C = `

Check the top-level render call using <` + k + ">.");
        }
        return C;
      }
    }
    function Po(c, C) {
      {
        if (!c._store || c._store.validated || c.key != null)
          return;
        c._store.validated = !0;
        var k = Fi(C);
        if (Eo[k])
          return;
        Eo[k] = !0;
        var q = "";
        c && c._owner && c._owner !== Bt.current && (q = " It was passed a child from " + z(c._owner.type) + "."), Ze(c), h('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', k, q), Ze(null);
      }
    }
    function Ro(c, C) {
      {
        if (typeof c != "object")
          return;
        if (Vt(c))
          for (var k = 0; k < c.length; k++) {
            var q = c[k];
            Xt(q) && Po(q, C);
          }
        else if (Xt(c))
          c._store && (c._store.validated = !0);
        else if (c) {
          var K = m(c);
          if (typeof K == "function" && K !== c.entries)
            for (var te = K.call(c), H; !(H = te.next()).done; )
              Xt(H.value) && Po(H.value, C);
        }
      }
    }
    function Vi(c) {
      {
        var C = c.type;
        if (C == null || typeof C == "string")
          return;
        var k;
        if (typeof C == "function")
          k = C.propTypes;
        else if (typeof C == "object" && (C.$$typeof === l || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        C.$$typeof === u))
          k = C.propTypes;
        else
          return;
        if (k) {
          var q = z(C);
          Ge(k, c.props, "prop", q, c);
        } else if (C.PropTypes !== void 0 && !Wt) {
          Wt = !0;
          var K = z(C);
          h("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", K || "Unknown");
        }
        typeof C.getDefaultProps == "function" && !C.getDefaultProps.isReactClassApproved && h("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function Hi(c) {
      {
        for (var C = Object.keys(c.props), k = 0; k < C.length; k++) {
          var q = C[k];
          if (q !== "children" && q !== "key") {
            Ze(c), h("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", q), Ze(null);
            break;
          }
        }
        c.ref !== null && (Ze(c), h("Invalid attribute `ref` supplied to `React.Fragment`."), Ze(null));
      }
    }
    function To(c, C, k, q, K, te) {
      {
        var H = X(c);
        if (!H) {
          var M = "";
          (c === void 0 || typeof c == "object" && c !== null && Object.keys(c).length === 0) && (M += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var xe = Mi(K);
          xe ? M += xe : M += So();
          var ne;
          c === null ? ne = "null" : Vt(c) ? ne = "array" : c !== void 0 && c.$$typeof === t ? (ne = "<" + (z(c.type) || "Unknown") + " />", M = " Did you accidentally export a JSX literal instead of a component?") : ne = typeof c, h("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", ne, M);
        }
        var re = Li(c, C, k, K, te);
        if (re == null)
          return re;
        if (H) {
          var $e = C.children;
          if ($e !== void 0)
            if (q)
              if (Vt($e)) {
                for (var Je = 0; Je < $e.length; Je++)
                  Ro($e[Je], c);
                Object.freeze && Object.freeze($e);
              } else
                h("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              Ro($e, c);
        }
        return c === n ? Hi(re) : Vi(re), re;
      }
    }
    function Bi(c, C, k) {
      return To(c, C, k, !0);
    }
    function Wi(c, C, k) {
      return To(c, C, k, !1);
    }
    var Xi = Wi, Ui = Bi;
    dt.Fragment = n, dt.jsx = Xi, dt.jsxs = Ui;
  }()), dt;
}
process.env.NODE_ENV === "production" ? to.exports = Qi() : to.exports = er();
var _ = to.exports;
function tr(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function or(e) {
  var t = tr(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function nr(e, t, o) {
  return t = or(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function jo(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function zo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? jo(Object(o), !0).forEach(function(n) {
      nr(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : jo(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var ir = (e, t, o) => {
  for (var n of Object.keys(e)) {
    var i;
    if (e[n] !== ((i = t[n]) !== null && i !== void 0 ? i : o[n]))
      return !1;
  }
  return !0;
}, we = (e) => {
  var t = (o) => {
    var n = e.defaultClassName, i = zo(zo({}, e.defaultVariants), o);
    for (var r in i) {
      var s, a = (s = i[r]) !== null && s !== void 0 ? s : e.defaultVariants[r];
      if (a != null) {
        var l = a;
        typeof l == "boolean" && (l = l === !0 ? "true" : "false");
        var d = (
          // @ts-expect-error
          e.variantClassNames[r][l]
        );
        d && (n += " " + d);
      }
    }
    for (var [f, u] of e.compoundVariants)
      ir(f, i, e.defaultVariants) && (n += " " + u);
    return n;
  };
  return t.variants = () => Object.keys(e.variantClassNames), t;
}, rr = we({ defaultClassName: "_1bycfvg9", variantClassNames: { size: { xs: "_1bycfvg2", sm: "_1bycfvg3", md: "_1bycfvg4", lg: "_1bycfvg5" }, shape: { circle: "_1bycfvg6", square: "_1bycfvg7", rounded: "_1bycfvg8" } }, defaultVariants: { size: "sm", shape: "rounded" }, compoundVariants: [] }), xn = "_1bycfvg0", ar = "_1bycfvg1";
function bn(e) {
  var t, o, n = "";
  if (typeof e == "string" || typeof e == "number")
    n += e;
  else if (typeof e == "object")
    if (Array.isArray(e))
      for (t = 0; t < e.length; t++)
        e[t] && (o = bn(e[t])) && (n && (n += " "), n += o);
    else
      for (t in e)
        e[t] && (n && (n += " "), n += t);
  return n;
}
function I() {
  for (var e, t, o = 0, n = ""; o < arguments.length; )
    (e = arguments[o++]) && (t = bn(e)) && (n && (n += " "), n += t);
  return n;
}
const yn = uo.Image, sr = uo.Fallback, lr = W.forwardRef(
  ({ className: e, size: t = "xs", shape: o = "rounded", ...n }, i) => /* @__PURE__ */ _.jsx(
    uo.Root,
    {
      ...n,
      ref: i,
      className: I(rr({ size: t, shape: o }), e)
    }
  )
), Cn = W.forwardRef(
  ({ className: e, ...t }, o) => /* @__PURE__ */ _.jsx(
    sr,
    {
      ...t,
      ref: o,
      className: I(ar, e)
    }
  )
), wn = W.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ _.jsx(
  yn,
  {
    ...t,
    ref: o,
    className: I(xn, e)
  }
)), cr = "https://cdn.atlrdsgn.com/assets/github/atlrdsgn/A2.jpg", _n = W.forwardRef(({ className: e, ...t }, o) => /* @__PURE__ */ _.jsx(
  yn,
  {
    ...t,
    ref: o,
    src: cr,
    className: I(xn, e)
  }
)), We = (e) => /* @__PURE__ */ _.jsx(lr, { ...e });
We.Fallback = Cn;
We.Image = wn;
We.Demo = _n;
We.displayName = "Avi";
We.Fallback.displayName = "AviFallback";
We.Image.displayName = "AviImage";
We.Demo.displayName = "AviDemoImage";
Cn.displayName = "AviFallback";
wn.displayName = "AviImage";
_n.displayName = "AviDemoImage";
var dr = we({ defaultClassName: "aefdx68", variantClassNames: { size: { xs: "aefdx60", sm: "aefdx61", md: "aefdx62", lg: "aefdx63" }, variant: { slate: "aefdx64", jade: "aefdx65", hyper: "aefdx66", neon: "aefdx67" } }, defaultVariants: { size: "sm", variant: "slate" }, compoundVariants: [] });
const ur = ({
  children: e,
  type: t = "button",
  as: o = "a",
  onClick: n = () => {
  },
  href: i,
  target: r = "_self",
  rel: s = "noopener noreferrer",
  size: a = "sm",
  variant: l = "hyper",
  ...d
}) => {
  const f = (u) => {
    i ? (u.preventDefault(), window.open(i, r, s)) : u.preventDefault(), n(u);
  };
  return /* @__PURE__ */ _.jsx(
    "button",
    {
      ...d,
      type: t,
      className: dr({ size: a, variant: l }),
      onClick: f,
      children: e
    }
  );
};
ur.displayName = "Button";
var fr = "_1dqe6mp0", gr = "_1dqe6mp1";
const pr = W.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: o,
      className: I(fr),
      ...t,
      children: e
    }
  )
), vr = W.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: o,
      className: I(gr),
      ...t,
      children: e
    }
  )
);
pr.displayName = "Canvas";
vr.displayName = "Blurred-Canvas";
var mr = we({ defaultClassName: "_1yx7lz87", variantClassNames: { size: { xsmall: "_1yx7lz80", small: "_1yx7lz81", medium: "_1yx7lz82" }, shape: { rounded: "_1yx7lz83", pill: "_1yx7lz84" }, variant: { slate: "_1yx7lz85", hyper: "_1yx7lz86" } }, defaultVariants: { size: "small", shape: "pill", variant: "slate" }, compoundVariants: [] });
const hr = ({
  children: e,
  className: t,
  size: o = "small",
  shape: n = "pill",
  variant: i = "slate",
  ...r
}) => /* @__PURE__ */ _.jsx(
  "span",
  {
    ...r,
    className: I(t, mr({ size: o, shape: n, variant: i })),
    children: e
  }
);
hr.displayName = "Chip";
var xr = we({ defaultClassName: "zhlr5ea", variantClassNames: { align: { start: "zhlr5e6", center: "zhlr5e7", end: "zhlr5e8" }, width: { small: "zhlr5e0", medium: "zhlr5e1", large: "zhlr5e2", xlarge: "zhlr5e3", max: "zhlr5e4", full: "zhlr5e5" }, border: { true: "zhlr5e9" } }, defaultVariants: { align: "start", width: "max", border: !1 }, compoundVariants: [] });
const br = ({
  children: e,
  className: t,
  width: o = "max",
  align: n = "start",
  border: i = !1,
  ...r
}) => /* @__PURE__ */ _.jsx(
  "div",
  {
    ...r,
    className: I(t, xr({ width: o, align: n, border: i })),
    children: e
  }
);
br.displayName = "Container";
var yr = we({ defaultClassName: "_18w0vmkl", variantClassNames: { direction: { row: "_18w0vmk0", column: "_18w0vmk1", rowReverse: "_18w0vmk2", columnReverse: "_18w0vmk3" }, align: { start: "_18w0vmk4", center: "_18w0vmk5", end: "_18w0vmk6", stretch: "_18w0vmk7", baseline: "_18w0vmk8" }, justify: { start: "_18w0vmk9", center: "_18w0vmka", end: "_18w0vmkb", between: "_18w0vmkc" }, gap: { xs: "_18w0vmkd", sm: "_18w0vmke", md: "_18w0vmkf", lg: "_18w0vmkg", xl: "_18w0vmkh" }, wrap: { wrap: "_18w0vmki", nowrap: "_18w0vmkj", wrapReverse: "_18w0vmkk" } }, defaultVariants: { direction: "row", align: "start", justify: "start", gap: "sm", wrap: "wrap" }, compoundVariants: [] });
const Cr = W.forwardRef(
  ({
    children: e,
    direction: t = "row",
    align: o = "center",
    justify: n = "center",
    gap: i = "sm",
    ...r
    //..
  }, s) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ...r,
      ref: s,
      className: yr({ direction: t, align: o, justify: n, gap: i }),
      children: e
    }
  )
);
Cr.displayName = "Flex";
var wr = we({ defaultClassName: "_1n0su94l", variantClassNames: { font: { system: "_1n0su940", sf: "_1n0su941", mono: "_1n0su942" }, size: { display: "_1n0su943", H1: "_1n0su944", H2: "_1n0su945", H3: "_1n0su946", H4: "_1n0su947", H5: "_1n0su948", H6: "_1n0su949" }, weight: { superlite: "_1n0su94a", lite: "_1n0su94b", normal: "_1n0su94c", medium: "_1n0su94d", semibold: "_1n0su94e", bold: "_1n0su94f", heavy: "_1n0su94g", black: "_1n0su94h" }, align: { left: "_1n0su94i", center: "_1n0su94j", right: "_1n0su94k" } }, defaultVariants: { font: "system", size: "H1", weight: "semibold", align: "left" }, compoundVariants: [] });
const _r = W.forwardRef(
  ({
    className: e,
    font: t = "system",
    size: o = "H1",
    weight: n = "semibold",
    align: i = "left",
    ...r
  }, s) => /* @__PURE__ */ _.jsx(
    "h1",
    {
      ...r,
      ref: s,
      className: I(e, wr({ font: t, size: o, weight: n, align: i }))
    }
  )
);
_r.displayName = "Heading";
var kr = we({ defaultClassName: "_1l37a3c6", variantClassNames: { size: { small: "_1l37a3c2", medium: "_1l37a3c3" }, variant: { slate: "_1l37a3c4", hyper: "_1l37a3c5" } }, defaultVariants: { size: "medium", variant: "slate" }, compoundVariants: [] }), $r = "_1l37a3c1", Sr = "_1l37a3c0";
const kn = V(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: n,
      className: I(t, Sr),
      ...o,
      children: e
    }
  )
), $n = V(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    "label",
    {
      ref: n,
      className: I(t, $r),
      ...o,
      children: /* @__PURE__ */ _.jsx("span", { children: e })
    }
  )
), Er = V(
  ({ className: e, size: t = "medium", variant: o = "slate", ...n }, i) => /* @__PURE__ */ _.jsx(
    "input",
    {
      ref: i,
      className: I(e, kr({ size: t, variant: o })),
      ...n
    }
  )
), fo = (e) => /* @__PURE__ */ _.jsx(Er, { ...e });
fo.Flex = kn;
fo.Label = $n;
fo.displayName = "Input";
kn.displayName = "Input.Flex";
$n.displayName = "Input.Label";
var Pr = "d9r7gl3", Rr = "d9r7gl2", Tr = "d9r7gl0", Ar = "d9r7gl1", Or = "d9r7gl5", qr = "d9r7gl4";
const Sn = De.Menu, En = De.Sub, Pn = De.Portal, jr = W.forwardRef(
  ({ children: e, className: t, loop: o = !0, ...n }, i) => /* @__PURE__ */ _.jsx(
    De.Root,
    {
      ...n,
      ref: i,
      className: I(t, Tr),
      loop: o,
      children: e
    }
  )
), Rn = W.forwardRef(
  ({ children: e, className: t, side: o = "bottom", sideOffset: n = 10, ...i }, r) => /* @__PURE__ */ _.jsx(
    De.Content,
    {
      ...i,
      ref: r,
      className: I(t, Pr),
      side: o,
      sideOffset: n,
      children: e
    }
  )
), Tn = W.forwardRef(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    De.Item,
    {
      ...o,
      ref: n,
      className: I(t, Rr),
      children: e
    }
  )
), An = W.forwardRef(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    De.Trigger,
    {
      ...o,
      ref: n,
      className: I(t, Ar),
      children: e
    }
  )
), On = W.forwardRef(
  ({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    De.SubTrigger,
    {
      ...o,
      ref: n,
      className: I(t, qr),
      children: e
    }
  )
), qn = W.forwardRef(
  ({ children: e, className: t, sideOffset: o = 10, ...n }, i) => /* @__PURE__ */ _.jsx(
    De.SubContent,
    {
      ...n,
      ref: i,
      className: I(t, Or),
      sideOffset: o,
      children: e
    }
  )
), Ie = (e) => /* @__PURE__ */ _.jsx(jr, { ...e });
Ie.displayName = "Menubar";
Ie.Menu = Sn;
Ie.Trigger = An;
Ie.Content = Rn;
Ie.Item = Tn;
Ie.SubMenu = En;
Ie.SubTrigger = On;
Ie.SubContent = qn;
Ie.Portal = Pn;
Sn.displayName = "Menubar-Menu";
An.displayName = "Menubar-Trigger";
Rn.displayName = "Menubar-Content";
Tn.displayName = "Menubar-Item";
En.displayName = "Menubar-SubMenu";
On.displayName = "Menubar-SubTrigger";
qn.displayName = "Menubar-SubContent";
Pn.displayName = "Menubar-Portal";
var zr = we({ defaultClassName: "qohxgz2s", variantClassNames: { size: { xs: "qohxgz0", sm: "qohxgz1", md: "qohxgz2", lg: "qohxgz3", xl: "qohxgz4" }, color: { transparent: "qohxgz5", current: "qohxgz6", white: "qohxgz7", black: "qohxgz8", gray100: "qohxgz9", gray200: "qohxgza", gray300: "qohxgzb", pale100: "qohxgzc", pale200: "qohxgzd", pale300: "qohxgze", pale400: "qohxgzf", pale500: "qohxgzg", hyper0: "qohxgzh", hyper1: "qohxgzi", hyper2: "qohxgzj", hyper3: "qohxgzk", hyper4: "qohxgzl", hyper5: "qohxgzm", hyper6: "qohxgzn", hyper7: "qohxgzo", hyper8: "qohxgzp", hyper9: "qohxgzq", hyper10: "qohxgzr", hyper11: "qohxgzs", hyper12: "qohxgzt", hyper13: "qohxgzu", lemon0: "qohxgzv", lemon1: "qohxgzw", lemon2: "qohxgzx", lemon3: "qohxgzy", lemon4: "qohxgzz", lemon5: "qohxgz10", lemon6: "qohxgz11", lemon7: "qohxgz12", lemon8: "qohxgz13", lemon9: "qohxgz14", lemon10: "qohxgz15", lemon11: "qohxgz16", lemon12: "qohxgz17", lemon13: "qohxgz18", slate1: "qohxgz19", slate2: "qohxgz1a", slate3: "qohxgz1b", slate4: "qohxgz1c", slate5: "qohxgz1d", slate6: "qohxgz1e", slate7: "qohxgz1f", slate8: "qohxgz1g", slate9: "qohxgz1h", slate10: "qohxgz1i", slate11: "qohxgz1j", slate12: "qohxgz1k", slate13: "qohxgz1l", sapphire0: "qohxgz1m", sapphire1: "qohxgz1n", sapphire2: "qohxgz1o", sapphire3: "qohxgz1p", sapphire4: "qohxgz1q", sapphire5: "qohxgz1r", sapphire6: "qohxgz1s", sapphire7: "qohxgz1t", sapphire8: "qohxgz1u", sapphire9: "qohxgz1v", sapphire10: "qohxgz1w", sapphire11: "qohxgz1x", sapphire12: "qohxgz1y", sapphire13: "qohxgz1z", volt0: "qohxgz20", volt1: "qohxgz21", volt2: "qohxgz22", volt3: "qohxgz23", volt4: "qohxgz24", volt5: "qohxgz25", volt6: "qohxgz26", volt7: "qohxgz27", volt8: "qohxgz28", volt9: "qohxgz29", volt10: "qohxgz2a", volt11: "qohxgz2b", volt12: "qohxgz2c", volt13: "qohxgz2d" }, weight: { superlite: "qohxgz2e", lite: "qohxgz2f", normal: "qohxgz2g", medium: "qohxgz2h", semibold: "qohxgz2i", bold: "qohxgz2j", heavy: "qohxgz2k", black: "qohxgz2l" }, align: { left: "qohxgz2m", center: "qohxgz2n", right: "qohxgz2o" }, font: { system: "qohxgz2p", inter: "qohxgz2q", mono: "qohxgz2r" } }, defaultVariants: { size: "sm", color: "slate12", weight: "normal", align: "left", font: "system" }, compoundVariants: [] });
const Nr = V(
  ({ children: e, className: t, size: o, color: n, weight: i, align: r, font: s, ...a }, l) => /* @__PURE__ */ _.jsx(
    "p",
    {
      ref: l,
      className: I(t, zr({ size: o, color: n, weight: i, align: r, font: s })),
      ...a,
      children: e
    }
  )
);
Nr.displayName = "Paragraph";
var Dr = we({ defaultClassName: "_1g4z5m4c", variantClassNames: { size: { xs: "_1g4z5m40", sm: "_1g4z5m41", md: "_1g4z5m42", lg: "_1g4z5m43", xl: "_1g4z5m44", xxl: "_1g4z5m45" }, variant: { inherit: "_1g4z5m46", primary: "_1g4z5m47", secondary: "_1g4z5m48" }, font: { inherit: "_1g4z5m49", system: "_1g4z5m4a", mono: "_1g4z5m4b" } }, defaultVariants: { size: "sm", variant: "primary" }, compoundVariants: [] });
const Ir = V(
  ({
    children: e,
    className: t,
    href: o,
    variant: n,
    target: i = "_self",
    size: r = "sm",
    font: s = "inherit",
    ...a
  }, l) => /* @__PURE__ */ _.jsx(
    "a",
    {
      ref: l,
      href: o,
      target: i,
      className: I(Dr({ size: r, variant: n }), t),
      ...a,
      children: e
    }
  )
);
Ir.displayName = "PassLink";
var Lr = "ltqw8z0", Mr = { article: "ltqw8z1", aside: "ltqw8z1", details: "ltqw8z1", figcaption: "ltqw8z1", figure: "ltqw8z1", footer: "ltqw8z1", header: "ltqw8z1", hgroup: "ltqw8z1", menu: "ltqw8z1", nav: "ltqw8z1", section: "ltqw8z1", ul: "ltqw8z3", ol: "ltqw8z3", blockquote: "ltqw8z4", q: "ltqw8z4", body: "ltqw8z2", a: "ltqw8zg", table: "ltqw8z5", mark: "ltqw8za ltqw8z7", select: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zb", button: "ltqw8z7", textarea: "ltqw8z1 ltqw8z6 ltqw8z8", input: "ltqw8z1 ltqw8z6 ltqw8z8 ltqw8zd" };
function Fr(e, t) {
  return Object.defineProperty(e, "__recipe__", {
    value: t,
    writable: !1
  }), e;
}
var jn = Fr;
function Vr(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  function o(n) {
    if (typeof n == "string" || typeof n == "number" || typeof n == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return {
        [t.defaultCondition]: n
      };
    }
    if (Array.isArray(n)) {
      if (!("responsiveArray" in t))
        throw new Error("Responsive arrays are not supported");
      var i = {};
      for (var r in t.responsiveArray)
        n[r] != null && (i[t.responsiveArray[r]] = n[r]);
      return i;
    }
    return n;
  }
  return jn(o, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createNormalizeValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function zn(e) {
  var {
    conditions: t
  } = e;
  if (!t)
    throw new Error("Styles have no conditions");
  var o = Vr(e);
  function n(i, r) {
    if (typeof i == "string" || typeof i == "number" || typeof i == "boolean") {
      if (!t.defaultCondition)
        throw new Error("No default condition");
      return r(i, t.defaultCondition);
    }
    var s = Array.isArray(i) ? o(i) : i, a = {};
    for (var l in s)
      s[l] != null && (a[l] = r(s[l], l));
    return a;
  }
  return jn(n, {
    importPath: "@vanilla-extract/sprinkles/createUtils",
    importName: "createMapValueFn",
    args: [{
      conditions: e.conditions
    }]
  });
}
function Hr(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var o = e[Symbol.toPrimitive];
  if (o !== void 0) {
    var n = o.call(e, t || "default");
    if (typeof n != "object")
      return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Br(e) {
  var t = Hr(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function Wr(e, t, o) {
  return t = Br(t), t in e ? Object.defineProperty(e, t, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = o, e;
}
function No(e, t) {
  var o = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), o.push.apply(o, n);
  }
  return o;
}
function Ut(e) {
  for (var t = 1; t < arguments.length; t++) {
    var o = arguments[t] != null ? arguments[t] : {};
    t % 2 ? No(Object(o), !0).forEach(function(n) {
      Wr(e, n, o[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : No(Object(o)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(o, n));
    });
  }
  return e;
}
var Xr = (e) => function() {
  for (var t = arguments.length, o = new Array(t), n = 0; n < t; n++)
    o[n] = arguments[n];
  var i = Object.assign({}, ...o.map((l) => l.styles)), r = Object.keys(i), s = r.filter((l) => "mappings" in i[l]), a = (l) => {
    var d = [], f = {}, u = Ut({}, l), v = !1;
    for (var p of s) {
      var x = l[p];
      if (x != null) {
        var g = i[p];
        v = !0;
        for (var m of g.mappings)
          f[m] = x, u[m] == null && delete u[m];
      }
    }
    var b = v ? Ut(Ut({}, f), u) : l, h = function() {
      var E = b[y], S = i[y];
      try {
        if (S.mappings)
          return "continue";
        if (typeof E == "string" || typeof E == "number") {
          if (process.env.NODE_ENV !== "production" && !S.values[E].defaultClass)
            throw new Error();
          d.push(S.values[E].defaultClass);
        } else if (Array.isArray(E))
          for (var P = 0; P < E.length; P++) {
            var L = E[P];
            if (L != null) {
              var X = S.responsiveArray[P];
              if (process.env.NODE_ENV !== "production" && !S.values[L].conditions[X])
                throw new Error();
              d.push(S.values[L].conditions[X]);
            }
          }
        else
          for (var j in E) {
            var F = E[j];
            if (F != null) {
              if (process.env.NODE_ENV !== "production" && !S.values[F].conditions[j])
                throw new Error();
              d.push(S.values[F].conditions[j]);
            }
          }
      } catch (fe) {
        if (process.env.NODE_ENV !== "production") {
          class oe extends Error {
            constructor(me) {
              super(me), this.name = "SprinklesError";
            }
          }
          var z = (se) => typeof se == "string" ? '"'.concat(se, '"') : se, D = (se, me, _e) => {
            throw new oe('"'.concat(se, '" has no value ').concat(z(me), ". Possible values are ").concat(Object.keys(_e).map(z).join(", ")));
          };
          if (!S)
            throw new oe('"'.concat(y, '" is not a valid sprinkle'));
          if ((typeof E == "string" || typeof E == "number") && (E in S.values || D(y, E, S.values), !S.values[E].defaultClass))
            throw new oe('"'.concat(y, '" has no default condition. You must specify which conditions to target explicitly. Possible options are ').concat(Object.keys(S.values[E].conditions).map(z).join(", ")));
          if (typeof E == "object") {
            if (!("conditions" in S.values[Object.keys(S.values)[0]]))
              throw new oe('"'.concat(y, '" is not a conditional property'));
            if (Array.isArray(E)) {
              if (!("responsiveArray" in S))
                throw new oe('"'.concat(y, '" does not support responsive arrays'));
              var N = S.responsiveArray.length;
              if (N < E.length)
                throw new oe('"'.concat(y, '" only supports up to ').concat(N, " breakpoints. You passed ").concat(E.length));
              for (var A of E)
                S.values[A] || D(y, A, S.values);
            } else
              for (var J in E) {
                var Q = E[J];
                if (Q != null && (S.values[Q] || D(y, Q, S.values), !S.values[Q].conditions[J]))
                  throw new oe('"'.concat(y, '" has no condition named ').concat(z(J), ". Possible values are ").concat(Object.keys(S.values[Q].conditions).map(z).join(", ")));
              }
          }
        }
        throw fe;
      }
    };
    for (var y in b)
      var w = h();
    return e(d.join(" "));
  };
  return Object.assign(a, {
    properties: new Set(r)
  });
}, Ur = (e) => e, Kr = function() {
  return Xr(Ur)(...arguments);
}, $c = zn({ conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 } }), Nn = zn({ conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] } }), Dn = Kr(function() {
  var e = { conditions: { defaultCondition: "small", conditionNames: ["small", "medium", "large", "xlarge"], responsiveArray: ["small", "medium", "large", "xlarge"] }, styles: { all: { values: { unset: { conditions: { small: "i77g9o0", medium: "i77g9o1", large: "i77g9o2", xlarge: "i77g9o3" }, defaultClass: "i77g9o0" } }, responsiveArray: void 0 }, boxSizing: { values: { "border-box": { conditions: { small: "i77g9o4", medium: "i77g9o5", large: "i77g9o6", xlarge: "i77g9o7" }, defaultClass: "i77g9o4" } }, responsiveArray: void 0 }, appearance: { values: { none: { conditions: { small: "i77g9o8", medium: "i77g9o9", large: "i77g9oa", xlarge: "i77g9ob" }, defaultClass: "i77g9o8" } }, responsiveArray: void 0 }, outline: { values: { none: { conditions: { small: "i77g9oc", medium: "i77g9od", large: "i77g9oe", xlarge: "i77g9of" }, defaultClass: "i77g9oc" } }, responsiveArray: void 0 }, userSelect: { values: { none: { conditions: { small: "i77g9og", medium: "i77g9oh", large: "i77g9oi", xlarge: "i77g9oj" }, defaultClass: "i77g9og" }, auto: { conditions: { small: "i77g9ok", medium: "i77g9ol", large: "i77g9om", xlarge: "i77g9on" }, defaultClass: "i77g9ok" } }, responsiveArray: void 0 }, fontVariantNumeric: { values: { "tabular-nums": { conditions: { small: "i77g9oo", medium: "i77g9op", large: "i77g9oq", xlarge: "i77g9or" }, defaultClass: "i77g9oo" } }, responsiveArray: void 0 }, WebkitTapHighlightColor: { values: { "rgba(0,0,0,0)": { conditions: { small: "i77g9os", medium: "i77g9ot", large: "i77g9ou", xlarge: "i77g9ov" }, defaultClass: "i77g9os" } }, responsiveArray: void 0 }, display: { values: { none: { conditions: { small: "i77g9ow", medium: "i77g9ox", large: "i77g9oy", xlarge: "i77g9oz" }, defaultClass: "i77g9ow" }, flex: { conditions: { small: "i77g9o10", medium: "i77g9o11", large: "i77g9o12", xlarge: "i77g9o13" }, defaultClass: "i77g9o10" }, block: { conditions: { small: "i77g9o14", medium: "i77g9o15", large: "i77g9o16", xlarge: "i77g9o17" }, defaultClass: "i77g9o14" }, "inline-block": { conditions: { small: "i77g9o18", medium: "i77g9o19", large: "i77g9o1a", xlarge: "i77g9o1b" }, defaultClass: "i77g9o18" }, "inline-flex": { conditions: { small: "i77g9o1c", medium: "i77g9o1d", large: "i77g9o1e", xlarge: "i77g9o1f" }, defaultClass: "i77g9o1c" }, inline: { conditions: { small: "i77g9o1g", medium: "i77g9o1h", large: "i77g9o1i", xlarge: "i77g9o1j" }, defaultClass: "i77g9o1g" } }, responsiveArray: void 0 }, flex: { values: { 1: { conditions: { small: "i77g9o1k", medium: "i77g9o1l", large: "i77g9o1m", xlarge: "i77g9o1n" }, defaultClass: "i77g9o1k" }, auto: { conditions: { small: "i77g9o1o", medium: "i77g9o1p", large: "i77g9o1q", xlarge: "i77g9o1r" }, defaultClass: "i77g9o1o" }, initial: { conditions: { small: "i77g9o1s", medium: "i77g9o1t", large: "i77g9o1u", xlarge: "i77g9o1v" }, defaultClass: "i77g9o1s" }, none: { conditions: { small: "i77g9o1w", medium: "i77g9o1x", large: "i77g9o1y", xlarge: "i77g9o1z" }, defaultClass: "i77g9o1w" } }, responsiveArray: void 0 }, flexDirection: { values: { row: { conditions: { small: "i77g9o20", medium: "i77g9o21", large: "i77g9o22", xlarge: "i77g9o23" }, defaultClass: "i77g9o20" }, column: { conditions: { small: "i77g9o24", medium: "i77g9o25", large: "i77g9o26", xlarge: "i77g9o27" }, defaultClass: "i77g9o24" }, "row-reverse": { conditions: { small: "i77g9o28", medium: "i77g9o29", large: "i77g9o2a", xlarge: "i77g9o2b" }, defaultClass: "i77g9o28" }, "column-reverse": { conditions: { small: "i77g9o2c", medium: "i77g9o2d", large: "i77g9o2e", xlarge: "i77g9o2f" }, defaultClass: "i77g9o2c" } }, responsiveArray: void 0 }, flexWrap: { values: { nowrap: { conditions: { small: "i77g9o2g", medium: "i77g9o2h", large: "i77g9o2i", xlarge: "i77g9o2j" }, defaultClass: "i77g9o2g" }, wrap: { conditions: { small: "i77g9o2k", medium: "i77g9o2l", large: "i77g9o2m", xlarge: "i77g9o2n" }, defaultClass: "i77g9o2k" }, "wrap-reverse": { conditions: { small: "i77g9o2o", medium: "i77g9o2p", large: "i77g9o2q", xlarge: "i77g9o2r" }, defaultClass: "i77g9o2o" } }, responsiveArray: void 0 }, justifyContent: { values: { "flex-start": { conditions: { small: "i77g9o2s", medium: "i77g9o2t", large: "i77g9o2u", xlarge: "i77g9o2v" }, defaultClass: "i77g9o2s" }, center: { conditions: { small: "i77g9o2w", medium: "i77g9o2x", large: "i77g9o2y", xlarge: "i77g9o2z" }, defaultClass: "i77g9o2w" }, "flex-end": { conditions: { small: "i77g9o30", medium: "i77g9o31", large: "i77g9o32", xlarge: "i77g9o33" }, defaultClass: "i77g9o30" }, stretch: { conditions: { small: "i77g9o34", medium: "i77g9o35", large: "i77g9o36", xlarge: "i77g9o37" }, defaultClass: "i77g9o34" }, "space-between": { conditions: { small: "i77g9o38", medium: "i77g9o39", large: "i77g9o3a", xlarge: "i77g9o3b" }, defaultClass: "i77g9o38" }, "space-around": { conditions: { small: "i77g9o3c", medium: "i77g9o3d", large: "i77g9o3e", xlarge: "i77g9o3f" }, defaultClass: "i77g9o3c" } }, responsiveArray: void 0 }, alignItems: { values: { "flex-start": { conditions: { small: "i77g9o3g", medium: "i77g9o3h", large: "i77g9o3i", xlarge: "i77g9o3j" }, defaultClass: "i77g9o3g" }, center: { conditions: { small: "i77g9o3k", medium: "i77g9o3l", large: "i77g9o3m", xlarge: "i77g9o3n" }, defaultClass: "i77g9o3k" }, "flex-end": { conditions: { small: "i77g9o3o", medium: "i77g9o3p", large: "i77g9o3q", xlarge: "i77g9o3r" }, defaultClass: "i77g9o3o" }, stretch: { conditions: { small: "i77g9o3s", medium: "i77g9o3t", large: "i77g9o3u", xlarge: "i77g9o3v" }, defaultClass: "i77g9o3s" }, baseline: { conditions: { small: "i77g9o3w", medium: "i77g9o3x", large: "i77g9o3y", xlarge: "i77g9o3z" }, defaultClass: "i77g9o3w" } }, responsiveArray: void 0 }, alignContent: { values: { "flex-start": { conditions: { small: "i77g9o40", medium: "i77g9o41", large: "i77g9o42", xlarge: "i77g9o43" }, defaultClass: "i77g9o40" }, center: { conditions: { small: "i77g9o44", medium: "i77g9o45", large: "i77g9o46", xlarge: "i77g9o47" }, defaultClass: "i77g9o44" }, "flex-end": { conditions: { small: "i77g9o48", medium: "i77g9o49", large: "i77g9o4a", xlarge: "i77g9o4b" }, defaultClass: "i77g9o48" }, stretch: { conditions: { small: "i77g9o4c", medium: "i77g9o4d", large: "i77g9o4e", xlarge: "i77g9o4f" }, defaultClass: "i77g9o4c" } }, responsiveArray: void 0 }, verticalAlign: { values: { top: { conditions: { small: "i77g9o4g", medium: "i77g9o4h", large: "i77g9o4i", xlarge: "i77g9o4j" }, defaultClass: "i77g9o4g" }, middle: { conditions: { small: "i77g9o4k", medium: "i77g9o4l", large: "i77g9o4m", xlarge: "i77g9o4n" }, defaultClass: "i77g9o4k" }, bottom: { conditions: { small: "i77g9o4o", medium: "i77g9o4p", large: "i77g9o4q", xlarge: "i77g9o4r" }, defaultClass: "i77g9o4o" }, baseline: { conditions: { small: "i77g9o4s", medium: "i77g9o4t", large: "i77g9o4u", xlarge: "i77g9o4v" }, defaultClass: "i77g9o4s" }, "text-top": { conditions: { small: "i77g9o4w", medium: "i77g9o4x", large: "i77g9o4y", xlarge: "i77g9o4z" }, defaultClass: "i77g9o4w" }, "text-bottom": { conditions: { small: "i77g9o50", medium: "i77g9o51", large: "i77g9o52", xlarge: "i77g9o53" }, defaultClass: "i77g9o50" } }, responsiveArray: void 0 }, position: { values: { initial: { conditions: { small: "i77g9o54", medium: "i77g9o55", large: "i77g9o56", xlarge: "i77g9o57" }, defaultClass: "i77g9o54" }, inherit: { conditions: { small: "i77g9o58", medium: "i77g9o59", large: "i77g9o5a", xlarge: "i77g9o5b" }, defaultClass: "i77g9o58" }, unset: { conditions: { small: "i77g9o5c", medium: "i77g9o5d", large: "i77g9o5e", xlarge: "i77g9o5f" }, defaultClass: "i77g9o5c" }, relative: { conditions: { small: "i77g9o5g", medium: "i77g9o5h", large: "i77g9o5i", xlarge: "i77g9o5j" }, defaultClass: "i77g9o5g" }, absolute: { conditions: { small: "i77g9o5k", medium: "i77g9o5l", large: "i77g9o5m", xlarge: "i77g9o5n" }, defaultClass: "i77g9o5k" }, fixed: { conditions: { small: "i77g9o5o", medium: "i77g9o5p", large: "i77g9o5q", xlarge: "i77g9o5r" }, defaultClass: "i77g9o5o" }, sticky: { conditions: { small: "i77g9o5s", medium: "i77g9o5t", large: "i77g9o5u", xlarge: "i77g9o5v" }, defaultClass: "i77g9o5s" } }, responsiveArray: void 0 }, margin: { values: { 0: { conditions: { small: "i77g9o68", medium: "i77g9o69", large: "i77g9o6a", xlarge: "i77g9o6b" }, defaultClass: "i77g9o68" }, initial: { conditions: { small: "i77g9o5w", medium: "i77g9o5x", large: "i77g9o5y", xlarge: "i77g9o5z" }, defaultClass: "i77g9o5w" }, inherit: { conditions: { small: "i77g9o60", medium: "i77g9o61", large: "i77g9o62", xlarge: "i77g9o63" }, defaultClass: "i77g9o60" }, unset: { conditions: { small: "i77g9o64", medium: "i77g9o65", large: "i77g9o66", xlarge: "i77g9o67" }, defaultClass: "i77g9o64" }, auto: { conditions: { small: "i77g9o6c", medium: "i77g9o6d", large: "i77g9o6e", xlarge: "i77g9o6f" }, defaultClass: "i77g9o6c" }, none: { conditions: { small: "i77g9o6g", medium: "i77g9o6h", large: "i77g9o6i", xlarge: "i77g9o6j" }, defaultClass: "i77g9o6g" } }, responsiveArray: void 0 }, padding: { values: { 0: { conditions: { small: "i77g9o6w", medium: "i77g9o6x", large: "i77g9o6y", xlarge: "i77g9o6z" }, defaultClass: "i77g9o6w" }, initial: { conditions: { small: "i77g9o6k", medium: "i77g9o6l", large: "i77g9o6m", xlarge: "i77g9o6n" }, defaultClass: "i77g9o6k" }, inherit: { conditions: { small: "i77g9o6o", medium: "i77g9o6p", large: "i77g9o6q", xlarge: "i77g9o6r" }, defaultClass: "i77g9o6o" }, unset: { conditions: { small: "i77g9o6s", medium: "i77g9o6t", large: "i77g9o6u", xlarge: "i77g9o6v" }, defaultClass: "i77g9o6s" }, none: { conditions: { small: "i77g9o70", medium: "i77g9o71", large: "i77g9o72", xlarge: "i77g9o73" }, defaultClass: "i77g9o70" }, auto: { conditions: { small: "i77g9o74", medium: "i77g9o75", large: "i77g9o76", xlarge: "i77g9o77" }, defaultClass: "i77g9o74" }, "4px": { conditions: { small: "i77g9o78", medium: "i77g9o79", large: "i77g9o7a", xlarge: "i77g9o7b" }, defaultClass: "i77g9o78" }, "8px": { conditions: { small: "i77g9o7c", medium: "i77g9o7d", large: "i77g9o7e", xlarge: "i77g9o7f" }, defaultClass: "i77g9o7c" }, "10px": { conditions: { small: "i77g9o7g", medium: "i77g9o7h", large: "i77g9o7i", xlarge: "i77g9o7j" }, defaultClass: "i77g9o7g" }, "12px": { conditions: { small: "i77g9o7k", medium: "i77g9o7l", large: "i77g9o7m", xlarge: "i77g9o7n" }, defaultClass: "i77g9o7k" }, "16px": { conditions: { small: "i77g9o7o", medium: "i77g9o7p", large: "i77g9o7q", xlarge: "i77g9o7r" }, defaultClass: "i77g9o7o" }, "20px": { conditions: { small: "i77g9o7s", medium: "i77g9o7t", large: "i77g9o7u", xlarge: "i77g9o7v" }, defaultClass: "i77g9o7s" } }, responsiveArray: void 0 }, width: { values: { auto: { conditions: { small: "i77g9o7w", medium: "i77g9o7x", large: "i77g9o7y", xlarge: "i77g9o7z" }, defaultClass: "i77g9o7w" }, "100%": { conditions: { small: "i77g9o80", medium: "i77g9o81", large: "i77g9o82", xlarge: "i77g9o83" }, defaultClass: "i77g9o80" } }, responsiveArray: void 0 }, height: { values: { auto: { conditions: { small: "i77g9o84", medium: "i77g9o85", large: "i77g9o86", xlarge: "i77g9o87" }, defaultClass: "i77g9o84" }, "100%": { conditions: { small: "i77g9o88", medium: "i77g9o89", large: "i77g9o8a", xlarge: "i77g9o8b" }, defaultClass: "i77g9o88" } }, responsiveArray: void 0 }, gap: { values: { 0: { conditions: { small: "i77g9o8c", medium: "i77g9o8d", large: "i77g9o8e", xlarge: "i77g9o8f" }, defaultClass: "i77g9o8c" }, "4px 4px": { conditions: { small: "i77g9o8g", medium: "i77g9o8h", large: "i77g9o8i", xlarge: "i77g9o8j" }, defaultClass: "i77g9o8g" }, "8px 8px": { conditions: { small: "i77g9o8k", medium: "i77g9o8l", large: "i77g9o8m", xlarge: "i77g9o8n" }, defaultClass: "i77g9o8k" }, "10px 10px": { conditions: { small: "i77g9o8o", medium: "i77g9o8p", large: "i77g9o8q", xlarge: "i77g9o8r" }, defaultClass: "i77g9o8o" }, "12px 12px": { conditions: { small: "i77g9o8s", medium: "i77g9o8t", large: "i77g9o8u", xlarge: "i77g9o8v" }, defaultClass: "i77g9o8s" }, "16px 16px": { conditions: { small: "i77g9o8w", medium: "i77g9o8x", large: "i77g9o8y", xlarge: "i77g9o8z" }, defaultClass: "i77g9o8w" }, "20px 20px": { conditions: { small: "i77g9o90", medium: "i77g9o91", large: "i77g9o92", xlarge: "i77g9o93" }, defaultClass: "i77g9o90" } }, responsiveArray: void 0 }, mixBlendMode: { values: { initial: { conditions: { small: "i77g9o94", medium: "i77g9o95", large: "i77g9o96", xlarge: "i77g9o97" }, defaultClass: "i77g9o94" }, inherit: { conditions: { small: "i77g9o98", medium: "i77g9o99", large: "i77g9o9a", xlarge: "i77g9o9b" }, defaultClass: "i77g9o98" }, unset: { conditions: { small: "i77g9o9c", medium: "i77g9o9d", large: "i77g9o9e", xlarge: "i77g9o9f" }, defaultClass: "i77g9o9c" }, difference: { conditions: { small: "i77g9o9g", medium: "i77g9o9h", large: "i77g9o9i", xlarge: "i77g9o9j" }, defaultClass: "i77g9o9g" }, multiply: { conditions: { small: "i77g9o9k", medium: "i77g9o9l", large: "i77g9o9m", xlarge: "i77g9o9n" }, defaultClass: "i77g9o9k" }, screen: { conditions: { small: "i77g9o9o", medium: "i77g9o9p", large: "i77g9o9q", xlarge: "i77g9o9r" }, defaultClass: "i77g9o9o" }, overlay: { conditions: { small: "i77g9o9s", medium: "i77g9o9t", large: "i77g9o9u", xlarge: "i77g9o9v" }, defaultClass: "i77g9o9s" } }, responsiveArray: void 0 } } };
  return e.styles.all.responsiveArray = e.conditions.responsiveArray, e.styles.boxSizing.responsiveArray = e.conditions.responsiveArray, e.styles.appearance.responsiveArray = e.conditions.responsiveArray, e.styles.outline.responsiveArray = e.conditions.responsiveArray, e.styles.userSelect.responsiveArray = e.conditions.responsiveArray, e.styles.fontVariantNumeric.responsiveArray = e.conditions.responsiveArray, e.styles.WebkitTapHighlightColor.responsiveArray = e.conditions.responsiveArray, e.styles.display.responsiveArray = e.conditions.responsiveArray, e.styles.flex.responsiveArray = e.conditions.responsiveArray, e.styles.flexDirection.responsiveArray = e.conditions.responsiveArray, e.styles.flexWrap.responsiveArray = e.conditions.responsiveArray, e.styles.justifyContent.responsiveArray = e.conditions.responsiveArray, e.styles.alignItems.responsiveArray = e.conditions.responsiveArray, e.styles.alignContent.responsiveArray = e.conditions.responsiveArray, e.styles.verticalAlign.responsiveArray = e.conditions.responsiveArray, e.styles.position.responsiveArray = e.conditions.responsiveArray, e.styles.margin.responsiveArray = e.conditions.responsiveArray, e.styles.padding.responsiveArray = e.conditions.responsiveArray, e.styles.width.responsiveArray = e.conditions.responsiveArray, e.styles.height.responsiveArray = e.conditions.responsiveArray, e.styles.gap.responsiveArray = e.conditions.responsiveArray, e.styles.mixBlendMode.responsiveArray = e.conditions.responsiveArray, e;
}(), { conditions: { defaultCondition: "light", conditionNames: ["light", "dark"], responsiveArray: void 0 }, styles: { color: { values: { transparent: { conditions: { light: "i77g9o9w", dark: "i77g9o9x" }, defaultClass: "i77g9o9w" }, current: { conditions: { light: "i77g9o9y", dark: "i77g9o9z" }, defaultClass: "i77g9o9y" }, white: { conditions: { light: "i77g9oa0", dark: "i77g9oa1" }, defaultClass: "i77g9oa0" }, black: { conditions: { light: "i77g9oa2", dark: "i77g9oa3" }, defaultClass: "i77g9oa2" }, gray100: { conditions: { light: "i77g9oa4", dark: "i77g9oa5" }, defaultClass: "i77g9oa4" }, gray200: { conditions: { light: "i77g9oa6", dark: "i77g9oa7" }, defaultClass: "i77g9oa6" }, gray300: { conditions: { light: "i77g9oa8", dark: "i77g9oa9" }, defaultClass: "i77g9oa8" }, pale100: { conditions: { light: "i77g9oaa", dark: "i77g9oab" }, defaultClass: "i77g9oaa" }, pale200: { conditions: { light: "i77g9oac", dark: "i77g9oad" }, defaultClass: "i77g9oac" }, pale300: { conditions: { light: "i77g9oae", dark: "i77g9oaf" }, defaultClass: "i77g9oae" }, pale400: { conditions: { light: "i77g9oag", dark: "i77g9oah" }, defaultClass: "i77g9oag" }, pale500: { conditions: { light: "i77g9oai", dark: "i77g9oaj" }, defaultClass: "i77g9oai" }, hyper0: { conditions: { light: "i77g9oak", dark: "i77g9oal" }, defaultClass: "i77g9oak" }, hyper1: { conditions: { light: "i77g9oam", dark: "i77g9oan" }, defaultClass: "i77g9oam" }, hyper2: { conditions: { light: "i77g9oao", dark: "i77g9oap" }, defaultClass: "i77g9oao" }, hyper3: { conditions: { light: "i77g9oaq", dark: "i77g9oar" }, defaultClass: "i77g9oaq" }, hyper4: { conditions: { light: "i77g9oas", dark: "i77g9oat" }, defaultClass: "i77g9oas" }, hyper5: { conditions: { light: "i77g9oau", dark: "i77g9oav" }, defaultClass: "i77g9oau" }, hyper6: { conditions: { light: "i77g9oaw", dark: "i77g9oax" }, defaultClass: "i77g9oaw" }, hyper7: { conditions: { light: "i77g9oay", dark: "i77g9oaz" }, defaultClass: "i77g9oay" }, hyper8: { conditions: { light: "i77g9ob0", dark: "i77g9ob1" }, defaultClass: "i77g9ob0" }, hyper9: { conditions: { light: "i77g9ob2", dark: "i77g9ob3" }, defaultClass: "i77g9ob2" }, hyper10: { conditions: { light: "i77g9ob4", dark: "i77g9ob5" }, defaultClass: "i77g9ob4" }, hyper11: { conditions: { light: "i77g9ob6", dark: "i77g9ob7" }, defaultClass: "i77g9ob6" }, hyper12: { conditions: { light: "i77g9ob8", dark: "i77g9ob9" }, defaultClass: "i77g9ob8" }, hyper13: { conditions: { light: "i77g9oba", dark: "i77g9obb" }, defaultClass: "i77g9oba" }, lemon0: { conditions: { light: "i77g9obc", dark: "i77g9obd" }, defaultClass: "i77g9obc" }, lemon1: { conditions: { light: "i77g9obe", dark: "i77g9obf" }, defaultClass: "i77g9obe" }, lemon2: { conditions: { light: "i77g9obg", dark: "i77g9obh" }, defaultClass: "i77g9obg" }, lemon3: { conditions: { light: "i77g9obi", dark: "i77g9obj" }, defaultClass: "i77g9obi" }, lemon4: { conditions: { light: "i77g9obk", dark: "i77g9obl" }, defaultClass: "i77g9obk" }, lemon5: { conditions: { light: "i77g9obm", dark: "i77g9obn" }, defaultClass: "i77g9obm" }, lemon6: { conditions: { light: "i77g9obo", dark: "i77g9obp" }, defaultClass: "i77g9obo" }, lemon7: { conditions: { light: "i77g9obq", dark: "i77g9obr" }, defaultClass: "i77g9obq" }, lemon8: { conditions: { light: "i77g9obs", dark: "i77g9obt" }, defaultClass: "i77g9obs" }, lemon9: { conditions: { light: "i77g9obu", dark: "i77g9obv" }, defaultClass: "i77g9obu" }, lemon10: { conditions: { light: "i77g9obw", dark: "i77g9obx" }, defaultClass: "i77g9obw" }, lemon11: { conditions: { light: "i77g9oby", dark: "i77g9obz" }, defaultClass: "i77g9oby" }, lemon12: { conditions: { light: "i77g9oc0", dark: "i77g9oc1" }, defaultClass: "i77g9oc0" }, lemon13: { conditions: { light: "i77g9oc2", dark: "i77g9oc3" }, defaultClass: "i77g9oc2" }, slate1: { conditions: { light: "i77g9oc4", dark: "i77g9oc5" }, defaultClass: "i77g9oc4" }, slate2: { conditions: { light: "i77g9oc6", dark: "i77g9oc7" }, defaultClass: "i77g9oc6" }, slate3: { conditions: { light: "i77g9oc8", dark: "i77g9oc9" }, defaultClass: "i77g9oc8" }, slate4: { conditions: { light: "i77g9oca", dark: "i77g9ocb" }, defaultClass: "i77g9oca" }, slate5: { conditions: { light: "i77g9occ", dark: "i77g9ocd" }, defaultClass: "i77g9occ" }, slate6: { conditions: { light: "i77g9oce", dark: "i77g9ocf" }, defaultClass: "i77g9oce" }, slate7: { conditions: { light: "i77g9ocg", dark: "i77g9och" }, defaultClass: "i77g9ocg" }, slate8: { conditions: { light: "i77g9oci", dark: "i77g9ocj" }, defaultClass: "i77g9oci" }, slate9: { conditions: { light: "i77g9ock", dark: "i77g9ocl" }, defaultClass: "i77g9ock" }, slate10: { conditions: { light: "i77g9ocm", dark: "i77g9ocn" }, defaultClass: "i77g9ocm" }, slate11: { conditions: { light: "i77g9oco", dark: "i77g9ocp" }, defaultClass: "i77g9oco" }, slate12: { conditions: { light: "i77g9ocq", dark: "i77g9ocr" }, defaultClass: "i77g9ocq" }, slate13: { conditions: { light: "i77g9ocs", dark: "i77g9oct" }, defaultClass: "i77g9ocs" }, sapphire0: { conditions: { light: "i77g9ocu", dark: "i77g9ocv" }, defaultClass: "i77g9ocu" }, sapphire1: { conditions: { light: "i77g9ocw", dark: "i77g9ocx" }, defaultClass: "i77g9ocw" }, sapphire2: { conditions: { light: "i77g9ocy", dark: "i77g9ocz" }, defaultClass: "i77g9ocy" }, sapphire3: { conditions: { light: "i77g9od0", dark: "i77g9od1" }, defaultClass: "i77g9od0" }, sapphire4: { conditions: { light: "i77g9od2", dark: "i77g9od3" }, defaultClass: "i77g9od2" }, sapphire5: { conditions: { light: "i77g9od4", dark: "i77g9od5" }, defaultClass: "i77g9od4" }, sapphire6: { conditions: { light: "i77g9od6", dark: "i77g9od7" }, defaultClass: "i77g9od6" }, sapphire7: { conditions: { light: "i77g9od8", dark: "i77g9od9" }, defaultClass: "i77g9od8" }, sapphire8: { conditions: { light: "i77g9oda", dark: "i77g9odb" }, defaultClass: "i77g9oda" }, sapphire9: { conditions: { light: "i77g9odc", dark: "i77g9odd" }, defaultClass: "i77g9odc" }, sapphire10: { conditions: { light: "i77g9ode", dark: "i77g9odf" }, defaultClass: "i77g9ode" }, sapphire11: { conditions: { light: "i77g9odg", dark: "i77g9odh" }, defaultClass: "i77g9odg" }, sapphire12: { conditions: { light: "i77g9odi", dark: "i77g9odj" }, defaultClass: "i77g9odi" }, sapphire13: { conditions: { light: "i77g9odk", dark: "i77g9odl" }, defaultClass: "i77g9odk" }, volt0: { conditions: { light: "i77g9odm", dark: "i77g9odn" }, defaultClass: "i77g9odm" }, volt1: { conditions: { light: "i77g9odo", dark: "i77g9odp" }, defaultClass: "i77g9odo" }, volt2: { conditions: { light: "i77g9odq", dark: "i77g9odr" }, defaultClass: "i77g9odq" }, volt3: { conditions: { light: "i77g9ods", dark: "i77g9odt" }, defaultClass: "i77g9ods" }, volt4: { conditions: { light: "i77g9odu", dark: "i77g9odv" }, defaultClass: "i77g9odu" }, volt5: { conditions: { light: "i77g9odw", dark: "i77g9odx" }, defaultClass: "i77g9odw" }, volt6: { conditions: { light: "i77g9ody", dark: "i77g9odz" }, defaultClass: "i77g9ody" }, volt7: { conditions: { light: "i77g9oe0", dark: "i77g9oe1" }, defaultClass: "i77g9oe0" }, volt8: { conditions: { light: "i77g9oe2", dark: "i77g9oe3" }, defaultClass: "i77g9oe2" }, volt9: { conditions: { light: "i77g9oe4", dark: "i77g9oe5" }, defaultClass: "i77g9oe4" }, volt10: { conditions: { light: "i77g9oe6", dark: "i77g9oe7" }, defaultClass: "i77g9oe6" }, volt11: { conditions: { light: "i77g9oe8", dark: "i77g9oe9" }, defaultClass: "i77g9oe8" }, volt12: { conditions: { light: "i77g9oea", dark: "i77g9oeb" }, defaultClass: "i77g9oea" }, volt13: { conditions: { light: "i77g9oec", dark: "i77g9oed" }, defaultClass: "i77g9oec" } } }, backgroundColor: { values: { transparent: { conditions: { light: "i77g9oee", dark: "i77g9oef" }, defaultClass: "i77g9oee" }, current: { conditions: { light: "i77g9oeg", dark: "i77g9oeh" }, defaultClass: "i77g9oeg" }, white: { conditions: { light: "i77g9oei", dark: "i77g9oej" }, defaultClass: "i77g9oei" }, black: { conditions: { light: "i77g9oek", dark: "i77g9oel" }, defaultClass: "i77g9oek" }, gray100: { conditions: { light: "i77g9oem", dark: "i77g9oen" }, defaultClass: "i77g9oem" }, gray200: { conditions: { light: "i77g9oeo", dark: "i77g9oep" }, defaultClass: "i77g9oeo" }, gray300: { conditions: { light: "i77g9oeq", dark: "i77g9oer" }, defaultClass: "i77g9oeq" }, pale100: { conditions: { light: "i77g9oes", dark: "i77g9oet" }, defaultClass: "i77g9oes" }, pale200: { conditions: { light: "i77g9oeu", dark: "i77g9oev" }, defaultClass: "i77g9oeu" }, pale300: { conditions: { light: "i77g9oew", dark: "i77g9oex" }, defaultClass: "i77g9oew" }, pale400: { conditions: { light: "i77g9oey", dark: "i77g9oez" }, defaultClass: "i77g9oey" }, pale500: { conditions: { light: "i77g9of0", dark: "i77g9of1" }, defaultClass: "i77g9of0" }, hyper0: { conditions: { light: "i77g9of2", dark: "i77g9of3" }, defaultClass: "i77g9of2" }, hyper1: { conditions: { light: "i77g9of4", dark: "i77g9of5" }, defaultClass: "i77g9of4" }, hyper2: { conditions: { light: "i77g9of6", dark: "i77g9of7" }, defaultClass: "i77g9of6" }, hyper3: { conditions: { light: "i77g9of8", dark: "i77g9of9" }, defaultClass: "i77g9of8" }, hyper4: { conditions: { light: "i77g9ofa", dark: "i77g9ofb" }, defaultClass: "i77g9ofa" }, hyper5: { conditions: { light: "i77g9ofc", dark: "i77g9ofd" }, defaultClass: "i77g9ofc" }, hyper6: { conditions: { light: "i77g9ofe", dark: "i77g9off" }, defaultClass: "i77g9ofe" }, hyper7: { conditions: { light: "i77g9ofg", dark: "i77g9ofh" }, defaultClass: "i77g9ofg" }, hyper8: { conditions: { light: "i77g9ofi", dark: "i77g9ofj" }, defaultClass: "i77g9ofi" }, hyper9: { conditions: { light: "i77g9ofk", dark: "i77g9ofl" }, defaultClass: "i77g9ofk" }, hyper10: { conditions: { light: "i77g9ofm", dark: "i77g9ofn" }, defaultClass: "i77g9ofm" }, hyper11: { conditions: { light: "i77g9ofo", dark: "i77g9ofp" }, defaultClass: "i77g9ofo" }, hyper12: { conditions: { light: "i77g9ofq", dark: "i77g9ofr" }, defaultClass: "i77g9ofq" }, hyper13: { conditions: { light: "i77g9ofs", dark: "i77g9oft" }, defaultClass: "i77g9ofs" }, lemon0: { conditions: { light: "i77g9ofu", dark: "i77g9ofv" }, defaultClass: "i77g9ofu" }, lemon1: { conditions: { light: "i77g9ofw", dark: "i77g9ofx" }, defaultClass: "i77g9ofw" }, lemon2: { conditions: { light: "i77g9ofy", dark: "i77g9ofz" }, defaultClass: "i77g9ofy" }, lemon3: { conditions: { light: "i77g9og0", dark: "i77g9og1" }, defaultClass: "i77g9og0" }, lemon4: { conditions: { light: "i77g9og2", dark: "i77g9og3" }, defaultClass: "i77g9og2" }, lemon5: { conditions: { light: "i77g9og4", dark: "i77g9og5" }, defaultClass: "i77g9og4" }, lemon6: { conditions: { light: "i77g9og6", dark: "i77g9og7" }, defaultClass: "i77g9og6" }, lemon7: { conditions: { light: "i77g9og8", dark: "i77g9og9" }, defaultClass: "i77g9og8" }, lemon8: { conditions: { light: "i77g9oga", dark: "i77g9ogb" }, defaultClass: "i77g9oga" }, lemon9: { conditions: { light: "i77g9ogc", dark: "i77g9ogd" }, defaultClass: "i77g9ogc" }, lemon10: { conditions: { light: "i77g9oge", dark: "i77g9ogf" }, defaultClass: "i77g9oge" }, lemon11: { conditions: { light: "i77g9ogg", dark: "i77g9ogh" }, defaultClass: "i77g9ogg" }, lemon12: { conditions: { light: "i77g9ogi", dark: "i77g9ogj" }, defaultClass: "i77g9ogi" }, lemon13: { conditions: { light: "i77g9ogk", dark: "i77g9ogl" }, defaultClass: "i77g9ogk" }, slate1: { conditions: { light: "i77g9ogm", dark: "i77g9ogn" }, defaultClass: "i77g9ogm" }, slate2: { conditions: { light: "i77g9ogo", dark: "i77g9ogp" }, defaultClass: "i77g9ogo" }, slate3: { conditions: { light: "i77g9ogq", dark: "i77g9ogr" }, defaultClass: "i77g9ogq" }, slate4: { conditions: { light: "i77g9ogs", dark: "i77g9ogt" }, defaultClass: "i77g9ogs" }, slate5: { conditions: { light: "i77g9ogu", dark: "i77g9ogv" }, defaultClass: "i77g9ogu" }, slate6: { conditions: { light: "i77g9ogw", dark: "i77g9ogx" }, defaultClass: "i77g9ogw" }, slate7: { conditions: { light: "i77g9ogy", dark: "i77g9ogz" }, defaultClass: "i77g9ogy" }, slate8: { conditions: { light: "i77g9oh0", dark: "i77g9oh1" }, defaultClass: "i77g9oh0" }, slate9: { conditions: { light: "i77g9oh2", dark: "i77g9oh3" }, defaultClass: "i77g9oh2" }, slate10: { conditions: { light: "i77g9oh4", dark: "i77g9oh5" }, defaultClass: "i77g9oh4" }, slate11: { conditions: { light: "i77g9oh6", dark: "i77g9oh7" }, defaultClass: "i77g9oh6" }, slate12: { conditions: { light: "i77g9oh8", dark: "i77g9oh9" }, defaultClass: "i77g9oh8" }, slate13: { conditions: { light: "i77g9oha", dark: "i77g9ohb" }, defaultClass: "i77g9oha" }, sapphire0: { conditions: { light: "i77g9ohc", dark: "i77g9ohd" }, defaultClass: "i77g9ohc" }, sapphire1: { conditions: { light: "i77g9ohe", dark: "i77g9ohf" }, defaultClass: "i77g9ohe" }, sapphire2: { conditions: { light: "i77g9ohg", dark: "i77g9ohh" }, defaultClass: "i77g9ohg" }, sapphire3: { conditions: { light: "i77g9ohi", dark: "i77g9ohj" }, defaultClass: "i77g9ohi" }, sapphire4: { conditions: { light: "i77g9ohk", dark: "i77g9ohl" }, defaultClass: "i77g9ohk" }, sapphire5: { conditions: { light: "i77g9ohm", dark: "i77g9ohn" }, defaultClass: "i77g9ohm" }, sapphire6: { conditions: { light: "i77g9oho", dark: "i77g9ohp" }, defaultClass: "i77g9oho" }, sapphire7: { conditions: { light: "i77g9ohq", dark: "i77g9ohr" }, defaultClass: "i77g9ohq" }, sapphire8: { conditions: { light: "i77g9ohs", dark: "i77g9oht" }, defaultClass: "i77g9ohs" }, sapphire9: { conditions: { light: "i77g9ohu", dark: "i77g9ohv" }, defaultClass: "i77g9ohu" }, sapphire10: { conditions: { light: "i77g9ohw", dark: "i77g9ohx" }, defaultClass: "i77g9ohw" }, sapphire11: { conditions: { light: "i77g9ohy", dark: "i77g9ohz" }, defaultClass: "i77g9ohy" }, sapphire12: { conditions: { light: "i77g9oi0", dark: "i77g9oi1" }, defaultClass: "i77g9oi0" }, sapphire13: { conditions: { light: "i77g9oi2", dark: "i77g9oi3" }, defaultClass: "i77g9oi2" }, volt0: { conditions: { light: "i77g9oi4", dark: "i77g9oi5" }, defaultClass: "i77g9oi4" }, volt1: { conditions: { light: "i77g9oi6", dark: "i77g9oi7" }, defaultClass: "i77g9oi6" }, volt2: { conditions: { light: "i77g9oi8", dark: "i77g9oi9" }, defaultClass: "i77g9oi8" }, volt3: { conditions: { light: "i77g9oia", dark: "i77g9oib" }, defaultClass: "i77g9oia" }, volt4: { conditions: { light: "i77g9oic", dark: "i77g9oid" }, defaultClass: "i77g9oic" }, volt5: { conditions: { light: "i77g9oie", dark: "i77g9oif" }, defaultClass: "i77g9oie" }, volt6: { conditions: { light: "i77g9oig", dark: "i77g9oih" }, defaultClass: "i77g9oig" }, volt7: { conditions: { light: "i77g9oii", dark: "i77g9oij" }, defaultClass: "i77g9oii" }, volt8: { conditions: { light: "i77g9oik", dark: "i77g9oil" }, defaultClass: "i77g9oik" }, volt9: { conditions: { light: "i77g9oim", dark: "i77g9oin" }, defaultClass: "i77g9oim" }, volt10: { conditions: { light: "i77g9oio", dark: "i77g9oip" }, defaultClass: "i77g9oio" }, volt11: { conditions: { light: "i77g9oiq", dark: "i77g9oir" }, defaultClass: "i77g9oiq" }, volt12: { conditions: { light: "i77g9ois", dark: "i77g9oit" }, defaultClass: "i77g9ois" }, volt13: { conditions: { light: "i77g9oiu", dark: "i77g9oiv" }, defaultClass: "i77g9oiu" } } }, borderColor: { values: { transparent: { conditions: { light: "i77g9oiw", dark: "i77g9oix" }, defaultClass: "i77g9oiw" }, current: { conditions: { light: "i77g9oiy", dark: "i77g9oiz" }, defaultClass: "i77g9oiy" }, white: { conditions: { light: "i77g9oj0", dark: "i77g9oj1" }, defaultClass: "i77g9oj0" }, black: { conditions: { light: "i77g9oj2", dark: "i77g9oj3" }, defaultClass: "i77g9oj2" }, gray100: { conditions: { light: "i77g9oj4", dark: "i77g9oj5" }, defaultClass: "i77g9oj4" }, gray200: { conditions: { light: "i77g9oj6", dark: "i77g9oj7" }, defaultClass: "i77g9oj6" }, gray300: { conditions: { light: "i77g9oj8", dark: "i77g9oj9" }, defaultClass: "i77g9oj8" }, pale100: { conditions: { light: "i77g9oja", dark: "i77g9ojb" }, defaultClass: "i77g9oja" }, pale200: { conditions: { light: "i77g9ojc", dark: "i77g9ojd" }, defaultClass: "i77g9ojc" }, pale300: { conditions: { light: "i77g9oje", dark: "i77g9ojf" }, defaultClass: "i77g9oje" }, pale400: { conditions: { light: "i77g9ojg", dark: "i77g9ojh" }, defaultClass: "i77g9ojg" }, pale500: { conditions: { light: "i77g9oji", dark: "i77g9ojj" }, defaultClass: "i77g9oji" }, hyper0: { conditions: { light: "i77g9ojk", dark: "i77g9ojl" }, defaultClass: "i77g9ojk" }, hyper1: { conditions: { light: "i77g9ojm", dark: "i77g9ojn" }, defaultClass: "i77g9ojm" }, hyper2: { conditions: { light: "i77g9ojo", dark: "i77g9ojp" }, defaultClass: "i77g9ojo" }, hyper3: { conditions: { light: "i77g9ojq", dark: "i77g9ojr" }, defaultClass: "i77g9ojq" }, hyper4: { conditions: { light: "i77g9ojs", dark: "i77g9ojt" }, defaultClass: "i77g9ojs" }, hyper5: { conditions: { light: "i77g9oju", dark: "i77g9ojv" }, defaultClass: "i77g9oju" }, hyper6: { conditions: { light: "i77g9ojw", dark: "i77g9ojx" }, defaultClass: "i77g9ojw" }, hyper7: { conditions: { light: "i77g9ojy", dark: "i77g9ojz" }, defaultClass: "i77g9ojy" }, hyper8: { conditions: { light: "i77g9ok0", dark: "i77g9ok1" }, defaultClass: "i77g9ok0" }, hyper9: { conditions: { light: "i77g9ok2", dark: "i77g9ok3" }, defaultClass: "i77g9ok2" }, hyper10: { conditions: { light: "i77g9ok4", dark: "i77g9ok5" }, defaultClass: "i77g9ok4" }, hyper11: { conditions: { light: "i77g9ok6", dark: "i77g9ok7" }, defaultClass: "i77g9ok6" }, hyper12: { conditions: { light: "i77g9ok8", dark: "i77g9ok9" }, defaultClass: "i77g9ok8" }, hyper13: { conditions: { light: "i77g9oka", dark: "i77g9okb" }, defaultClass: "i77g9oka" }, lemon0: { conditions: { light: "i77g9okc", dark: "i77g9okd" }, defaultClass: "i77g9okc" }, lemon1: { conditions: { light: "i77g9oke", dark: "i77g9okf" }, defaultClass: "i77g9oke" }, lemon2: { conditions: { light: "i77g9okg", dark: "i77g9okh" }, defaultClass: "i77g9okg" }, lemon3: { conditions: { light: "i77g9oki", dark: "i77g9okj" }, defaultClass: "i77g9oki" }, lemon4: { conditions: { light: "i77g9okk", dark: "i77g9okl" }, defaultClass: "i77g9okk" }, lemon5: { conditions: { light: "i77g9okm", dark: "i77g9okn" }, defaultClass: "i77g9okm" }, lemon6: { conditions: { light: "i77g9oko", dark: "i77g9okp" }, defaultClass: "i77g9oko" }, lemon7: { conditions: { light: "i77g9okq", dark: "i77g9okr" }, defaultClass: "i77g9okq" }, lemon8: { conditions: { light: "i77g9oks", dark: "i77g9okt" }, defaultClass: "i77g9oks" }, lemon9: { conditions: { light: "i77g9oku", dark: "i77g9okv" }, defaultClass: "i77g9oku" }, lemon10: { conditions: { light: "i77g9okw", dark: "i77g9okx" }, defaultClass: "i77g9okw" }, lemon11: { conditions: { light: "i77g9oky", dark: "i77g9okz" }, defaultClass: "i77g9oky" }, lemon12: { conditions: { light: "i77g9ol0", dark: "i77g9ol1" }, defaultClass: "i77g9ol0" }, lemon13: { conditions: { light: "i77g9ol2", dark: "i77g9ol3" }, defaultClass: "i77g9ol2" }, slate1: { conditions: { light: "i77g9ol4", dark: "i77g9ol5" }, defaultClass: "i77g9ol4" }, slate2: { conditions: { light: "i77g9ol6", dark: "i77g9ol7" }, defaultClass: "i77g9ol6" }, slate3: { conditions: { light: "i77g9ol8", dark: "i77g9ol9" }, defaultClass: "i77g9ol8" }, slate4: { conditions: { light: "i77g9ola", dark: "i77g9olb" }, defaultClass: "i77g9ola" }, slate5: { conditions: { light: "i77g9olc", dark: "i77g9old" }, defaultClass: "i77g9olc" }, slate6: { conditions: { light: "i77g9ole", dark: "i77g9olf" }, defaultClass: "i77g9ole" }, slate7: { conditions: { light: "i77g9olg", dark: "i77g9olh" }, defaultClass: "i77g9olg" }, slate8: { conditions: { light: "i77g9oli", dark: "i77g9olj" }, defaultClass: "i77g9oli" }, slate9: { conditions: { light: "i77g9olk", dark: "i77g9oll" }, defaultClass: "i77g9olk" }, slate10: { conditions: { light: "i77g9olm", dark: "i77g9oln" }, defaultClass: "i77g9olm" }, slate11: { conditions: { light: "i77g9olo", dark: "i77g9olp" }, defaultClass: "i77g9olo" }, slate12: { conditions: { light: "i77g9olq", dark: "i77g9olr" }, defaultClass: "i77g9olq" }, slate13: { conditions: { light: "i77g9ols", dark: "i77g9olt" }, defaultClass: "i77g9ols" }, sapphire0: { conditions: { light: "i77g9olu", dark: "i77g9olv" }, defaultClass: "i77g9olu" }, sapphire1: { conditions: { light: "i77g9olw", dark: "i77g9olx" }, defaultClass: "i77g9olw" }, sapphire2: { conditions: { light: "i77g9oly", dark: "i77g9olz" }, defaultClass: "i77g9oly" }, sapphire3: { conditions: { light: "i77g9om0", dark: "i77g9om1" }, defaultClass: "i77g9om0" }, sapphire4: { conditions: { light: "i77g9om2", dark: "i77g9om3" }, defaultClass: "i77g9om2" }, sapphire5: { conditions: { light: "i77g9om4", dark: "i77g9om5" }, defaultClass: "i77g9om4" }, sapphire6: { conditions: { light: "i77g9om6", dark: "i77g9om7" }, defaultClass: "i77g9om6" }, sapphire7: { conditions: { light: "i77g9om8", dark: "i77g9om9" }, defaultClass: "i77g9om8" }, sapphire8: { conditions: { light: "i77g9oma", dark: "i77g9omb" }, defaultClass: "i77g9oma" }, sapphire9: { conditions: { light: "i77g9omc", dark: "i77g9omd" }, defaultClass: "i77g9omc" }, sapphire10: { conditions: { light: "i77g9ome", dark: "i77g9omf" }, defaultClass: "i77g9ome" }, sapphire11: { conditions: { light: "i77g9omg", dark: "i77g9omh" }, defaultClass: "i77g9omg" }, sapphire12: { conditions: { light: "i77g9omi", dark: "i77g9omj" }, defaultClass: "i77g9omi" }, sapphire13: { conditions: { light: "i77g9omk", dark: "i77g9oml" }, defaultClass: "i77g9omk" }, volt0: { conditions: { light: "i77g9omm", dark: "i77g9omn" }, defaultClass: "i77g9omm" }, volt1: { conditions: { light: "i77g9omo", dark: "i77g9omp" }, defaultClass: "i77g9omo" }, volt2: { conditions: { light: "i77g9omq", dark: "i77g9omr" }, defaultClass: "i77g9omq" }, volt3: { conditions: { light: "i77g9oms", dark: "i77g9omt" }, defaultClass: "i77g9oms" }, volt4: { conditions: { light: "i77g9omu", dark: "i77g9omv" }, defaultClass: "i77g9omu" }, volt5: { conditions: { light: "i77g9omw", dark: "i77g9omx" }, defaultClass: "i77g9omw" }, volt6: { conditions: { light: "i77g9omy", dark: "i77g9omz" }, defaultClass: "i77g9omy" }, volt7: { conditions: { light: "i77g9on0", dark: "i77g9on1" }, defaultClass: "i77g9on0" }, volt8: { conditions: { light: "i77g9on2", dark: "i77g9on3" }, defaultClass: "i77g9on2" }, volt9: { conditions: { light: "i77g9on4", dark: "i77g9on5" }, defaultClass: "i77g9on4" }, volt10: { conditions: { light: "i77g9on6", dark: "i77g9on7" }, defaultClass: "i77g9on6" }, volt11: { conditions: { light: "i77g9on8", dark: "i77g9on9" }, defaultClass: "i77g9on8" }, volt12: { conditions: { light: "i77g9ona", dark: "i77g9onb" }, defaultClass: "i77g9ona" }, volt13: { conditions: { light: "i77g9onc", dark: "i77g9ond" }, defaultClass: "i77g9onc" } } } } });
const Yr = ({ reset: e, ...t }) => {
  const o = Dn(t), n = e ? [Lr, Mr[e]] : null;
  return I(n, o);
}, Sc = {
  small: 0,
  medium: 768,
  large: 1200,
  xlarge: 1600
};
var Gr = Zr, ft = { base: "_1oxbat10", light: "_1oxbat155", dark: "_1oxbat156" }, Zr = { media: { breakpoints: { small: "var(--_1oxbat11)", medium: "var(--_1oxbat12)", large: "var(--_1oxbat13)", xlarge: "var(--_1oxbat14)" }, colorModes: { LIGHT: "var(--_1oxbat15)", DARK: "var(--_1oxbat16)" } }, font: { family: { system: "var(--_1oxbat17)", sf: "var(--_1oxbat18)", mono: "var(--_1oxbat19)" }, heading: { H1: "var(--_1oxbat1a)", H2: "var(--_1oxbat1b)", H3: "var(--_1oxbat1c)", H4: "var(--_1oxbat1d)", H5: "var(--_1oxbat1e)", H6: "var(--_1oxbat1f)" }, size: { MINI: "var(--_1oxbat1g)", XS: "var(--_1oxbat1h)", SM: "var(--_1oxbat1i)", MD: "var(--_1oxbat1j)", LG: "var(--_1oxbat1k)", XL: "var(--_1oxbat1l)", XXL: "var(--_1oxbat1m)", "3XL": "var(--_1oxbat1n)", "4XL": "var(--_1oxbat1o)", "5XL": "var(--_1oxbat1p)", "6XL": "var(--_1oxbat1q)", "7XL": "var(--_1oxbat1r)", "8XL": "var(--_1oxbat1s)", "9XL": "var(--_1oxbat1t)" }, lineheight: { MINI: "var(--_1oxbat1u)", XS: "var(--_1oxbat1v)", SM: "var(--_1oxbat1w)", MD: "var(--_1oxbat1x)", LG: "var(--_1oxbat1y)", XL: "var(--_1oxbat1z)", XXL: "var(--_1oxbat110)", "3XL": "var(--_1oxbat111)", "4XL": "var(--_1oxbat112)", "5XL": "var(--_1oxbat113)", "6XL": "var(--_1oxbat114)", "7XL": "var(--_1oxbat115)", "8XL": "var(--_1oxbat116)", "9XL": "var(--_1oxbat117)" }, weight: { SUPRLITE: "var(--_1oxbat118)", ULTRALITE: "var(--_1oxbat119)", LITE: "var(--_1oxbat11a)", REGULAR: "var(--_1oxbat11b)", MEDIUM: "var(--_1oxbat11c)", SEMIBOLD: "var(--_1oxbat11d)", BOLD: "var(--_1oxbat11e)", HEAVY: "var(--_1oxbat11f)", BLACK: "var(--_1oxbat11g)" } }, radii: { ZERO: "var(--_1oxbat11h)", NO: "var(--_1oxbat11i)", DF: "var(--_1oxbat11j)", XS: "var(--_1oxbat11k)", SM: "var(--_1oxbat11l)", MD: "var(--_1oxbat11m)", LG: "var(--_1oxbat11n)", XL: "var(--_1oxbat11o)", XXL: "var(--_1oxbat11p)", PILL: "var(--_1oxbat11q)" }, space: { ZERO: "var(--_1oxbat11r)", NO: "var(--_1oxbat11s)", DF: "var(--_1oxbat11t)", APX: "var(--_1oxbat11u)", BPX: "var(--_1oxbat11v)", CPX: "var(--_1oxbat11w)", DPX: "var(--_1oxbat11x)", EPX: "var(--_1oxbat11y)", FPX: "var(--_1oxbat11z)", GPX: "var(--_1oxbat120)", HPX: "var(--_1oxbat121)", IPX: "var(--_1oxbat122)", JPX: "var(--_1oxbat123)", KPX: "var(--_1oxbat124)", LPX: "var(--_1oxbat125)", MPX: "var(--_1oxbat126)", NPX: "var(--_1oxbat127)", OPX: "var(--_1oxbat128)", PPX: "var(--_1oxbat129)", QPX: "var(--_1oxbat12a)", RPX: "var(--_1oxbat12b)", SPX: "var(--_1oxbat12c)", TPX: "var(--_1oxbat12d)", UPX: "var(--_1oxbat12e)", VPX: "var(--_1oxbat12f)", WPX: "var(--_1oxbat12g)", XPX: "var(--_1oxbat12h)", YPX: "var(--_1oxbat12i)", ZPX: "var(--_1oxbat12j)" }, z: { indice: { ZERO: "var(--_1oxbat12k)", DF: "var(--_1oxbat12l)", LOW: "var(--_1oxbat12m)", MED: "var(--_1oxbat12n)", HIGH: "var(--_1oxbat12o)", TOP: "var(--_1oxbat12p)", MAX: "var(--_1oxbat12q)" } }, shadow: { NO: "var(--_1oxbat12r)", DF: "var(--_1oxbat12s)", LOW: "var(--_1oxbat12t)", MED: "var(--_1oxbat12u)", HIGH: "var(--_1oxbat12v)" }, color: { transparent: "var(--_1oxbat12w)", current: "var(--_1oxbat12x)", white: "var(--_1oxbat12y)", black: "var(--_1oxbat12z)", gray100: "var(--_1oxbat130)", gray200: "var(--_1oxbat131)", gray300: "var(--_1oxbat132)", pale100: "var(--_1oxbat133)", pale200: "var(--_1oxbat134)", pale300: "var(--_1oxbat135)", pale400: "var(--_1oxbat136)", pale500: "var(--_1oxbat137)", hyper0: "var(--_1oxbat138)", hyper1: "var(--_1oxbat139)", hyper2: "var(--_1oxbat13a)", hyper3: "var(--_1oxbat13b)", hyper4: "var(--_1oxbat13c)", hyper5: "var(--_1oxbat13d)", hyper6: "var(--_1oxbat13e)", hyper7: "var(--_1oxbat13f)", hyper8: "var(--_1oxbat13g)", hyper9: "var(--_1oxbat13h)", hyper10: "var(--_1oxbat13i)", hyper11: "var(--_1oxbat13j)", hyper12: "var(--_1oxbat13k)", hyper13: "var(--_1oxbat13l)", lemon0: "var(--_1oxbat13m)", lemon1: "var(--_1oxbat13n)", lemon2: "var(--_1oxbat13o)", lemon3: "var(--_1oxbat13p)", lemon4: "var(--_1oxbat13q)", lemon5: "var(--_1oxbat13r)", lemon6: "var(--_1oxbat13s)", lemon7: "var(--_1oxbat13t)", lemon8: "var(--_1oxbat13u)", lemon9: "var(--_1oxbat13v)", lemon10: "var(--_1oxbat13w)", lemon11: "var(--_1oxbat13x)", lemon12: "var(--_1oxbat13y)", lemon13: "var(--_1oxbat13z)", slate1: "var(--_1oxbat140)", slate2: "var(--_1oxbat141)", slate3: "var(--_1oxbat142)", slate4: "var(--_1oxbat143)", slate5: "var(--_1oxbat144)", slate6: "var(--_1oxbat145)", slate7: "var(--_1oxbat146)", slate8: "var(--_1oxbat147)", slate9: "var(--_1oxbat148)", slate10: "var(--_1oxbat149)", slate11: "var(--_1oxbat14a)", slate12: "var(--_1oxbat14b)", slate13: "var(--_1oxbat14c)", sapphire0: "var(--_1oxbat14d)", sapphire1: "var(--_1oxbat14e)", sapphire2: "var(--_1oxbat14f)", sapphire3: "var(--_1oxbat14g)", sapphire4: "var(--_1oxbat14h)", sapphire5: "var(--_1oxbat14i)", sapphire6: "var(--_1oxbat14j)", sapphire7: "var(--_1oxbat14k)", sapphire8: "var(--_1oxbat14l)", sapphire9: "var(--_1oxbat14m)", sapphire10: "var(--_1oxbat14n)", sapphire11: "var(--_1oxbat14o)", sapphire12: "var(--_1oxbat14p)", sapphire13: "var(--_1oxbat14q)", volt0: "var(--_1oxbat14r)", volt1: "var(--_1oxbat14s)", volt2: "var(--_1oxbat14t)", volt3: "var(--_1oxbat14u)", volt4: "var(--_1oxbat14v)", volt5: "var(--_1oxbat14w)", volt6: "var(--_1oxbat14x)", volt7: "var(--_1oxbat14y)", volt8: "var(--_1oxbat14z)", volt9: "var(--_1oxbat150)", volt10: "var(--_1oxbat151)", volt11: "var(--_1oxbat152)", volt12: "var(--_1oxbat153)", volt13: "var(--_1oxbat154)" } };
const Jr = {
  light: `html:not(${ft.light}) &`,
  dark: `html${ft.dark} &`
}, Do = (e, t) => !t || Object.keys(t).length === 0 ? {} : {
  [Jr[e]]: t
}, Ec = ({ lightMode: e, darkMode: t }) => ({
  ...e || t ? {
    selectors: {
      ...Do("light", e),
      ...Do("dark", t)
    }
  } : {}
}), In = vt({
  theme: "light",
  toggleTheme: null
}), Pc = () => {
  const e = zt(In);
  if (!e)
    throw new Error("Atelier® Kit components must be used within [KitProvider]");
  return e;
}, Rc = ({
  children: e
}) => {
  const [t, o] = ee("light"), n = () => {
    o((r) => r === "light" ? "dark" : "light");
  }, i = t === "light" ? ft.dark : ft.light;
  return /* @__PURE__ */ _.jsx(In.Provider, { value: { theme: t, toggleTheme: n }, children: /* @__PURE__ */ _.jsx("div", { className: `${ft.base} ${i}`, children: e }) });
}, Qr = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M12.0916 14.9959C12.2854 14.9802 12.4708 14.902 12.6225 14.7846L16.6417 11.583C16.8439 11.4343 16.9703 11.2151 16.9956 10.9725C17.0209 10.7298 16.9366 10.495 16.7681 10.3149C16.5996 10.1349 16.3552 10.0175 16.1024 10.0096C15.8412 9.99399 15.5884 10.0801 15.3946 10.2366L11.9989 12.945L8.60325 10.2366C8.40945 10.0723 8.15667 9.98616 7.90388 10.0018C7.64268 10.0175 7.39832 10.1271 7.2298 10.3149C7.06128 10.495 6.98545 10.7376 7.0023 10.9725C7.02758 11.2151 7.15397 11.4343 7.35619 11.583L11.3754 14.7846C11.5692 14.9411 11.8304 15.0194 12.0832 14.9959H12.0916Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
), Tc = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, {}), ea = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M15.3529 1L8.64709 1C8.08172 1 7.78927 1.71527 8.17595 2.15231L11.2933 5.67559C11.676 6.10814 12.324 6.10814 12.7067 5.67559L15.8241 2.15231C16.2107 1.71527 15.9183 1 15.3529 1Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
) }), ta = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M8.64709 6H15.3529C15.9183 6 16.2107 5.28473 15.8241 4.84769L12.7067 1.32441C12.324 0.891862 11.676 0.891862 11.2933 1.32441L8.17595 4.84769C7.78927 5.28473 8.08172 6 8.64709 6Z",
        fill: e,
        "fill-rule": "evenodd",
        "clip-rule": "evenodd"
      }
    )
  }
) }), yt = {
  background: "#9E9CA6",
  inner: "#F6F4F0"
}, Ac = ({
  color: e = yt.background,
  width: t,
  height: o,
  ...n
}) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsxs(
  "svg",
  {
    width: t || "18",
    height: o || "18",
    viewBox: "0 0 18 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...n,
    children: [
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M6.9 16H11.1C14.6 16 16 14.6 16 11.1V6.9C16 3.4 14.6 2 11.1 2H6.9C3.4 2 2 3.4 2 6.9V11.1C2 14.6 3.4 16 6.9 16Z",
          fill: e,
          stroke: e,
          strokeWidth: "1.4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M7.14 6.49999L4 11.5H6.68L7.15 10.7H10.8L11.26 11.5H14L10.86 6.49999H7.14ZM7.82 9.53999L8.98 7.55999L10.12 9.53999H7.82Z",
          fill: yt.inner
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M12.35 8.14999C12.44 8.23999 12.54 8.30999 12.66 8.35999C12.78 8.40999 12.9 8.42999 13.04 8.42999C13.18 8.42999 13.3 8.40999 13.42 8.35999C13.54 8.30999 13.64 8.23999 13.73 8.14999C13.82 8.05999 13.89 7.95999 13.94 7.83999C13.99 7.71999 14.01 7.59999 14.01 7.45999C14.01 7.31999 13.99 7.19999 13.94 7.07999C13.89 6.95999 13.82 6.85999 13.73 6.76999C13.64 6.67999 13.54 6.60999 13.42 6.55999C13.3 6.50999 13.18 6.48999 13.04 6.48999C12.9 6.48999 12.78 6.50999 12.66 6.55999C12.54 6.60999 12.44 6.67999 12.35 6.76999C12.26 6.85999 12.19 6.95999 12.14 7.07999C12.09 7.19999 12.07 7.31999 12.07 7.45999C12.07 7.59999 12.09 7.71999 12.14 7.83999C12.19 7.95999 12.26 8.05999 12.35 8.14999ZM12.4 7.09999C12.47 6.98999 12.55 6.89999 12.66 6.83999C12.77 6.76999 12.89 6.73999 13.03 6.73999C13.17 6.73999 13.29 6.76999 13.39 6.83999C13.5 6.89999 13.59 6.98999 13.65 7.09999C13.72 7.20999 13.75 7.32999 13.75 7.46999C13.75 7.60999 13.72 7.72999 13.65 7.82999C13.59 7.93999 13.5 8.02999 13.39 8.08999C13.28 8.15999 13.16 8.18999 13.03 8.18999C12.9 8.18999 12.77 8.15999 12.66 8.08999C12.55 8.01999 12.46 7.93999 12.4 7.82999C12.33 7.71999 12.3 7.59999 12.3 7.46999C12.3 7.33999 12.33 7.20999 12.4 7.09999Z",
          fill: yt.inner
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M12.9 7.59999H13.08L13.23 7.89999H13.46L13.28 7.54999C13.28 7.54999 13.35 7.49999 13.38 7.45999C13.41 7.40999 13.43 7.35999 13.43 7.29999C13.43 7.23999 13.42 7.17999 13.39 7.13999C13.36 7.09999 13.32 7.05999 13.28 7.03999C13.24 7.01999 13.19 7.00999 13.15 7.00999H12.71V7.89999H12.92V7.59999H12.9ZM13.07 7.15999C13.07 7.15999 13.12 7.15999 13.15 7.18999C13.18 7.20999 13.19 7.23999 13.19 7.29999C13.19 7.35999 13.18 7.38999 13.15 7.40999C13.12 7.42999 13.09 7.44999 13.06 7.44999H12.89V7.16999H13.06L13.07 7.15999Z",
          fill: yt.inner
        }
      )
    ]
  }
) }), Ln = V(
  ({ as: e = "div", className: t, ...o }, n) => {
    const i = {}, r = {};
    for (const a in o)
      Dn.properties.has(a) ? i[a] = o[a] : r[a] = o[a];
    const s = Yr({
      reset: typeof e == "string" ? e : "div",
      ...i
    });
    return R(e, {
      className: I(s, t),
      ...r,
      ref: n
    });
  }
);
Ln.displayName = "RectBox";
var oa = we({ defaultClassName: "ti68jl4", variantClassNames: { size: { sm: "ti68jl0", md: "ti68jl1", lg: "ti68jl2", vw: "ti68jl3" } }, defaultVariants: { size: "vw" }, compoundVariants: [] });
const na = ({
  children: e,
  className: t,
  size: o = "vw",
  ...n
}) => /* @__PURE__ */ _.jsx(
  "div",
  {
    ...n,
    className: I(t, oa({ size: o })),
    children: e
  }
);
na.displayName = "Section";
function Y() {
  return Y = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var o = arguments[t];
      for (var n in o)
        Object.prototype.hasOwnProperty.call(o, n) && (e[n] = o[n]);
    }
    return e;
  }, Y.apply(this, arguments);
}
function Io(e, [t, o]) {
  return Math.min(o, Math.max(t, e));
}
function ce(e, t, { checkForDefaultPrevented: o = !0 } = {}) {
  return function(i) {
    if (e == null || e(i), o === !1 || !i.defaultPrevented)
      return t == null ? void 0 : t(i);
  };
}
function go(e, t = []) {
  let o = [];
  function n(r, s) {
    const a = /* @__PURE__ */ vt(s), l = o.length;
    o = [
      ...o,
      s
    ];
    function d(u) {
      const { scope: v, children: p, ...x } = u, g = (v == null ? void 0 : v[e][l]) || a, m = nt(
        () => x,
        Object.values(x)
      );
      return /* @__PURE__ */ R(g.Provider, {
        value: m
      }, p);
    }
    function f(u, v) {
      const p = (v == null ? void 0 : v[e][l]) || a, x = zt(p);
      if (x)
        return x;
      if (s !== void 0)
        return s;
      throw new Error(`\`${u}\` must be used within \`${r}\``);
    }
    return d.displayName = r + "Provider", [
      d,
      f
    ];
  }
  const i = () => {
    const r = o.map((s) => /* @__PURE__ */ vt(s));
    return function(a) {
      const l = (a == null ? void 0 : a[e]) || r;
      return nt(
        () => ({
          [`__scope${e}`]: {
            ...a,
            [e]: l
          }
        }),
        [
          a,
          l
        ]
      );
    };
  };
  return i.scopeName = e, [
    n,
    ia(i, ...t)
  ];
}
function ia(...e) {
  const t = e[0];
  if (e.length === 1)
    return t;
  const o = () => {
    const n = e.map(
      (i) => ({
        useScope: i(),
        scopeName: i.scopeName
      })
    );
    return function(r) {
      const s = n.reduce((a, { useScope: l, scopeName: d }) => {
        const u = l(r)[`__scope${d}`];
        return {
          ...a,
          ...u
        };
      }, {});
      return nt(
        () => ({
          [`__scope${t.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return o.scopeName = t.scopeName, o;
}
function ra(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Mn(...e) {
  return (t) => e.forEach(
    (o) => ra(o, t)
  );
}
function ve(...e) {
  return pe(Mn(...e), e);
}
const mt = /* @__PURE__ */ V((e, t) => {
  const { children: o, ...n } = e, i = ut.toArray(o), r = i.find(sa);
  if (r) {
    const s = r.props.children, a = i.map((l) => l === r ? ut.count(s) > 1 ? ut.only(null) : /* @__PURE__ */ Rt(s) ? s.props.children : null : l);
    return /* @__PURE__ */ R(oo, Y({}, n, {
      ref: t
    }), /* @__PURE__ */ Rt(s) ? /* @__PURE__ */ vn(s, void 0, a) : null);
  }
  return /* @__PURE__ */ R(oo, Y({}, n, {
    ref: t
  }), o);
});
mt.displayName = "Slot";
const oo = /* @__PURE__ */ V((e, t) => {
  const { children: o, ...n } = e;
  return /* @__PURE__ */ Rt(o) ? /* @__PURE__ */ vn(o, {
    ...la(n, o.props),
    ref: t ? Mn(t, o.ref) : o.ref
  }) : ut.count(o) > 1 ? ut.only(null) : null;
});
oo.displayName = "SlotClone";
const aa = ({ children: e }) => /* @__PURE__ */ R(co, null, e);
function sa(e) {
  return /* @__PURE__ */ Rt(e) && e.type === aa;
}
function la(e, t) {
  const o = {
    ...t
  };
  for (const n in t) {
    const i = e[n], r = t[n];
    /^on[A-Z]/.test(n) ? i && r ? o[n] = (...a) => {
      r(...a), i(...a);
    } : i && (o[n] = i) : n === "style" ? o[n] = {
      ...i,
      ...r
    } : n === "className" && (o[n] = [
      i,
      r
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...o
  };
}
function ca(e) {
  const t = e + "CollectionProvider", [o, n] = go(t), [i, r] = o(t, {
    collectionRef: {
      current: null
    },
    itemMap: /* @__PURE__ */ new Map()
  }), s = (p) => {
    const { scope: x, children: g } = p, m = W.useRef(null), b = W.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ W.createElement(i, {
      scope: x,
      itemMap: b,
      collectionRef: m
    }, g);
  }, a = e + "CollectionSlot", l = /* @__PURE__ */ W.forwardRef((p, x) => {
    const { scope: g, children: m } = p, b = r(a, g), h = ve(x, b.collectionRef);
    return /* @__PURE__ */ W.createElement(mt, {
      ref: h
    }, m);
  }), d = e + "CollectionItemSlot", f = "data-radix-collection-item", u = /* @__PURE__ */ W.forwardRef((p, x) => {
    const { scope: g, children: m, ...b } = p, h = W.useRef(null), y = ve(x, h), w = r(d, g);
    return W.useEffect(() => (w.itemMap.set(h, {
      ref: h,
      ...b
    }), () => void w.itemMap.delete(h))), /* @__PURE__ */ W.createElement(mt, {
      [f]: "",
      ref: y
    }, m);
  });
  function v(p) {
    const x = r(e + "CollectionConsumer", p);
    return W.useCallback(() => {
      const m = x.collectionRef.current;
      if (!m)
        return [];
      const b = Array.from(m.querySelectorAll(`[${f}]`));
      return Array.from(x.itemMap.values()).sort(
        (w, $) => b.indexOf(w.ref.current) - b.indexOf($.ref.current)
      );
    }, [
      x.collectionRef,
      x.itemMap
    ]);
  }
  return [
    {
      Provider: s,
      Slot: l,
      ItemSlot: u
    },
    v,
    n
  ];
}
const da = /* @__PURE__ */ vt(void 0);
function ua(e) {
  const t = zt(da);
  return e || t || "ltr";
}
const fa = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], ue = fa.reduce((e, t) => {
  const o = /* @__PURE__ */ V((n, i) => {
    const { asChild: r, ...s } = n, a = r ? mt : t;
    return ie(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ R(a, Y({}, s, {
      ref: i
    }));
  });
  return o.displayName = `Primitive.${t}`, {
    ...e,
    [t]: o
  };
}, {});
function ga(e, t) {
  e && Gi(
    () => e.dispatchEvent(t)
  );
}
function Ne(e) {
  const t = de(e);
  return ie(() => {
    t.current = e;
  }), nt(
    () => (...o) => {
      var n;
      return (n = t.current) === null || n === void 0 ? void 0 : n.call(t, ...o);
    },
    []
  );
}
function pa(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = Ne(e);
  ie(() => {
    const n = (i) => {
      i.key === "Escape" && o(i);
    };
    return t.addEventListener("keydown", n), () => t.removeEventListener("keydown", n);
  }, [
    o,
    t
  ]);
}
const no = "dismissableLayer.update", va = "dismissableLayer.pointerDownOutside", ma = "dismissableLayer.focusOutside";
let Lo;
const ha = /* @__PURE__ */ vt({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), xa = /* @__PURE__ */ V((e, t) => {
  var o;
  const { disableOutsidePointerEvents: n = !1, onEscapeKeyDown: i, onPointerDownOutside: r, onFocusOutside: s, onInteractOutside: a, onDismiss: l, ...d } = e, f = zt(ha), [u, v] = ee(null), p = (o = u == null ? void 0 : u.ownerDocument) !== null && o !== void 0 ? o : globalThis == null ? void 0 : globalThis.document, [, x] = ee({}), g = ve(
    t,
    (P) => v(P)
  ), m = Array.from(f.layers), [b] = [
    ...f.layersWithOutsidePointerEventsDisabled
  ].slice(-1), h = m.indexOf(b), y = u ? m.indexOf(u) : -1, w = f.layersWithOutsidePointerEventsDisabled.size > 0, $ = y >= h, E = ba((P) => {
    const L = P.target, X = [
      ...f.branches
    ].some(
      (j) => j.contains(L)
    );
    !$ || X || (r == null || r(P), a == null || a(P), P.defaultPrevented || l == null || l());
  }, p), S = ya((P) => {
    const L = P.target;
    [
      ...f.branches
    ].some(
      (j) => j.contains(L)
    ) || (s == null || s(P), a == null || a(P), P.defaultPrevented || l == null || l());
  }, p);
  return pa((P) => {
    y === f.layers.size - 1 && (i == null || i(P), !P.defaultPrevented && l && (P.preventDefault(), l()));
  }, p), ie(() => {
    if (u)
      return n && (f.layersWithOutsidePointerEventsDisabled.size === 0 && (Lo = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), f.layersWithOutsidePointerEventsDisabled.add(u)), f.layers.add(u), Mo(), () => {
        n && f.layersWithOutsidePointerEventsDisabled.size === 1 && (p.body.style.pointerEvents = Lo);
      };
  }, [
    u,
    p,
    n,
    f
  ]), ie(() => () => {
    u && (f.layers.delete(u), f.layersWithOutsidePointerEventsDisabled.delete(u), Mo());
  }, [
    u,
    f
  ]), ie(() => {
    const P = () => x({});
    return document.addEventListener(no, P), () => document.removeEventListener(no, P);
  }, []), /* @__PURE__ */ R(ue.div, Y({}, d, {
    ref: g,
    style: {
      pointerEvents: w ? $ ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: ce(e.onFocusCapture, S.onFocusCapture),
    onBlurCapture: ce(e.onBlurCapture, S.onBlurCapture),
    onPointerDownCapture: ce(e.onPointerDownCapture, E.onPointerDownCapture)
  }));
});
function ba(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = Ne(e), n = de(!1), i = de(() => {
  });
  return ie(() => {
    const r = (a) => {
      if (a.target && !n.current) {
        let d = function() {
          Fn(va, o, l, {
            discrete: !0
          });
        };
        const l = {
          originalEvent: a
        };
        a.pointerType === "touch" ? (t.removeEventListener("click", i.current), i.current = d, t.addEventListener("click", i.current, {
          once: !0
        })) : d();
      }
      n.current = !1;
    }, s = window.setTimeout(() => {
      t.addEventListener("pointerdown", r);
    }, 0);
    return () => {
      window.clearTimeout(s), t.removeEventListener("pointerdown", r), t.removeEventListener("click", i.current);
    };
  }, [
    t,
    o
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => n.current = !0
  };
}
function ya(e, t = globalThis == null ? void 0 : globalThis.document) {
  const o = Ne(e), n = de(!1);
  return ie(() => {
    const i = (r) => {
      r.target && !n.current && Fn(ma, o, {
        originalEvent: r
      }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", i), () => t.removeEventListener("focusin", i);
  }, [
    t,
    o
  ]), {
    onFocusCapture: () => n.current = !0,
    onBlurCapture: () => n.current = !1
  };
}
function Mo() {
  const e = new CustomEvent(no);
  document.dispatchEvent(e);
}
function Fn(e, t, o, { discrete: n }) {
  const i = o.originalEvent.target, r = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: o
  });
  t && i.addEventListener(e, t, {
    once: !0
  }), n ? ga(i, r) : i.dispatchEvent(r);
}
let Kt = 0;
function Ca() {
  ie(() => {
    var e, t;
    const o = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = o[0]) !== null && e !== void 0 ? e : Fo()), document.body.insertAdjacentElement("beforeend", (t = o[1]) !== null && t !== void 0 ? t : Fo()), Kt++, () => {
      Kt === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (n) => n.remove()
      ), Kt--;
    };
  }, []);
}
function Fo() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
const Yt = "focusScope.autoFocusOnMount", Gt = "focusScope.autoFocusOnUnmount", Vo = {
  bubbles: !1,
  cancelable: !0
}, wa = /* @__PURE__ */ V((e, t) => {
  const { loop: o = !1, trapped: n = !1, onMountAutoFocus: i, onUnmountAutoFocus: r, ...s } = e, [a, l] = ee(null), d = Ne(i), f = Ne(r), u = de(null), v = ve(
    t,
    (g) => l(g)
  ), p = de({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  ie(() => {
    if (n) {
      let g = function(y) {
        if (p.paused || !a)
          return;
        const w = y.target;
        a.contains(w) ? u.current = w : Me(u.current, {
          select: !0
        });
      }, m = function(y) {
        if (p.paused || !a)
          return;
        const w = y.relatedTarget;
        w !== null && (a.contains(w) || Me(u.current, {
          select: !0
        }));
      }, b = function(y) {
        const w = document.activeElement;
        for (const $ of y)
          $.removedNodes.length > 0 && (a != null && a.contains(w) || Me(a));
      };
      document.addEventListener("focusin", g), document.addEventListener("focusout", m);
      const h = new MutationObserver(b);
      return a && h.observe(a, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", g), document.removeEventListener("focusout", m), h.disconnect();
      };
    }
  }, [
    n,
    a,
    p.paused
  ]), ie(() => {
    if (a) {
      Bo.add(p);
      const g = document.activeElement;
      if (!a.contains(g)) {
        const b = new CustomEvent(Yt, Vo);
        a.addEventListener(Yt, d), a.dispatchEvent(b), b.defaultPrevented || (_a(Pa(Vn(a)), {
          select: !0
        }), document.activeElement === g && Me(a));
      }
      return () => {
        a.removeEventListener(Yt, d), setTimeout(() => {
          const b = new CustomEvent(Gt, Vo);
          a.addEventListener(Gt, f), a.dispatchEvent(b), b.defaultPrevented || Me(g ?? document.body, {
            select: !0
          }), a.removeEventListener(Gt, f), Bo.remove(p);
        }, 0);
      };
    }
  }, [
    a,
    d,
    f,
    p
  ]);
  const x = pe((g) => {
    if (!o && !n || p.paused)
      return;
    const m = g.key === "Tab" && !g.altKey && !g.ctrlKey && !g.metaKey, b = document.activeElement;
    if (m && b) {
      const h = g.currentTarget, [y, w] = ka(h);
      y && w ? !g.shiftKey && b === w ? (g.preventDefault(), o && Me(y, {
        select: !0
      })) : g.shiftKey && b === y && (g.preventDefault(), o && Me(w, {
        select: !0
      })) : b === h && g.preventDefault();
    }
  }, [
    o,
    n,
    p.paused
  ]);
  return /* @__PURE__ */ R(ue.div, Y({
    tabIndex: -1
  }, s, {
    ref: v,
    onKeyDown: x
  }));
});
function _a(e, { select: t = !1 } = {}) {
  const o = document.activeElement;
  for (const n of e)
    if (Me(n, {
      select: t
    }), document.activeElement !== o)
      return;
}
function ka(e) {
  const t = Vn(e), o = Ho(t, e), n = Ho(t.reverse(), e);
  return [
    o,
    n
  ];
}
function Vn(e) {
  const t = [], o = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (n) => {
      const i = n.tagName === "INPUT" && n.type === "hidden";
      return n.disabled || n.hidden || i ? NodeFilter.FILTER_SKIP : n.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; o.nextNode(); )
    t.push(o.currentNode);
  return t;
}
function Ho(e, t) {
  for (const o of e)
    if (!$a(o, {
      upTo: t
    }))
      return o;
}
function $a(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t !== void 0 && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function Sa(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function Me(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const o = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== o && Sa(e) && t && e.select();
  }
}
const Bo = Ea();
function Ea() {
  let e = [];
  return {
    add(t) {
      const o = e[0];
      t !== o && (o == null || o.pause()), e = Wo(e, t), e.unshift(t);
    },
    remove(t) {
      var o;
      e = Wo(e, t), (o = e[0]) === null || o === void 0 || o.resume();
    }
  };
}
function Wo(e, t) {
  const o = [
    ...e
  ], n = o.indexOf(t);
  return n !== -1 && o.splice(n, 1), o;
}
function Pa(e) {
  return e.filter(
    (t) => t.tagName !== "A"
  );
}
const Ee = globalThis != null && globalThis.document ? mn : () => {
}, Ra = T["useId".toString()] || (() => {
});
let Ta = 0;
function po(e) {
  const [t, o] = T.useState(Ra());
  return Ee(() => {
    e || o(
      (n) => n ?? String(Ta++)
    );
  }, [
    e
  ]), e || (t ? `radix-${t}` : "");
}
function at(e) {
  return e.split("-")[1];
}
function vo(e) {
  return e === "y" ? "height" : "width";
}
function ze(e) {
  return e.split("-")[0];
}
function Xe(e) {
  return ["top", "bottom"].includes(ze(e)) ? "x" : "y";
}
function Xo(e, t, o) {
  let { reference: n, floating: i } = e;
  const r = n.x + n.width / 2 - i.width / 2, s = n.y + n.height / 2 - i.height / 2, a = Xe(t), l = vo(a), d = n[l] / 2 - i[l] / 2, f = a === "x";
  let u;
  switch (ze(t)) {
    case "top":
      u = { x: r, y: n.y - i.height };
      break;
    case "bottom":
      u = { x: r, y: n.y + n.height };
      break;
    case "right":
      u = { x: n.x + n.width, y: s };
      break;
    case "left":
      u = { x: n.x - i.width, y: s };
      break;
    default:
      u = { x: n.x, y: n.y };
  }
  switch (at(t)) {
    case "start":
      u[a] -= d * (o && f ? -1 : 1);
      break;
    case "end":
      u[a] += d * (o && f ? -1 : 1);
  }
  return u;
}
const Aa = async (e, t, o) => {
  const { placement: n = "bottom", strategy: i = "absolute", middleware: r = [], platform: s } = o, a = r.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let d = await s.getElementRects({ reference: e, floating: t, strategy: i }), { x: f, y: u } = Xo(d, n, l), v = n, p = {}, x = 0;
  for (let g = 0; g < a.length; g++) {
    const { name: m, fn: b } = a[g], { x: h, y, data: w, reset: $ } = await b({ x: f, y: u, initialPlacement: n, placement: v, strategy: i, middlewareData: p, rects: d, platform: s, elements: { reference: e, floating: t } });
    f = h ?? f, u = y ?? u, p = { ...p, [m]: { ...p[m], ...w } }, $ && x <= 50 && (x++, typeof $ == "object" && ($.placement && (v = $.placement), $.rects && (d = $.rects === !0 ? await s.getElementRects({ reference: e, floating: t, strategy: i }) : $.rects), { x: f, y: u } = Xo(d, v, l)), g = -1);
  }
  return { x: f, y: u, placement: v, strategy: i, middlewareData: p };
};
function Hn(e) {
  return typeof e != "number" ? function(t) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...t };
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function At(e) {
  return { ...e, top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height };
}
async function ht(e, t) {
  var o;
  t === void 0 && (t = {});
  const { x: n, y: i, platform: r, rects: s, elements: a, strategy: l } = e, { boundary: d = "clippingAncestors", rootBoundary: f = "viewport", elementContext: u = "floating", altBoundary: v = !1, padding: p = 0 } = t, x = Hn(p), g = a[v ? u === "floating" ? "reference" : "floating" : u], m = At(await r.getClippingRect({ element: (o = await (r.isElement == null ? void 0 : r.isElement(g))) == null || o ? g : g.contextElement || await (r.getDocumentElement == null ? void 0 : r.getDocumentElement(a.floating)), boundary: d, rootBoundary: f, strategy: l })), b = u === "floating" ? { ...s.floating, x: n, y: i } : s.reference, h = await (r.getOffsetParent == null ? void 0 : r.getOffsetParent(a.floating)), y = await (r.isElement == null ? void 0 : r.isElement(h)) && await (r.getScale == null ? void 0 : r.getScale(h)) || { x: 1, y: 1 }, w = At(r.convertOffsetParentRelativeRectToViewportRelativeRect ? await r.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: b, offsetParent: h, strategy: l }) : b);
  return { top: (m.top - w.top + x.top) / y.y, bottom: (w.bottom - m.bottom + x.bottom) / y.y, left: (m.left - w.left + x.left) / y.x, right: (w.right - m.right + x.right) / y.x };
}
const io = Math.min, He = Math.max;
function ro(e, t, o) {
  return He(e, io(t, o));
}
const Uo = (e) => ({ name: "arrow", options: e, async fn(t) {
  const { element: o, padding: n = 0 } = e || {}, { x: i, y: r, placement: s, rects: a, platform: l, elements: d } = t;
  if (o == null)
    return {};
  const f = Hn(n), u = { x: i, y: r }, v = Xe(s), p = vo(v), x = await l.getDimensions(o), g = v === "y", m = g ? "top" : "left", b = g ? "bottom" : "right", h = g ? "clientHeight" : "clientWidth", y = a.reference[p] + a.reference[v] - u[v] - a.floating[p], w = u[v] - a.reference[v], $ = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(o));
  let E = $ ? $[h] : 0;
  E && await (l.isElement == null ? void 0 : l.isElement($)) || (E = d.floating[h] || a.floating[p]);
  const S = y / 2 - w / 2, P = f[m], L = E - x[p] - f[b], X = E / 2 - x[p] / 2 + S, j = ro(P, X, L), F = at(s) != null && X != j && a.reference[p] / 2 - (X < P ? f[m] : f[b]) - x[p] / 2 < 0;
  return { [v]: u[v] - (F ? X < P ? P - X : L - X : 0), data: { [v]: j, centerOffset: X - j } };
} }), Bn = ["top", "right", "bottom", "left"];
Bn.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
const Oa = { left: "right", right: "left", bottom: "top", top: "bottom" };
function Ot(e) {
  return e.replace(/left|right|bottom|top/g, (t) => Oa[t]);
}
function qa(e, t, o) {
  o === void 0 && (o = !1);
  const n = at(e), i = Xe(e), r = vo(i);
  let s = i === "x" ? n === (o ? "end" : "start") ? "right" : "left" : n === "start" ? "bottom" : "top";
  return t.reference[r] > t.floating[r] && (s = Ot(s)), { main: s, cross: Ot(s) };
}
const ja = { start: "end", end: "start" };
function Zt(e) {
  return e.replace(/start|end/g, (t) => ja[t]);
}
const za = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
    var o;
    const { placement: n, middlewareData: i, rects: r, initialPlacement: s, platform: a, elements: l } = t, { mainAxis: d = !0, crossAxis: f = !0, fallbackPlacements: u, fallbackStrategy: v = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: x = !0, ...g } = e, m = ze(n), b = ze(s) === s, h = await (a.isRTL == null ? void 0 : a.isRTL(l.floating)), y = u || (b || !x ? [Ot(s)] : function(j) {
      const F = Ot(j);
      return [Zt(j), F, Zt(F)];
    }(s));
    u || p === "none" || y.push(...function(j, F, z, D) {
      const N = at(j);
      let A = function(J, Q, fe) {
        const oe = ["left", "right"], se = ["right", "left"], me = ["top", "bottom"], _e = ["bottom", "top"];
        switch (J) {
          case "top":
          case "bottom":
            return fe ? Q ? se : oe : Q ? oe : se;
          case "left":
          case "right":
            return Q ? me : _e;
          default:
            return [];
        }
      }(ze(j), z === "start", D);
      return N && (A = A.map((J) => J + "-" + N), F && (A = A.concat(A.map(Zt)))), A;
    }(s, x, p, h));
    const w = [s, ...y], $ = await ht(t, g), E = [];
    let S = ((o = i.flip) == null ? void 0 : o.overflows) || [];
    if (d && E.push($[m]), f) {
      const { main: j, cross: F } = qa(n, r, h);
      E.push($[j], $[F]);
    }
    if (S = [...S, { placement: n, overflows: E }], !E.every((j) => j <= 0)) {
      var P, L;
      const j = (((P = i.flip) == null ? void 0 : P.index) || 0) + 1, F = w[j];
      if (F)
        return { data: { index: j, overflows: S }, reset: { placement: F } };
      let z = (L = S.filter((D) => D.overflows[0] <= 0).sort((D, N) => D.overflows[1] - N.overflows[1])[0]) == null ? void 0 : L.placement;
      if (!z)
        switch (v) {
          case "bestFit": {
            var X;
            const D = (X = S.map((N) => [N.placement, N.overflows.filter((A) => A > 0).reduce((A, J) => A + J, 0)]).sort((N, A) => N[1] - A[1])[0]) == null ? void 0 : X[0];
            D && (z = D);
            break;
          }
          case "initialPlacement":
            z = s;
        }
      if (n !== z)
        return { reset: { placement: z } };
    }
    return {};
  } };
};
function Ko(e, t) {
  return { top: e.top - t.height, right: e.right - t.width, bottom: e.bottom - t.height, left: e.left - t.width };
}
function Yo(e) {
  return Bn.some((t) => e[t] >= 0);
}
const Na = function(e) {
  return e === void 0 && (e = {}), { name: "hide", options: e, async fn(t) {
    const { strategy: o = "referenceHidden", ...n } = e, { rects: i } = t;
    switch (o) {
      case "referenceHidden": {
        const r = Ko(await ht(t, { ...n, elementContext: "reference" }), i.reference);
        return { data: { referenceHiddenOffsets: r, referenceHidden: Yo(r) } };
      }
      case "escaped": {
        const r = Ko(await ht(t, { ...n, altBoundary: !0 }), i.floating);
        return { data: { escapedOffsets: r, escaped: Yo(r) } };
      }
      default:
        return {};
    }
  } };
}, Da = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
    const { x: o, y: n } = t, i = await async function(r, s) {
      const { placement: a, platform: l, elements: d } = r, f = await (l.isRTL == null ? void 0 : l.isRTL(d.floating)), u = ze(a), v = at(a), p = Xe(a) === "x", x = ["left", "top"].includes(u) ? -1 : 1, g = f && p ? -1 : 1, m = typeof s == "function" ? s(r) : s;
      let { mainAxis: b, crossAxis: h, alignmentAxis: y } = typeof m == "number" ? { mainAxis: m, crossAxis: 0, alignmentAxis: null } : { mainAxis: 0, crossAxis: 0, alignmentAxis: null, ...m };
      return v && typeof y == "number" && (h = v === "end" ? -1 * y : y), p ? { x: h * g, y: b * x } : { x: b * x, y: h * g };
    }(t, e);
    return { x: o + i.x, y: n + i.y, data: i };
  } };
};
function Wn(e) {
  return e === "x" ? "y" : "x";
}
const Ia = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
    const { x: o, y: n, placement: i } = t, { mainAxis: r = !0, crossAxis: s = !1, limiter: a = { fn: (m) => {
      let { x: b, y: h } = m;
      return { x: b, y: h };
    } }, ...l } = e, d = { x: o, y: n }, f = await ht(t, l), u = Xe(ze(i)), v = Wn(u);
    let p = d[u], x = d[v];
    if (r) {
      const m = u === "y" ? "bottom" : "right";
      p = ro(p + f[u === "y" ? "top" : "left"], p, p - f[m]);
    }
    if (s) {
      const m = v === "y" ? "bottom" : "right";
      x = ro(x + f[v === "y" ? "top" : "left"], x, x - f[m]);
    }
    const g = a.fn({ ...t, [u]: p, [v]: x });
    return { ...g, data: { x: g.x - o, y: g.y - n } };
  } };
}, La = function(e) {
  return e === void 0 && (e = {}), { options: e, fn(t) {
    const { x: o, y: n, placement: i, rects: r, middlewareData: s } = t, { offset: a = 0, mainAxis: l = !0, crossAxis: d = !0 } = e, f = { x: o, y: n }, u = Xe(i), v = Wn(u);
    let p = f[u], x = f[v];
    const g = typeof a == "function" ? a(t) : a, m = typeof g == "number" ? { mainAxis: g, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...g };
    if (l) {
      const y = u === "y" ? "height" : "width", w = r.reference[u] - r.floating[y] + m.mainAxis, $ = r.reference[u] + r.reference[y] - m.mainAxis;
      p < w ? p = w : p > $ && (p = $);
    }
    if (d) {
      var b, h;
      const y = u === "y" ? "width" : "height", w = ["top", "left"].includes(ze(i)), $ = r.reference[v] - r.floating[y] + (w && ((b = s.offset) == null ? void 0 : b[v]) || 0) + (w ? 0 : m.crossAxis), E = r.reference[v] + r.reference[y] + (w ? 0 : ((h = s.offset) == null ? void 0 : h[v]) || 0) - (w ? m.crossAxis : 0);
      x < $ ? x = $ : x > E && (x = E);
    }
    return { [u]: p, [v]: x };
  } };
}, Ma = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
    const { placement: o, rects: n, platform: i, elements: r } = t, { apply: s = () => {
    }, ...a } = e, l = await ht(t, a), d = ze(o), f = at(o), u = Xe(o) === "x", { width: v, height: p } = n.floating;
    let x, g;
    d === "top" || d === "bottom" ? (x = d, g = f === (await (i.isRTL == null ? void 0 : i.isRTL(r.floating)) ? "start" : "end") ? "left" : "right") : (g = d, x = f === "end" ? "top" : "bottom");
    const m = p - l[x], b = v - l[g], h = !t.middlewareData.shift;
    let y = m, w = b;
    if (u) {
      const E = v - l.left - l.right;
      w = f || h ? io(b, E) : E;
    } else {
      const E = p - l.top - l.bottom;
      y = f || h ? io(m, E) : E;
    }
    if (h && !f) {
      const E = He(l.left, 0), S = He(l.right, 0), P = He(l.top, 0), L = He(l.bottom, 0);
      u ? w = v - 2 * (E !== 0 || S !== 0 ? E + S : He(l.left, l.right)) : y = p - 2 * (P !== 0 || L !== 0 ? P + L : He(l.top, l.bottom));
    }
    await s({ ...t, availableWidth: w, availableHeight: y });
    const $ = await i.getDimensions(r.floating);
    return v !== $.width || p !== $.height ? { reset: { rects: !0 } } : {};
  } };
};
function Se(e) {
  var t;
  return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Pe(e) {
  return Se(e).getComputedStyle(e);
}
function Xn(e) {
  return e instanceof Se(e).Node;
}
function Ve(e) {
  return Xn(e) ? (e.nodeName || "").toLowerCase() : "";
}
function Re(e) {
  return e instanceof Se(e).HTMLElement;
}
function Ce(e) {
  return e instanceof Se(e).Element;
}
function Go(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof Se(e).ShadowRoot || e instanceof ShadowRoot;
}
function xt(e) {
  const { overflow: t, overflowX: o, overflowY: n, display: i } = Pe(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + n + o) && !["inline", "contents"].includes(i);
}
function Fa(e) {
  return ["table", "td", "th"].includes(Ve(e));
}
function ao(e) {
  const t = mo(), o = Pe(e);
  return o.transform !== "none" || o.perspective !== "none" || !t && !!o.backdropFilter && o.backdropFilter !== "none" || !t && !!o.filter && o.filter !== "none" || ["transform", "perspective", "filter"].some((n) => (o.willChange || "").includes(n)) || ["paint", "layout", "strict", "content"].some((n) => (o.contain || "").includes(n));
}
function mo() {
  return !(typeof CSS > "u" || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
}
function Nt(e) {
  return ["html", "body", "#document"].includes(Ve(e));
}
const Zo = Math.min, gt = Math.max, qt = Math.round;
function Un(e) {
  const t = Pe(e);
  let o = parseFloat(t.width) || 0, n = parseFloat(t.height) || 0;
  const i = Re(e), r = i ? e.offsetWidth : o, s = i ? e.offsetHeight : n, a = qt(o) !== r || qt(n) !== s;
  return a && (o = r, n = s), { width: o, height: n, fallback: a };
}
function Kn(e) {
  return Ce(e) ? e : e.contextElement;
}
const Yn = { x: 1, y: 1 };
function ot(e) {
  const t = Kn(e);
  if (!Re(t))
    return Yn;
  const o = t.getBoundingClientRect(), { width: n, height: i, fallback: r } = Un(t);
  let s = (r ? qt(o.width) : o.width) / n, a = (r ? qt(o.height) : o.height) / i;
  return s && Number.isFinite(s) || (s = 1), a && Number.isFinite(a) || (a = 1), { x: s, y: a };
}
const Jo = { x: 0, y: 0 };
function Gn(e, t, o) {
  var n, i;
  if (t === void 0 && (t = !0), !mo())
    return Jo;
  const r = e ? Se(e) : window;
  return !o || t && o !== r ? Jo : { x: ((n = r.visualViewport) == null ? void 0 : n.offsetLeft) || 0, y: ((i = r.visualViewport) == null ? void 0 : i.offsetTop) || 0 };
}
function Be(e, t, o, n) {
  t === void 0 && (t = !1), o === void 0 && (o = !1);
  const i = e.getBoundingClientRect(), r = Kn(e);
  let s = Yn;
  t && (n ? Ce(n) && (s = ot(n)) : s = ot(e));
  const a = Gn(r, o, n);
  let l = (i.left + a.x) / s.x, d = (i.top + a.y) / s.y, f = i.width / s.x, u = i.height / s.y;
  if (r) {
    const v = Se(r), p = n && Ce(n) ? Se(n) : n;
    let x = v.frameElement;
    for (; x && n && p !== v; ) {
      const g = ot(x), m = x.getBoundingClientRect(), b = getComputedStyle(x);
      m.x += (x.clientLeft + parseFloat(b.paddingLeft)) * g.x, m.y += (x.clientTop + parseFloat(b.paddingTop)) * g.y, l *= g.x, d *= g.y, f *= g.x, u *= g.y, l += m.x, d += m.y, x = Se(x).frameElement;
    }
  }
  return At({ width: f, height: u, x: l, y: d });
}
function Fe(e) {
  return ((Xn(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function Dt(e) {
  return Ce(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function Zn(e) {
  return Be(Fe(e)).left + Dt(e).scrollLeft;
}
function it(e) {
  if (Ve(e) === "html")
    return e;
  const t = e.assignedSlot || e.parentNode || Go(e) && e.host || Fe(e);
  return Go(t) ? t.host : t;
}
function Jn(e) {
  const t = it(e);
  return Nt(t) ? t.ownerDocument.body : Re(t) && xt(t) ? t : Jn(t);
}
function pt(e, t) {
  var o;
  t === void 0 && (t = []);
  const n = Jn(e), i = n === ((o = e.ownerDocument) == null ? void 0 : o.body), r = Se(n);
  return i ? t.concat(r, r.visualViewport || [], xt(n) ? n : []) : t.concat(n, pt(n));
}
function Qo(e, t, o) {
  let n;
  if (t === "viewport")
    n = function(i, r) {
      const s = Se(i), a = Fe(i), l = s.visualViewport;
      let d = a.clientWidth, f = a.clientHeight, u = 0, v = 0;
      if (l) {
        d = l.width, f = l.height;
        const p = mo();
        (!p || p && r === "fixed") && (u = l.offsetLeft, v = l.offsetTop);
      }
      return { width: d, height: f, x: u, y: v };
    }(e, o);
  else if (t === "document")
    n = function(i) {
      const r = Fe(i), s = Dt(i), a = i.ownerDocument.body, l = gt(r.scrollWidth, r.clientWidth, a.scrollWidth, a.clientWidth), d = gt(r.scrollHeight, r.clientHeight, a.scrollHeight, a.clientHeight);
      let f = -s.scrollLeft + Zn(i);
      const u = -s.scrollTop;
      return Pe(a).direction === "rtl" && (f += gt(r.clientWidth, a.clientWidth) - l), { width: l, height: d, x: f, y: u };
    }(Fe(e));
  else if (Ce(t))
    n = function(i, r) {
      const s = Be(i, !0, r === "fixed"), a = s.top + i.clientTop, l = s.left + i.clientLeft, d = Re(i) ? ot(i) : { x: 1, y: 1 };
      return { width: i.clientWidth * d.x, height: i.clientHeight * d.y, x: l * d.x, y: a * d.y };
    }(t, o);
  else {
    const i = Gn(e);
    n = { ...t, x: t.x - i.x, y: t.y - i.y };
  }
  return At(n);
}
function Qn(e, t) {
  const o = it(e);
  return !(o === t || !Ce(o) || Nt(o)) && (Pe(o).position === "fixed" || Qn(o, t));
}
function en(e, t) {
  return Re(e) && Pe(e).position !== "fixed" ? t ? t(e) : e.offsetParent : null;
}
function tn(e, t) {
  const o = Se(e);
  if (!Re(e))
    return o;
  let n = en(e, t);
  for (; n && Fa(n) && Pe(n).position === "static"; )
    n = en(n, t);
  return n && (Ve(n) === "html" || Ve(n) === "body" && Pe(n).position === "static" && !ao(n)) ? o : n || function(i) {
    let r = it(i);
    for (; Re(r) && !Nt(r); ) {
      if (ao(r))
        return r;
      r = it(r);
    }
    return null;
  }(e) || o;
}
function Va(e, t, o) {
  const n = Re(t), i = Fe(t), r = o === "fixed", s = Be(e, !0, r, t);
  let a = { scrollLeft: 0, scrollTop: 0 };
  const l = { x: 0, y: 0 };
  if (n || !n && !r)
    if ((Ve(t) !== "body" || xt(i)) && (a = Dt(t)), Re(t)) {
      const d = Be(t, !0, r, t);
      l.x = d.x + t.clientLeft, l.y = d.y + t.clientTop;
    } else
      i && (l.x = Zn(i));
  return { x: s.left + a.scrollLeft - l.x, y: s.top + a.scrollTop - l.y, width: s.width, height: s.height };
}
const Ha = { getClippingRect: function(e) {
  let { element: t, boundary: o, rootBoundary: n, strategy: i } = e;
  const r = o === "clippingAncestors" ? function(d, f) {
    const u = f.get(d);
    if (u)
      return u;
    let v = pt(d).filter((m) => Ce(m) && Ve(m) !== "body"), p = null;
    const x = Pe(d).position === "fixed";
    let g = x ? it(d) : d;
    for (; Ce(g) && !Nt(g); ) {
      const m = Pe(g), b = ao(g);
      b || m.position !== "fixed" || (p = null), (x ? !b && !p : !b && m.position === "static" && p && ["absolute", "fixed"].includes(p.position) || xt(g) && !b && Qn(d, g)) ? v = v.filter((h) => h !== g) : p = m, g = it(g);
    }
    return f.set(d, v), v;
  }(t, this._c) : [].concat(o), s = [...r, n], a = s[0], l = s.reduce((d, f) => {
    const u = Qo(t, f, i);
    return d.top = gt(u.top, d.top), d.right = Zo(u.right, d.right), d.bottom = Zo(u.bottom, d.bottom), d.left = gt(u.left, d.left), d;
  }, Qo(t, a, i));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: t, offsetParent: o, strategy: n } = e;
  const i = Re(o), r = Fe(o);
  if (o === r)
    return t;
  let s = { scrollLeft: 0, scrollTop: 0 }, a = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((i || !i && n !== "fixed") && ((Ve(o) !== "body" || xt(r)) && (s = Dt(o)), Re(o))) {
    const d = Be(o);
    a = ot(o), l.x = d.x + o.clientLeft, l.y = d.y + o.clientTop;
  }
  return { width: t.width * a.x, height: t.height * a.y, x: t.x * a.x - s.scrollLeft * a.x + l.x, y: t.y * a.y - s.scrollTop * a.y + l.y };
}, isElement: Ce, getDimensions: function(e) {
  return Un(e);
}, getOffsetParent: tn, getDocumentElement: Fe, getScale: ot, async getElementRects(e) {
  let { reference: t, floating: o, strategy: n } = e;
  const i = this.getOffsetParent || tn, r = this.getDimensions;
  return { reference: Va(t, await i(o), n), floating: { x: 0, y: 0, ...await r(o) } };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Pe(e).direction === "rtl" };
function Ba(e, t, o, n) {
  n === void 0 && (n = {});
  const { ancestorScroll: i = !0, ancestorResize: r = !0, elementResize: s = !0, animationFrame: a = !1 } = n, l = i || r ? [...Ce(e) ? pt(e) : e.contextElement ? pt(e.contextElement) : [], ...pt(t)] : [];
  l.forEach((v) => {
    const p = !Ce(v) && v.toString().includes("V");
    !i || a && !p || v.addEventListener("scroll", o, { passive: !0 }), r && v.addEventListener("resize", o);
  });
  let d, f = null;
  s && (f = new ResizeObserver(() => {
    o();
  }), Ce(e) && !a && f.observe(e), Ce(e) || !e.contextElement || a || f.observe(e.contextElement), f.observe(t));
  let u = a ? Be(e) : null;
  return a && function v() {
    const p = Be(e);
    !u || p.x === u.x && p.y === u.y && p.width === u.width && p.height === u.height || o(), u = p, d = requestAnimationFrame(v);
  }(), o(), () => {
    var v;
    l.forEach((p) => {
      i && p.removeEventListener("scroll", o), r && p.removeEventListener("resize", o);
    }), (v = f) == null || v.disconnect(), f = null, a && cancelAnimationFrame(d);
  };
}
const Wa = (e, t, o) => {
  const n = /* @__PURE__ */ new Map(), i = { platform: Ha, ...o }, r = { ...i.platform, _c: n };
  return Aa(e, t, { ...i, platform: r });
}, Xa = (e) => {
  const {
    element: t,
    padding: o
  } = e;
  function n(i) {
    return {}.hasOwnProperty.call(i, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(i) {
      return t && n(t) ? t.current != null ? Uo({
        element: t.current,
        padding: o
      }).fn(i) : {} : t ? Uo({
        element: t,
        padding: o
      }).fn(i) : {};
    }
  };
};
var St = typeof document < "u" ? mn : ie;
function jt(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let o, n, i;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (o = e.length, o != t.length)
        return !1;
      for (n = o; n-- !== 0; )
        if (!jt(e[n], t[n]))
          return !1;
      return !0;
    }
    if (i = Object.keys(e), o = i.length, o !== Object.keys(t).length)
      return !1;
    for (n = o; n-- !== 0; )
      if (!{}.hasOwnProperty.call(t, i[n]))
        return !1;
    for (n = o; n-- !== 0; ) {
      const r = i[n];
      if (!(r === "_owner" && e.$$typeof) && !jt(e[r], t[r]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function ei(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function on(e, t) {
  const o = ei(e);
  return Math.round(t * o) / o;
}
function nn(e) {
  const t = T.useRef(e);
  return St(() => {
    t.current = e;
  }), t;
}
function Ua(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: o = "absolute",
    middleware: n = [],
    platform: i,
    elements: {
      reference: r,
      floating: s
    } = {},
    transform: a = !0,
    whileElementsMounted: l,
    open: d
  } = e, [f, u] = T.useState({
    x: 0,
    y: 0,
    strategy: o,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [v, p] = T.useState(n);
  jt(v, n) || p(n);
  const [x, g] = T.useState(null), [m, b] = T.useState(null), h = T.useCallback((A) => {
    A != E.current && (E.current = A, g(A));
  }, [g]), y = T.useCallback((A) => {
    A !== S.current && (S.current = A, b(A));
  }, [b]), w = r || x, $ = s || m, E = T.useRef(null), S = T.useRef(null), P = T.useRef(f), L = nn(l), X = nn(i), j = T.useCallback(() => {
    if (!E.current || !S.current)
      return;
    const A = {
      placement: t,
      strategy: o,
      middleware: v
    };
    X.current && (A.platform = X.current), Wa(E.current, S.current, A).then((J) => {
      const Q = {
        ...J,
        isPositioned: !0
      };
      F.current && !jt(P.current, Q) && (P.current = Q, Ki.flushSync(() => {
        u(Q);
      }));
    });
  }, [v, t, o, X]);
  St(() => {
    d === !1 && P.current.isPositioned && (P.current.isPositioned = !1, u((A) => ({
      ...A,
      isPositioned: !1
    })));
  }, [d]);
  const F = T.useRef(!1);
  St(() => (F.current = !0, () => {
    F.current = !1;
  }), []), St(() => {
    if (w && (E.current = w), $ && (S.current = $), w && $) {
      if (L.current)
        return L.current(w, $, j);
      j();
    }
  }, [w, $, j, L]);
  const z = T.useMemo(() => ({
    reference: E,
    floating: S,
    setReference: h,
    setFloating: y
  }), [h, y]), D = T.useMemo(() => ({
    reference: w,
    floating: $
  }), [w, $]), N = T.useMemo(() => {
    const A = {
      position: o,
      left: 0,
      top: 0
    };
    if (!D.floating)
      return A;
    const J = on(D.floating, f.x), Q = on(D.floating, f.y);
    return a ? {
      ...A,
      transform: "translate(" + J + "px, " + Q + "px)",
      ...ei(D.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: o,
      left: J,
      top: Q
    };
  }, [o, a, D.floating, f.x, f.y]);
  return T.useMemo(() => ({
    ...f,
    update: j,
    refs: z,
    elements: D,
    floatingStyles: N
  }), [f, j, z, D, N]);
}
function Ka(e) {
  const [t, o] = ee(void 0);
  return Ee(() => {
    if (e) {
      o({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const n = new ResizeObserver((i) => {
        if (!Array.isArray(i) || !i.length)
          return;
        const r = i[0];
        let s, a;
        if ("borderBoxSize" in r) {
          const l = r.borderBoxSize, d = Array.isArray(l) ? l[0] : l;
          s = d.inlineSize, a = d.blockSize;
        } else
          s = e.offsetWidth, a = e.offsetHeight;
        o({
          width: s,
          height: a
        });
      });
      return n.observe(e, {
        box: "border-box"
      }), () => n.unobserve(e);
    } else
      o(void 0);
  }, [
    e
  ]), t;
}
const ti = "Popper", [oi, ni] = go(ti), [Ya, ii] = oi(ti), Ga = (e) => {
  const { __scopePopper: t, children: o } = e, [n, i] = ee(null);
  return /* @__PURE__ */ R(Ya, {
    scope: t,
    anchor: n,
    onAnchorChange: i
  }, o);
}, Za = "PopperAnchor", Ja = /* @__PURE__ */ V((e, t) => {
  const { __scopePopper: o, virtualRef: n, ...i } = e, r = ii(Za, o), s = de(null), a = ve(t, s);
  return ie(() => {
    r.onAnchorChange((n == null ? void 0 : n.current) || s.current);
  }), n ? null : /* @__PURE__ */ R(ue.div, Y({}, i, {
    ref: a
  }));
}), ri = "PopperContent", [Qa, Oc] = oi(ri), es = /* @__PURE__ */ V((e, t) => {
  var o, n, i, r, s, a, l, d;
  const { __scopePopper: f, side: u = "bottom", sideOffset: v = 0, align: p = "center", alignOffset: x = 0, arrowPadding: g = 0, collisionBoundary: m = [], collisionPadding: b = 0, sticky: h = "partial", hideWhenDetached: y = !1, avoidCollisions: w = !0, onPlaced: $, ...E } = e, S = ii(ri, f), [P, L] = ee(null), X = ve(
    t,
    (ge) => L(ge)
  ), [j, F] = ee(null), z = Ka(j), D = (o = z == null ? void 0 : z.width) !== null && o !== void 0 ? o : 0, N = (n = z == null ? void 0 : z.height) !== null && n !== void 0 ? n : 0, A = u + (p !== "center" ? "-" + p : ""), J = typeof b == "number" ? b : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...b
  }, Q = Array.isArray(m) ? m : [
    m
  ], fe = Q.length > 0, oe = {
    padding: J,
    boundary: Q.filter(ts),
    // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
    altBoundary: fe
  }, { refs: se, floatingStyles: me, placement: _e, isPositioned: be, middlewareData: ye } = Ua({
    // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
    strategy: "fixed",
    placement: A,
    whileElementsMounted: Ba,
    elements: {
      reference: S.anchor
    },
    middleware: [
      Da({
        mainAxis: v + N,
        alignmentAxis: x
      }),
      w && Ia({
        mainAxis: !0,
        crossAxis: !1,
        limiter: h === "partial" ? La() : void 0,
        ...oe
      }),
      w && za({
        ...oe
      }),
      Ma({
        ...oe,
        apply: ({ elements: ge, rects: Te, availableWidth: Ae, availableHeight: Le }) => {
          const { width: bt, height: Ye } = Te.reference, Ge = ge.floating.style;
          Ge.setProperty("--radix-popper-available-width", `${Ae}px`), Ge.setProperty("--radix-popper-available-height", `${Le}px`), Ge.setProperty("--radix-popper-anchor-width", `${bt}px`), Ge.setProperty("--radix-popper-anchor-height", `${Ye}px`);
        }
      }),
      j && Xa({
        element: j,
        padding: g
      }),
      os({
        arrowWidth: D,
        arrowHeight: N
      }),
      y && Na({
        strategy: "referenceHidden"
      })
    ]
  }), [ke, O] = ai(_e), B = Ne($);
  Ee(() => {
    be && (B == null || B());
  }, [
    be,
    B
  ]);
  const le = (i = ye.arrow) === null || i === void 0 ? void 0 : i.x, G = (r = ye.arrow) === null || r === void 0 ? void 0 : r.y, Z = ((s = ye.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0, [U, he] = ee();
  return Ee(() => {
    P && he(window.getComputedStyle(P).zIndex);
  }, [
    P
  ]), /* @__PURE__ */ R("div", {
    ref: se.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...me,
      transform: be ? me.transform : "translate(0, -200%)",
      // keep off the page when measuring
      minWidth: "max-content",
      zIndex: U,
      ["--radix-popper-transform-origin"]: [
        (a = ye.transformOrigin) === null || a === void 0 ? void 0 : a.x,
        (l = ye.transformOrigin) === null || l === void 0 ? void 0 : l.y
      ].join(" ")
    },
    dir: e.dir
  }, /* @__PURE__ */ R(Qa, {
    scope: f,
    placedSide: ke,
    onArrowChange: F,
    arrowX: le,
    arrowY: G,
    shouldHideArrow: Z
  }, /* @__PURE__ */ R(ue.div, Y({
    "data-side": ke,
    "data-align": O
  }, E, {
    ref: X,
    style: {
      ...E.style,
      // if the PopperContent hasn't been placed yet (not all measurements done)
      // we prevent animations so that users's animation don't kick in too early referring wrong sides
      animation: be ? void 0 : "none",
      // hide the content if using the hide middleware and should be hidden
      opacity: (d = ye.hide) !== null && d !== void 0 && d.referenceHidden ? 0 : void 0
    }
  }))));
});
function ts(e) {
  return e !== null;
}
const os = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var o, n, i, r, s;
    const { placement: a, rects: l, middlewareData: d } = t, u = ((o = d.arrow) === null || o === void 0 ? void 0 : o.centerOffset) !== 0, v = u ? 0 : e.arrowWidth, p = u ? 0 : e.arrowHeight, [x, g] = ai(a), m = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[g], b = ((n = (i = d.arrow) === null || i === void 0 ? void 0 : i.x) !== null && n !== void 0 ? n : 0) + v / 2, h = ((r = (s = d.arrow) === null || s === void 0 ? void 0 : s.y) !== null && r !== void 0 ? r : 0) + p / 2;
    let y = "", w = "";
    return x === "bottom" ? (y = u ? m : `${b}px`, w = `${-p}px`) : x === "top" ? (y = u ? m : `${b}px`, w = `${l.floating.height + p}px`) : x === "right" ? (y = `${-p}px`, w = u ? m : `${h}px`) : x === "left" && (y = `${l.floating.width + p}px`, w = u ? m : `${h}px`), {
      data: {
        x: y,
        y: w
      }
    };
  }
});
function ai(e) {
  const [t, o = "center"] = e.split("-");
  return [
    t,
    o
  ];
}
const ns = Ga, is = Ja, rs = es, as = /* @__PURE__ */ V((e, t) => {
  var o;
  const { container: n = globalThis == null || (o = globalThis.document) === null || o === void 0 ? void 0 : o.body, ...i } = e;
  return n ? /* @__PURE__ */ Yi.createPortal(/* @__PURE__ */ R(ue.div, Y({}, i, {
    ref: t
  })), n) : null;
});
function rn({ prop: e, defaultProp: t, onChange: o = () => {
} }) {
  const [n, i] = ss({
    defaultProp: t,
    onChange: o
  }), r = e !== void 0, s = r ? e : n, a = Ne(o), l = pe((d) => {
    if (r) {
      const u = typeof d == "function" ? d(e) : d;
      u !== e && a(u);
    } else
      i(d);
  }, [
    r,
    e,
    i,
    a
  ]);
  return [
    s,
    l
  ];
}
function ss({ defaultProp: e, onChange: t }) {
  const o = ee(e), [n] = o, i = de(n), r = Ne(t);
  return ie(() => {
    i.current !== n && (r(n), i.current = n);
  }, [
    n,
    i,
    r
  ]), o;
}
function ls(e) {
  const t = de({
    value: e,
    previous: e
  });
  return nt(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [
    e
  ]);
}
const cs = /* @__PURE__ */ V((e, t) => /* @__PURE__ */ R(ue.span, Y({}, e, {
  ref: t,
  style: {
    // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
})));
var ds = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, Qe = /* @__PURE__ */ new WeakMap(), Ct = /* @__PURE__ */ new WeakMap(), wt = {}, Jt = 0, si = function(e) {
  return e && (e.host || si(e.parentNode));
}, us = function(e, t) {
  return t.map(function(o) {
    if (e.contains(o))
      return o;
    var n = si(o);
    return n && e.contains(n) ? n : (console.error("aria-hidden", o, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(o) {
    return !!o;
  });
}, fs = function(e, t, o, n) {
  var i = us(t, Array.isArray(e) ? e : [e]);
  wt[o] || (wt[o] = /* @__PURE__ */ new WeakMap());
  var r = wt[o], s = [], a = /* @__PURE__ */ new Set(), l = new Set(i), d = function(u) {
    !u || a.has(u) || (a.add(u), d(u.parentNode));
  };
  i.forEach(d);
  var f = function(u) {
    !u || l.has(u) || Array.prototype.forEach.call(u.children, function(v) {
      if (a.has(v))
        f(v);
      else {
        var p = v.getAttribute(n), x = p !== null && p !== "false", g = (Qe.get(v) || 0) + 1, m = (r.get(v) || 0) + 1;
        Qe.set(v, g), r.set(v, m), s.push(v), g === 1 && x && Ct.set(v, !0), m === 1 && v.setAttribute(o, "true"), x || v.setAttribute(n, "true");
      }
    });
  };
  return f(t), a.clear(), Jt++, function() {
    s.forEach(function(u) {
      var v = Qe.get(u) - 1, p = r.get(u) - 1;
      Qe.set(u, v), r.set(u, p), v || (Ct.has(u) || u.removeAttribute(n), Ct.delete(u)), p || u.removeAttribute(o);
    }), Jt--, Jt || (Qe = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ new WeakMap(), Ct = /* @__PURE__ */ new WeakMap(), wt = {});
  };
}, gs = function(e, t, o) {
  o === void 0 && (o = "data-aria-hidden");
  var n = Array.from(Array.isArray(e) ? e : [e]), i = t || ds(e);
  return i ? (n.push.apply(n, Array.from(i.querySelectorAll("[aria-live]"))), fs(n, i, o, "aria-hidden")) : function() {
    return null;
  };
}, Oe = function() {
  return Oe = Object.assign || function(t) {
    for (var o, n = 1, i = arguments.length; n < i; n++) {
      o = arguments[n];
      for (var r in o)
        Object.prototype.hasOwnProperty.call(o, r) && (t[r] = o[r]);
    }
    return t;
  }, Oe.apply(this, arguments);
};
function li(e, t) {
  var o = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (o[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var i = 0, n = Object.getOwnPropertySymbols(e); i < n.length; i++)
      t.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[i]) && (o[n[i]] = e[n[i]]);
  return o;
}
function ps(e, t, o) {
  if (o || arguments.length === 2)
    for (var n = 0, i = t.length, r; n < i; n++)
      (r || !(n in t)) && (r || (r = Array.prototype.slice.call(t, 0, n)), r[n] = t[n]);
  return e.concat(r || Array.prototype.slice.call(t));
}
var Et = "right-scroll-bar-position", Pt = "width-before-scroll-bar", vs = "with-scroll-bars-hidden", ms = "--removed-body-scroll-bar-size";
function hs(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function xs(e, t) {
  var o = ee(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return o.value;
        },
        set current(n) {
          var i = o.value;
          i !== n && (o.value = n, o.callback(n, i));
        }
      }
    };
  })[0];
  return o.callback = t, o.facade;
}
function bs(e, t) {
  return xs(t || null, function(o) {
    return e.forEach(function(n) {
      return hs(n, o);
    });
  });
}
function ys(e) {
  return e;
}
function Cs(e, t) {
  t === void 0 && (t = ys);
  var o = [], n = !1, i = {
    read: function() {
      if (n)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return o.length ? o[o.length - 1] : e;
    },
    useMedium: function(r) {
      var s = t(r, n);
      return o.push(s), function() {
        o = o.filter(function(a) {
          return a !== s;
        });
      };
    },
    assignSyncMedium: function(r) {
      for (n = !0; o.length; ) {
        var s = o;
        o = [], s.forEach(r);
      }
      o = {
        push: function(a) {
          return r(a);
        },
        filter: function() {
          return o;
        }
      };
    },
    assignMedium: function(r) {
      n = !0;
      var s = [];
      if (o.length) {
        var a = o;
        o = [], a.forEach(r), s = o;
      }
      var l = function() {
        var f = s;
        s = [], f.forEach(r);
      }, d = function() {
        return Promise.resolve().then(l);
      };
      d(), o = {
        push: function(f) {
          s.push(f), d();
        },
        filter: function(f) {
          return s = s.filter(f), o;
        }
      };
    }
  };
  return i;
}
function ws(e) {
  e === void 0 && (e = {});
  var t = Cs(null);
  return t.options = Oe({ async: !0, ssr: !1 }, e), t;
}
var ci = function(e) {
  var t = e.sideCar, o = li(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var n = t.read();
  if (!n)
    throw new Error("Sidecar medium not found");
  return T.createElement(n, Oe({}, o));
};
ci.isSideCarExport = !0;
function _s(e, t) {
  return e.useMedium(t), ci;
}
var di = ws(), Qt = function() {
}, It = T.forwardRef(function(e, t) {
  var o = T.useRef(null), n = T.useState({
    onScrollCapture: Qt,
    onWheelCapture: Qt,
    onTouchMoveCapture: Qt
  }), i = n[0], r = n[1], s = e.forwardProps, a = e.children, l = e.className, d = e.removeScrollBar, f = e.enabled, u = e.shards, v = e.sideCar, p = e.noIsolation, x = e.inert, g = e.allowPinchZoom, m = e.as, b = m === void 0 ? "div" : m, h = li(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), y = v, w = bs([o, t]), $ = Oe(Oe({}, h), i);
  return T.createElement(
    T.Fragment,
    null,
    f && T.createElement(y, { sideCar: di, removeScrollBar: d, shards: u, noIsolation: p, inert: x, setCallbacks: r, allowPinchZoom: !!g, lockRef: o }),
    s ? T.cloneElement(T.Children.only(a), Oe(Oe({}, $), { ref: w })) : T.createElement(b, Oe({}, $, { className: l, ref: w }), a)
  );
});
It.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
It.classNames = {
  fullWidth: Pt,
  zeroRight: Et
};
var an, ks = function() {
  if (an)
    return an;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function $s() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = ks();
  return t && e.setAttribute("nonce", t), e;
}
function Ss(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Es(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var Ps = function() {
  var e = 0, t = null;
  return {
    add: function(o) {
      e == 0 && (t = $s()) && (Ss(t, o), Es(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, Rs = function() {
  var e = Ps();
  return function(t, o) {
    T.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && o]);
  };
}, ui = function() {
  var e = Rs(), t = function(o) {
    var n = o.styles, i = o.dynamic;
    return e(n, i), null;
  };
  return t;
}, Ts = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, eo = function(e) {
  return parseInt(e || "", 10) || 0;
}, As = function(e) {
  var t = window.getComputedStyle(document.body), o = t[e === "padding" ? "paddingLeft" : "marginLeft"], n = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [eo(o), eo(n), eo(i)];
}, Os = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return Ts;
  var t = As(e), o = document.documentElement.clientWidth, n = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, n - o + t[2] - t[0])
  };
}, qs = ui(), js = function(e, t, o, n) {
  var i = e.left, r = e.top, s = e.right, a = e.gap;
  return o === void 0 && (o = "margin"), `
  .`.concat(vs, ` {
   overflow: hidden `).concat(n, `;
   padding-right: `).concat(a, "px ").concat(n, `;
  }
  body {
    overflow: hidden `).concat(n, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(n, ";"),
    o === "margin" && `
    padding-left: `.concat(i, `px;
    padding-top: `).concat(r, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(a, "px ").concat(n, `;
    `),
    o === "padding" && "padding-right: ".concat(a, "px ").concat(n, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Et, ` {
    right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(Pt, ` {
    margin-right: `).concat(a, "px ").concat(n, `;
  }
  
  .`).concat(Et, " .").concat(Et, ` {
    right: 0 `).concat(n, `;
  }
  
  .`).concat(Pt, " .").concat(Pt, ` {
    margin-right: 0 `).concat(n, `;
  }
  
  body {
    `).concat(ms, ": ").concat(a, `px;
  }
`);
}, zs = function(e) {
  var t = e.noRelative, o = e.noImportant, n = e.gapMode, i = n === void 0 ? "margin" : n, r = T.useMemo(function() {
    return Os(i);
  }, [i]);
  return T.createElement(qs, { styles: js(r, !t, i, o ? "" : "!important") });
}, so = !1;
if (typeof window < "u")
  try {
    var _t = Object.defineProperty({}, "passive", {
      get: function() {
        return so = !0, !0;
      }
    });
    window.addEventListener("test", _t, _t), window.removeEventListener("test", _t, _t);
  } catch {
    so = !1;
  }
var et = so ? { passive: !1 } : !1, Ns = function(e) {
  return e.tagName === "TEXTAREA";
}, fi = function(e, t) {
  var o = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    o[t] !== "hidden" && // contains scroll inside self
    !(o.overflowY === o.overflowX && !Ns(e) && o[t] === "visible")
  );
}, Ds = function(e) {
  return fi(e, "overflowY");
}, Is = function(e) {
  return fi(e, "overflowX");
}, sn = function(e, t) {
  var o = t;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var n = gi(e, o);
    if (n) {
      var i = pi(e, o), r = i[1], s = i[2];
      if (r > s)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== document.body);
  return !1;
}, Ls = function(e) {
  var t = e.scrollTop, o = e.scrollHeight, n = e.clientHeight;
  return [
    t,
    o,
    n
  ];
}, Ms = function(e) {
  var t = e.scrollLeft, o = e.scrollWidth, n = e.clientWidth;
  return [
    t,
    o,
    n
  ];
}, gi = function(e, t) {
  return e === "v" ? Ds(t) : Is(t);
}, pi = function(e, t) {
  return e === "v" ? Ls(t) : Ms(t);
}, Fs = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Vs = function(e, t, o, n, i) {
  var r = Fs(e, window.getComputedStyle(t).direction), s = r * n, a = o.target, l = t.contains(a), d = !1, f = s > 0, u = 0, v = 0;
  do {
    var p = pi(e, a), x = p[0], g = p[1], m = p[2], b = g - m - r * x;
    (x || b) && gi(e, a) && (u += b, v += x), a = a.parentNode;
  } while (
    // portaled content
    !l && a !== document.body || // self content
    l && (t.contains(a) || t === a)
  );
  return (f && (i && u === 0 || !i && s > u) || !f && (i && v === 0 || !i && -s > v)) && (d = !0), d;
}, kt = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, ln = function(e) {
  return [e.deltaX, e.deltaY];
}, cn = function(e) {
  return e && "current" in e ? e.current : e;
}, Hs = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Bs = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Ws = 0, tt = [];
function Xs(e) {
  var t = T.useRef([]), o = T.useRef([0, 0]), n = T.useRef(), i = T.useState(Ws++)[0], r = T.useState(function() {
    return ui();
  })[0], s = T.useRef(e);
  T.useEffect(function() {
    s.current = e;
  }, [e]), T.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(i));
      var g = ps([e.lockRef.current], (e.shards || []).map(cn), !0).filter(Boolean);
      return g.forEach(function(m) {
        return m.classList.add("allow-interactivity-".concat(i));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(i)), g.forEach(function(m) {
          return m.classList.remove("allow-interactivity-".concat(i));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var a = T.useCallback(function(g, m) {
    if ("touches" in g && g.touches.length === 2)
      return !s.current.allowPinchZoom;
    var b = kt(g), h = o.current, y = "deltaX" in g ? g.deltaX : h[0] - b[0], w = "deltaY" in g ? g.deltaY : h[1] - b[1], $, E = g.target, S = Math.abs(y) > Math.abs(w) ? "h" : "v";
    if ("touches" in g && S === "h" && E.type === "range")
      return !1;
    var P = sn(S, E);
    if (!P)
      return !0;
    if (P ? $ = S : ($ = S === "v" ? "h" : "v", P = sn(S, E)), !P)
      return !1;
    if (!n.current && "changedTouches" in g && (y || w) && (n.current = $), !$)
      return !0;
    var L = n.current || $;
    return Vs(L, m, g, L === "h" ? y : w, !0);
  }, []), l = T.useCallback(function(g) {
    var m = g;
    if (!(!tt.length || tt[tt.length - 1] !== r)) {
      var b = "deltaY" in m ? ln(m) : kt(m), h = t.current.filter(function($) {
        return $.name === m.type && $.target === m.target && Hs($.delta, b);
      })[0];
      if (h && h.should) {
        m.cancelable && m.preventDefault();
        return;
      }
      if (!h) {
        var y = (s.current.shards || []).map(cn).filter(Boolean).filter(function($) {
          return $.contains(m.target);
        }), w = y.length > 0 ? a(m, y[0]) : !s.current.noIsolation;
        w && m.cancelable && m.preventDefault();
      }
    }
  }, []), d = T.useCallback(function(g, m, b, h) {
    var y = { name: g, delta: m, target: b, should: h };
    t.current.push(y), setTimeout(function() {
      t.current = t.current.filter(function(w) {
        return w !== y;
      });
    }, 1);
  }, []), f = T.useCallback(function(g) {
    o.current = kt(g), n.current = void 0;
  }, []), u = T.useCallback(function(g) {
    d(g.type, ln(g), g.target, a(g, e.lockRef.current));
  }, []), v = T.useCallback(function(g) {
    d(g.type, kt(g), g.target, a(g, e.lockRef.current));
  }, []);
  T.useEffect(function() {
    return tt.push(r), e.setCallbacks({
      onScrollCapture: u,
      onWheelCapture: u,
      onTouchMoveCapture: v
    }), document.addEventListener("wheel", l, et), document.addEventListener("touchmove", l, et), document.addEventListener("touchstart", f, et), function() {
      tt = tt.filter(function(g) {
        return g !== r;
      }), document.removeEventListener("wheel", l, et), document.removeEventListener("touchmove", l, et), document.removeEventListener("touchstart", f, et);
    };
  }, []);
  var p = e.removeScrollBar, x = e.inert;
  return T.createElement(
    T.Fragment,
    null,
    x ? T.createElement(r, { styles: Bs(i) }) : null,
    p ? T.createElement(zs, { gapMode: "margin" }) : null
  );
}
const Us = _s(di, Xs);
var vi = T.forwardRef(function(e, t) {
  return T.createElement(It, Oe({}, e, { ref: t, sideCar: Us }));
});
vi.classNames = It.classNames;
const Ks = vi, Ys = [
  " ",
  "Enter",
  "ArrowUp",
  "ArrowDown"
], Gs = [
  " ",
  "Enter"
], Lt = "Select", [Mt, Ft, Zs] = ca(Lt), [st, qc] = go(Lt, [
  Zs,
  ni
]), ho = ni(), [Js, Ue] = st(Lt), [Qs, el] = st(Lt), tl = (e) => {
  const { __scopeSelect: t, children: o, open: n, defaultOpen: i, onOpenChange: r, value: s, defaultValue: a, onValueChange: l, dir: d, name: f, autoComplete: u, disabled: v, required: p } = e, x = ho(t), [g, m] = ee(null), [b, h] = ee(null), [y, w] = ee(!1), $ = ua(d), [E = !1, S] = rn({
    prop: n,
    defaultProp: i,
    onChange: r
  }), [P, L] = rn({
    prop: s,
    defaultProp: a,
    onChange: l
  }), X = de(null), j = g ? !!g.closest("form") : !0, [F, z] = ee(/* @__PURE__ */ new Set()), D = Array.from(F).map(
    (N) => N.props.value
  ).join(";");
  return /* @__PURE__ */ R(ns, x, /* @__PURE__ */ R(Js, {
    required: p,
    scope: t,
    trigger: g,
    onTriggerChange: m,
    valueNode: b,
    onValueNodeChange: h,
    valueNodeHasChildren: y,
    onValueNodeHasChildrenChange: w,
    contentId: po(),
    value: P,
    onValueChange: L,
    open: E,
    onOpenChange: S,
    dir: $,
    triggerPointerDownPosRef: X,
    disabled: v
  }, /* @__PURE__ */ R(Mt.Provider, {
    scope: t
  }, /* @__PURE__ */ R(Qs, {
    scope: e.__scopeSelect,
    onNativeOptionAdd: pe((N) => {
      z(
        (A) => new Set(A).add(N)
      );
    }, []),
    onNativeOptionRemove: pe((N) => {
      z((A) => {
        const J = new Set(A);
        return J.delete(N), J;
      });
    }, [])
  }, o)), j ? /* @__PURE__ */ R(bi, {
    key: D,
    "aria-hidden": !0,
    required: p,
    tabIndex: -1,
    name: f,
    autoComplete: u,
    value: P,
    onChange: (N) => L(N.target.value),
    disabled: v
  }, P === void 0 ? /* @__PURE__ */ R("option", {
    value: ""
  }) : null, Array.from(F)) : null));
}, ol = "SelectTrigger", nl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, disabled: n = !1, ...i } = e, r = ho(o), s = Ue(ol, o), a = s.disabled || n, l = ve(t, s.onTriggerChange), d = Ft(o), [f, u, v] = yi((x) => {
    const g = d().filter(
      (h) => !h.disabled
    ), m = g.find(
      (h) => h.value === s.value
    ), b = Ci(g, x, m);
    b !== void 0 && s.onValueChange(b.value);
  }), p = () => {
    a || (s.onOpenChange(!0), v());
  };
  return /* @__PURE__ */ R(is, Y({
    asChild: !0
  }, r), /* @__PURE__ */ R(ue.button, Y({
    type: "button",
    role: "combobox",
    "aria-controls": s.contentId,
    "aria-expanded": s.open,
    "aria-required": s.required,
    "aria-autocomplete": "none",
    dir: s.dir,
    "data-state": s.open ? "open" : "closed",
    disabled: a,
    "data-disabled": a ? "" : void 0,
    "data-placeholder": s.value === void 0 ? "" : void 0
  }, i, {
    ref: l,
    onClick: ce(i.onClick, (x) => {
      x.currentTarget.focus();
    }),
    onPointerDown: ce(i.onPointerDown, (x) => {
      const g = x.target;
      g.hasPointerCapture(x.pointerId) && g.releasePointerCapture(x.pointerId), x.button === 0 && x.ctrlKey === !1 && (p(), s.triggerPointerDownPosRef.current = {
        x: Math.round(x.pageX),
        y: Math.round(x.pageY)
      }, x.preventDefault());
    }),
    onKeyDown: ce(i.onKeyDown, (x) => {
      const g = f.current !== "";
      !(x.ctrlKey || x.altKey || x.metaKey) && x.key.length === 1 && u(x.key), !(g && x.key === " ") && Ys.includes(x.key) && (p(), x.preventDefault());
    })
  })));
}), il = "SelectValue", rl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, className: n, style: i, children: r, placeholder: s, ...a } = e, l = Ue(il, o), { onValueNodeHasChildrenChange: d } = l, f = r !== void 0, u = ve(t, l.onValueNodeChange);
  return Ee(() => {
    d(f);
  }, [
    d,
    f
  ]), /* @__PURE__ */ R(ue.span, Y({}, a, {
    ref: u,
    style: {
      pointerEvents: "none"
    }
  }), l.value === void 0 && s !== void 0 ? s : r);
}), al = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, children: n, ...i } = e;
  return /* @__PURE__ */ R(ue.span, Y({
    "aria-hidden": !0
  }, i, {
    ref: t
  }), n || "▼");
}), sl = (e) => /* @__PURE__ */ R(as, Y({
  asChild: !0
}, e)), rt = "SelectContent", ll = /* @__PURE__ */ V((e, t) => {
  const o = Ue(rt, e.__scopeSelect), [n, i] = ee();
  if (Ee(() => {
    i(new DocumentFragment());
  }, []), !o.open) {
    const r = n;
    return r ? /* @__PURE__ */ hn(/* @__PURE__ */ R(mi, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ R(Mt.Slot, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ R("div", null, e.children))), r) : null;
  }
  return /* @__PURE__ */ R(cl, Y({}, e, {
    ref: t
  }));
}), je = 10, [mi, Ke] = st(rt), cl = /* @__PURE__ */ V((e, t) => {
  const {
    __scopeSelect: o,
    position: n = "item-aligned",
    onCloseAutoFocus: i,
    onEscapeKeyDown: r,
    onPointerDownOutside: s,
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: v,
    collisionPadding: p,
    sticky: x,
    hideWhenDetached: g,
    avoidCollisions: m,
    //
    ...b
  } = e, h = Ue(rt, o), [y, w] = ee(null), [$, E] = ee(null), S = ve(
    t,
    (O) => w(O)
  ), [P, L] = ee(null), [X, j] = ee(null), F = Ft(o), [z, D] = ee(!1), N = de(!1);
  ie(() => {
    if (y)
      return gs(y);
  }, [
    y
  ]), Ca();
  const A = pe((O) => {
    const [B, ...le] = F().map(
      (U) => U.ref.current
    ), [G] = le.slice(-1), Z = document.activeElement;
    for (const U of O)
      if (U === Z || (U == null || U.scrollIntoView({
        block: "nearest"
      }), U === B && $ && ($.scrollTop = 0), U === G && $ && ($.scrollTop = $.scrollHeight), U == null || U.focus(), document.activeElement !== Z))
        return;
  }, [
    F,
    $
  ]), J = pe(
    () => A([
      P,
      y
    ]),
    [
      A,
      P,
      y
    ]
  );
  ie(() => {
    z && J();
  }, [
    z,
    J
  ]);
  const { onOpenChange: Q, triggerPointerDownPosRef: fe } = h;
  ie(() => {
    if (y) {
      let O = {
        x: 0,
        y: 0
      };
      const B = (G) => {
        var Z, U, he, ge;
        O = {
          x: Math.abs(Math.round(G.pageX) - ((Z = (U = fe.current) === null || U === void 0 ? void 0 : U.x) !== null && Z !== void 0 ? Z : 0)),
          y: Math.abs(Math.round(G.pageY) - ((he = (ge = fe.current) === null || ge === void 0 ? void 0 : ge.y) !== null && he !== void 0 ? he : 0))
        };
      }, le = (G) => {
        O.x <= 10 && O.y <= 10 ? G.preventDefault() : y.contains(G.target) || Q(!1), document.removeEventListener("pointermove", B), fe.current = null;
      };
      return fe.current !== null && (document.addEventListener("pointermove", B), document.addEventListener("pointerup", le, {
        capture: !0,
        once: !0
      })), () => {
        document.removeEventListener("pointermove", B), document.removeEventListener("pointerup", le, {
          capture: !0
        });
      };
    }
  }, [
    y,
    Q,
    fe
  ]), ie(() => {
    const O = () => Q(!1);
    return window.addEventListener("blur", O), window.addEventListener("resize", O), () => {
      window.removeEventListener("blur", O), window.removeEventListener("resize", O);
    };
  }, [
    Q
  ]);
  const [oe, se] = yi((O) => {
    const B = F().filter(
      (Z) => !Z.disabled
    ), le = B.find(
      (Z) => Z.ref.current === document.activeElement
    ), G = Ci(B, O, le);
    G && setTimeout(
      () => G.ref.current.focus()
    );
  }), me = pe((O, B, le) => {
    const G = !N.current && !le;
    (h.value !== void 0 && h.value === B || G) && (L(O), G && (N.current = !0));
  }, [
    h.value
  ]), _e = pe(
    () => y == null ? void 0 : y.focus(),
    [
      y
    ]
  ), be = pe((O, B, le) => {
    const G = !N.current && !le;
    (h.value !== void 0 && h.value === B || G) && j(O);
  }, [
    h.value
  ]), ye = n === "popper" ? dn : dl, ke = ye === dn ? {
    side: a,
    sideOffset: l,
    align: d,
    alignOffset: f,
    arrowPadding: u,
    collisionBoundary: v,
    collisionPadding: p,
    sticky: x,
    hideWhenDetached: g,
    avoidCollisions: m
  } : {};
  return /* @__PURE__ */ R(mi, {
    scope: o,
    content: y,
    viewport: $,
    onViewportChange: E,
    itemRefCallback: me,
    selectedItem: P,
    onItemLeave: _e,
    itemTextRefCallback: be,
    focusSelectedItem: J,
    selectedItemText: X,
    position: n,
    isPositioned: z,
    searchRef: oe
  }, /* @__PURE__ */ R(Ks, {
    as: mt,
    allowPinchZoom: !0
  }, /* @__PURE__ */ R(wa, {
    asChild: !0,
    trapped: h.open,
    onMountAutoFocus: (O) => {
      O.preventDefault();
    },
    onUnmountAutoFocus: ce(i, (O) => {
      var B;
      (B = h.trigger) === null || B === void 0 || B.focus({
        preventScroll: !0
      }), O.preventDefault();
    })
  }, /* @__PURE__ */ R(xa, {
    asChild: !0,
    disableOutsidePointerEvents: !0,
    onEscapeKeyDown: r,
    onPointerDownOutside: s,
    onFocusOutside: (O) => O.preventDefault(),
    onDismiss: () => h.onOpenChange(!1)
  }, /* @__PURE__ */ R(ye, Y({
    role: "listbox",
    id: h.contentId,
    "data-state": h.open ? "open" : "closed",
    dir: h.dir,
    onContextMenu: (O) => O.preventDefault()
  }, b, ke, {
    onPlaced: () => D(!0),
    ref: S,
    style: {
      // flex layout so we can place the scroll buttons properly
      display: "flex",
      flexDirection: "column",
      // reset the outline by default as the content MAY get focused
      outline: "none",
      ...b.style
    },
    onKeyDown: ce(b.onKeyDown, (O) => {
      const B = O.ctrlKey || O.altKey || O.metaKey;
      if (O.key === "Tab" && O.preventDefault(), !B && O.key.length === 1 && se(O.key), [
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End"
      ].includes(O.key)) {
        let G = F().filter(
          (Z) => !Z.disabled
        ).map(
          (Z) => Z.ref.current
        );
        if ([
          "ArrowUp",
          "End"
        ].includes(O.key) && (G = G.slice().reverse()), [
          "ArrowUp",
          "ArrowDown"
        ].includes(O.key)) {
          const Z = O.target, U = G.indexOf(Z);
          G = G.slice(U + 1);
        }
        setTimeout(
          () => A(G)
        ), O.preventDefault();
      }
    })
  }))))));
}), dl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, onPlaced: n, ...i } = e, r = Ue(rt, o), s = Ke(rt, o), [a, l] = ee(null), [d, f] = ee(null), u = ve(
    t,
    (S) => f(S)
  ), v = Ft(o), p = de(!1), x = de(!0), { viewport: g, selectedItem: m, selectedItemText: b, focusSelectedItem: h } = s, y = pe(() => {
    if (r.trigger && r.valueNode && a && d && g && m && b) {
      const S = r.trigger.getBoundingClientRect(), P = d.getBoundingClientRect(), L = r.valueNode.getBoundingClientRect(), X = b.getBoundingClientRect();
      if (r.dir !== "rtl") {
        const Z = X.left - P.left, U = L.left - Z, he = S.left - U, ge = S.width + he, Te = Math.max(ge, P.width), Ae = window.innerWidth - je, Le = Io(U, [
          je,
          Ae - Te
        ]);
        a.style.minWidth = ge + "px", a.style.left = Le + "px";
      } else {
        const Z = P.right - X.right, U = window.innerWidth - L.right - Z, he = window.innerWidth - S.right - U, ge = S.width + he, Te = Math.max(ge, P.width), Ae = window.innerWidth - je, Le = Io(U, [
          je,
          Ae - Te
        ]);
        a.style.minWidth = ge + "px", a.style.right = Le + "px";
      }
      const j = v(), F = window.innerHeight - je * 2, z = g.scrollHeight, D = window.getComputedStyle(d), N = parseInt(D.borderTopWidth, 10), A = parseInt(D.paddingTop, 10), J = parseInt(D.borderBottomWidth, 10), Q = parseInt(D.paddingBottom, 10), fe = N + A + z + Q + J, oe = Math.min(m.offsetHeight * 5, fe), se = window.getComputedStyle(g), me = parseInt(se.paddingTop, 10), _e = parseInt(se.paddingBottom, 10), be = S.top + S.height / 2 - je, ye = F - be, ke = m.offsetHeight / 2, O = m.offsetTop + ke, B = N + A + O, le = fe - B;
      if (B <= be) {
        const Z = m === j[j.length - 1].ref.current;
        a.style.bottom = "0px";
        const U = d.clientHeight - g.offsetTop - g.offsetHeight, he = Math.max(ye, ke + (Z ? _e : 0) + U + J), ge = B + he;
        a.style.height = ge + "px";
      } else {
        const Z = m === j[0].ref.current;
        a.style.top = "0px";
        const he = Math.max(be, N + g.offsetTop + (Z ? me : 0) + ke) + le;
        a.style.height = he + "px", g.scrollTop = B - be + g.offsetTop;
      }
      a.style.margin = `${je}px 0`, a.style.minHeight = oe + "px", a.style.maxHeight = F + "px", n == null || n(), requestAnimationFrame(
        () => p.current = !0
      );
    }
  }, [
    v,
    r.trigger,
    r.valueNode,
    a,
    d,
    g,
    m,
    b,
    r.dir,
    n
  ]);
  Ee(
    () => y(),
    [
      y
    ]
  );
  const [w, $] = ee();
  Ee(() => {
    d && $(window.getComputedStyle(d).zIndex);
  }, [
    d
  ]);
  const E = pe((S) => {
    S && x.current === !0 && (y(), h == null || h(), x.current = !1);
  }, [
    y,
    h
  ]);
  return /* @__PURE__ */ R(ul, {
    scope: o,
    contentWrapper: a,
    shouldExpandOnScrollRef: p,
    onScrollButtonChange: E
  }, /* @__PURE__ */ R("div", {
    ref: l,
    style: {
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      zIndex: w
    }
  }, /* @__PURE__ */ R(ue.div, Y({}, i, {
    ref: u,
    style: {
      // When we get the height of the content, it includes borders. If we were to set
      // the height without having `boxSizing: 'border-box'` it would be too big.
      boxSizing: "border-box",
      // We need to ensure the content doesn't get taller than the wrapper
      maxHeight: "100%",
      ...i.style
    }
  }))));
}), dn = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, align: n = "start", collisionPadding: i = je, ...r } = e, s = ho(o);
  return /* @__PURE__ */ R(rs, Y({}, s, r, {
    ref: t,
    align: n,
    collisionPadding: i,
    style: {
      // Ensure border-box for floating-ui calculations
      boxSizing: "border-box",
      ...r.style,
      "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-select-content-available-width": "var(--radix-popper-available-width)",
      "--radix-select-content-available-height": "var(--radix-popper-available-height)",
      "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
    }
  }));
}), [ul, xo] = st(rt, {}), un = "SelectViewport", fl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = Ke(un, o), r = xo(un, o), s = ve(t, i.onViewportChange), a = de(0);
  return /* @__PURE__ */ R(co, null, /* @__PURE__ */ R("style", {
    dangerouslySetInnerHTML: {
      __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
    }
  }), /* @__PURE__ */ R(Mt.Slot, {
    scope: o
  }, /* @__PURE__ */ R(ue.div, Y({
    "data-radix-select-viewport": "",
    role: "presentation"
  }, n, {
    ref: s,
    style: {
      // we use position: 'relative' here on the `viewport` so that when we call
      // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
      // (independent of the scrollUpButton).
      position: "relative",
      flex: 1,
      overflow: "auto",
      ...n.style
    },
    onScroll: ce(n.onScroll, (l) => {
      const d = l.currentTarget, { contentWrapper: f, shouldExpandOnScrollRef: u } = r;
      if (u != null && u.current && f) {
        const v = Math.abs(a.current - d.scrollTop);
        if (v > 0) {
          const p = window.innerHeight - je * 2, x = parseFloat(f.style.minHeight), g = parseFloat(f.style.height), m = Math.max(x, g);
          if (m < p) {
            const b = m + v, h = Math.min(p, b), y = b - h;
            f.style.height = h + "px", f.style.bottom === "0px" && (d.scrollTop = y > 0 ? y : 0, f.style.justifyContent = "flex-end");
          }
        }
      }
      a.current = d.scrollTop;
    })
  }))));
}), gl = "SelectGroup", [pl, vl] = st(gl), ml = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = po();
  return /* @__PURE__ */ R(pl, {
    scope: o,
    id: i
  }, /* @__PURE__ */ R(ue.div, Y({
    role: "group",
    "aria-labelledby": i
  }, n, {
    ref: t
  })));
}), hl = "SelectLabel", xl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, ...n } = e, i = vl(hl, o);
  return /* @__PURE__ */ R(ue.div, Y({
    id: i.id
  }, n, {
    ref: t
  }));
}), lo = "SelectItem", [bl, hi] = st(lo), yl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, value: n, disabled: i = !1, textValue: r, ...s } = e, a = Ue(lo, o), l = Ke(lo, o), d = a.value === n, [f, u] = ee(r ?? ""), [v, p] = ee(!1), x = ve(t, (b) => {
    var h;
    return (h = l.itemRefCallback) === null || h === void 0 ? void 0 : h.call(l, b, n, i);
  }), g = po(), m = () => {
    i || (a.onValueChange(n), a.onOpenChange(!1));
  };
  return /* @__PURE__ */ R(bl, {
    scope: o,
    value: n,
    disabled: i,
    textId: g,
    isSelected: d,
    onItemTextChange: pe((b) => {
      u((h) => {
        var y;
        return h || ((y = b == null ? void 0 : b.textContent) !== null && y !== void 0 ? y : "").trim();
      });
    }, [])
  }, /* @__PURE__ */ R(Mt.ItemSlot, {
    scope: o,
    value: n,
    disabled: i,
    textValue: f
  }, /* @__PURE__ */ R(ue.div, Y({
    role: "option",
    "aria-labelledby": g,
    "data-highlighted": v ? "" : void 0,
    "aria-selected": d && v,
    "data-state": d ? "checked" : "unchecked",
    "aria-disabled": i || void 0,
    "data-disabled": i ? "" : void 0,
    tabIndex: i ? void 0 : -1
  }, s, {
    ref: x,
    onFocus: ce(
      s.onFocus,
      () => p(!0)
    ),
    onBlur: ce(
      s.onBlur,
      () => p(!1)
    ),
    onPointerUp: ce(s.onPointerUp, m),
    onPointerMove: ce(s.onPointerMove, (b) => {
      if (i) {
        var h;
        (h = l.onItemLeave) === null || h === void 0 || h.call(l);
      } else
        b.currentTarget.focus({
          preventScroll: !0
        });
    }),
    onPointerLeave: ce(s.onPointerLeave, (b) => {
      if (b.currentTarget === document.activeElement) {
        var h;
        (h = l.onItemLeave) === null || h === void 0 || h.call(l);
      }
    }),
    onKeyDown: ce(s.onKeyDown, (b) => {
      var h;
      ((h = l.searchRef) === null || h === void 0 ? void 0 : h.current) !== "" && b.key === " " || (Gs.includes(b.key) && m(), b.key === " " && b.preventDefault());
    })
  }))));
}), $t = "SelectItemText", Cl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, className: n, style: i, ...r } = e, s = Ue($t, o), a = Ke($t, o), l = hi($t, o), d = el($t, o), [f, u] = ee(null), v = ve(
    t,
    (b) => u(b),
    l.onItemTextChange,
    (b) => {
      var h;
      return (h = a.itemTextRefCallback) === null || h === void 0 ? void 0 : h.call(a, b, l.value, l.disabled);
    }
  ), p = f == null ? void 0 : f.textContent, x = nt(
    () => /* @__PURE__ */ R("option", {
      key: l.value,
      value: l.value,
      disabled: l.disabled
    }, p),
    [
      l.disabled,
      l.value,
      p
    ]
  ), { onNativeOptionAdd: g, onNativeOptionRemove: m } = d;
  return Ee(() => (g(x), () => m(x)), [
    g,
    m,
    x
  ]), /* @__PURE__ */ R(co, null, /* @__PURE__ */ R(ue.span, Y({
    id: l.textId
  }, r, {
    ref: v
  })), l.isSelected && s.valueNode && !s.valueNodeHasChildren ? /* @__PURE__ */ hn(r.children, s.valueNode) : null);
}), wl = "SelectItemIndicator", _l = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return hi(wl, o).isSelected ? /* @__PURE__ */ R(ue.span, Y({
    "aria-hidden": !0
  }, n, {
    ref: t
  })) : null;
}), fn = "SelectScrollUpButton", kl = /* @__PURE__ */ V((e, t) => {
  const o = Ke(fn, e.__scopeSelect), n = xo(fn, e.__scopeSelect), [i, r] = ee(!1), s = ve(t, n.onScrollButtonChange);
  return Ee(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollTop > 0;
        r(d);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ R(xi, Y({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop - l.offsetHeight);
    }
  })) : null;
}), gn = "SelectScrollDownButton", $l = /* @__PURE__ */ V((e, t) => {
  const o = Ke(gn, e.__scopeSelect), n = xo(gn, e.__scopeSelect), [i, r] = ee(!1), s = ve(t, n.onScrollButtonChange);
  return Ee(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const d = a.scrollHeight - a.clientHeight, f = Math.ceil(a.scrollTop) < d;
        r(f);
      };
      const a = o.viewport;
      return l(), a.addEventListener("scroll", l), () => a.removeEventListener("scroll", l);
    }
  }, [
    o.viewport,
    o.isPositioned
  ]), i ? /* @__PURE__ */ R(xi, Y({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: a, selectedItem: l } = o;
      a && l && (a.scrollTop = a.scrollTop + l.offsetHeight);
    }
  })) : null;
}), xi = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, onAutoScroll: n, ...i } = e, r = Ke("SelectScrollButton", o), s = de(null), a = Ft(o), l = pe(() => {
    s.current !== null && (window.clearInterval(s.current), s.current = null);
  }, []);
  return ie(() => () => l(), [
    l
  ]), Ee(() => {
    var d;
    const f = a().find(
      (u) => u.ref.current === document.activeElement
    );
    f == null || (d = f.ref.current) === null || d === void 0 || d.scrollIntoView({
      block: "nearest"
    });
  }, [
    a
  ]), /* @__PURE__ */ R(ue.div, Y({
    "aria-hidden": !0
  }, i, {
    ref: t,
    style: {
      flexShrink: 0,
      ...i.style
    },
    onPointerDown: ce(i.onPointerDown, () => {
      s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerMove: ce(i.onPointerMove, () => {
      var d;
      (d = r.onItemLeave) === null || d === void 0 || d.call(r), s.current === null && (s.current = window.setInterval(n, 50));
    }),
    onPointerLeave: ce(i.onPointerLeave, () => {
      l();
    })
  }));
}), Sl = /* @__PURE__ */ V((e, t) => {
  const { __scopeSelect: o, ...n } = e;
  return /* @__PURE__ */ R(ue.div, Y({
    "aria-hidden": !0
  }, n, {
    ref: t
  }));
}), bi = /* @__PURE__ */ V((e, t) => {
  const { value: o, ...n } = e, i = de(null), r = ve(t, i), s = ls(o);
  return ie(() => {
    const a = i.current, l = window.HTMLSelectElement.prototype, f = Object.getOwnPropertyDescriptor(l, "value").set;
    if (s !== o && f) {
      const u = new Event("change", {
        bubbles: !0
      });
      f.call(a, o), a.dispatchEvent(u);
    }
  }, [
    s,
    o
  ]), /* @__PURE__ */ R(cs, {
    asChild: !0
  }, /* @__PURE__ */ R("select", Y({}, n, {
    ref: r,
    defaultValue: o
  })));
});
bi.displayName = "BubbleSelect";
function yi(e) {
  const t = Ne(e), o = de(""), n = de(0), i = pe((s) => {
    const a = o.current + s;
    t(a), function l(d) {
      o.current = d, window.clearTimeout(n.current), d !== "" && (n.current = window.setTimeout(
        () => l(""),
        1e3
      ));
    }(a);
  }, [
    t
  ]), r = pe(() => {
    o.current = "", window.clearTimeout(n.current);
  }, []);
  return ie(() => () => window.clearTimeout(n.current), []), [
    o,
    i,
    r
  ];
}
function Ci(e, t, o) {
  const i = t.length > 1 && Array.from(t).every(
    (d) => d === t[0]
  ) ? t[0] : t, r = o ? e.indexOf(o) : -1;
  let s = El(e, Math.max(r, 0));
  i.length === 1 && (s = s.filter(
    (d) => d !== o
  ));
  const l = s.find(
    (d) => d.textValue.toLowerCase().startsWith(i.toLowerCase())
  );
  return l !== o ? l : void 0;
}
function El(e, t) {
  return e.map(
    (o, n) => e[(t + n) % e.length]
  );
}
const Pl = tl, Rl = nl, Tl = rl, Al = al, Ol = sl, ql = ll, wi = fl, jl = ml, zl = xl, Nl = yl, Dl = Cl, Il = _l, _i = kl, ki = $l, Ll = Sl;
var Ml = "ibaddl9", Fl = "ibaddla", Vl = "ibaddl2", Hl = "ibaddl8", Bl = "ibaddl7", Wl = "ibaddl3", Xl = "ibaddl4", Ul = "ibaddl5", Kl = "ibaddl0", Yl = "ibaddl6", Gl = "ibaddl1";
const Zl = ({
  children: e,
  className: t,
  open: o,
  defaultOpen: n,
  disabled: i,
  required: r,
  defaultValue: s,
  value: a,
  onValueChange: l,
  ...d
}) => /* @__PURE__ */ _.jsx(
  Pl,
  {
    ...d,
    open: o,
    defaultOpen: n,
    disabled: i,
    required: r,
    defaultValue: s,
    value: a,
    onValueChange: l,
    children: /* @__PURE__ */ _.jsx(
      "div",
      {
        ...d,
        className: I(Kl, t),
        children: e
      }
    )
  }
), Jl = W.forwardRef(({ children: e, placeholder: t, ...o }, n) => /* @__PURE__ */ _.jsx(
  Tl,
  {
    ...o,
    ref: n,
    placeholder: t,
    children: e
  }
)), Ql = W.forwardRef(
  ({ className: e, asChild: t, ...o }, n) => /* @__PURE__ */ _.jsx(
    Al,
    {
      ...o,
      ref: n,
      asChild: t,
      className: I(Bl, e),
      children: /* @__PURE__ */ _.jsx(Qr, { color: Gr.color.slate5 })
    }
  )
), ec = ({
  children: e,
  asChild: t,
  className: o,
  ...n
}) => /* @__PURE__ */ _.jsx(
  Rl,
  {
    ...n,
    asChild: t,
    className: I(o, Gl),
    children: e
  }
), tc = ({
  children: e,
  className: t,
  position: o = "popper",
  side: n = "bottom",
  sideOffset: i,
  align: r,
  alignOffset: s = 0,
  avoidCollisions: a = !0,
  sticky: l = "partial",
  hideWhenDetached: d = !1,
  ...f
}) => /* @__PURE__ */ _.jsxs(
  ql,
  {
    ...f,
    className: I(Vl, t),
    position: o,
    side: n,
    sideOffset: i,
    align: r,
    alignOffset: s,
    avoidCollisions: a,
    sticky: l,
    hideWhenDetached: d,
    children: [
      /* @__PURE__ */ _.jsx(_i, { className: I(Fl, t), children: /* @__PURE__ */ _.jsx(ta, {}) }),
      /* @__PURE__ */ _.jsx(wi, { children: e }),
      /* @__PURE__ */ _.jsx(ki, { className: I(Ml, t), children: /* @__PURE__ */ _.jsx(ea, {}) })
    ]
  }
), oc = W.forwardRef(({ children: e, className: t, ...o }, n) => /* @__PURE__ */ _.jsxs(
  Nl,
  {
    ...o,
    ref: n,
    className: I(Wl, t),
    children: [
      /* @__PURE__ */ _.jsx(Dl, { children: e }),
      /* @__PURE__ */ _.jsx($i, {})
    ]
  }
)), $i = ({ className: e, ...t }) => /* @__PURE__ */ _.jsx(
  Il,
  {
    ...t,
    className: I(Xl, e)
  }
), nc = ({ className: e, ...t }) => /* @__PURE__ */ _.jsx(
  Ll,
  {
    ...t,
    className: I(Yl, e)
  }
), ic = ({ children: e, className: t, ...o }) => /* @__PURE__ */ _.jsx(
  zl,
  {
    ...o,
    className: I(Ul, t),
    children: e
  }
), rc = ({ children: e, className: t, ...o }) => /* @__PURE__ */ _.jsx(
  jl,
  {
    ...o,
    className: I(Hl, t),
    children: e
  }
), ae = (e) => /* @__PURE__ */ _.jsx(Zl, { ...e });
ae.Trigger = ec;
ae.Value = Jl;
ae.Content = tc;
ae.Item = oc;
ae.Viewport = wi;
ae.Portal = Ol;
ae.Icon = Ql;
ae.Indicator = $i;
ae.Separator = nc;
ae.Label = ic;
ae.Group = rc;
ae.ScrollUpButton = _i;
ae.ScrollDownButton = ki;
ae.displayName = "Select";
ae.Value.displayName = "Select.Value";
ae.Item.displayName = "Select.Item";
ae.Viewport.displayName = "Select.Viewport";
ae.Portal.displayName = "Select.Portal";
ae.ScrollUpButton.displayName = "Select.ScrollUpButton";
ae.ScrollDownButton.displayName = "Select.ScrollDownButton";
var ac = we({ defaultClassName: "_1yr5zenb", variantClassNames: { size: { xs: "_1yr5zen0", sm: "_1yr5zen1", md: "_1yr5zen2", lg: "_1yr5zen3", xl: "_1yr5zen4", xxl: "_1yr5zen5", "3xl": "_1yr5zen6", "4xl": "_1yr5zen7", "5xl": "_1yr5zen8", "6xl": "_1yr5zen9", "7xl": "_1yr5zena" } }, defaultVariants: { size: "sm" }, compoundVariants: [] });
const sc = V(
  ({ size: e = "sm", className: t, ...o }, n) => {
    const i = ac({ size: e });
    return /* @__PURE__ */ _.jsx(
      "div",
      {
        ...o,
        ref: n,
        className: t ? `${t} ${i}` : i
      }
    );
  }
);
sc.displayName = "Space";
const pn = {
  1: "wrap",
  0: "nowrap"
}, lc = {
  horizontal: "row",
  vertical: "column"
}, cc = (e) => e ? Nn(e, (t) => lc[t]) : void 0, dc = (e) => e ? typeof e == "boolean" ? pn[1] : Nn(
  e,
  // Hack to convert boolean to number since Sprinkles does not support
  // boolean responsive keys
  (t) => pn[+t]
) : void 0, jc = [
  "a",
  "article",
  "div",
  "form",
  "header",
  "label",
  "li",
  "main",
  "section",
  "span"
], zc = ({
  as: e = "div",
  align: t,
  children: o,
  justify: n,
  flex: i,
  direction: r = "vertical",
  space: s = "4px 4px",
  wrap: a
}) => {
  const l = cc(r), d = dc(a);
  return /* @__PURE__ */ _.jsx(
    Ln,
    {
      alignItems: t,
      as: e,
      display: "flex",
      flex: i,
      flexDirection: l,
      flexWrap: d,
      gap: s,
      justifyContent: n,
      children: o
    }
  );
};
var uc = "_17w677g0", fc = we({ defaultClassName: "_17w677g7", variantClassNames: { size: { small: "_17w677g1", medium: "_17w677g2", large: "_17w677g3" }, variant: { default: "_17w677g4", hyper: "_17w677g5", volt: "_17w677g6" } }, defaultVariants: { size: "small", variant: "default" }, compoundVariants: [] });
const gc = ({
  className: e,
  asChild: t,
  defaultChecked: o,
  checked: n,
  onCheckedChange: i,
  disabled: r,
  required: s,
  name: a,
  value: l,
  ...d
}) => /* @__PURE__ */ _.jsx(
  Ji,
  {
    ...d,
    className: I(e, uc),
    defaultChecked: o,
    checked: n,
    onCheckedChange: i,
    disabled: r,
    required: s,
    name: a,
    value: l
  }
), Si = V(
  (e, t) => {
    const {
      className: o,
      size: n = "small",
      variant: i = "default",
      asChild: r = !1,
      ...s
    } = e;
    return /* @__PURE__ */ _.jsx(
      Zi,
      {
        ...s,
        ref: t,
        asChild: r,
        className: I(o, fc({ size: n, variant: i }))
      }
    );
  }
), bo = (e) => /* @__PURE__ */ _.jsx(gc, { ...e });
bo.Toggle = Si;
bo.displayName = "Switch";
bo.Toggle.displayName = "Switch.Toggle";
Si.displayName = "Switch.Toggle";
var pc = we({ defaultClassName: "fpsfqv30", variantClassNames: { font: { system: "fpsfqv0", inter: "fpsfqv1", mono: "fpsfqv2" }, size: { xs: "fpsfqv3", sm: "fpsfqv4", md: "fpsfqv5", lg: "fpsfqv6", xl: "fpsfqv7", xxl: "fpsfqv8", "3xl": "fpsfqv9", "4xl": "fpsfqva", "5xl": "fpsfqvb", "6xl": "fpsfqvc", "7xl": "fpsfqvd", "8xl": "fpsfqve", "9xl": "fpsfqvf" }, weight: { superlite: "fpsfqvg", lite: "fpsfqvh", normal: "fpsfqvi", medium: "fpsfqvj", semibold: "fpsfqvk", bold: "fpsfqvl", heavy: "fpsfqvm", black: "fpsfqvn" }, color: { transparent: "fpsfqvo", current: "fpsfqvp", white: "fpsfqvq", black: "fpsfqvr", gray100: "fpsfqvs", gray200: "fpsfqvt", gray300: "fpsfqvu", pale100: "fpsfqvv", pale200: "fpsfqvw", pale300: "fpsfqvx", pale400: "fpsfqvy", pale500: "fpsfqvz", hyper0: "fpsfqv10", hyper1: "fpsfqv11", hyper2: "fpsfqv12", hyper3: "fpsfqv13", hyper4: "fpsfqv14", hyper5: "fpsfqv15", hyper6: "fpsfqv16", hyper7: "fpsfqv17", hyper8: "fpsfqv18", hyper9: "fpsfqv19", hyper10: "fpsfqv1a", hyper11: "fpsfqv1b", hyper12: "fpsfqv1c", hyper13: "fpsfqv1d", lemon0: "fpsfqv1e", lemon1: "fpsfqv1f", lemon2: "fpsfqv1g", lemon3: "fpsfqv1h", lemon4: "fpsfqv1i", lemon5: "fpsfqv1j", lemon6: "fpsfqv1k", lemon7: "fpsfqv1l", lemon8: "fpsfqv1m", lemon9: "fpsfqv1n", lemon10: "fpsfqv1o", lemon11: "fpsfqv1p", lemon12: "fpsfqv1q", lemon13: "fpsfqv1r", slate1: "fpsfqv1s", slate2: "fpsfqv1t", slate3: "fpsfqv1u", slate4: "fpsfqv1v", slate5: "fpsfqv1w", slate6: "fpsfqv1x", slate7: "fpsfqv1y", slate8: "fpsfqv1z", slate9: "fpsfqv20", slate10: "fpsfqv21", slate11: "fpsfqv22", slate12: "fpsfqv23", slate13: "fpsfqv24", sapphire0: "fpsfqv25", sapphire1: "fpsfqv26", sapphire2: "fpsfqv27", sapphire3: "fpsfqv28", sapphire4: "fpsfqv29", sapphire5: "fpsfqv2a", sapphire6: "fpsfqv2b", sapphire7: "fpsfqv2c", sapphire8: "fpsfqv2d", sapphire9: "fpsfqv2e", sapphire10: "fpsfqv2f", sapphire11: "fpsfqv2g", sapphire12: "fpsfqv2h", sapphire13: "fpsfqv2i", volt0: "fpsfqv2j", volt1: "fpsfqv2k", volt2: "fpsfqv2l", volt3: "fpsfqv2m", volt4: "fpsfqv2n", volt5: "fpsfqv2o", volt6: "fpsfqv2p", volt7: "fpsfqv2q", volt8: "fpsfqv2r", volt9: "fpsfqv2s", volt10: "fpsfqv2t", volt11: "fpsfqv2u", volt12: "fpsfqv2v", volt13: "fpsfqv2w" }, align: { left: "fpsfqv2x", center: "fpsfqv2y", right: "fpsfqv2z" } }, defaultVariants: { font: "system", size: "md", weight: "medium", color: "slate5", align: "left" }, compoundVariants: [] });
const vc = W.forwardRef(
  ({
    children: e,
    className: t,
    font: o = "inter",
    size: n = "md",
    align: i = "left",
    color: r = "slate5",
    weight: s = "medium",
    ...a
  }, l) => /* @__PURE__ */ _.jsx(
    "p",
    {
      ref: l,
      className: I(t, pc({ font: o, size: n, align: i, color: r, weight: s })),
      ...a,
      children: e
    }
  )
);
vc.displayName = "Text";
var mc = "fgg2xl1", hc = "fgg2xl0";
const xc = 500, bc = 300, yc = !1, Cc = ({ children: e, ...t }) => /* @__PURE__ */ _.jsx(
  Tt.Provider,
  {
    delayDuration: xc,
    skipDelayDuration: bc,
    disableHoverableContent: yc,
    children: /* @__PURE__ */ _.jsx(Tt.Root, { ...t, children: e })
  }
), Ei = W.forwardRef(
  ({
    children: e,
    className: t,
    onEscapeKeyDown: o,
    onPointerDownOutside: n,
    forceMount: i,
    side: r = "right",
    sideOffset: s = 10,
    align: a = "center",
    alignOffset: l = 0,
    avoidCollisions: d = !0,
    sticky: f = "always",
    hideWhenDetached: u = !1,
    //..
    ...v
  }, p) => /* @__PURE__ */ _.jsx(
    Tt.Content,
    {
      ...v,
      ref: p,
      "aria-label": "atelier-tip",
      side: r,
      sideOffset: s,
      align: a,
      alignOffset: l,
      avoidCollisions: d,
      sticky: f,
      hideWhenDetached: u,
      className: I(t, mc),
      children: e
    }
  )
), Pi = W.forwardRef(
  ({ children: e, ...t }, o) => /* @__PURE__ */ _.jsx(
    Tt.Trigger,
    {
      ...t,
      ref: o,
      className: hc,
      children: e
    }
  )
), yo = (e) => /* @__PURE__ */ _.jsx(Cc, { ...e });
yo.Trigger = Pi;
yo.Content = Ei;
yo.displayName = "Tip";
Pi.displayName = "TipTrigger";
Ei.displayName = "TipContent";
export {
  Qr as ArrowDownIcon,
  Tc as ArrowUpIcon,
  We as Avi,
  ur as Button,
  pr as Canvas,
  vr as CanvasBlur,
  hr as Chip,
  br as Container,
  Cr as Flex,
  _r as Heading,
  fo as Input,
  In as KitContext,
  Rc as KitProvider,
  Ac as LogoIcon,
  Ie as Menubar,
  Nr as Paragraph,
  Ir as PassLink,
  Ln as Rect,
  na as Section,
  ae as Select,
  ea as SmallArrowDownIcon,
  ta as SmallArrowUpIcon,
  sc as Space,
  zc as Stack,
  bo as Switch,
  vc as Text,
  yo as Tip,
  Yr as atoms,
  Lr as base,
  Sc as breakpoints,
  Ec as colorModeStyle,
  cc as directionToFlexDirection,
  Mr as element,
  Gr as kit,
  $c as mapColorValue,
  Nn as mapResponsiveValue,
  Dn as sprinkles,
  Pc as useTheme,
  jc as validStackComponents,
  dc as wrapToFlexWrap
};
//# sourceMappingURL=index.js.map
