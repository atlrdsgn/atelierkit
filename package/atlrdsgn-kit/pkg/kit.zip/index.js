/*! 
    atelierkit© v0.2.95. 
    Copyright © 2023 atlrdsgn®. All rights reserved.
    
    see https://docs.atlrdsgn.com for more information.
     */
import * as R from "react";
import B, { forwardRef as F, createContext as vt, useMemo as rt, createElement as P, useContext as At, useCallback as fe, Children as ft, isValidElement as Rt, cloneElement as ur, Fragment as cn, useEffect as re, useRef as le, useState as Z, useLayoutEffect as fr } from "react";
import * as un from "@radix-ui/react-avatar";
import * as Le from "@radix-ui/react-menubar";
import * as Mo from "react-dom";
import jo, { flushSync as Fo, createPortal as dr } from "react-dom";
import { Thumb as Vo, Root as Ho } from "@radix-ui/react-switch";
import * as Tt from "@radix-ui/react-tooltip";
var en = { exports: {} }, ct = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var qn;
function Bo() {
  if (qn)
    return ct;
  qn = 1;
  var e = B, t = Symbol.for("react.element"), n = Symbol.for("react.fragment"), r = Object.prototype.hasOwnProperty, o = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, a = { key: !0, ref: !0, __self: !0, __source: !0 };
  function s(i, l, u) {
    var d, f = {}, m = null, v = null;
    u !== void 0 && (m = "" + u), l.key !== void 0 && (m = "" + l.key), l.ref !== void 0 && (v = l.ref);
    for (d in l)
      r.call(l, d) && !a.hasOwnProperty(d) && (f[d] = l[d]);
    if (i && i.defaultProps)
      for (d in l = i.defaultProps, l)
        f[d] === void 0 && (f[d] = l[d]);
    return { $$typeof: t, type: i, key: m, ref: v, props: f, _owner: o.current };
  }
  return ct.Fragment = n, ct.jsx = s, ct.jsxs = s, ct;
}
var ut = {};
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Nn;
function Wo() {
  return Nn || (Nn = 1, process.env.NODE_ENV !== "production" && function() {
    var e = B, t = Symbol.for("react.element"), n = Symbol.for("react.portal"), r = Symbol.for("react.fragment"), o = Symbol.for("react.strict_mode"), a = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), i = Symbol.for("react.context"), l = Symbol.for("react.forward_ref"), u = Symbol.for("react.suspense"), d = Symbol.for("react.suspense_list"), f = Symbol.for("react.memo"), m = Symbol.for("react.lazy"), v = Symbol.for("react.offscreen"), x = Symbol.iterator, p = "@@iterator";
    function g(c) {
      if (c === null || typeof c != "object")
        return null;
      var w = x && c[x] || c[p];
      return typeof w == "function" ? w : null;
    }
    var b = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    function h(c) {
      {
        for (var w = arguments.length, C = new Array(w > 1 ? w - 1 : 0), O = 1; O < w; O++)
          C[O - 1] = arguments[O];
        y("error", c, C);
      }
    }
    function y(c, w, C) {
      {
        var O = b.ReactDebugCurrentFrame, U = O.getStackAddendum();
        U !== "" && (w += "%s", C = C.concat([U]));
        var Q = C.map(function(j) {
          return String(j);
        });
        Q.unshift("Warning: " + w), Function.prototype.apply.call(console[c], console, Q);
      }
    }
    var $ = !1, S = !1, q = !1, N = !1, E = !1, V;
    V = Symbol.for("react.module.reference");
    function J(c) {
      return !!(typeof c == "string" || typeof c == "function" || c === r || c === a || E || c === o || c === u || c === d || N || c === v || $ || S || q || typeof c == "object" && c !== null && (c.$$typeof === m || c.$$typeof === f || c.$$typeof === s || c.$$typeof === i || c.$$typeof === l || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      c.$$typeof === V || c.getModuleId !== void 0));
    }
    function A(c, w, C) {
      var O = c.displayName;
      if (O)
        return O;
      var U = w.displayName || w.name || "";
      return U !== "" ? C + "(" + U + ")" : C;
    }
    function W(c) {
      return c.displayName || "Context";
    }
    function I(c) {
      if (c == null)
        return null;
      if (typeof c.tag == "number" && h("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof c == "function")
        return c.displayName || c.name || null;
      if (typeof c == "string")
        return c;
      switch (c) {
        case r:
          return "Fragment";
        case n:
          return "Portal";
        case a:
          return "Profiler";
        case o:
          return "StrictMode";
        case u:
          return "Suspense";
        case d:
          return "SuspenseList";
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case i:
            var w = c;
            return W(w) + ".Consumer";
          case s:
            var C = c;
            return W(C._context) + ".Provider";
          case l:
            return A(c, c.render, "ForwardRef");
          case f:
            var O = c.displayName || null;
            return O !== null ? O : I(c.type) || "Memo";
          case m: {
            var U = c, Q = U._payload, j = U._init;
            try {
              return I(j(Q));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var M = Object.assign, D = 0, z, ee, te, pe, he, we, Ee;
    function Te() {
    }
    Te.__reactDisabledLog = !0;
    function ge() {
      {
        if (D === 0) {
          z = console.log, ee = console.info, te = console.warn, pe = console.error, he = console.group, we = console.groupCollapsed, Ee = console.groupEnd;
          var c = {
            configurable: !0,
            enumerable: !0,
            value: Te,
            writable: !0
          };
          Object.defineProperties(console, {
            info: c,
            log: c,
            warn: c,
            error: c,
            group: c,
            groupCollapsed: c,
            groupEnd: c
          });
        }
        D++;
      }
    }
    function xe() {
      {
        if (D--, D === 0) {
          var c = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: M({}, c, {
              value: z
            }),
            info: M({}, c, {
              value: ee
            }),
            warn: M({}, c, {
              value: te
            }),
            error: M({}, c, {
              value: pe
            }),
            group: M({}, c, {
              value: he
            }),
            groupCollapsed: M({}, c, {
              value: we
            }),
            groupEnd: M({}, c, {
              value: Ee
            })
          });
        }
        D < 0 && h("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var _e = b.ReactCurrentDispatcher, T;
    function H(c, w, C) {
      {
        if (T === void 0)
          try {
            throw Error();
          } catch (U) {
            var O = U.stack.trim().match(/\n( *(at )?)/);
            T = O && O[1] || "";
          }
        return `
` + T + c;
      }
    }
    var ie = !1, Y;
    {
      var G = typeof WeakMap == "function" ? WeakMap : Map;
      Y = new G();
    }
    function X(c, w) {
      if (!c || ie)
        return "";
      {
        var C = Y.get(c);
        if (C !== void 0)
          return C;
      }
      var O;
      ie = !0;
      var U = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var Q;
      Q = _e.current, _e.current = null, ge();
      try {
        if (w) {
          var j = function() {
            throw Error();
          };
          if (Object.defineProperty(j.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(j, []);
            } catch (ze) {
              O = ze;
            }
            Reflect.construct(c, [], j);
          } else {
            try {
              j.call();
            } catch (ze) {
              O = ze;
            }
            c.call(j.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (ze) {
            O = ze;
          }
          c();
        }
      } catch (ze) {
        if (ze && O && typeof ze.stack == "string") {
          for (var L = ze.stack.split(`
`), me = O.stack.split(`
`), ne = L.length - 1, oe = me.length - 1; ne >= 1 && oe >= 0 && L[ne] !== me[oe]; )
            oe--;
          for (; ne >= 1 && oe >= 0; ne--, oe--)
            if (L[ne] !== me[oe]) {
              if (ne !== 1 || oe !== 1)
                do
                  if (ne--, oe--, oe < 0 || L[ne] !== me[oe]) {
                    var $e = `
` + L[ne].replace(" at new ", " at ");
                    return c.displayName && $e.includes("<anonymous>") && ($e = $e.replace("<anonymous>", c.displayName)), typeof c == "function" && Y.set(c, $e), $e;
                  }
                while (ne >= 1 && oe >= 0);
              break;
            }
        }
      } finally {
        ie = !1, _e.current = Q, xe(), Error.prepareStackTrace = U;
      }
      var Je = c ? c.displayName || c.name : "", On = Je ? H(Je) : "";
      return typeof c == "function" && Y.set(c, On), On;
    }
    function ve(c, w, C) {
      return X(c, !1);
    }
    function ue(c) {
      var w = c.prototype;
      return !!(w && w.isReactComponent);
    }
    function Oe(c, w, C) {
      if (c == null)
        return "";
      if (typeof c == "function")
        return X(c, ue(c));
      if (typeof c == "string")
        return H(c);
      switch (c) {
        case u:
          return H("Suspense");
        case d:
          return H("SuspenseList");
      }
      if (typeof c == "object")
        switch (c.$$typeof) {
          case l:
            return ve(c.render);
          case f:
            return Oe(c.type, w, C);
          case m: {
            var O = c, U = O._payload, Q = O._init;
            try {
              return Oe(Q(U), w, C);
            } catch {
            }
          }
        }
      return "";
    }
    var qe = Object.prototype.hasOwnProperty, Me = {}, xt = b.ReactDebugCurrentFrame;
    function Ye(c) {
      if (c) {
        var w = c._owner, C = Oe(c.type, c._source, w ? w.type : null);
        xt.setExtraStackFrame(C);
      } else
        xt.setExtraStackFrame(null);
    }
    function Ge(c, w, C, O, U) {
      {
        var Q = Function.call.bind(qe);
        for (var j in c)
          if (Q(c, j)) {
            var L = void 0;
            try {
              if (typeof c[j] != "function") {
                var me = Error((O || "React class") + ": " + C + " type `" + j + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof c[j] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw me.name = "Invariant Violation", me;
              }
              L = c[j](w, j, O, C, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (ne) {
              L = ne;
            }
            L && !(L instanceof Error) && (Ye(U), h("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", O || "React class", C, j, typeof L), Ye(null)), L instanceof Error && !(L.message in Me) && (Me[L.message] = !0, Ye(U), h("Failed %s type: %s", C, L.message), Ye(null));
          }
      }
    }
    var yo = Array.isArray;
    function Ft(c) {
      return yo(c);
    }
    function wo(c) {
      {
        var w = typeof Symbol == "function" && Symbol.toStringTag, C = w && c[Symbol.toStringTag] || c.constructor.name || "Object";
        return C;
      }
    }
    function _o(c) {
      try {
        return yn(c), !1;
      } catch {
        return !0;
      }
    }
    function yn(c) {
      return "" + c;
    }
    function wn(c) {
      if (_o(c))
        return h("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", wo(c)), yn(c);
    }
    var lt = b.ReactCurrentOwner, $o = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, _n, $n, Vt;
    Vt = {};
    function Co(c) {
      if (qe.call(c, "ref")) {
        var w = Object.getOwnPropertyDescriptor(c, "ref").get;
        if (w && w.isReactWarning)
          return !1;
      }
      return c.ref !== void 0;
    }
    function So(c) {
      if (qe.call(c, "key")) {
        var w = Object.getOwnPropertyDescriptor(c, "key").get;
        if (w && w.isReactWarning)
          return !1;
      }
      return c.key !== void 0;
    }
    function Eo(c, w) {
      if (typeof c.ref == "string" && lt.current && w && lt.current.stateNode !== w) {
        var C = I(lt.current.type);
        Vt[C] || (h('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', I(lt.current.type), c.ref), Vt[C] = !0);
      }
    }
    function Po(c, w) {
      {
        var C = function() {
          _n || (_n = !0, h("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", w));
        };
        C.isReactWarning = !0, Object.defineProperty(c, "key", {
          get: C,
          configurable: !0
        });
      }
    }
    function Ro(c, w) {
      {
        var C = function() {
          $n || ($n = !0, h("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", w));
        };
        C.isReactWarning = !0, Object.defineProperty(c, "ref", {
          get: C,
          configurable: !0
        });
      }
    }
    var To = function(c, w, C, O, U, Q, j) {
      var L = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: t,
        // Built-in properties that belong on the element
        type: c,
        key: w,
        ref: C,
        props: j,
        // Record the component responsible for creating this element.
        _owner: Q
      };
      return L._store = {}, Object.defineProperty(L._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(L, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: O
      }), Object.defineProperty(L, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: U
      }), Object.freeze && (Object.freeze(L.props), Object.freeze(L)), L;
    };
    function Oo(c, w, C, O, U) {
      {
        var Q, j = {}, L = null, me = null;
        C !== void 0 && (wn(C), L = "" + C), So(w) && (wn(w.key), L = "" + w.key), Co(w) && (me = w.ref, Eo(w, U));
        for (Q in w)
          qe.call(w, Q) && !$o.hasOwnProperty(Q) && (j[Q] = w[Q]);
        if (c && c.defaultProps) {
          var ne = c.defaultProps;
          for (Q in ne)
            j[Q] === void 0 && (j[Q] = ne[Q]);
        }
        if (L || me) {
          var oe = typeof c == "function" ? c.displayName || c.name || "Unknown" : c;
          L && Po(j, oe), me && Ro(j, oe);
        }
        return To(c, L, me, U, O, lt.current, j);
      }
    }
    var Ht = b.ReactCurrentOwner, Cn = b.ReactDebugCurrentFrame;
    function Ze(c) {
      if (c) {
        var w = c._owner, C = Oe(c.type, c._source, w ? w.type : null);
        Cn.setExtraStackFrame(C);
      } else
        Cn.setExtraStackFrame(null);
    }
    var Bt;
    Bt = !1;
    function Wt(c) {
      return typeof c == "object" && c !== null && c.$$typeof === t;
    }
    function Sn() {
      {
        if (Ht.current) {
          var c = I(Ht.current.type);
          if (c)
            return `

Check the render method of \`` + c + "`.";
        }
        return "";
      }
    }
    function qo(c) {
      {
        if (c !== void 0) {
          var w = c.fileName.replace(/^.*[\\\/]/, ""), C = c.lineNumber;
          return `

Check your code at ` + w + ":" + C + ".";
        }
        return "";
      }
    }
    var En = {};
    function No(c) {
      {
        var w = Sn();
        if (!w) {
          var C = typeof c == "string" ? c : c.displayName || c.name;
          C && (w = `

Check the top-level render call using <` + C + ">.");
        }
        return w;
      }
    }
    function Pn(c, w) {
      {
        if (!c._store || c._store.validated || c.key != null)
          return;
        c._store.validated = !0;
        var C = No(w);
        if (En[C])
          return;
        En[C] = !0;
        var O = "";
        c && c._owner && c._owner !== Ht.current && (O = " It was passed a child from " + I(c._owner.type) + "."), Ze(c), h('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', C, O), Ze(null);
      }
    }
    function Rn(c, w) {
      {
        if (typeof c != "object")
          return;
        if (Ft(c))
          for (var C = 0; C < c.length; C++) {
            var O = c[C];
            Wt(O) && Pn(O, w);
          }
        else if (Wt(c))
          c._store && (c._store.validated = !0);
        else if (c) {
          var U = g(c);
          if (typeof U == "function" && U !== c.entries)
            for (var Q = U.call(c), j; !(j = Q.next()).done; )
              Wt(j.value) && Pn(j.value, w);
        }
      }
    }
    function zo(c) {
      {
        var w = c.type;
        if (w == null || typeof w == "string")
          return;
        var C;
        if (typeof w == "function")
          C = w.propTypes;
        else if (typeof w == "object" && (w.$$typeof === l || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        w.$$typeof === f))
          C = w.propTypes;
        else
          return;
        if (C) {
          var O = I(w);
          Ge(C, c.props, "prop", O, c);
        } else if (w.PropTypes !== void 0 && !Bt) {
          Bt = !0;
          var U = I(w);
          h("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", U || "Unknown");
        }
        typeof w.getDefaultProps == "function" && !w.getDefaultProps.isReactClassApproved && h("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function Ao(c) {
      {
        for (var w = Object.keys(c.props), C = 0; C < w.length; C++) {
          var O = w[C];
          if (O !== "children" && O !== "key") {
            Ze(c), h("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", O), Ze(null);
            break;
          }
        }
        c.ref !== null && (Ze(c), h("Invalid attribute `ref` supplied to `React.Fragment`."), Ze(null));
      }
    }
    function Tn(c, w, C, O, U, Q) {
      {
        var j = J(c);
        if (!j) {
          var L = "";
          (c === void 0 || typeof c == "object" && c !== null && Object.keys(c).length === 0) && (L += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var me = qo(U);
          me ? L += me : L += Sn();
          var ne;
          c === null ? ne = "null" : Ft(c) ? ne = "array" : c !== void 0 && c.$$typeof === t ? (ne = "<" + (I(c.type) || "Unknown") + " />", L = " Did you accidentally export a JSX literal instead of a component?") : ne = typeof c, h("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", ne, L);
        }
        var oe = Oo(c, w, C, U, Q);
        if (oe == null)
          return oe;
        if (j) {
          var $e = w.children;
          if ($e !== void 0)
            if (O)
              if (Ft($e)) {
                for (var Je = 0; Je < $e.length; Je++)
                  Rn($e[Je], c);
                Object.freeze && Object.freeze($e);
              } else
                h("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else
              Rn($e, c);
        }
        return c === r ? Ao(oe) : zo(oe), oe;
      }
    }
    function Do(c, w, C) {
      return Tn(c, w, C, !0);
    }
    function Io(c, w, C) {
      return Tn(c, w, C, !1);
    }
    var Lo = Io, ko = Do;
    ut.Fragment = r, ut.jsx = Lo, ut.jsxs = ko;
  }()), ut;
}
process.env.NODE_ENV === "production" ? en.exports = Bo() : en.exports = Wo();
var _ = en.exports;
function Xo(e, t) {
  if (typeof e != "object" || e === null)
    return e;
  var n = e[Symbol.toPrimitive];
  if (n !== void 0) {
    var r = n.call(e, t || "default");
    if (typeof r != "object")
      return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Uo(e) {
  var t = Xo(e, "string");
  return typeof t == "symbol" ? t : String(t);
}
function Ko(e, t, n) {
  return t = Uo(t), t in e ? Object.defineProperty(e, t, {
    value: n,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = n, e;
}
function zn(e, t) {
  var n = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    t && (r = r.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), n.push.apply(n, r);
  }
  return n;
}
function An(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t] != null ? arguments[t] : {};
    t % 2 ? zn(Object(n), !0).forEach(function(r) {
      Ko(e, r, n[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : zn(Object(n)).forEach(function(r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r));
    });
  }
  return e;
}
var Yo = (e, t, n) => {
  for (var r of Object.keys(e)) {
    var o;
    if (e[r] !== ((o = t[r]) !== null && o !== void 0 ? o : n[r]))
      return !1;
  }
  return !0;
}, ye = (e) => {
  var t = (n) => {
    var r = e.defaultClassName, o = An(An({}, e.defaultVariants), n);
    for (var a in o) {
      var s, i = (s = o[a]) !== null && s !== void 0 ? s : e.defaultVariants[a];
      if (i != null) {
        var l = i;
        typeof l == "boolean" && (l = l === !0 ? "true" : "false");
        var u = (
          // @ts-expect-error
          e.variantClassNames[a][l]
        );
        u && (r += " " + u);
      }
    }
    for (var [d, f] of e.compoundVariants)
      Yo(d, o, e.defaultVariants) && (r += " " + f);
    return r;
  };
  return t.variants = () => Object.keys(e.variantClassNames), t;
}, Go = ye({ defaultClassName: "_1bycfvg9", variantClassNames: { size: { xs: "_1bycfvg2", sm: "_1bycfvg3", md: "_1bycfvg4", lg: "_1bycfvg5" }, shape: { circle: "_1bycfvg6", square: "_1bycfvg7", rounded: "_1bycfvg8" } }, defaultVariants: { size: "sm", shape: "rounded" }, compoundVariants: [] }), pr = "_1bycfvg0", Zo = "_1bycfvg1";
function vr(e) {
  var t, n, r = "";
  if (typeof e == "string" || typeof e == "number")
    r += e;
  else if (typeof e == "object")
    if (Array.isArray(e))
      for (t = 0; t < e.length; t++)
        e[t] && (n = vr(e[t])) && (r && (r += " "), r += n);
    else
      for (t in e)
        e[t] && (r && (r += " "), r += t);
  return r;
}
function k() {
  for (var e, t, n = 0, r = ""; n < arguments.length; )
    (e = arguments[n++]) && (t = vr(e)) && (r && (r += " "), r += t);
  return r;
}
const mr = un.Image, Jo = un.Fallback, Qo = B.forwardRef(
  ({ className: e, size: t = "xs", shape: n = "rounded", ...r }, o) => /* @__PURE__ */ _.jsx(
    un.Root,
    {
      ...r,
      ref: o,
      className: k(Go({ size: t, shape: n }), e)
    }
  )
), hr = B.forwardRef(
  ({ className: e, ...t }, n) => /* @__PURE__ */ _.jsx(
    Jo,
    {
      ...t,
      ref: n,
      className: k(Zo, e)
    }
  )
), gr = B.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ _.jsx(
  mr,
  {
    ...t,
    ref: n,
    className: k(pr, e)
  }
)), ea = "https://cdn.atlrdsgn.com/assets/github/atlrdsgn/A2.jpg", xr = B.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ _.jsx(
  mr,
  {
    ...t,
    ref: n,
    src: ea,
    className: k(pr, e)
  }
)), We = (e) => /* @__PURE__ */ _.jsx(Qo, { ...e });
We.Fallback = hr;
We.Image = gr;
We.Demo = xr;
We.displayName = "Avi";
We.Fallback.displayName = "AviFallback";
We.Image.displayName = "AviImage";
We.Demo.displayName = "AviDemoImage";
hr.displayName = "AviFallback";
gr.displayName = "AviImage";
xr.displayName = "AviDemoImage";
var ta = ye({ defaultClassName: "aefdx68", variantClassNames: { size: { xs: "aefdx60", sm: "aefdx61", md: "aefdx62", lg: "aefdx63" }, variant: { slate: "aefdx64", jade: "aefdx65", hyper: "aefdx66", neon: "aefdx67" } }, defaultVariants: { size: "sm", variant: "slate" }, compoundVariants: [] });
const na = ({
  children: e,
  type: t = "button",
  as: n = "a",
  onClick: r = () => {
  },
  href: o,
  target: a = "_self",
  rel: s = "noopener noreferrer",
  size: i = "sm",
  variant: l = "hyper",
  ...u
}) => {
  const d = (f) => {
    o ? (f.preventDefault(), window.open(o, a, s)) : f.preventDefault(), r(f);
  };
  return /* @__PURE__ */ _.jsx(
    "button",
    {
      ...u,
      type: t,
      className: ta({ size: i, variant: l }),
      onClick: d,
      children: e
    }
  );
};
na.displayName = "Button";
var ra = "_1dqe6mp0", oa = "_1dqe6mp1";
const aa = B.forwardRef(
  ({ children: e, ...t }, n) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: n,
      className: k(ra),
      ...t,
      children: e
    }
  )
), ia = B.forwardRef(
  ({ children: e, ...t }, n) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: n,
      className: k(oa),
      ...t,
      children: e
    }
  )
);
aa.displayName = "Canvas";
ia.displayName = "Blurred-Canvas";
var sa = ye({ defaultClassName: "_1yx7lz87", variantClassNames: { size: { xsmall: "_1yx7lz80", small: "_1yx7lz81", medium: "_1yx7lz82" }, shape: { rounded: "_1yx7lz83", pill: "_1yx7lz84" }, variant: { slate: "_1yx7lz85", hyper: "_1yx7lz86" } }, defaultVariants: { size: "small", shape: "pill", variant: "slate" }, compoundVariants: [] });
const la = ({
  children: e,
  className: t,
  size: n = "small",
  shape: r = "pill",
  variant: o = "slate",
  ...a
}) => /* @__PURE__ */ _.jsx(
  "span",
  {
    ...a,
    className: k(t, sa({ size: n, shape: r, variant: o })),
    children: e
  }
);
la.displayName = "Chip";
var ca = ye({ defaultClassName: "zhlr5ea", variantClassNames: { align: { start: "zhlr5e6", center: "zhlr5e7", end: "zhlr5e8" }, width: { small: "zhlr5e0", medium: "zhlr5e1", large: "zhlr5e2", xlarge: "zhlr5e3", max: "zhlr5e4", full: "zhlr5e5" }, border: { true: "zhlr5e9" } }, defaultVariants: { align: "start", width: "max", border: !1 }, compoundVariants: [] });
const ua = ({
  children: e,
  className: t,
  width: n = "max",
  align: r = "start",
  border: o = !1,
  ...a
}) => /* @__PURE__ */ _.jsx(
  "div",
  {
    ...a,
    className: k(t, ca({ width: n, align: r, border: o })),
    children: e
  }
);
ua.displayName = "Container";
var fa = ye({ defaultClassName: "_18w0vmkl", variantClassNames: { direction: { row: "_18w0vmk0", column: "_18w0vmk1", rowReverse: "_18w0vmk2", columnReverse: "_18w0vmk3" }, align: { start: "_18w0vmk4", center: "_18w0vmk5", end: "_18w0vmk6", stretch: "_18w0vmk7", baseline: "_18w0vmk8" }, justify: { start: "_18w0vmk9", center: "_18w0vmka", end: "_18w0vmkb", between: "_18w0vmkc" }, gap: { xs: "_18w0vmkd", sm: "_18w0vmke", md: "_18w0vmkf", lg: "_18w0vmkg", xl: "_18w0vmkh" }, wrap: { wrap: "_18w0vmki", nowrap: "_18w0vmkj", wrapReverse: "_18w0vmkk" } }, defaultVariants: { direction: "row", align: "start", justify: "start", gap: "sm", wrap: "wrap" }, compoundVariants: [] });
const da = B.forwardRef(
  ({
    children: e,
    direction: t = "row",
    align: n = "center",
    justify: r = "center",
    gap: o = "sm",
    ...a
    //..
  }, s) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ...a,
      ref: s,
      className: fa({ direction: t, align: n, justify: r, gap: o }),
      children: e
    }
  )
);
da.displayName = "Flex";
var pa = ye({ defaultClassName: "_1n0su94m", variantClassNames: { font: { system: "_1n0su940", sf: "_1n0su941", aspekta: "_1n0su942", mono: "_1n0su943" }, size: { display: "_1n0su944", H1: "_1n0su945", H2: "_1n0su946", H3: "_1n0su947", H4: "_1n0su948", H5: "_1n0su949", H6: "_1n0su94a" }, weight: { superlite: "_1n0su94b", lite: "_1n0su94c", normal: "_1n0su94d", medium: "_1n0su94e", semibold: "_1n0su94f", bold: "_1n0su94g", heavy: "_1n0su94h", black: "_1n0su94i" }, align: { left: "_1n0su94j", center: "_1n0su94k", right: "_1n0su94l" } }, defaultVariants: { font: "system", size: "H1", weight: "semibold", align: "left" }, compoundVariants: [] });
const va = B.forwardRef(
  ({
    className: e,
    font: t = "system",
    size: n = "H1",
    weight: r = "semibold",
    align: o = "left",
    ...a
  }, s) => /* @__PURE__ */ _.jsx(
    "h1",
    {
      ...a,
      ref: s,
      className: k(e, pa({ font: t, size: n, weight: r, align: o }))
    }
  )
);
va.displayName = "Heading";
var ma = ye({ defaultClassName: "_1l37a3c6", variantClassNames: { size: { small: "_1l37a3c2", medium: "_1l37a3c3" }, variant: { slate: "_1l37a3c4", hyper: "_1l37a3c5" } }, defaultVariants: { size: "medium", variant: "slate" }, compoundVariants: [] }), ha = "_1l37a3c1", ga = "_1l37a3c0";
const br = F(
  ({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    "div",
    {
      ref: r,
      className: k(t, ga),
      ...n,
      children: e
    }
  )
), yr = F(
  ({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    "label",
    {
      ref: r,
      className: k(t, ha),
      ...n,
      children: /* @__PURE__ */ _.jsx("span", { children: e })
    }
  )
), xa = F(
  ({ className: e, size: t = "medium", variant: n = "slate", ...r }, o) => /* @__PURE__ */ _.jsx(
    "input",
    {
      ref: o,
      className: k(e, ma({ size: t, variant: n })),
      ...r
    }
  )
), fn = (e) => /* @__PURE__ */ _.jsx(xa, { ...e });
fn.Flex = br;
fn.Label = yr;
fn.displayName = "Input";
br.displayName = "Input.Flex";
yr.displayName = "Input.Label";
var ba = "d9r7gl3", ya = "d9r7gl2", wa = "d9r7gl0", _a = "d9r7gl1", $a = "d9r7gl5", Ca = "d9r7gl4";
const wr = Le.Menu, _r = Le.Sub, $r = Le.Portal, Sa = B.forwardRef(
  ({ children: e, className: t, loop: n = !0, ...r }, o) => /* @__PURE__ */ _.jsx(
    Le.Root,
    {
      ...r,
      ref: o,
      className: k(t, wa),
      loop: n,
      children: e
    }
  )
), Cr = B.forwardRef(
  ({ children: e, className: t, side: n = "bottom", sideOffset: r = 10, ...o }, a) => /* @__PURE__ */ _.jsx(
    Le.Content,
    {
      ...o,
      ref: a,
      className: k(t, ba),
      side: n,
      sideOffset: r,
      children: e
    }
  )
), Sr = B.forwardRef(
  ({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    Le.Item,
    {
      ...n,
      ref: r,
      className: k(t, ya),
      children: e
    }
  )
), Er = B.forwardRef(
  ({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    Le.Trigger,
    {
      ...n,
      ref: r,
      className: k(t, _a),
      children: e
    }
  )
), Pr = B.forwardRef(
  ({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    Le.SubTrigger,
    {
      ...n,
      ref: r,
      className: k(t, Ca),
      children: e
    }
  )
), Rr = B.forwardRef(
  ({ children: e, className: t, sideOffset: n = 10, ...r }, o) => /* @__PURE__ */ _.jsx(
    Le.SubContent,
    {
      ...r,
      ref: o,
      className: k(t, $a),
      sideOffset: n,
      children: e
    }
  )
), ke = (e) => /* @__PURE__ */ _.jsx(Sa, { ...e });
ke.displayName = "Menubar";
ke.Menu = wr;
ke.Trigger = Er;
ke.Content = Cr;
ke.Item = Sr;
ke.SubMenu = _r;
ke.SubTrigger = Pr;
ke.SubContent = Rr;
ke.Portal = $r;
wr.displayName = "Menubar-Menu";
Er.displayName = "Menubar-Trigger";
Cr.displayName = "Menubar-Content";
Sr.displayName = "Menubar-Item";
_r.displayName = "Menubar-SubMenu";
Pr.displayName = "Menubar-SubTrigger";
Rr.displayName = "Menubar-SubContent";
$r.displayName = "Menubar-Portal";
var Ea = ye({ defaultClassName: "qohxgz2s", variantClassNames: { size: { xs: "qohxgz0", sm: "qohxgz1", md: "qohxgz2", lg: "qohxgz3", xl: "qohxgz4" }, color: { transparent: "qohxgz5", current: "qohxgz6", white: "qohxgz7", black: "qohxgz8", gray100: "qohxgz9", gray200: "qohxgza", gray300: "qohxgzb", pale100: "qohxgzc", pale200: "qohxgzd", pale300: "qohxgze", pale400: "qohxgzf", pale500: "qohxgzg", hyper0: "qohxgzh", hyper1: "qohxgzi", hyper2: "qohxgzj", hyper3: "qohxgzk", hyper4: "qohxgzl", hyper5: "qohxgzm", hyper6: "qohxgzn", hyper7: "qohxgzo", hyper8: "qohxgzp", hyper9: "qohxgzq", hyper10: "qohxgzr", hyper11: "qohxgzs", hyper12: "qohxgzt", hyper13: "qohxgzu", lemon0: "qohxgzv", lemon1: "qohxgzw", lemon2: "qohxgzx", lemon3: "qohxgzy", lemon4: "qohxgzz", lemon5: "qohxgz10", lemon6: "qohxgz11", lemon7: "qohxgz12", lemon8: "qohxgz13", lemon9: "qohxgz14", lemon10: "qohxgz15", lemon11: "qohxgz16", lemon12: "qohxgz17", lemon13: "qohxgz18", slate1: "qohxgz19", slate2: "qohxgz1a", slate3: "qohxgz1b", slate4: "qohxgz1c", slate5: "qohxgz1d", slate6: "qohxgz1e", slate7: "qohxgz1f", slate8: "qohxgz1g", slate9: "qohxgz1h", slate10: "qohxgz1i", slate11: "qohxgz1j", slate12: "qohxgz1k", slate13: "qohxgz1l", sapphire0: "qohxgz1m", sapphire1: "qohxgz1n", sapphire2: "qohxgz1o", sapphire3: "qohxgz1p", sapphire4: "qohxgz1q", sapphire5: "qohxgz1r", sapphire6: "qohxgz1s", sapphire7: "qohxgz1t", sapphire8: "qohxgz1u", sapphire9: "qohxgz1v", sapphire10: "qohxgz1w", sapphire11: "qohxgz1x", sapphire12: "qohxgz1y", sapphire13: "qohxgz1z", volt0: "qohxgz20", volt1: "qohxgz21", volt2: "qohxgz22", volt3: "qohxgz23", volt4: "qohxgz24", volt5: "qohxgz25", volt6: "qohxgz26", volt7: "qohxgz27", volt8: "qohxgz28", volt9: "qohxgz29", volt10: "qohxgz2a", volt11: "qohxgz2b", volt12: "qohxgz2c", volt13: "qohxgz2d" }, weight: { superlite: "qohxgz2e", lite: "qohxgz2f", normal: "qohxgz2g", medium: "qohxgz2h", semibold: "qohxgz2i", bold: "qohxgz2j", heavy: "qohxgz2k", black: "qohxgz2l" }, align: { left: "qohxgz2m", center: "qohxgz2n", right: "qohxgz2o" }, font: { system: "qohxgz2p", inter: "qohxgz2q", mono: "qohxgz2r" } }, defaultVariants: { size: "sm", color: "slate12", weight: "normal", align: "left", font: "system" }, compoundVariants: [] });
const Pa = F(
  ({ children: e, className: t, size: n, color: r, weight: o, align: a, font: s, ...i }, l) => /* @__PURE__ */ _.jsx(
    "p",
    {
      ref: l,
      className: k(t, Ea({ size: n, color: r, weight: o, align: a, font: s })),
      ...i,
      children: e
    }
  )
);
Pa.displayName = "Paragraph";
var Ra = ye({ defaultClassName: "_1g4z5m4c", variantClassNames: { size: { xs: "_1g4z5m40", sm: "_1g4z5m41", md: "_1g4z5m42", lg: "_1g4z5m43", xl: "_1g4z5m44", xxl: "_1g4z5m45" }, variant: { inherit: "_1g4z5m46", primary: "_1g4z5m47", secondary: "_1g4z5m48" }, font: { inherit: "_1g4z5m49", system: "_1g4z5m4a", mono: "_1g4z5m4b" } }, defaultVariants: { size: "sm", variant: "primary" }, compoundVariants: [] });
const Ta = F(
  ({
    children: e,
    className: t,
    href: n,
    variant: r,
    target: o = "_self",
    size: a = "sm",
    font: s = "inherit",
    ...i
  }, l) => /* @__PURE__ */ _.jsx(
    "a",
    {
      ref: l,
      href: n,
      target: o,
      className: k(Ra({ size: a, variant: r }), t),
      ...i,
      children: e
    }
  )
);
Ta.displayName = "PassLink";
var Oa = ye({ defaultClassName: "ti68jl4", variantClassNames: { size: { sm: "ti68jl0", md: "ti68jl1", lg: "ti68jl2", vw: "ti68jl3" } }, defaultVariants: { size: "vw" }, compoundVariants: [] });
const qa = ({
  children: e,
  className: t,
  size: n = "vw",
  ...r
}) => /* @__PURE__ */ _.jsx(
  "div",
  {
    ...r,
    className: k(t, Oa({ size: n })),
    children: e
  }
);
qa.displayName = "Section";
function K() {
  return K = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var n = arguments[t];
      for (var r in n)
        Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
  }, K.apply(this, arguments);
}
function Dn(e, [t, n]) {
  return Math.min(n, Math.max(t, e));
}
function se(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return function(o) {
    if (e == null || e(o), n === !1 || !o.defaultPrevented)
      return t == null ? void 0 : t(o);
  };
}
function dn(e, t = []) {
  let n = [];
  function r(a, s) {
    const i = /* @__PURE__ */ vt(s), l = n.length;
    n = [
      ...n,
      s
    ];
    function u(f) {
      const { scope: m, children: v, ...x } = f, p = (m == null ? void 0 : m[e][l]) || i, g = rt(
        () => x,
        Object.values(x)
      );
      return /* @__PURE__ */ P(p.Provider, {
        value: g
      }, v);
    }
    function d(f, m) {
      const v = (m == null ? void 0 : m[e][l]) || i, x = At(v);
      if (x)
        return x;
      if (s !== void 0)
        return s;
      throw new Error(`\`${f}\` must be used within \`${a}\``);
    }
    return u.displayName = a + "Provider", [
      u,
      d
    ];
  }
  const o = () => {
    const a = n.map((s) => /* @__PURE__ */ vt(s));
    return function(i) {
      const l = (i == null ? void 0 : i[e]) || a;
      return rt(
        () => ({
          [`__scope${e}`]: {
            ...i,
            [e]: l
          }
        }),
        [
          i,
          l
        ]
      );
    };
  };
  return o.scopeName = e, [
    r,
    Na(o, ...t)
  ];
}
function Na(...e) {
  const t = e[0];
  if (e.length === 1)
    return t;
  const n = () => {
    const r = e.map(
      (o) => ({
        useScope: o(),
        scopeName: o.scopeName
      })
    );
    return function(a) {
      const s = r.reduce((i, { useScope: l, scopeName: u }) => {
        const f = l(a)[`__scope${u}`];
        return {
          ...i,
          ...f
        };
      }, {});
      return rt(
        () => ({
          [`__scope${t.scopeName}`]: s
        }),
        [
          s
        ]
      );
    };
  };
  return n.scopeName = t.scopeName, n;
}
function za(e, t) {
  typeof e == "function" ? e(t) : e != null && (e.current = t);
}
function Tr(...e) {
  return (t) => e.forEach(
    (n) => za(n, t)
  );
}
function de(...e) {
  return fe(Tr(...e), e);
}
const mt = /* @__PURE__ */ F((e, t) => {
  const { children: n, ...r } = e, o = ft.toArray(n), a = o.find(Da);
  if (a) {
    const s = a.props.children, i = o.map((l) => l === a ? ft.count(s) > 1 ? ft.only(null) : /* @__PURE__ */ Rt(s) ? s.props.children : null : l);
    return /* @__PURE__ */ P(tn, K({}, r, {
      ref: t
    }), /* @__PURE__ */ Rt(s) ? /* @__PURE__ */ ur(s, void 0, i) : null);
  }
  return /* @__PURE__ */ P(tn, K({}, r, {
    ref: t
  }), n);
});
mt.displayName = "Slot";
const tn = /* @__PURE__ */ F((e, t) => {
  const { children: n, ...r } = e;
  return /* @__PURE__ */ Rt(n) ? /* @__PURE__ */ ur(n, {
    ...Ia(r, n.props),
    ref: t ? Tr(t, n.ref) : n.ref
  }) : ft.count(n) > 1 ? ft.only(null) : null;
});
tn.displayName = "SlotClone";
const Aa = ({ children: e }) => /* @__PURE__ */ P(cn, null, e);
function Da(e) {
  return /* @__PURE__ */ Rt(e) && e.type === Aa;
}
function Ia(e, t) {
  const n = {
    ...t
  };
  for (const r in t) {
    const o = e[r], a = t[r];
    /^on[A-Z]/.test(r) ? o && a ? n[r] = (...i) => {
      a(...i), o(...i);
    } : o && (n[r] = o) : r === "style" ? n[r] = {
      ...o,
      ...a
    } : r === "className" && (n[r] = [
      o,
      a
    ].filter(Boolean).join(" "));
  }
  return {
    ...e,
    ...n
  };
}
function La(e) {
  const t = e + "CollectionProvider", [n, r] = dn(t), [o, a] = n(t, {
    collectionRef: {
      current: null
    },
    itemMap: /* @__PURE__ */ new Map()
  }), s = (v) => {
    const { scope: x, children: p } = v, g = B.useRef(null), b = B.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ B.createElement(o, {
      scope: x,
      itemMap: b,
      collectionRef: g
    }, p);
  }, i = e + "CollectionSlot", l = /* @__PURE__ */ B.forwardRef((v, x) => {
    const { scope: p, children: g } = v, b = a(i, p), h = de(x, b.collectionRef);
    return /* @__PURE__ */ B.createElement(mt, {
      ref: h
    }, g);
  }), u = e + "CollectionItemSlot", d = "data-radix-collection-item", f = /* @__PURE__ */ B.forwardRef((v, x) => {
    const { scope: p, children: g, ...b } = v, h = B.useRef(null), y = de(x, h), $ = a(u, p);
    return B.useEffect(() => ($.itemMap.set(h, {
      ref: h,
      ...b
    }), () => void $.itemMap.delete(h))), /* @__PURE__ */ B.createElement(mt, {
      [d]: "",
      ref: y
    }, g);
  });
  function m(v) {
    const x = a(e + "CollectionConsumer", v);
    return B.useCallback(() => {
      const g = x.collectionRef.current;
      if (!g)
        return [];
      const b = Array.from(g.querySelectorAll(`[${d}]`));
      return Array.from(x.itemMap.values()).sort(
        ($, S) => b.indexOf($.ref.current) - b.indexOf(S.ref.current)
      );
    }, [
      x.collectionRef,
      x.itemMap
    ]);
  }
  return [
    {
      Provider: s,
      Slot: l,
      ItemSlot: f
    },
    m,
    r
  ];
}
const ka = /* @__PURE__ */ vt(void 0);
function Ma(e) {
  const t = At(ka);
  return e || t || "ltr";
}
const ja = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], ce = ja.reduce((e, t) => {
  const n = /* @__PURE__ */ F((r, o) => {
    const { asChild: a, ...s } = r, i = a ? mt : t;
    return re(() => {
      window[Symbol.for("radix-ui")] = !0;
    }, []), /* @__PURE__ */ P(i, K({}, s, {
      ref: o
    }));
  });
  return n.displayName = `Primitive.${t}`, {
    ...e,
    [t]: n
  };
}, {});
function Fa(e, t) {
  e && Fo(
    () => e.dispatchEvent(t)
  );
}
function Ie(e) {
  const t = le(e);
  return re(() => {
    t.current = e;
  }), rt(
    () => (...n) => {
      var r;
      return (r = t.current) === null || r === void 0 ? void 0 : r.call(t, ...n);
    },
    []
  );
}
function Va(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Ie(e);
  re(() => {
    const r = (o) => {
      o.key === "Escape" && n(o);
    };
    return t.addEventListener("keydown", r), () => t.removeEventListener("keydown", r);
  }, [
    n,
    t
  ]);
}
const nn = "dismissableLayer.update", Ha = "dismissableLayer.pointerDownOutside", Ba = "dismissableLayer.focusOutside";
let In;
const Wa = /* @__PURE__ */ vt({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), Xa = /* @__PURE__ */ F((e, t) => {
  var n;
  const { disableOutsidePointerEvents: r = !1, onEscapeKeyDown: o, onPointerDownOutside: a, onFocusOutside: s, onInteractOutside: i, onDismiss: l, ...u } = e, d = At(Wa), [f, m] = Z(null), v = (n = f == null ? void 0 : f.ownerDocument) !== null && n !== void 0 ? n : globalThis == null ? void 0 : globalThis.document, [, x] = Z({}), p = de(
    t,
    (E) => m(E)
  ), g = Array.from(d.layers), [b] = [
    ...d.layersWithOutsidePointerEventsDisabled
  ].slice(-1), h = g.indexOf(b), y = f ? g.indexOf(f) : -1, $ = d.layersWithOutsidePointerEventsDisabled.size > 0, S = y >= h, q = Ua((E) => {
    const V = E.target, J = [
      ...d.branches
    ].some(
      (A) => A.contains(V)
    );
    !S || J || (a == null || a(E), i == null || i(E), E.defaultPrevented || l == null || l());
  }, v), N = Ka((E) => {
    const V = E.target;
    [
      ...d.branches
    ].some(
      (A) => A.contains(V)
    ) || (s == null || s(E), i == null || i(E), E.defaultPrevented || l == null || l());
  }, v);
  return Va((E) => {
    y === d.layers.size - 1 && (o == null || o(E), !E.defaultPrevented && l && (E.preventDefault(), l()));
  }, v), re(() => {
    if (f)
      return r && (d.layersWithOutsidePointerEventsDisabled.size === 0 && (In = v.body.style.pointerEvents, v.body.style.pointerEvents = "none"), d.layersWithOutsidePointerEventsDisabled.add(f)), d.layers.add(f), Ln(), () => {
        r && d.layersWithOutsidePointerEventsDisabled.size === 1 && (v.body.style.pointerEvents = In);
      };
  }, [
    f,
    v,
    r,
    d
  ]), re(() => () => {
    f && (d.layers.delete(f), d.layersWithOutsidePointerEventsDisabled.delete(f), Ln());
  }, [
    f,
    d
  ]), re(() => {
    const E = () => x({});
    return document.addEventListener(nn, E), () => document.removeEventListener(nn, E);
  }, []), /* @__PURE__ */ P(ce.div, K({}, u, {
    ref: p,
    style: {
      pointerEvents: $ ? S ? "auto" : "none" : void 0,
      ...e.style
    },
    onFocusCapture: se(e.onFocusCapture, N.onFocusCapture),
    onBlurCapture: se(e.onBlurCapture, N.onBlurCapture),
    onPointerDownCapture: se(e.onPointerDownCapture, q.onPointerDownCapture)
  }));
});
function Ua(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Ie(e), r = le(!1), o = le(() => {
  });
  return re(() => {
    const a = (i) => {
      if (i.target && !r.current) {
        let u = function() {
          Or(Ha, n, l, {
            discrete: !0
          });
        };
        const l = {
          originalEvent: i
        };
        i.pointerType === "touch" ? (t.removeEventListener("click", o.current), o.current = u, t.addEventListener("click", o.current, {
          once: !0
        })) : u();
      }
      r.current = !1;
    }, s = window.setTimeout(() => {
      t.addEventListener("pointerdown", a);
    }, 0);
    return () => {
      window.clearTimeout(s), t.removeEventListener("pointerdown", a), t.removeEventListener("click", o.current);
    };
  }, [
    t,
    n
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => r.current = !0
  };
}
function Ka(e, t = globalThis == null ? void 0 : globalThis.document) {
  const n = Ie(e), r = le(!1);
  return re(() => {
    const o = (a) => {
      a.target && !r.current && Or(Ba, n, {
        originalEvent: a
      }, {
        discrete: !1
      });
    };
    return t.addEventListener("focusin", o), () => t.removeEventListener("focusin", o);
  }, [
    t,
    n
  ]), {
    onFocusCapture: () => r.current = !0,
    onBlurCapture: () => r.current = !1
  };
}
function Ln() {
  const e = new CustomEvent(nn);
  document.dispatchEvent(e);
}
function Or(e, t, n, { discrete: r }) {
  const o = n.originalEvent.target, a = new CustomEvent(e, {
    bubbles: !1,
    cancelable: !0,
    detail: n
  });
  t && o.addEventListener(e, t, {
    once: !0
  }), r ? Fa(o, a) : o.dispatchEvent(a);
}
let Xt = 0;
function Ya() {
  re(() => {
    var e, t;
    const n = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", (e = n[0]) !== null && e !== void 0 ? e : kn()), document.body.insertAdjacentElement("beforeend", (t = n[1]) !== null && t !== void 0 ? t : kn()), Xt++, () => {
      Xt === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach(
        (r) => r.remove()
      ), Xt--;
    };
  }, []);
}
function kn() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
const Ut = "focusScope.autoFocusOnMount", Kt = "focusScope.autoFocusOnUnmount", Mn = {
  bubbles: !1,
  cancelable: !0
}, Ga = /* @__PURE__ */ F((e, t) => {
  const { loop: n = !1, trapped: r = !1, onMountAutoFocus: o, onUnmountAutoFocus: a, ...s } = e, [i, l] = Z(null), u = Ie(o), d = Ie(a), f = le(null), m = de(
    t,
    (p) => l(p)
  ), v = le({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  re(() => {
    if (r) {
      let p = function(y) {
        if (v.paused || !i)
          return;
        const $ = y.target;
        i.contains($) ? f.current = $ : je(f.current, {
          select: !0
        });
      }, g = function(y) {
        if (v.paused || !i)
          return;
        const $ = y.relatedTarget;
        $ !== null && (i.contains($) || je(f.current, {
          select: !0
        }));
      }, b = function(y) {
        const $ = document.activeElement;
        for (const S of y)
          S.removedNodes.length > 0 && (i != null && i.contains($) || je(i));
      };
      document.addEventListener("focusin", p), document.addEventListener("focusout", g);
      const h = new MutationObserver(b);
      return i && h.observe(i, {
        childList: !0,
        subtree: !0
      }), () => {
        document.removeEventListener("focusin", p), document.removeEventListener("focusout", g), h.disconnect();
      };
    }
  }, [
    r,
    i,
    v.paused
  ]), re(() => {
    if (i) {
      Fn.add(v);
      const p = document.activeElement;
      if (!i.contains(p)) {
        const b = new CustomEvent(Ut, Mn);
        i.addEventListener(Ut, u), i.dispatchEvent(b), b.defaultPrevented || (Za(ni(qr(i)), {
          select: !0
        }), document.activeElement === p && je(i));
      }
      return () => {
        i.removeEventListener(Ut, u), setTimeout(() => {
          const b = new CustomEvent(Kt, Mn);
          i.addEventListener(Kt, d), i.dispatchEvent(b), b.defaultPrevented || je(p ?? document.body, {
            select: !0
          }), i.removeEventListener(Kt, d), Fn.remove(v);
        }, 0);
      };
    }
  }, [
    i,
    u,
    d,
    v
  ]);
  const x = fe((p) => {
    if (!n && !r || v.paused)
      return;
    const g = p.key === "Tab" && !p.altKey && !p.ctrlKey && !p.metaKey, b = document.activeElement;
    if (g && b) {
      const h = p.currentTarget, [y, $] = Ja(h);
      y && $ ? !p.shiftKey && b === $ ? (p.preventDefault(), n && je(y, {
        select: !0
      })) : p.shiftKey && b === y && (p.preventDefault(), n && je($, {
        select: !0
      })) : b === h && p.preventDefault();
    }
  }, [
    n,
    r,
    v.paused
  ]);
  return /* @__PURE__ */ P(ce.div, K({
    tabIndex: -1
  }, s, {
    ref: m,
    onKeyDown: x
  }));
});
function Za(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const r of e)
    if (je(r, {
      select: t
    }), document.activeElement !== n)
      return;
}
function Ja(e) {
  const t = qr(e), n = jn(t, e), r = jn(t.reverse(), e);
  return [
    n,
    r
  ];
}
function qr(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (r) => {
      const o = r.tagName === "INPUT" && r.type === "hidden";
      return r.disabled || r.hidden || o ? NodeFilter.FILTER_SKIP : r.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; n.nextNode(); )
    t.push(n.currentNode);
  return t;
}
function jn(e, t) {
  for (const n of e)
    if (!Qa(n, {
      upTo: t
    }))
      return n;
}
function Qa(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  for (; e; ) {
    if (t !== void 0 && e === t)
      return !1;
    if (getComputedStyle(e).display === "none")
      return !0;
    e = e.parentElement;
  }
  return !1;
}
function ei(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function je(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({
      preventScroll: !0
    }), e !== n && ei(e) && t && e.select();
  }
}
const Fn = ti();
function ti() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && (n == null || n.pause()), e = Vn(e, t), e.unshift(t);
    },
    remove(t) {
      var n;
      e = Vn(e, t), (n = e[0]) === null || n === void 0 || n.resume();
    }
  };
}
function Vn(e, t) {
  const n = [
    ...e
  ], r = n.indexOf(t);
  return r !== -1 && n.splice(r, 1), n;
}
function ni(e) {
  return e.filter(
    (t) => t.tagName !== "A"
  );
}
const Se = globalThis != null && globalThis.document ? fr : () => {
}, ri = R["useId".toString()] || (() => {
});
let oi = 0;
function pn(e) {
  const [t, n] = R.useState(ri());
  return Se(() => {
    e || n(
      (r) => r ?? String(oi++)
    );
  }, [
    e
  ]), e || (t ? `radix-${t}` : "");
}
function it(e) {
  return e.split("-")[1];
}
function vn(e) {
  return e === "y" ? "height" : "width";
}
function De(e) {
  return e.split("-")[0];
}
function Xe(e) {
  return ["top", "bottom"].includes(De(e)) ? "x" : "y";
}
function Hn(e, t, n) {
  let { reference: r, floating: o } = e;
  const a = r.x + r.width / 2 - o.width / 2, s = r.y + r.height / 2 - o.height / 2, i = Xe(t), l = vn(i), u = r[l] / 2 - o[l] / 2, d = i === "x";
  let f;
  switch (De(t)) {
    case "top":
      f = { x: a, y: r.y - o.height };
      break;
    case "bottom":
      f = { x: a, y: r.y + r.height };
      break;
    case "right":
      f = { x: r.x + r.width, y: s };
      break;
    case "left":
      f = { x: r.x - o.width, y: s };
      break;
    default:
      f = { x: r.x, y: r.y };
  }
  switch (it(t)) {
    case "start":
      f[i] -= u * (n && d ? -1 : 1);
      break;
    case "end":
      f[i] += u * (n && d ? -1 : 1);
  }
  return f;
}
const ai = async (e, t, n) => {
  const { placement: r = "bottom", strategy: o = "absolute", middleware: a = [], platform: s } = n, i = a.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(t));
  let u = await s.getElementRects({ reference: e, floating: t, strategy: o }), { x: d, y: f } = Hn(u, r, l), m = r, v = {}, x = 0;
  for (let p = 0; p < i.length; p++) {
    const { name: g, fn: b } = i[p], { x: h, y, data: $, reset: S } = await b({ x: d, y: f, initialPlacement: r, placement: m, strategy: o, middlewareData: v, rects: u, platform: s, elements: { reference: e, floating: t } });
    d = h ?? d, f = y ?? f, v = { ...v, [g]: { ...v[g], ...$ } }, S && x <= 50 && (x++, typeof S == "object" && (S.placement && (m = S.placement), S.rects && (u = S.rects === !0 ? await s.getElementRects({ reference: e, floating: t, strategy: o }) : S.rects), { x: d, y: f } = Hn(u, m, l)), p = -1);
  }
  return { x: d, y: f, placement: m, strategy: o, middlewareData: v };
};
function Nr(e) {
  return typeof e != "number" ? function(t) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...t };
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function Ot(e) {
  return { ...e, top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height };
}
async function ht(e, t) {
  var n;
  t === void 0 && (t = {});
  const { x: r, y: o, platform: a, rects: s, elements: i, strategy: l } = e, { boundary: u = "clippingAncestors", rootBoundary: d = "viewport", elementContext: f = "floating", altBoundary: m = !1, padding: v = 0 } = t, x = Nr(v), p = i[m ? f === "floating" ? "reference" : "floating" : f], g = Ot(await a.getClippingRect({ element: (n = await (a.isElement == null ? void 0 : a.isElement(p))) == null || n ? p : p.contextElement || await (a.getDocumentElement == null ? void 0 : a.getDocumentElement(i.floating)), boundary: u, rootBoundary: d, strategy: l })), b = f === "floating" ? { ...s.floating, x: r, y: o } : s.reference, h = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(i.floating)), y = await (a.isElement == null ? void 0 : a.isElement(h)) && await (a.getScale == null ? void 0 : a.getScale(h)) || { x: 1, y: 1 }, $ = Ot(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: b, offsetParent: h, strategy: l }) : b);
  return { top: (g.top - $.top + x.top) / y.y, bottom: ($.bottom - g.bottom + x.bottom) / y.y, left: (g.left - $.left + x.left) / y.x, right: ($.right - g.right + x.right) / y.x };
}
const rn = Math.min, He = Math.max;
function on(e, t, n) {
  return He(e, rn(t, n));
}
const Bn = (e) => ({ name: "arrow", options: e, async fn(t) {
  const { element: n, padding: r = 0 } = e || {}, { x: o, y: a, placement: s, rects: i, platform: l, elements: u } = t;
  if (n == null)
    return {};
  const d = Nr(r), f = { x: o, y: a }, m = Xe(s), v = vn(m), x = await l.getDimensions(n), p = m === "y", g = p ? "top" : "left", b = p ? "bottom" : "right", h = p ? "clientHeight" : "clientWidth", y = i.reference[v] + i.reference[m] - f[m] - i.floating[v], $ = f[m] - i.reference[m], S = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(n));
  let q = S ? S[h] : 0;
  q && await (l.isElement == null ? void 0 : l.isElement(S)) || (q = u.floating[h] || i.floating[v]);
  const N = y / 2 - $ / 2, E = d[g], V = q - x[v] - d[b], J = q / 2 - x[v] / 2 + N, A = on(E, J, V), W = it(s) != null && J != A && i.reference[v] / 2 - (J < E ? d[g] : d[b]) - x[v] / 2 < 0;
  return { [m]: f[m] - (W ? J < E ? E - J : V - J : 0), data: { [m]: A, centerOffset: J - A } };
} }), zr = ["top", "right", "bottom", "left"];
zr.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
const ii = { left: "right", right: "left", bottom: "top", top: "bottom" };
function qt(e) {
  return e.replace(/left|right|bottom|top/g, (t) => ii[t]);
}
function si(e, t, n) {
  n === void 0 && (n = !1);
  const r = it(e), o = Xe(e), a = vn(o);
  let s = o === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
  return t.reference[a] > t.floating[a] && (s = qt(s)), { main: s, cross: qt(s) };
}
const li = { start: "end", end: "start" };
function Yt(e) {
  return e.replace(/start|end/g, (t) => li[t]);
}
const ci = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
    var n;
    const { placement: r, middlewareData: o, rects: a, initialPlacement: s, platform: i, elements: l } = t, { mainAxis: u = !0, crossAxis: d = !0, fallbackPlacements: f, fallbackStrategy: m = "bestFit", fallbackAxisSideDirection: v = "none", flipAlignment: x = !0, ...p } = e, g = De(r), b = De(s) === s, h = await (i.isRTL == null ? void 0 : i.isRTL(l.floating)), y = f || (b || !x ? [qt(s)] : function(A) {
      const W = qt(A);
      return [Yt(A), W, Yt(W)];
    }(s));
    f || v === "none" || y.push(...function(A, W, I, M) {
      const D = it(A);
      let z = function(ee, te, pe) {
        const he = ["left", "right"], we = ["right", "left"], Ee = ["top", "bottom"], Te = ["bottom", "top"];
        switch (ee) {
          case "top":
          case "bottom":
            return pe ? te ? we : he : te ? he : we;
          case "left":
          case "right":
            return te ? Ee : Te;
          default:
            return [];
        }
      }(De(A), I === "start", M);
      return D && (z = z.map((ee) => ee + "-" + D), W && (z = z.concat(z.map(Yt)))), z;
    }(s, x, v, h));
    const $ = [s, ...y], S = await ht(t, p), q = [];
    let N = ((n = o.flip) == null ? void 0 : n.overflows) || [];
    if (u && q.push(S[g]), d) {
      const { main: A, cross: W } = si(r, a, h);
      q.push(S[A], S[W]);
    }
    if (N = [...N, { placement: r, overflows: q }], !q.every((A) => A <= 0)) {
      var E, V;
      const A = (((E = o.flip) == null ? void 0 : E.index) || 0) + 1, W = $[A];
      if (W)
        return { data: { index: A, overflows: N }, reset: { placement: W } };
      let I = (V = N.filter((M) => M.overflows[0] <= 0).sort((M, D) => M.overflows[1] - D.overflows[1])[0]) == null ? void 0 : V.placement;
      if (!I)
        switch (m) {
          case "bestFit": {
            var J;
            const M = (J = N.map((D) => [D.placement, D.overflows.filter((z) => z > 0).reduce((z, ee) => z + ee, 0)]).sort((D, z) => D[1] - z[1])[0]) == null ? void 0 : J[0];
            M && (I = M);
            break;
          }
          case "initialPlacement":
            I = s;
        }
      if (r !== I)
        return { reset: { placement: I } };
    }
    return {};
  } };
};
function Wn(e, t) {
  return { top: e.top - t.height, right: e.right - t.width, bottom: e.bottom - t.height, left: e.left - t.width };
}
function Xn(e) {
  return zr.some((t) => e[t] >= 0);
}
const ui = function(e) {
  return e === void 0 && (e = {}), { name: "hide", options: e, async fn(t) {
    const { strategy: n = "referenceHidden", ...r } = e, { rects: o } = t;
    switch (n) {
      case "referenceHidden": {
        const a = Wn(await ht(t, { ...r, elementContext: "reference" }), o.reference);
        return { data: { referenceHiddenOffsets: a, referenceHidden: Xn(a) } };
      }
      case "escaped": {
        const a = Wn(await ht(t, { ...r, altBoundary: !0 }), o.floating);
        return { data: { escapedOffsets: a, escaped: Xn(a) } };
      }
      default:
        return {};
    }
  } };
}, fi = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
    const { x: n, y: r } = t, o = await async function(a, s) {
      const { placement: i, platform: l, elements: u } = a, d = await (l.isRTL == null ? void 0 : l.isRTL(u.floating)), f = De(i), m = it(i), v = Xe(i) === "x", x = ["left", "top"].includes(f) ? -1 : 1, p = d && v ? -1 : 1, g = typeof s == "function" ? s(a) : s;
      let { mainAxis: b, crossAxis: h, alignmentAxis: y } = typeof g == "number" ? { mainAxis: g, crossAxis: 0, alignmentAxis: null } : { mainAxis: 0, crossAxis: 0, alignmentAxis: null, ...g };
      return m && typeof y == "number" && (h = m === "end" ? -1 * y : y), v ? { x: h * p, y: b * x } : { x: b * x, y: h * p };
    }(t, e);
    return { x: n + o.x, y: r + o.y, data: o };
  } };
};
function Ar(e) {
  return e === "x" ? "y" : "x";
}
const di = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
    const { x: n, y: r, placement: o } = t, { mainAxis: a = !0, crossAxis: s = !1, limiter: i = { fn: (g) => {
      let { x: b, y: h } = g;
      return { x: b, y: h };
    } }, ...l } = e, u = { x: n, y: r }, d = await ht(t, l), f = Xe(De(o)), m = Ar(f);
    let v = u[f], x = u[m];
    if (a) {
      const g = f === "y" ? "bottom" : "right";
      v = on(v + d[f === "y" ? "top" : "left"], v, v - d[g]);
    }
    if (s) {
      const g = m === "y" ? "bottom" : "right";
      x = on(x + d[m === "y" ? "top" : "left"], x, x - d[g]);
    }
    const p = i.fn({ ...t, [f]: v, [m]: x });
    return { ...p, data: { x: p.x - n, y: p.y - r } };
  } };
}, pi = function(e) {
  return e === void 0 && (e = {}), { options: e, fn(t) {
    const { x: n, y: r, placement: o, rects: a, middlewareData: s } = t, { offset: i = 0, mainAxis: l = !0, crossAxis: u = !0 } = e, d = { x: n, y: r }, f = Xe(o), m = Ar(f);
    let v = d[f], x = d[m];
    const p = typeof i == "function" ? i(t) : i, g = typeof p == "number" ? { mainAxis: p, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...p };
    if (l) {
      const y = f === "y" ? "height" : "width", $ = a.reference[f] - a.floating[y] + g.mainAxis, S = a.reference[f] + a.reference[y] - g.mainAxis;
      v < $ ? v = $ : v > S && (v = S);
    }
    if (u) {
      var b, h;
      const y = f === "y" ? "width" : "height", $ = ["top", "left"].includes(De(o)), S = a.reference[m] - a.floating[y] + ($ && ((b = s.offset) == null ? void 0 : b[m]) || 0) + ($ ? 0 : g.crossAxis), q = a.reference[m] + a.reference[y] + ($ ? 0 : ((h = s.offset) == null ? void 0 : h[m]) || 0) - ($ ? g.crossAxis : 0);
      x < S ? x = S : x > q && (x = q);
    }
    return { [f]: v, [m]: x };
  } };
}, vi = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
    const { placement: n, rects: r, platform: o, elements: a } = t, { apply: s = () => {
    }, ...i } = e, l = await ht(t, i), u = De(n), d = it(n), f = Xe(n) === "x", { width: m, height: v } = r.floating;
    let x, p;
    u === "top" || u === "bottom" ? (x = u, p = d === (await (o.isRTL == null ? void 0 : o.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (p = u, x = d === "end" ? "top" : "bottom");
    const g = v - l[x], b = m - l[p], h = !t.middlewareData.shift;
    let y = g, $ = b;
    if (f) {
      const q = m - l.left - l.right;
      $ = d || h ? rn(b, q) : q;
    } else {
      const q = v - l.top - l.bottom;
      y = d || h ? rn(g, q) : q;
    }
    if (h && !d) {
      const q = He(l.left, 0), N = He(l.right, 0), E = He(l.top, 0), V = He(l.bottom, 0);
      f ? $ = m - 2 * (q !== 0 || N !== 0 ? q + N : He(l.left, l.right)) : y = v - 2 * (E !== 0 || V !== 0 ? E + V : He(l.top, l.bottom));
    }
    await s({ ...t, availableWidth: $, availableHeight: y });
    const S = await o.getDimensions(a.floating);
    return m !== S.width || v !== S.height ? { reset: { rects: !0 } } : {};
  } };
};
function Ce(e) {
  var t;
  return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Pe(e) {
  return Ce(e).getComputedStyle(e);
}
function Dr(e) {
  return e instanceof Ce(e).Node;
}
function Ve(e) {
  return Dr(e) ? (e.nodeName || "").toLowerCase() : "";
}
function Re(e) {
  return e instanceof Ce(e).HTMLElement;
}
function be(e) {
  return e instanceof Ce(e).Element;
}
function Un(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof Ce(e).ShadowRoot || e instanceof ShadowRoot;
}
function gt(e) {
  const { overflow: t, overflowX: n, overflowY: r, display: o } = Pe(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && !["inline", "contents"].includes(o);
}
function mi(e) {
  return ["table", "td", "th"].includes(Ve(e));
}
function an(e) {
  const t = mn(), n = Pe(e);
  return n.transform !== "none" || n.perspective !== "none" || !t && !!n.backdropFilter && n.backdropFilter !== "none" || !t && !!n.filter && n.filter !== "none" || ["transform", "perspective", "filter"].some((r) => (n.willChange || "").includes(r)) || ["paint", "layout", "strict", "content"].some((r) => (n.contain || "").includes(r));
}
function mn() {
  return !(typeof CSS > "u" || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none");
}
function Dt(e) {
  return ["html", "body", "#document"].includes(Ve(e));
}
const Kn = Math.min, dt = Math.max, Nt = Math.round;
function Ir(e) {
  const t = Pe(e);
  let n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0;
  const o = Re(e), a = o ? e.offsetWidth : n, s = o ? e.offsetHeight : r, i = Nt(n) !== a || Nt(r) !== s;
  return i && (n = a, r = s), { width: n, height: r, fallback: i };
}
function Lr(e) {
  return be(e) ? e : e.contextElement;
}
const kr = { x: 1, y: 1 };
function nt(e) {
  const t = Lr(e);
  if (!Re(t))
    return kr;
  const n = t.getBoundingClientRect(), { width: r, height: o, fallback: a } = Ir(t);
  let s = (a ? Nt(n.width) : n.width) / r, i = (a ? Nt(n.height) : n.height) / o;
  return s && Number.isFinite(s) || (s = 1), i && Number.isFinite(i) || (i = 1), { x: s, y: i };
}
const Yn = { x: 0, y: 0 };
function Mr(e, t, n) {
  var r, o;
  if (t === void 0 && (t = !0), !mn())
    return Yn;
  const a = e ? Ce(e) : window;
  return !n || t && n !== a ? Yn : { x: ((r = a.visualViewport) == null ? void 0 : r.offsetLeft) || 0, y: ((o = a.visualViewport) == null ? void 0 : o.offsetTop) || 0 };
}
function Be(e, t, n, r) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  const o = e.getBoundingClientRect(), a = Lr(e);
  let s = kr;
  t && (r ? be(r) && (s = nt(r)) : s = nt(e));
  const i = Mr(a, n, r);
  let l = (o.left + i.x) / s.x, u = (o.top + i.y) / s.y, d = o.width / s.x, f = o.height / s.y;
  if (a) {
    const m = Ce(a), v = r && be(r) ? Ce(r) : r;
    let x = m.frameElement;
    for (; x && r && v !== m; ) {
      const p = nt(x), g = x.getBoundingClientRect(), b = getComputedStyle(x);
      g.x += (x.clientLeft + parseFloat(b.paddingLeft)) * p.x, g.y += (x.clientTop + parseFloat(b.paddingTop)) * p.y, l *= p.x, u *= p.y, d *= p.x, f *= p.y, l += g.x, u += g.y, x = Ce(x).frameElement;
    }
  }
  return Ot({ width: d, height: f, x: l, y: u });
}
function Fe(e) {
  return ((Dr(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function It(e) {
  return be(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function jr(e) {
  return Be(Fe(e)).left + It(e).scrollLeft;
}
function ot(e) {
  if (Ve(e) === "html")
    return e;
  const t = e.assignedSlot || e.parentNode || Un(e) && e.host || Fe(e);
  return Un(t) ? t.host : t;
}
function Fr(e) {
  const t = ot(e);
  return Dt(t) ? t.ownerDocument.body : Re(t) && gt(t) ? t : Fr(t);
}
function pt(e, t) {
  var n;
  t === void 0 && (t = []);
  const r = Fr(e), o = r === ((n = e.ownerDocument) == null ? void 0 : n.body), a = Ce(r);
  return o ? t.concat(a, a.visualViewport || [], gt(r) ? r : []) : t.concat(r, pt(r));
}
function Gn(e, t, n) {
  let r;
  if (t === "viewport")
    r = function(o, a) {
      const s = Ce(o), i = Fe(o), l = s.visualViewport;
      let u = i.clientWidth, d = i.clientHeight, f = 0, m = 0;
      if (l) {
        u = l.width, d = l.height;
        const v = mn();
        (!v || v && a === "fixed") && (f = l.offsetLeft, m = l.offsetTop);
      }
      return { width: u, height: d, x: f, y: m };
    }(e, n);
  else if (t === "document")
    r = function(o) {
      const a = Fe(o), s = It(o), i = o.ownerDocument.body, l = dt(a.scrollWidth, a.clientWidth, i.scrollWidth, i.clientWidth), u = dt(a.scrollHeight, a.clientHeight, i.scrollHeight, i.clientHeight);
      let d = -s.scrollLeft + jr(o);
      const f = -s.scrollTop;
      return Pe(i).direction === "rtl" && (d += dt(a.clientWidth, i.clientWidth) - l), { width: l, height: u, x: d, y: f };
    }(Fe(e));
  else if (be(t))
    r = function(o, a) {
      const s = Be(o, !0, a === "fixed"), i = s.top + o.clientTop, l = s.left + o.clientLeft, u = Re(o) ? nt(o) : { x: 1, y: 1 };
      return { width: o.clientWidth * u.x, height: o.clientHeight * u.y, x: l * u.x, y: i * u.y };
    }(t, n);
  else {
    const o = Mr(e);
    r = { ...t, x: t.x - o.x, y: t.y - o.y };
  }
  return Ot(r);
}
function Vr(e, t) {
  const n = ot(e);
  return !(n === t || !be(n) || Dt(n)) && (Pe(n).position === "fixed" || Vr(n, t));
}
function Zn(e, t) {
  return Re(e) && Pe(e).position !== "fixed" ? t ? t(e) : e.offsetParent : null;
}
function Jn(e, t) {
  const n = Ce(e);
  if (!Re(e))
    return n;
  let r = Zn(e, t);
  for (; r && mi(r) && Pe(r).position === "static"; )
    r = Zn(r, t);
  return r && (Ve(r) === "html" || Ve(r) === "body" && Pe(r).position === "static" && !an(r)) ? n : r || function(o) {
    let a = ot(o);
    for (; Re(a) && !Dt(a); ) {
      if (an(a))
        return a;
      a = ot(a);
    }
    return null;
  }(e) || n;
}
function hi(e, t, n) {
  const r = Re(t), o = Fe(t), a = n === "fixed", s = Be(e, !0, a, t);
  let i = { scrollLeft: 0, scrollTop: 0 };
  const l = { x: 0, y: 0 };
  if (r || !r && !a)
    if ((Ve(t) !== "body" || gt(o)) && (i = It(t)), Re(t)) {
      const u = Be(t, !0, a, t);
      l.x = u.x + t.clientLeft, l.y = u.y + t.clientTop;
    } else
      o && (l.x = jr(o));
  return { x: s.left + i.scrollLeft - l.x, y: s.top + i.scrollTop - l.y, width: s.width, height: s.height };
}
const gi = { getClippingRect: function(e) {
  let { element: t, boundary: n, rootBoundary: r, strategy: o } = e;
  const a = n === "clippingAncestors" ? function(u, d) {
    const f = d.get(u);
    if (f)
      return f;
    let m = pt(u).filter((g) => be(g) && Ve(g) !== "body"), v = null;
    const x = Pe(u).position === "fixed";
    let p = x ? ot(u) : u;
    for (; be(p) && !Dt(p); ) {
      const g = Pe(p), b = an(p);
      b || g.position !== "fixed" || (v = null), (x ? !b && !v : !b && g.position === "static" && v && ["absolute", "fixed"].includes(v.position) || gt(p) && !b && Vr(u, p)) ? m = m.filter((h) => h !== p) : v = g, p = ot(p);
    }
    return d.set(u, m), m;
  }(t, this._c) : [].concat(n), s = [...a, r], i = s[0], l = s.reduce((u, d) => {
    const f = Gn(t, d, o);
    return u.top = dt(f.top, u.top), u.right = Kn(f.right, u.right), u.bottom = Kn(f.bottom, u.bottom), u.left = dt(f.left, u.left), u;
  }, Gn(t, i, o));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: t, offsetParent: n, strategy: r } = e;
  const o = Re(n), a = Fe(n);
  if (n === a)
    return t;
  let s = { scrollLeft: 0, scrollTop: 0 }, i = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((o || !o && r !== "fixed") && ((Ve(n) !== "body" || gt(a)) && (s = It(n)), Re(n))) {
    const u = Be(n);
    i = nt(n), l.x = u.x + n.clientLeft, l.y = u.y + n.clientTop;
  }
  return { width: t.width * i.x, height: t.height * i.y, x: t.x * i.x - s.scrollLeft * i.x + l.x, y: t.y * i.y - s.scrollTop * i.y + l.y };
}, isElement: be, getDimensions: function(e) {
  return Ir(e);
}, getOffsetParent: Jn, getDocumentElement: Fe, getScale: nt, async getElementRects(e) {
  let { reference: t, floating: n, strategy: r } = e;
  const o = this.getOffsetParent || Jn, a = this.getDimensions;
  return { reference: hi(t, await o(n), r), floating: { x: 0, y: 0, ...await a(n) } };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Pe(e).direction === "rtl" };
function xi(e, t, n, r) {
  r === void 0 && (r = {});
  const { ancestorScroll: o = !0, ancestorResize: a = !0, elementResize: s = !0, animationFrame: i = !1 } = r, l = o || a ? [...be(e) ? pt(e) : e.contextElement ? pt(e.contextElement) : [], ...pt(t)] : [];
  l.forEach((m) => {
    const v = !be(m) && m.toString().includes("V");
    !o || i && !v || m.addEventListener("scroll", n, { passive: !0 }), a && m.addEventListener("resize", n);
  });
  let u, d = null;
  s && (d = new ResizeObserver(() => {
    n();
  }), be(e) && !i && d.observe(e), be(e) || !e.contextElement || i || d.observe(e.contextElement), d.observe(t));
  let f = i ? Be(e) : null;
  return i && function m() {
    const v = Be(e);
    !f || v.x === f.x && v.y === f.y && v.width === f.width && v.height === f.height || n(), f = v, u = requestAnimationFrame(m);
  }(), n(), () => {
    var m;
    l.forEach((v) => {
      o && v.removeEventListener("scroll", n), a && v.removeEventListener("resize", n);
    }), (m = d) == null || m.disconnect(), d = null, i && cancelAnimationFrame(u);
  };
}
const bi = (e, t, n) => {
  const r = /* @__PURE__ */ new Map(), o = { platform: gi, ...n }, a = { ...o.platform, _c: r };
  return ai(e, t, { ...o, platform: a });
}, yi = (e) => {
  const {
    element: t,
    padding: n
  } = e;
  function r(o) {
    return {}.hasOwnProperty.call(o, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(o) {
      return t && r(t) ? t.current != null ? Bn({
        element: t.current,
        padding: n
      }).fn(o) : {} : t ? Bn({
        element: t,
        padding: n
      }).fn(o) : {};
    }
  };
};
var St = typeof document < "u" ? fr : re;
function zt(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let n, r, o;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (n = e.length, n != t.length)
        return !1;
      for (r = n; r-- !== 0; )
        if (!zt(e[r], t[r]))
          return !1;
      return !0;
    }
    if (o = Object.keys(e), n = o.length, n !== Object.keys(t).length)
      return !1;
    for (r = n; r-- !== 0; )
      if (!{}.hasOwnProperty.call(t, o[r]))
        return !1;
    for (r = n; r-- !== 0; ) {
      const a = o[r];
      if (!(a === "_owner" && e.$$typeof) && !zt(e[a], t[a]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function Hr(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Qn(e, t) {
  const n = Hr(e);
  return Math.round(t * n) / n;
}
function er(e) {
  const t = R.useRef(e);
  return St(() => {
    t.current = e;
  }), t;
}
function wi(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: n = "absolute",
    middleware: r = [],
    platform: o,
    elements: {
      reference: a,
      floating: s
    } = {},
    transform: i = !0,
    whileElementsMounted: l,
    open: u
  } = e, [d, f] = R.useState({
    x: 0,
    y: 0,
    strategy: n,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [m, v] = R.useState(r);
  zt(m, r) || v(r);
  const [x, p] = R.useState(null), [g, b] = R.useState(null), h = R.useCallback((z) => {
    z != q.current && (q.current = z, p(z));
  }, [p]), y = R.useCallback((z) => {
    z !== N.current && (N.current = z, b(z));
  }, [b]), $ = a || x, S = s || g, q = R.useRef(null), N = R.useRef(null), E = R.useRef(d), V = er(l), J = er(o), A = R.useCallback(() => {
    if (!q.current || !N.current)
      return;
    const z = {
      placement: t,
      strategy: n,
      middleware: m
    };
    J.current && (z.platform = J.current), bi(q.current, N.current, z).then((ee) => {
      const te = {
        ...ee,
        isPositioned: !0
      };
      W.current && !zt(E.current, te) && (E.current = te, Mo.flushSync(() => {
        f(te);
      }));
    });
  }, [m, t, n, J]);
  St(() => {
    u === !1 && E.current.isPositioned && (E.current.isPositioned = !1, f((z) => ({
      ...z,
      isPositioned: !1
    })));
  }, [u]);
  const W = R.useRef(!1);
  St(() => (W.current = !0, () => {
    W.current = !1;
  }), []), St(() => {
    if ($ && (q.current = $), S && (N.current = S), $ && S) {
      if (V.current)
        return V.current($, S, A);
      A();
    }
  }, [$, S, A, V]);
  const I = R.useMemo(() => ({
    reference: q,
    floating: N,
    setReference: h,
    setFloating: y
  }), [h, y]), M = R.useMemo(() => ({
    reference: $,
    floating: S
  }), [$, S]), D = R.useMemo(() => {
    const z = {
      position: n,
      left: 0,
      top: 0
    };
    if (!M.floating)
      return z;
    const ee = Qn(M.floating, d.x), te = Qn(M.floating, d.y);
    return i ? {
      ...z,
      transform: "translate(" + ee + "px, " + te + "px)",
      ...Hr(M.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: n,
      left: ee,
      top: te
    };
  }, [n, i, M.floating, d.x, d.y]);
  return R.useMemo(() => ({
    ...d,
    update: A,
    refs: I,
    elements: M,
    floatingStyles: D
  }), [d, A, I, M, D]);
}
function _i(e) {
  const [t, n] = Z(void 0);
  return Se(() => {
    if (e) {
      n({
        width: e.offsetWidth,
        height: e.offsetHeight
      });
      const r = new ResizeObserver((o) => {
        if (!Array.isArray(o) || !o.length)
          return;
        const a = o[0];
        let s, i;
        if ("borderBoxSize" in a) {
          const l = a.borderBoxSize, u = Array.isArray(l) ? l[0] : l;
          s = u.inlineSize, i = u.blockSize;
        } else
          s = e.offsetWidth, i = e.offsetHeight;
        n({
          width: s,
          height: i
        });
      });
      return r.observe(e, {
        box: "border-box"
      }), () => r.unobserve(e);
    } else
      n(void 0);
  }, [
    e
  ]), t;
}
const Br = "Popper", [Wr, Xr] = dn(Br), [$i, Ur] = Wr(Br), Ci = (e) => {
  const { __scopePopper: t, children: n } = e, [r, o] = Z(null);
  return /* @__PURE__ */ P($i, {
    scope: t,
    anchor: r,
    onAnchorChange: o
  }, n);
}, Si = "PopperAnchor", Ei = /* @__PURE__ */ F((e, t) => {
  const { __scopePopper: n, virtualRef: r, ...o } = e, a = Ur(Si, n), s = le(null), i = de(t, s);
  return re(() => {
    a.onAnchorChange((r == null ? void 0 : r.current) || s.current);
  }), r ? null : /* @__PURE__ */ P(ce.div, K({}, o, {
    ref: i
  }));
}), Kr = "PopperContent", [Pi, rc] = Wr(Kr), Ri = /* @__PURE__ */ F((e, t) => {
  var n, r, o, a, s, i, l, u;
  const { __scopePopper: d, side: f = "bottom", sideOffset: m = 0, align: v = "center", alignOffset: x = 0, arrowPadding: p = 0, collisionBoundary: g = [], collisionPadding: b = 0, sticky: h = "partial", hideWhenDetached: y = !1, avoidCollisions: $ = !0, onPlaced: S, ...q } = e, N = Ur(Kr, d), [E, V] = Z(null), J = de(
    t,
    (ue) => V(ue)
  ), [A, W] = Z(null), I = _i(A), M = (n = I == null ? void 0 : I.width) !== null && n !== void 0 ? n : 0, D = (r = I == null ? void 0 : I.height) !== null && r !== void 0 ? r : 0, z = f + (v !== "center" ? "-" + v : ""), ee = typeof b == "number" ? b : {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...b
  }, te = Array.isArray(g) ? g : [
    g
  ], pe = te.length > 0, he = {
    padding: ee,
    boundary: te.filter(Ti),
    // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
    altBoundary: pe
  }, { refs: we, floatingStyles: Ee, placement: Te, isPositioned: ge, middlewareData: xe } = wi({
    // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
    strategy: "fixed",
    placement: z,
    whileElementsMounted: xi,
    elements: {
      reference: N.anchor
    },
    middleware: [
      fi({
        mainAxis: m + D,
        alignmentAxis: x
      }),
      $ && di({
        mainAxis: !0,
        crossAxis: !1,
        limiter: h === "partial" ? pi() : void 0,
        ...he
      }),
      $ && ci({
        ...he
      }),
      vi({
        ...he,
        apply: ({ elements: ue, rects: Oe, availableWidth: qe, availableHeight: Me }) => {
          const { width: xt, height: Ye } = Oe.reference, Ge = ue.floating.style;
          Ge.setProperty("--radix-popper-available-width", `${qe}px`), Ge.setProperty("--radix-popper-available-height", `${Me}px`), Ge.setProperty("--radix-popper-anchor-width", `${xt}px`), Ge.setProperty("--radix-popper-anchor-height", `${Ye}px`);
        }
      }),
      A && yi({
        element: A,
        padding: p
      }),
      Oi({
        arrowWidth: M,
        arrowHeight: D
      }),
      y && ui({
        strategy: "referenceHidden"
      })
    ]
  }), [_e, T] = Yr(Te), H = Ie(S);
  Se(() => {
    ge && (H == null || H());
  }, [
    ge,
    H
  ]);
  const ie = (o = xe.arrow) === null || o === void 0 ? void 0 : o.x, Y = (a = xe.arrow) === null || a === void 0 ? void 0 : a.y, G = ((s = xe.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0, [X, ve] = Z();
  return Se(() => {
    E && ve(window.getComputedStyle(E).zIndex);
  }, [
    E
  ]), /* @__PURE__ */ P("div", {
    ref: we.setFloating,
    "data-radix-popper-content-wrapper": "",
    style: {
      ...Ee,
      transform: ge ? Ee.transform : "translate(0, -200%)",
      // keep off the page when measuring
      minWidth: "max-content",
      zIndex: X,
      ["--radix-popper-transform-origin"]: [
        (i = xe.transformOrigin) === null || i === void 0 ? void 0 : i.x,
        (l = xe.transformOrigin) === null || l === void 0 ? void 0 : l.y
      ].join(" ")
    },
    dir: e.dir
  }, /* @__PURE__ */ P(Pi, {
    scope: d,
    placedSide: _e,
    onArrowChange: W,
    arrowX: ie,
    arrowY: Y,
    shouldHideArrow: G
  }, /* @__PURE__ */ P(ce.div, K({
    "data-side": _e,
    "data-align": T
  }, q, {
    ref: J,
    style: {
      ...q.style,
      // if the PopperContent hasn't been placed yet (not all measurements done)
      // we prevent animations so that users's animation don't kick in too early referring wrong sides
      animation: ge ? void 0 : "none",
      // hide the content if using the hide middleware and should be hidden
      opacity: (u = xe.hide) !== null && u !== void 0 && u.referenceHidden ? 0 : void 0
    }
  }))));
});
function Ti(e) {
  return e !== null;
}
const Oi = (e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    var n, r, o, a, s;
    const { placement: i, rects: l, middlewareData: u } = t, f = ((n = u.arrow) === null || n === void 0 ? void 0 : n.centerOffset) !== 0, m = f ? 0 : e.arrowWidth, v = f ? 0 : e.arrowHeight, [x, p] = Yr(i), g = {
      start: "0%",
      center: "50%",
      end: "100%"
    }[p], b = ((r = (o = u.arrow) === null || o === void 0 ? void 0 : o.x) !== null && r !== void 0 ? r : 0) + m / 2, h = ((a = (s = u.arrow) === null || s === void 0 ? void 0 : s.y) !== null && a !== void 0 ? a : 0) + v / 2;
    let y = "", $ = "";
    return x === "bottom" ? (y = f ? g : `${b}px`, $ = `${-v}px`) : x === "top" ? (y = f ? g : `${b}px`, $ = `${l.floating.height + v}px`) : x === "right" ? (y = `${-v}px`, $ = f ? g : `${h}px`) : x === "left" && (y = `${l.floating.width + v}px`, $ = f ? g : `${h}px`), {
      data: {
        x: y,
        y: $
      }
    };
  }
});
function Yr(e) {
  const [t, n = "center"] = e.split("-");
  return [
    t,
    n
  ];
}
const qi = Ci, Ni = Ei, zi = Ri, Ai = /* @__PURE__ */ F((e, t) => {
  var n;
  const { container: r = globalThis == null || (n = globalThis.document) === null || n === void 0 ? void 0 : n.body, ...o } = e;
  return r ? /* @__PURE__ */ jo.createPortal(/* @__PURE__ */ P(ce.div, K({}, o, {
    ref: t
  })), r) : null;
});
function tr({ prop: e, defaultProp: t, onChange: n = () => {
} }) {
  const [r, o] = Di({
    defaultProp: t,
    onChange: n
  }), a = e !== void 0, s = a ? e : r, i = Ie(n), l = fe((u) => {
    if (a) {
      const f = typeof u == "function" ? u(e) : u;
      f !== e && i(f);
    } else
      o(u);
  }, [
    a,
    e,
    o,
    i
  ]);
  return [
    s,
    l
  ];
}
function Di({ defaultProp: e, onChange: t }) {
  const n = Z(e), [r] = n, o = le(r), a = Ie(t);
  return re(() => {
    o.current !== r && (a(r), o.current = r);
  }, [
    r,
    o,
    a
  ]), n;
}
function Ii(e) {
  const t = le({
    value: e,
    previous: e
  });
  return rt(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [
    e
  ]);
}
const Li = /* @__PURE__ */ F((e, t) => /* @__PURE__ */ P(ce.span, K({}, e, {
  ref: t,
  style: {
    // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal",
    ...e.style
  }
})));
var ki = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, Qe = /* @__PURE__ */ new WeakMap(), bt = /* @__PURE__ */ new WeakMap(), yt = {}, Gt = 0, Gr = function(e) {
  return e && (e.host || Gr(e.parentNode));
}, Mi = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var r = Gr(n);
    return r && e.contains(r) ? r : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, ji = function(e, t, n, r) {
  var o = Mi(t, Array.isArray(e) ? e : [e]);
  yt[n] || (yt[n] = /* @__PURE__ */ new WeakMap());
  var a = yt[n], s = [], i = /* @__PURE__ */ new Set(), l = new Set(o), u = function(f) {
    !f || i.has(f) || (i.add(f), u(f.parentNode));
  };
  o.forEach(u);
  var d = function(f) {
    !f || l.has(f) || Array.prototype.forEach.call(f.children, function(m) {
      if (i.has(m))
        d(m);
      else {
        var v = m.getAttribute(r), x = v !== null && v !== "false", p = (Qe.get(m) || 0) + 1, g = (a.get(m) || 0) + 1;
        Qe.set(m, p), a.set(m, g), s.push(m), p === 1 && x && bt.set(m, !0), g === 1 && m.setAttribute(n, "true"), x || m.setAttribute(r, "true");
      }
    });
  };
  return d(t), i.clear(), Gt++, function() {
    s.forEach(function(f) {
      var m = Qe.get(f) - 1, v = a.get(f) - 1;
      Qe.set(f, m), a.set(f, v), m || (bt.has(f) || f.removeAttribute(r), bt.delete(f)), v || f.removeAttribute(n);
    }), Gt--, Gt || (Qe = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ new WeakMap(), bt = /* @__PURE__ */ new WeakMap(), yt = {});
  };
}, Fi = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var r = Array.from(Array.isArray(e) ? e : [e]), o = t || ki(e);
  return o ? (r.push.apply(r, Array.from(o.querySelectorAll("[aria-live]"))), ji(r, o, n, "aria-hidden")) : function() {
    return null;
  };
}, Ne = function() {
  return Ne = Object.assign || function(t) {
    for (var n, r = 1, o = arguments.length; r < o; r++) {
      n = arguments[r];
      for (var a in n)
        Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
    }
    return t;
  }, Ne.apply(this, arguments);
};
function Zr(e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++)
      t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
  return n;
}
function Vi(e, t, n) {
  if (n || arguments.length === 2)
    for (var r = 0, o = t.length, a; r < o; r++)
      (a || !(r in t)) && (a || (a = Array.prototype.slice.call(t, 0, r)), a[r] = t[r]);
  return e.concat(a || Array.prototype.slice.call(t));
}
var Et = "right-scroll-bar-position", Pt = "width-before-scroll-bar", Hi = "with-scroll-bars-hidden", Bi = "--removed-body-scroll-bar-size";
function Wi(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function Xi(e, t) {
  var n = Z(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(r) {
          var o = n.value;
          o !== r && (n.value = r, n.callback(r, o));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
function Ui(e, t) {
  return Xi(t || null, function(n) {
    return e.forEach(function(r) {
      return Wi(r, n);
    });
  });
}
function Ki(e) {
  return e;
}
function Yi(e, t) {
  t === void 0 && (t = Ki);
  var n = [], r = !1, o = {
    read: function() {
      if (r)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(a) {
      var s = t(a, r);
      return n.push(s), function() {
        n = n.filter(function(i) {
          return i !== s;
        });
      };
    },
    assignSyncMedium: function(a) {
      for (r = !0; n.length; ) {
        var s = n;
        n = [], s.forEach(a);
      }
      n = {
        push: function(i) {
          return a(i);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(a) {
      r = !0;
      var s = [];
      if (n.length) {
        var i = n;
        n = [], i.forEach(a), s = n;
      }
      var l = function() {
        var d = s;
        s = [], d.forEach(a);
      }, u = function() {
        return Promise.resolve().then(l);
      };
      u(), n = {
        push: function(d) {
          s.push(d), u();
        },
        filter: function(d) {
          return s = s.filter(d), n;
        }
      };
    }
  };
  return o;
}
function Gi(e) {
  e === void 0 && (e = {});
  var t = Yi(null);
  return t.options = Ne({ async: !0, ssr: !1 }, e), t;
}
var Jr = function(e) {
  var t = e.sideCar, n = Zr(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var r = t.read();
  if (!r)
    throw new Error("Sidecar medium not found");
  return R.createElement(r, Ne({}, n));
};
Jr.isSideCarExport = !0;
function Zi(e, t) {
  return e.useMedium(t), Jr;
}
var Qr = Gi(), Zt = function() {
}, Lt = R.forwardRef(function(e, t) {
  var n = R.useRef(null), r = R.useState({
    onScrollCapture: Zt,
    onWheelCapture: Zt,
    onTouchMoveCapture: Zt
  }), o = r[0], a = r[1], s = e.forwardProps, i = e.children, l = e.className, u = e.removeScrollBar, d = e.enabled, f = e.shards, m = e.sideCar, v = e.noIsolation, x = e.inert, p = e.allowPinchZoom, g = e.as, b = g === void 0 ? "div" : g, h = Zr(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as"]), y = m, $ = Ui([n, t]), S = Ne(Ne({}, h), o);
  return R.createElement(
    R.Fragment,
    null,
    d && R.createElement(y, { sideCar: Qr, removeScrollBar: u, shards: f, noIsolation: v, inert: x, setCallbacks: a, allowPinchZoom: !!p, lockRef: n }),
    s ? R.cloneElement(R.Children.only(i), Ne(Ne({}, S), { ref: $ })) : R.createElement(b, Ne({}, S, { className: l, ref: $ }), i)
  );
});
Lt.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
Lt.classNames = {
  fullWidth: Pt,
  zeroRight: Et
};
var nr, Ji = function() {
  if (nr)
    return nr;
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function Qi() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = Ji();
  return t && e.setAttribute("nonce", t), e;
}
function es(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function ts(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var ns = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = Qi()) && (es(t, n), ts(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, rs = function() {
  var e = ns();
  return function(t, n) {
    R.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, eo = function() {
  var e = rs(), t = function(n) {
    var r = n.styles, o = n.dynamic;
    return e(r, o), null;
  };
  return t;
}, os = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, Jt = function(e) {
  return parseInt(e || "", 10) || 0;
}, as = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], o = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [Jt(n), Jt(r), Jt(o)];
}, is = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return os;
  var t = as(e), n = document.documentElement.clientWidth, r = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, r - n + t[2] - t[0])
  };
}, ss = eo(), ls = function(e, t, n, r) {
  var o = e.left, a = e.top, s = e.right, i = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(Hi, ` {
   overflow: hidden `).concat(r, `;
   padding-right: `).concat(i, "px ").concat(r, `;
  }
  body {
    overflow: hidden `).concat(r, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(r, ";"),
    n === "margin" && `
    padding-left: `.concat(o, `px;
    padding-top: `).concat(a, `px;
    padding-right: `).concat(s, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(i, "px ").concat(r, `;
    `),
    n === "padding" && "padding-right: ".concat(i, "px ").concat(r, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Et, ` {
    right: `).concat(i, "px ").concat(r, `;
  }
  
  .`).concat(Pt, ` {
    margin-right: `).concat(i, "px ").concat(r, `;
  }
  
  .`).concat(Et, " .").concat(Et, ` {
    right: 0 `).concat(r, `;
  }
  
  .`).concat(Pt, " .").concat(Pt, ` {
    margin-right: 0 `).concat(r, `;
  }
  
  body {
    `).concat(Bi, ": ").concat(i, `px;
  }
`);
}, cs = function(e) {
  var t = e.noRelative, n = e.noImportant, r = e.gapMode, o = r === void 0 ? "margin" : r, a = R.useMemo(function() {
    return is(o);
  }, [o]);
  return R.createElement(ss, { styles: ls(a, !t, o, n ? "" : "!important") });
}, sn = !1;
if (typeof window < "u")
  try {
    var wt = Object.defineProperty({}, "passive", {
      get: function() {
        return sn = !0, !0;
      }
    });
    window.addEventListener("test", wt, wt), window.removeEventListener("test", wt, wt);
  } catch {
    sn = !1;
  }
var et = sn ? { passive: !1 } : !1, us = function(e) {
  return e.tagName === "TEXTAREA";
}, to = function(e, t) {
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !us(e) && n[t] === "visible")
  );
}, fs = function(e) {
  return to(e, "overflowY");
}, ds = function(e) {
  return to(e, "overflowX");
}, rr = function(e, t) {
  var n = t;
  do {
    typeof ShadowRoot < "u" && n instanceof ShadowRoot && (n = n.host);
    var r = no(e, n);
    if (r) {
      var o = ro(e, n), a = o[1], s = o[2];
      if (a > s)
        return !0;
    }
    n = n.parentNode;
  } while (n && n !== document.body);
  return !1;
}, ps = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, r = e.clientHeight;
  return [
    t,
    n,
    r
  ];
}, vs = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, r = e.clientWidth;
  return [
    t,
    n,
    r
  ];
}, no = function(e, t) {
  return e === "v" ? fs(t) : ds(t);
}, ro = function(e, t) {
  return e === "v" ? ps(t) : vs(t);
}, ms = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, hs = function(e, t, n, r, o) {
  var a = ms(e, window.getComputedStyle(t).direction), s = a * r, i = n.target, l = t.contains(i), u = !1, d = s > 0, f = 0, m = 0;
  do {
    var v = ro(e, i), x = v[0], p = v[1], g = v[2], b = p - g - a * x;
    (x || b) && no(e, i) && (f += b, m += x), i = i.parentNode;
  } while (
    // portaled content
    !l && i !== document.body || // self content
    l && (t.contains(i) || t === i)
  );
  return (d && (o && f === 0 || !o && s > f) || !d && (o && m === 0 || !o && -s > m)) && (u = !0), u;
}, _t = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, or = function(e) {
  return [e.deltaX, e.deltaY];
}, ar = function(e) {
  return e && "current" in e ? e.current : e;
}, gs = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, xs = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, bs = 0, tt = [];
function ys(e) {
  var t = R.useRef([]), n = R.useRef([0, 0]), r = R.useRef(), o = R.useState(bs++)[0], a = R.useState(function() {
    return eo();
  })[0], s = R.useRef(e);
  R.useEffect(function() {
    s.current = e;
  }, [e]), R.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(o));
      var p = Vi([e.lockRef.current], (e.shards || []).map(ar), !0).filter(Boolean);
      return p.forEach(function(g) {
        return g.classList.add("allow-interactivity-".concat(o));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(o)), p.forEach(function(g) {
          return g.classList.remove("allow-interactivity-".concat(o));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var i = R.useCallback(function(p, g) {
    if ("touches" in p && p.touches.length === 2)
      return !s.current.allowPinchZoom;
    var b = _t(p), h = n.current, y = "deltaX" in p ? p.deltaX : h[0] - b[0], $ = "deltaY" in p ? p.deltaY : h[1] - b[1], S, q = p.target, N = Math.abs(y) > Math.abs($) ? "h" : "v";
    if ("touches" in p && N === "h" && q.type === "range")
      return !1;
    var E = rr(N, q);
    if (!E)
      return !0;
    if (E ? S = N : (S = N === "v" ? "h" : "v", E = rr(N, q)), !E)
      return !1;
    if (!r.current && "changedTouches" in p && (y || $) && (r.current = S), !S)
      return !0;
    var V = r.current || S;
    return hs(V, g, p, V === "h" ? y : $, !0);
  }, []), l = R.useCallback(function(p) {
    var g = p;
    if (!(!tt.length || tt[tt.length - 1] !== a)) {
      var b = "deltaY" in g ? or(g) : _t(g), h = t.current.filter(function(S) {
        return S.name === g.type && S.target === g.target && gs(S.delta, b);
      })[0];
      if (h && h.should) {
        g.cancelable && g.preventDefault();
        return;
      }
      if (!h) {
        var y = (s.current.shards || []).map(ar).filter(Boolean).filter(function(S) {
          return S.contains(g.target);
        }), $ = y.length > 0 ? i(g, y[0]) : !s.current.noIsolation;
        $ && g.cancelable && g.preventDefault();
      }
    }
  }, []), u = R.useCallback(function(p, g, b, h) {
    var y = { name: p, delta: g, target: b, should: h };
    t.current.push(y), setTimeout(function() {
      t.current = t.current.filter(function($) {
        return $ !== y;
      });
    }, 1);
  }, []), d = R.useCallback(function(p) {
    n.current = _t(p), r.current = void 0;
  }, []), f = R.useCallback(function(p) {
    u(p.type, or(p), p.target, i(p, e.lockRef.current));
  }, []), m = R.useCallback(function(p) {
    u(p.type, _t(p), p.target, i(p, e.lockRef.current));
  }, []);
  R.useEffect(function() {
    return tt.push(a), e.setCallbacks({
      onScrollCapture: f,
      onWheelCapture: f,
      onTouchMoveCapture: m
    }), document.addEventListener("wheel", l, et), document.addEventListener("touchmove", l, et), document.addEventListener("touchstart", d, et), function() {
      tt = tt.filter(function(p) {
        return p !== a;
      }), document.removeEventListener("wheel", l, et), document.removeEventListener("touchmove", l, et), document.removeEventListener("touchstart", d, et);
    };
  }, []);
  var v = e.removeScrollBar, x = e.inert;
  return R.createElement(
    R.Fragment,
    null,
    x ? R.createElement(a, { styles: xs(o) }) : null,
    v ? R.createElement(cs, { gapMode: "margin" }) : null
  );
}
const ws = Zi(Qr, ys);
var oo = R.forwardRef(function(e, t) {
  return R.createElement(Lt, Ne({}, e, { ref: t, sideCar: ws }));
});
oo.classNames = Lt.classNames;
const _s = oo, $s = [
  " ",
  "Enter",
  "ArrowUp",
  "ArrowDown"
], Cs = [
  " ",
  "Enter"
], kt = "Select", [Mt, jt, Ss] = La(kt), [st, oc] = dn(kt, [
  Ss,
  Xr
]), hn = Xr(), [Es, Ue] = st(kt), [Ps, Rs] = st(kt), Ts = (e) => {
  const { __scopeSelect: t, children: n, open: r, defaultOpen: o, onOpenChange: a, value: s, defaultValue: i, onValueChange: l, dir: u, name: d, autoComplete: f, disabled: m, required: v } = e, x = hn(t), [p, g] = Z(null), [b, h] = Z(null), [y, $] = Z(!1), S = Ma(u), [q = !1, N] = tr({
    prop: r,
    defaultProp: o,
    onChange: a
  }), [E, V] = tr({
    prop: s,
    defaultProp: i,
    onChange: l
  }), J = le(null), A = p ? !!p.closest("form") : !0, [W, I] = Z(/* @__PURE__ */ new Set()), M = Array.from(W).map(
    (D) => D.props.value
  ).join(";");
  return /* @__PURE__ */ P(qi, x, /* @__PURE__ */ P(Es, {
    required: v,
    scope: t,
    trigger: p,
    onTriggerChange: g,
    valueNode: b,
    onValueNodeChange: h,
    valueNodeHasChildren: y,
    onValueNodeHasChildrenChange: $,
    contentId: pn(),
    value: E,
    onValueChange: V,
    open: q,
    onOpenChange: N,
    dir: S,
    triggerPointerDownPosRef: J,
    disabled: m
  }, /* @__PURE__ */ P(Mt.Provider, {
    scope: t
  }, /* @__PURE__ */ P(Ps, {
    scope: e.__scopeSelect,
    onNativeOptionAdd: fe((D) => {
      I(
        (z) => new Set(z).add(D)
      );
    }, []),
    onNativeOptionRemove: fe((D) => {
      I((z) => {
        const ee = new Set(z);
        return ee.delete(D), ee;
      });
    }, [])
  }, n)), A ? /* @__PURE__ */ P(lo, {
    key: M,
    "aria-hidden": !0,
    required: v,
    tabIndex: -1,
    name: d,
    autoComplete: f,
    value: E,
    onChange: (D) => V(D.target.value),
    disabled: m
  }, E === void 0 ? /* @__PURE__ */ P("option", {
    value: ""
  }) : null, Array.from(W)) : null));
}, Os = "SelectTrigger", qs = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, disabled: r = !1, ...o } = e, a = hn(n), s = Ue(Os, n), i = s.disabled || r, l = de(t, s.onTriggerChange), u = jt(n), [d, f, m] = co((x) => {
    const p = u().filter(
      (h) => !h.disabled
    ), g = p.find(
      (h) => h.value === s.value
    ), b = uo(p, x, g);
    b !== void 0 && s.onValueChange(b.value);
  }), v = () => {
    i || (s.onOpenChange(!0), m());
  };
  return /* @__PURE__ */ P(Ni, K({
    asChild: !0
  }, a), /* @__PURE__ */ P(ce.button, K({
    type: "button",
    role: "combobox",
    "aria-controls": s.contentId,
    "aria-expanded": s.open,
    "aria-required": s.required,
    "aria-autocomplete": "none",
    dir: s.dir,
    "data-state": s.open ? "open" : "closed",
    disabled: i,
    "data-disabled": i ? "" : void 0,
    "data-placeholder": s.value === void 0 ? "" : void 0
  }, o, {
    ref: l,
    onClick: se(o.onClick, (x) => {
      x.currentTarget.focus();
    }),
    onPointerDown: se(o.onPointerDown, (x) => {
      const p = x.target;
      p.hasPointerCapture(x.pointerId) && p.releasePointerCapture(x.pointerId), x.button === 0 && x.ctrlKey === !1 && (v(), s.triggerPointerDownPosRef.current = {
        x: Math.round(x.pageX),
        y: Math.round(x.pageY)
      }, x.preventDefault());
    }),
    onKeyDown: se(o.onKeyDown, (x) => {
      const p = d.current !== "";
      !(x.ctrlKey || x.altKey || x.metaKey) && x.key.length === 1 && f(x.key), !(p && x.key === " ") && $s.includes(x.key) && (v(), x.preventDefault());
    })
  })));
}), Ns = "SelectValue", zs = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, className: r, style: o, children: a, placeholder: s, ...i } = e, l = Ue(Ns, n), { onValueNodeHasChildrenChange: u } = l, d = a !== void 0, f = de(t, l.onValueNodeChange);
  return Se(() => {
    u(d);
  }, [
    u,
    d
  ]), /* @__PURE__ */ P(ce.span, K({}, i, {
    ref: f,
    style: {
      pointerEvents: "none"
    }
  }), l.value === void 0 && s !== void 0 ? s : a);
}), As = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, children: r, ...o } = e;
  return /* @__PURE__ */ P(ce.span, K({
    "aria-hidden": !0
  }, o, {
    ref: t
  }), r || "▼");
}), Ds = (e) => /* @__PURE__ */ P(Ai, K({
  asChild: !0
}, e)), at = "SelectContent", Is = /* @__PURE__ */ F((e, t) => {
  const n = Ue(at, e.__scopeSelect), [r, o] = Z();
  if (Se(() => {
    o(new DocumentFragment());
  }, []), !n.open) {
    const a = r;
    return a ? /* @__PURE__ */ dr(/* @__PURE__ */ P(ao, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ P(Mt.Slot, {
      scope: e.__scopeSelect
    }, /* @__PURE__ */ P("div", null, e.children))), a) : null;
  }
  return /* @__PURE__ */ P(Ls, K({}, e, {
    ref: t
  }));
}), Ae = 10, [ao, Ke] = st(at), Ls = /* @__PURE__ */ F((e, t) => {
  const {
    __scopeSelect: n,
    position: r = "item-aligned",
    onCloseAutoFocus: o,
    onEscapeKeyDown: a,
    onPointerDownOutside: s,
    side: i,
    sideOffset: l,
    align: u,
    alignOffset: d,
    arrowPadding: f,
    collisionBoundary: m,
    collisionPadding: v,
    sticky: x,
    hideWhenDetached: p,
    avoidCollisions: g,
    //
    ...b
  } = e, h = Ue(at, n), [y, $] = Z(null), [S, q] = Z(null), N = de(
    t,
    (T) => $(T)
  ), [E, V] = Z(null), [J, A] = Z(null), W = jt(n), [I, M] = Z(!1), D = le(!1);
  re(() => {
    if (y)
      return Fi(y);
  }, [
    y
  ]), Ya();
  const z = fe((T) => {
    const [H, ...ie] = W().map(
      (X) => X.ref.current
    ), [Y] = ie.slice(-1), G = document.activeElement;
    for (const X of T)
      if (X === G || (X == null || X.scrollIntoView({
        block: "nearest"
      }), X === H && S && (S.scrollTop = 0), X === Y && S && (S.scrollTop = S.scrollHeight), X == null || X.focus(), document.activeElement !== G))
        return;
  }, [
    W,
    S
  ]), ee = fe(
    () => z([
      E,
      y
    ]),
    [
      z,
      E,
      y
    ]
  );
  re(() => {
    I && ee();
  }, [
    I,
    ee
  ]);
  const { onOpenChange: te, triggerPointerDownPosRef: pe } = h;
  re(() => {
    if (y) {
      let T = {
        x: 0,
        y: 0
      };
      const H = (Y) => {
        var G, X, ve, ue;
        T = {
          x: Math.abs(Math.round(Y.pageX) - ((G = (X = pe.current) === null || X === void 0 ? void 0 : X.x) !== null && G !== void 0 ? G : 0)),
          y: Math.abs(Math.round(Y.pageY) - ((ve = (ue = pe.current) === null || ue === void 0 ? void 0 : ue.y) !== null && ve !== void 0 ? ve : 0))
        };
      }, ie = (Y) => {
        T.x <= 10 && T.y <= 10 ? Y.preventDefault() : y.contains(Y.target) || te(!1), document.removeEventListener("pointermove", H), pe.current = null;
      };
      return pe.current !== null && (document.addEventListener("pointermove", H), document.addEventListener("pointerup", ie, {
        capture: !0,
        once: !0
      })), () => {
        document.removeEventListener("pointermove", H), document.removeEventListener("pointerup", ie, {
          capture: !0
        });
      };
    }
  }, [
    y,
    te,
    pe
  ]), re(() => {
    const T = () => te(!1);
    return window.addEventListener("blur", T), window.addEventListener("resize", T), () => {
      window.removeEventListener("blur", T), window.removeEventListener("resize", T);
    };
  }, [
    te
  ]);
  const [he, we] = co((T) => {
    const H = W().filter(
      (G) => !G.disabled
    ), ie = H.find(
      (G) => G.ref.current === document.activeElement
    ), Y = uo(H, T, ie);
    Y && setTimeout(
      () => Y.ref.current.focus()
    );
  }), Ee = fe((T, H, ie) => {
    const Y = !D.current && !ie;
    (h.value !== void 0 && h.value === H || Y) && (V(T), Y && (D.current = !0));
  }, [
    h.value
  ]), Te = fe(
    () => y == null ? void 0 : y.focus(),
    [
      y
    ]
  ), ge = fe((T, H, ie) => {
    const Y = !D.current && !ie;
    (h.value !== void 0 && h.value === H || Y) && A(T);
  }, [
    h.value
  ]), xe = r === "popper" ? ir : ks, _e = xe === ir ? {
    side: i,
    sideOffset: l,
    align: u,
    alignOffset: d,
    arrowPadding: f,
    collisionBoundary: m,
    collisionPadding: v,
    sticky: x,
    hideWhenDetached: p,
    avoidCollisions: g
  } : {};
  return /* @__PURE__ */ P(ao, {
    scope: n,
    content: y,
    viewport: S,
    onViewportChange: q,
    itemRefCallback: Ee,
    selectedItem: E,
    onItemLeave: Te,
    itemTextRefCallback: ge,
    focusSelectedItem: ee,
    selectedItemText: J,
    position: r,
    isPositioned: I,
    searchRef: he
  }, /* @__PURE__ */ P(_s, {
    as: mt,
    allowPinchZoom: !0
  }, /* @__PURE__ */ P(Ga, {
    asChild: !0,
    trapped: h.open,
    onMountAutoFocus: (T) => {
      T.preventDefault();
    },
    onUnmountAutoFocus: se(o, (T) => {
      var H;
      (H = h.trigger) === null || H === void 0 || H.focus({
        preventScroll: !0
      }), T.preventDefault();
    })
  }, /* @__PURE__ */ P(Xa, {
    asChild: !0,
    disableOutsidePointerEvents: !0,
    onEscapeKeyDown: a,
    onPointerDownOutside: s,
    onFocusOutside: (T) => T.preventDefault(),
    onDismiss: () => h.onOpenChange(!1)
  }, /* @__PURE__ */ P(xe, K({
    role: "listbox",
    id: h.contentId,
    "data-state": h.open ? "open" : "closed",
    dir: h.dir,
    onContextMenu: (T) => T.preventDefault()
  }, b, _e, {
    onPlaced: () => M(!0),
    ref: N,
    style: {
      // flex layout so we can place the scroll buttons properly
      display: "flex",
      flexDirection: "column",
      // reset the outline by default as the content MAY get focused
      outline: "none",
      ...b.style
    },
    onKeyDown: se(b.onKeyDown, (T) => {
      const H = T.ctrlKey || T.altKey || T.metaKey;
      if (T.key === "Tab" && T.preventDefault(), !H && T.key.length === 1 && we(T.key), [
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End"
      ].includes(T.key)) {
        let Y = W().filter(
          (G) => !G.disabled
        ).map(
          (G) => G.ref.current
        );
        if ([
          "ArrowUp",
          "End"
        ].includes(T.key) && (Y = Y.slice().reverse()), [
          "ArrowUp",
          "ArrowDown"
        ].includes(T.key)) {
          const G = T.target, X = Y.indexOf(G);
          Y = Y.slice(X + 1);
        }
        setTimeout(
          () => z(Y)
        ), T.preventDefault();
      }
    })
  }))))));
}), ks = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, onPlaced: r, ...o } = e, a = Ue(at, n), s = Ke(at, n), [i, l] = Z(null), [u, d] = Z(null), f = de(
    t,
    (N) => d(N)
  ), m = jt(n), v = le(!1), x = le(!0), { viewport: p, selectedItem: g, selectedItemText: b, focusSelectedItem: h } = s, y = fe(() => {
    if (a.trigger && a.valueNode && i && u && p && g && b) {
      const N = a.trigger.getBoundingClientRect(), E = u.getBoundingClientRect(), V = a.valueNode.getBoundingClientRect(), J = b.getBoundingClientRect();
      if (a.dir !== "rtl") {
        const G = J.left - E.left, X = V.left - G, ve = N.left - X, ue = N.width + ve, Oe = Math.max(ue, E.width), qe = window.innerWidth - Ae, Me = Dn(X, [
          Ae,
          qe - Oe
        ]);
        i.style.minWidth = ue + "px", i.style.left = Me + "px";
      } else {
        const G = E.right - J.right, X = window.innerWidth - V.right - G, ve = window.innerWidth - N.right - X, ue = N.width + ve, Oe = Math.max(ue, E.width), qe = window.innerWidth - Ae, Me = Dn(X, [
          Ae,
          qe - Oe
        ]);
        i.style.minWidth = ue + "px", i.style.right = Me + "px";
      }
      const A = m(), W = window.innerHeight - Ae * 2, I = p.scrollHeight, M = window.getComputedStyle(u), D = parseInt(M.borderTopWidth, 10), z = parseInt(M.paddingTop, 10), ee = parseInt(M.borderBottomWidth, 10), te = parseInt(M.paddingBottom, 10), pe = D + z + I + te + ee, he = Math.min(g.offsetHeight * 5, pe), we = window.getComputedStyle(p), Ee = parseInt(we.paddingTop, 10), Te = parseInt(we.paddingBottom, 10), ge = N.top + N.height / 2 - Ae, xe = W - ge, _e = g.offsetHeight / 2, T = g.offsetTop + _e, H = D + z + T, ie = pe - H;
      if (H <= ge) {
        const G = g === A[A.length - 1].ref.current;
        i.style.bottom = "0px";
        const X = u.clientHeight - p.offsetTop - p.offsetHeight, ve = Math.max(xe, _e + (G ? Te : 0) + X + ee), ue = H + ve;
        i.style.height = ue + "px";
      } else {
        const G = g === A[0].ref.current;
        i.style.top = "0px";
        const ve = Math.max(ge, D + p.offsetTop + (G ? Ee : 0) + _e) + ie;
        i.style.height = ve + "px", p.scrollTop = H - ge + p.offsetTop;
      }
      i.style.margin = `${Ae}px 0`, i.style.minHeight = he + "px", i.style.maxHeight = W + "px", r == null || r(), requestAnimationFrame(
        () => v.current = !0
      );
    }
  }, [
    m,
    a.trigger,
    a.valueNode,
    i,
    u,
    p,
    g,
    b,
    a.dir,
    r
  ]);
  Se(
    () => y(),
    [
      y
    ]
  );
  const [$, S] = Z();
  Se(() => {
    u && S(window.getComputedStyle(u).zIndex);
  }, [
    u
  ]);
  const q = fe((N) => {
    N && x.current === !0 && (y(), h == null || h(), x.current = !1);
  }, [
    y,
    h
  ]);
  return /* @__PURE__ */ P(Ms, {
    scope: n,
    contentWrapper: i,
    shouldExpandOnScrollRef: v,
    onScrollButtonChange: q
  }, /* @__PURE__ */ P("div", {
    ref: l,
    style: {
      display: "flex",
      flexDirection: "column",
      position: "fixed",
      zIndex: $
    }
  }, /* @__PURE__ */ P(ce.div, K({}, o, {
    ref: f,
    style: {
      // When we get the height of the content, it includes borders. If we were to set
      // the height without having `boxSizing: 'border-box'` it would be too big.
      boxSizing: "border-box",
      // We need to ensure the content doesn't get taller than the wrapper
      maxHeight: "100%",
      ...o.style
    }
  }))));
}), ir = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, align: r = "start", collisionPadding: o = Ae, ...a } = e, s = hn(n);
  return /* @__PURE__ */ P(zi, K({}, s, a, {
    ref: t,
    align: r,
    collisionPadding: o,
    style: {
      // Ensure border-box for floating-ui calculations
      boxSizing: "border-box",
      ...a.style,
      "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
      "--radix-select-content-available-width": "var(--radix-popper-available-width)",
      "--radix-select-content-available-height": "var(--radix-popper-available-height)",
      "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
      "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
    }
  }));
}), [Ms, gn] = st(at, {}), sr = "SelectViewport", js = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, ...r } = e, o = Ke(sr, n), a = gn(sr, n), s = de(t, o.onViewportChange), i = le(0);
  return /* @__PURE__ */ P(cn, null, /* @__PURE__ */ P("style", {
    dangerouslySetInnerHTML: {
      __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
    }
  }), /* @__PURE__ */ P(Mt.Slot, {
    scope: n
  }, /* @__PURE__ */ P(ce.div, K({
    "data-radix-select-viewport": "",
    role: "presentation"
  }, r, {
    ref: s,
    style: {
      // we use position: 'relative' here on the `viewport` so that when we call
      // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
      // (independent of the scrollUpButton).
      position: "relative",
      flex: 1,
      overflow: "auto",
      ...r.style
    },
    onScroll: se(r.onScroll, (l) => {
      const u = l.currentTarget, { contentWrapper: d, shouldExpandOnScrollRef: f } = a;
      if (f != null && f.current && d) {
        const m = Math.abs(i.current - u.scrollTop);
        if (m > 0) {
          const v = window.innerHeight - Ae * 2, x = parseFloat(d.style.minHeight), p = parseFloat(d.style.height), g = Math.max(x, p);
          if (g < v) {
            const b = g + m, h = Math.min(v, b), y = b - h;
            d.style.height = h + "px", d.style.bottom === "0px" && (u.scrollTop = y > 0 ? y : 0, d.style.justifyContent = "flex-end");
          }
        }
      }
      i.current = u.scrollTop;
    })
  }))));
}), Fs = "SelectGroup", [Vs, Hs] = st(Fs), Bs = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, ...r } = e, o = pn();
  return /* @__PURE__ */ P(Vs, {
    scope: n,
    id: o
  }, /* @__PURE__ */ P(ce.div, K({
    role: "group",
    "aria-labelledby": o
  }, r, {
    ref: t
  })));
}), Ws = "SelectLabel", Xs = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, ...r } = e, o = Hs(Ws, n);
  return /* @__PURE__ */ P(ce.div, K({
    id: o.id
  }, r, {
    ref: t
  }));
}), ln = "SelectItem", [Us, io] = st(ln), Ks = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, value: r, disabled: o = !1, textValue: a, ...s } = e, i = Ue(ln, n), l = Ke(ln, n), u = i.value === r, [d, f] = Z(a ?? ""), [m, v] = Z(!1), x = de(t, (b) => {
    var h;
    return (h = l.itemRefCallback) === null || h === void 0 ? void 0 : h.call(l, b, r, o);
  }), p = pn(), g = () => {
    o || (i.onValueChange(r), i.onOpenChange(!1));
  };
  return /* @__PURE__ */ P(Us, {
    scope: n,
    value: r,
    disabled: o,
    textId: p,
    isSelected: u,
    onItemTextChange: fe((b) => {
      f((h) => {
        var y;
        return h || ((y = b == null ? void 0 : b.textContent) !== null && y !== void 0 ? y : "").trim();
      });
    }, [])
  }, /* @__PURE__ */ P(Mt.ItemSlot, {
    scope: n,
    value: r,
    disabled: o,
    textValue: d
  }, /* @__PURE__ */ P(ce.div, K({
    role: "option",
    "aria-labelledby": p,
    "data-highlighted": m ? "" : void 0,
    "aria-selected": u && m,
    "data-state": u ? "checked" : "unchecked",
    "aria-disabled": o || void 0,
    "data-disabled": o ? "" : void 0,
    tabIndex: o ? void 0 : -1
  }, s, {
    ref: x,
    onFocus: se(
      s.onFocus,
      () => v(!0)
    ),
    onBlur: se(
      s.onBlur,
      () => v(!1)
    ),
    onPointerUp: se(s.onPointerUp, g),
    onPointerMove: se(s.onPointerMove, (b) => {
      if (o) {
        var h;
        (h = l.onItemLeave) === null || h === void 0 || h.call(l);
      } else
        b.currentTarget.focus({
          preventScroll: !0
        });
    }),
    onPointerLeave: se(s.onPointerLeave, (b) => {
      if (b.currentTarget === document.activeElement) {
        var h;
        (h = l.onItemLeave) === null || h === void 0 || h.call(l);
      }
    }),
    onKeyDown: se(s.onKeyDown, (b) => {
      var h;
      ((h = l.searchRef) === null || h === void 0 ? void 0 : h.current) !== "" && b.key === " " || (Cs.includes(b.key) && g(), b.key === " " && b.preventDefault());
    })
  }))));
}), $t = "SelectItemText", Ys = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, className: r, style: o, ...a } = e, s = Ue($t, n), i = Ke($t, n), l = io($t, n), u = Rs($t, n), [d, f] = Z(null), m = de(
    t,
    (b) => f(b),
    l.onItemTextChange,
    (b) => {
      var h;
      return (h = i.itemTextRefCallback) === null || h === void 0 ? void 0 : h.call(i, b, l.value, l.disabled);
    }
  ), v = d == null ? void 0 : d.textContent, x = rt(
    () => /* @__PURE__ */ P("option", {
      key: l.value,
      value: l.value,
      disabled: l.disabled
    }, v),
    [
      l.disabled,
      l.value,
      v
    ]
  ), { onNativeOptionAdd: p, onNativeOptionRemove: g } = u;
  return Se(() => (p(x), () => g(x)), [
    p,
    g,
    x
  ]), /* @__PURE__ */ P(cn, null, /* @__PURE__ */ P(ce.span, K({
    id: l.textId
  }, a, {
    ref: m
  })), l.isSelected && s.valueNode && !s.valueNodeHasChildren ? /* @__PURE__ */ dr(a.children, s.valueNode) : null);
}), Gs = "SelectItemIndicator", Zs = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, ...r } = e;
  return io(Gs, n).isSelected ? /* @__PURE__ */ P(ce.span, K({
    "aria-hidden": !0
  }, r, {
    ref: t
  })) : null;
}), lr = "SelectScrollUpButton", Js = /* @__PURE__ */ F((e, t) => {
  const n = Ke(lr, e.__scopeSelect), r = gn(lr, e.__scopeSelect), [o, a] = Z(!1), s = de(t, r.onScrollButtonChange);
  return Se(() => {
    if (n.viewport && n.isPositioned) {
      let l = function() {
        const u = i.scrollTop > 0;
        a(u);
      };
      const i = n.viewport;
      return l(), i.addEventListener("scroll", l), () => i.removeEventListener("scroll", l);
    }
  }, [
    n.viewport,
    n.isPositioned
  ]), o ? /* @__PURE__ */ P(so, K({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: i, selectedItem: l } = n;
      i && l && (i.scrollTop = i.scrollTop - l.offsetHeight);
    }
  })) : null;
}), cr = "SelectScrollDownButton", Qs = /* @__PURE__ */ F((e, t) => {
  const n = Ke(cr, e.__scopeSelect), r = gn(cr, e.__scopeSelect), [o, a] = Z(!1), s = de(t, r.onScrollButtonChange);
  return Se(() => {
    if (n.viewport && n.isPositioned) {
      let l = function() {
        const u = i.scrollHeight - i.clientHeight, d = Math.ceil(i.scrollTop) < u;
        a(d);
      };
      const i = n.viewport;
      return l(), i.addEventListener("scroll", l), () => i.removeEventListener("scroll", l);
    }
  }, [
    n.viewport,
    n.isPositioned
  ]), o ? /* @__PURE__ */ P(so, K({}, e, {
    ref: s,
    onAutoScroll: () => {
      const { viewport: i, selectedItem: l } = n;
      i && l && (i.scrollTop = i.scrollTop + l.offsetHeight);
    }
  })) : null;
}), so = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, onAutoScroll: r, ...o } = e, a = Ke("SelectScrollButton", n), s = le(null), i = jt(n), l = fe(() => {
    s.current !== null && (window.clearInterval(s.current), s.current = null);
  }, []);
  return re(() => () => l(), [
    l
  ]), Se(() => {
    var u;
    const d = i().find(
      (f) => f.ref.current === document.activeElement
    );
    d == null || (u = d.ref.current) === null || u === void 0 || u.scrollIntoView({
      block: "nearest"
    });
  }, [
    i
  ]), /* @__PURE__ */ P(ce.div, K({
    "aria-hidden": !0
  }, o, {
    ref: t,
    style: {
      flexShrink: 0,
      ...o.style
    },
    onPointerDown: se(o.onPointerDown, () => {
      s.current === null && (s.current = window.setInterval(r, 50));
    }),
    onPointerMove: se(o.onPointerMove, () => {
      var u;
      (u = a.onItemLeave) === null || u === void 0 || u.call(a), s.current === null && (s.current = window.setInterval(r, 50));
    }),
    onPointerLeave: se(o.onPointerLeave, () => {
      l();
    })
  }));
}), el = /* @__PURE__ */ F((e, t) => {
  const { __scopeSelect: n, ...r } = e;
  return /* @__PURE__ */ P(ce.div, K({
    "aria-hidden": !0
  }, r, {
    ref: t
  }));
}), lo = /* @__PURE__ */ F((e, t) => {
  const { value: n, ...r } = e, o = le(null), a = de(t, o), s = Ii(n);
  return re(() => {
    const i = o.current, l = window.HTMLSelectElement.prototype, d = Object.getOwnPropertyDescriptor(l, "value").set;
    if (s !== n && d) {
      const f = new Event("change", {
        bubbles: !0
      });
      d.call(i, n), i.dispatchEvent(f);
    }
  }, [
    s,
    n
  ]), /* @__PURE__ */ P(Li, {
    asChild: !0
  }, /* @__PURE__ */ P("select", K({}, r, {
    ref: a,
    defaultValue: n
  })));
});
lo.displayName = "BubbleSelect";
function co(e) {
  const t = Ie(e), n = le(""), r = le(0), o = fe((s) => {
    const i = n.current + s;
    t(i), function l(u) {
      n.current = u, window.clearTimeout(r.current), u !== "" && (r.current = window.setTimeout(
        () => l(""),
        1e3
      ));
    }(i);
  }, [
    t
  ]), a = fe(() => {
    n.current = "", window.clearTimeout(r.current);
  }, []);
  return re(() => () => window.clearTimeout(r.current), []), [
    n,
    o,
    a
  ];
}
function uo(e, t, n) {
  const o = t.length > 1 && Array.from(t).every(
    (u) => u === t[0]
  ) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let s = tl(e, Math.max(a, 0));
  o.length === 1 && (s = s.filter(
    (u) => u !== n
  ));
  const l = s.find(
    (u) => u.textValue.toLowerCase().startsWith(o.toLowerCase())
  );
  return l !== n ? l : void 0;
}
function tl(e, t) {
  return e.map(
    (n, r) => e[(t + r) % e.length]
  );
}
const nl = Ts, rl = qs, ol = zs, al = As, il = Ds, sl = Is, fo = js, ll = Bs, cl = Xs, ul = Ks, fl = Ys, dl = Zs, po = Js, vo = Qs, pl = el;
var vl = "ibaddl9", ml = "ibaddla", hl = "ibaddl2", gl = "ibaddl8", xl = "ibaddl7", bl = "ibaddl3", yl = "ibaddl4", wl = "ibaddl5", _l = "ibaddl0", $l = "ibaddl6", Cl = "ibaddl1", Sl = El, Qt = { base: "_1oxbat10", light: "_1oxbat15b", dark: "_1oxbat15c" }, El = { media: { small: "var(--_1oxbat11)", medium: "var(--_1oxbat12)", large: "var(--_1oxbat13)", xlarge: "var(--_1oxbat14)", queries: { XS: "var(--_1oxbat15)", SM: "var(--_1oxbat16)", MD: "var(--_1oxbat17)", LG: "var(--_1oxbat18)", XL: "var(--_1oxbat19)", LIGHT: "var(--_1oxbat1a)", DARK: "var(--_1oxbat1b)" } }, font: { family: { system: "var(--_1oxbat1c)", sf: "var(--_1oxbat1d)", aspekta: "var(--_1oxbat1e)", mono: "var(--_1oxbat1f)" }, heading: { H1: "var(--_1oxbat1g)", H2: "var(--_1oxbat1h)", H3: "var(--_1oxbat1i)", H4: "var(--_1oxbat1j)", H5: "var(--_1oxbat1k)", H6: "var(--_1oxbat1l)" }, size: { MINI: "var(--_1oxbat1m)", XS: "var(--_1oxbat1n)", SM: "var(--_1oxbat1o)", MD: "var(--_1oxbat1p)", LG: "var(--_1oxbat1q)", XL: "var(--_1oxbat1r)", XXL: "var(--_1oxbat1s)", "3XL": "var(--_1oxbat1t)", "4XL": "var(--_1oxbat1u)", "5XL": "var(--_1oxbat1v)", "6XL": "var(--_1oxbat1w)", "7XL": "var(--_1oxbat1x)", "8XL": "var(--_1oxbat1y)", "9XL": "var(--_1oxbat1z)" }, lineheight: { MINI: "var(--_1oxbat110)", XS: "var(--_1oxbat111)", SM: "var(--_1oxbat112)", MD: "var(--_1oxbat113)", LG: "var(--_1oxbat114)", XL: "var(--_1oxbat115)", XXL: "var(--_1oxbat116)", "3XL": "var(--_1oxbat117)", "4XL": "var(--_1oxbat118)", "5XL": "var(--_1oxbat119)", "6XL": "var(--_1oxbat11a)", "7XL": "var(--_1oxbat11b)", "8XL": "var(--_1oxbat11c)", "9XL": "var(--_1oxbat11d)" }, weight: { SUPRLITE: "var(--_1oxbat11e)", ULTRALITE: "var(--_1oxbat11f)", LITE: "var(--_1oxbat11g)", REGULAR: "var(--_1oxbat11h)", MEDIUM: "var(--_1oxbat11i)", SEMIBOLD: "var(--_1oxbat11j)", BOLD: "var(--_1oxbat11k)", HEAVY: "var(--_1oxbat11l)", BLACK: "var(--_1oxbat11m)" } }, radii: { ZERO: "var(--_1oxbat11n)", NO: "var(--_1oxbat11o)", DF: "var(--_1oxbat11p)", XS: "var(--_1oxbat11q)", SM: "var(--_1oxbat11r)", MD: "var(--_1oxbat11s)", LG: "var(--_1oxbat11t)", XL: "var(--_1oxbat11u)", XXL: "var(--_1oxbat11v)", PILL: "var(--_1oxbat11w)" }, space: { ZERO: "var(--_1oxbat11x)", NO: "var(--_1oxbat11y)", DF: "var(--_1oxbat11z)", APX: "var(--_1oxbat120)", BPX: "var(--_1oxbat121)", CPX: "var(--_1oxbat122)", DPX: "var(--_1oxbat123)", EPX: "var(--_1oxbat124)", FPX: "var(--_1oxbat125)", GPX: "var(--_1oxbat126)", HPX: "var(--_1oxbat127)", IPX: "var(--_1oxbat128)", JPX: "var(--_1oxbat129)", KPX: "var(--_1oxbat12a)", LPX: "var(--_1oxbat12b)", MPX: "var(--_1oxbat12c)", NPX: "var(--_1oxbat12d)", OPX: "var(--_1oxbat12e)", PPX: "var(--_1oxbat12f)", QPX: "var(--_1oxbat12g)", RPX: "var(--_1oxbat12h)", SPX: "var(--_1oxbat12i)", TPX: "var(--_1oxbat12j)", UPX: "var(--_1oxbat12k)", VPX: "var(--_1oxbat12l)", WPX: "var(--_1oxbat12m)", XPX: "var(--_1oxbat12n)", YPX: "var(--_1oxbat12o)", ZPX: "var(--_1oxbat12p)" }, z: { indice: { ZERO: "var(--_1oxbat12q)", DF: "var(--_1oxbat12r)", LOW: "var(--_1oxbat12s)", MED: "var(--_1oxbat12t)", HIGH: "var(--_1oxbat12u)", TOP: "var(--_1oxbat12v)", MAX: "var(--_1oxbat12w)" } }, shadow: { NO: "var(--_1oxbat12x)", DF: "var(--_1oxbat12y)", LOW: "var(--_1oxbat12z)", MED: "var(--_1oxbat130)", HIGH: "var(--_1oxbat131)" }, color: { transparent: "var(--_1oxbat132)", current: "var(--_1oxbat133)", white: "var(--_1oxbat134)", black: "var(--_1oxbat135)", gray100: "var(--_1oxbat136)", gray200: "var(--_1oxbat137)", gray300: "var(--_1oxbat138)", pale100: "var(--_1oxbat139)", pale200: "var(--_1oxbat13a)", pale300: "var(--_1oxbat13b)", pale400: "var(--_1oxbat13c)", pale500: "var(--_1oxbat13d)", hyper0: "var(--_1oxbat13e)", hyper1: "var(--_1oxbat13f)", hyper2: "var(--_1oxbat13g)", hyper3: "var(--_1oxbat13h)", hyper4: "var(--_1oxbat13i)", hyper5: "var(--_1oxbat13j)", hyper6: "var(--_1oxbat13k)", hyper7: "var(--_1oxbat13l)", hyper8: "var(--_1oxbat13m)", hyper9: "var(--_1oxbat13n)", hyper10: "var(--_1oxbat13o)", hyper11: "var(--_1oxbat13p)", hyper12: "var(--_1oxbat13q)", hyper13: "var(--_1oxbat13r)", lemon0: "var(--_1oxbat13s)", lemon1: "var(--_1oxbat13t)", lemon2: "var(--_1oxbat13u)", lemon3: "var(--_1oxbat13v)", lemon4: "var(--_1oxbat13w)", lemon5: "var(--_1oxbat13x)", lemon6: "var(--_1oxbat13y)", lemon7: "var(--_1oxbat13z)", lemon8: "var(--_1oxbat140)", lemon9: "var(--_1oxbat141)", lemon10: "var(--_1oxbat142)", lemon11: "var(--_1oxbat143)", lemon12: "var(--_1oxbat144)", lemon13: "var(--_1oxbat145)", slate1: "var(--_1oxbat146)", slate2: "var(--_1oxbat147)", slate3: "var(--_1oxbat148)", slate4: "var(--_1oxbat149)", slate5: "var(--_1oxbat14a)", slate6: "var(--_1oxbat14b)", slate7: "var(--_1oxbat14c)", slate8: "var(--_1oxbat14d)", slate9: "var(--_1oxbat14e)", slate10: "var(--_1oxbat14f)", slate11: "var(--_1oxbat14g)", slate12: "var(--_1oxbat14h)", slate13: "var(--_1oxbat14i)", sapphire0: "var(--_1oxbat14j)", sapphire1: "var(--_1oxbat14k)", sapphire2: "var(--_1oxbat14l)", sapphire3: "var(--_1oxbat14m)", sapphire4: "var(--_1oxbat14n)", sapphire5: "var(--_1oxbat14o)", sapphire6: "var(--_1oxbat14p)", sapphire7: "var(--_1oxbat14q)", sapphire8: "var(--_1oxbat14r)", sapphire9: "var(--_1oxbat14s)", sapphire10: "var(--_1oxbat14t)", sapphire11: "var(--_1oxbat14u)", sapphire12: "var(--_1oxbat14v)", sapphire13: "var(--_1oxbat14w)", volt0: "var(--_1oxbat14x)", volt1: "var(--_1oxbat14y)", volt2: "var(--_1oxbat14z)", volt3: "var(--_1oxbat150)", volt4: "var(--_1oxbat151)", volt5: "var(--_1oxbat152)", volt6: "var(--_1oxbat153)", volt7: "var(--_1oxbat154)", volt8: "var(--_1oxbat155)", volt9: "var(--_1oxbat156)", volt10: "var(--_1oxbat157)", volt11: "var(--_1oxbat158)", volt12: "var(--_1oxbat159)", volt13: "var(--_1oxbat15a)" } };
const Pl = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M12.0916 14.9959C12.2854 14.9802 12.4708 14.902 12.6225 14.7846L16.6417 11.583C16.8439 11.4343 16.9703 11.2151 16.9956 10.9725C17.0209 10.7298 16.9366 10.495 16.7681 10.3149C16.5996 10.1349 16.3552 10.0175 16.1024 10.0096C15.8412 9.99399 15.5884 10.0801 15.3946 10.2366L11.9989 12.945L8.60325 10.2366C8.40945 10.0723 8.15667 9.98616 7.90388 10.0018C7.64268 10.0175 7.39832 10.1271 7.2298 10.3149C7.06128 10.495 6.98545 10.7376 7.0023 10.9725C7.02758 11.2151 7.15397 11.4343 7.35619 11.583L11.3754 14.7846C11.5692 14.9411 11.8304 15.0194 12.0832 14.9959H12.0916Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
), ac = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, {}), Rl = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M15.3529 1L8.64709 1C8.08172 1 7.78927 1.71527 8.17595 2.15231L11.2933 5.67559C11.676 6.10814 12.324 6.10814 12.7067 5.67559L15.8241 2.15231C16.2107 1.71527 15.9183 1 15.3529 1Z",
        fill: e,
        fillRule: "evenodd",
        clipRule: "evenodd"
      }
    )
  }
) }), Tl = ({ color: e = "currentColor", ...t }) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsx(
  "svg",
  {
    width: "24",
    height: "7",
    viewBox: "0 0 24 7",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...t,
    children: /* @__PURE__ */ _.jsx(
      "path",
      {
        d: "M8.64709 6H15.3529C15.9183 6 16.2107 5.28473 15.8241 4.84769L12.7067 1.32441C12.324 0.891862 11.676 0.891862 11.2933 1.32441L8.17595 4.84769C7.78927 5.28473 8.08172 6 8.64709 6Z",
        fill: e,
        "fill-rule": "evenodd",
        "clip-rule": "evenodd"
      }
    )
  }
) }), Ct = {
  background: "#9E9CA6",
  inner: "#F6F4F0"
}, ic = ({
  color: e = Ct.background,
  width: t,
  height: n,
  ...r
}) => /* @__PURE__ */ _.jsx(_.Fragment, { children: /* @__PURE__ */ _.jsxs(
  "svg",
  {
    width: t || "18",
    height: n || "18",
    viewBox: "0 0 18 18",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    ...r,
    children: [
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M6.9 16H11.1C14.6 16 16 14.6 16 11.1V6.9C16 3.4 14.6 2 11.1 2H6.9C3.4 2 2 3.4 2 6.9V11.1C2 14.6 3.4 16 6.9 16Z",
          fill: e,
          stroke: e,
          strokeWidth: "1.4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M7.14 6.49999L4 11.5H6.68L7.15 10.7H10.8L11.26 11.5H14L10.86 6.49999H7.14ZM7.82 9.53999L8.98 7.55999L10.12 9.53999H7.82Z",
          fill: Ct.inner
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M12.35 8.14999C12.44 8.23999 12.54 8.30999 12.66 8.35999C12.78 8.40999 12.9 8.42999 13.04 8.42999C13.18 8.42999 13.3 8.40999 13.42 8.35999C13.54 8.30999 13.64 8.23999 13.73 8.14999C13.82 8.05999 13.89 7.95999 13.94 7.83999C13.99 7.71999 14.01 7.59999 14.01 7.45999C14.01 7.31999 13.99 7.19999 13.94 7.07999C13.89 6.95999 13.82 6.85999 13.73 6.76999C13.64 6.67999 13.54 6.60999 13.42 6.55999C13.3 6.50999 13.18 6.48999 13.04 6.48999C12.9 6.48999 12.78 6.50999 12.66 6.55999C12.54 6.60999 12.44 6.67999 12.35 6.76999C12.26 6.85999 12.19 6.95999 12.14 7.07999C12.09 7.19999 12.07 7.31999 12.07 7.45999C12.07 7.59999 12.09 7.71999 12.14 7.83999C12.19 7.95999 12.26 8.05999 12.35 8.14999ZM12.4 7.09999C12.47 6.98999 12.55 6.89999 12.66 6.83999C12.77 6.76999 12.89 6.73999 13.03 6.73999C13.17 6.73999 13.29 6.76999 13.39 6.83999C13.5 6.89999 13.59 6.98999 13.65 7.09999C13.72 7.20999 13.75 7.32999 13.75 7.46999C13.75 7.60999 13.72 7.72999 13.65 7.82999C13.59 7.93999 13.5 8.02999 13.39 8.08999C13.28 8.15999 13.16 8.18999 13.03 8.18999C12.9 8.18999 12.77 8.15999 12.66 8.08999C12.55 8.01999 12.46 7.93999 12.4 7.82999C12.33 7.71999 12.3 7.59999 12.3 7.46999C12.3 7.33999 12.33 7.20999 12.4 7.09999Z",
          fill: Ct.inner
        }
      ),
      /* @__PURE__ */ _.jsx(
        "path",
        {
          d: "M12.9 7.59999H13.08L13.23 7.89999H13.46L13.28 7.54999C13.28 7.54999 13.35 7.49999 13.38 7.45999C13.41 7.40999 13.43 7.35999 13.43 7.29999C13.43 7.23999 13.42 7.17999 13.39 7.13999C13.36 7.09999 13.32 7.05999 13.28 7.03999C13.24 7.01999 13.19 7.00999 13.15 7.00999H12.71V7.89999H12.92V7.59999H12.9ZM13.07 7.15999C13.07 7.15999 13.12 7.15999 13.15 7.18999C13.18 7.20999 13.19 7.23999 13.19 7.29999C13.19 7.35999 13.18 7.38999 13.15 7.40999C13.12 7.42999 13.09 7.44999 13.06 7.44999H12.89V7.16999H13.06L13.07 7.15999Z",
          fill: Ct.inner
        }
      )
    ]
  }
) });
var Ol = "ltqw8z0", ql = { article: "ltqw8z1", aside: "ltqw8z1", details: "ltqw8z1", figcaption: "ltqw8z1", figure: "ltqw8z1", footer: "ltqw8z1", header: "ltqw8z1", hgroup: "ltqw8z1", menu: "ltqw8z1", nav: "ltqw8z1", section: "ltqw8z1", ul: "ltqw8z3", ol: "ltqw8z3", blockquote: "ltqw8z4", q: "ltqw8z4", body: "ltqw8z2", a: "ltqw8zf", table: "ltqw8z5", mark: "ltqw8z9 ltqw8z7", select: "ltqw8z1 ltqw8z6 ltqw8z7 ltqw8za", button: "ltqw8z7", textarea: "ltqw8z1 ltqw8z6 ltqw8z7", input: "ltqw8z1 ltqw8z6 ltqw8z7 ltqw8zc" };
const sc = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  base: Ol,
  element: ql
}, Symbol.toStringTag, { value: "Module" })), mo = vt({
  theme: "light",
  toggleTheme: null
}), lc = () => {
  const e = At(mo);
  if (!e)
    throw new Error("Atelier® Kit components must be used within [KitProvider]");
  return e;
}, cc = ({
  children: e
}) => {
  const [t, n] = Z("light"), r = () => {
    n((a) => a === "light" ? "dark" : "light");
  }, o = t === "light" ? Qt.dark : Qt.light;
  return /* @__PURE__ */ _.jsx(mo.Provider, { value: { theme: t, toggleTheme: r }, children: /* @__PURE__ */ _.jsx("div", { className: `${Qt.base} ${o}`, children: e }) });
}, Nl = ({
  children: e,
  className: t,
  open: n,
  defaultOpen: r,
  disabled: o,
  required: a,
  defaultValue: s,
  value: i,
  onValueChange: l,
  ...u
}) => /* @__PURE__ */ _.jsx(
  nl,
  {
    ...u,
    open: n,
    defaultOpen: r,
    disabled: o,
    required: a,
    defaultValue: s,
    value: i,
    onValueChange: l,
    children: /* @__PURE__ */ _.jsx(
      "div",
      {
        ...u,
        className: k(_l, t),
        children: e
      }
    )
  }
), zl = B.forwardRef(({ children: e, placeholder: t, ...n }, r) => /* @__PURE__ */ _.jsx(
  ol,
  {
    ...n,
    ref: r,
    placeholder: t,
    children: e
  }
)), Al = B.forwardRef(
  ({ className: e, asChild: t, ...n }, r) => /* @__PURE__ */ _.jsx(
    al,
    {
      ...n,
      ref: r,
      asChild: t,
      className: k(xl, e),
      children: /* @__PURE__ */ _.jsx(Pl, { color: Sl.color.slate5 })
    }
  )
), Dl = ({
  children: e,
  asChild: t,
  className: n,
  ...r
}) => /* @__PURE__ */ _.jsx(
  rl,
  {
    ...r,
    asChild: t,
    className: k(n, Cl),
    children: e
  }
), Il = ({
  children: e,
  className: t,
  position: n = "popper",
  side: r = "bottom",
  sideOffset: o,
  align: a,
  alignOffset: s = 0,
  avoidCollisions: i = !0,
  sticky: l = "partial",
  hideWhenDetached: u = !1,
  ...d
}) => /* @__PURE__ */ _.jsxs(
  sl,
  {
    ...d,
    className: k(hl, t),
    position: n,
    side: r,
    sideOffset: o,
    align: a,
    alignOffset: s,
    avoidCollisions: i,
    sticky: l,
    hideWhenDetached: u,
    children: [
      /* @__PURE__ */ _.jsx(po, { className: k(ml, t), children: /* @__PURE__ */ _.jsx(Tl, {}) }),
      /* @__PURE__ */ _.jsx(fo, { children: e }),
      /* @__PURE__ */ _.jsx(vo, { className: k(vl, t), children: /* @__PURE__ */ _.jsx(Rl, {}) })
    ]
  }
), Ll = B.forwardRef(({ children: e, className: t, ...n }, r) => /* @__PURE__ */ _.jsxs(
  ul,
  {
    ...n,
    ref: r,
    className: k(bl, t),
    children: [
      /* @__PURE__ */ _.jsx(fl, { children: e }),
      /* @__PURE__ */ _.jsx(ho, {})
    ]
  }
)), ho = ({ className: e, ...t }) => /* @__PURE__ */ _.jsx(
  dl,
  {
    ...t,
    className: k(yl, e)
  }
), kl = ({ className: e, ...t }) => /* @__PURE__ */ _.jsx(
  pl,
  {
    ...t,
    className: k($l, e)
  }
), Ml = ({ children: e, className: t, ...n }) => /* @__PURE__ */ _.jsx(
  cl,
  {
    ...n,
    className: k(wl, t),
    children: e
  }
), jl = ({ children: e, className: t, ...n }) => /* @__PURE__ */ _.jsx(
  ll,
  {
    ...n,
    className: k(gl, t),
    children: e
  }
), ae = (e) => /* @__PURE__ */ _.jsx(Nl, { ...e });
ae.Trigger = Dl;
ae.Value = zl;
ae.Content = Il;
ae.Item = Ll;
ae.Viewport = fo;
ae.Portal = il;
ae.Icon = Al;
ae.Indicator = ho;
ae.Separator = kl;
ae.Label = Ml;
ae.Group = jl;
ae.ScrollUpButton = po;
ae.ScrollDownButton = vo;
ae.displayName = "Select";
ae.Value.displayName = "Select.Value";
ae.Item.displayName = "Select.Item";
ae.Viewport.displayName = "Select.Viewport";
ae.Portal.displayName = "Select.Portal";
ae.ScrollUpButton.displayName = "Select.ScrollUpButton";
ae.ScrollDownButton.displayName = "Select.ScrollDownButton";
var Fl = ye({ defaultClassName: "_1yr5zenb", variantClassNames: { size: { xs: "_1yr5zen0", sm: "_1yr5zen1", md: "_1yr5zen2", lg: "_1yr5zen3", xl: "_1yr5zen4", xxl: "_1yr5zen5", "3xl": "_1yr5zen6", "4xl": "_1yr5zen7", "5xl": "_1yr5zen8", "6xl": "_1yr5zen9", "7xl": "_1yr5zena" } }, defaultVariants: { size: "sm" }, compoundVariants: [] });
const Vl = F(
  ({ size: e = "sm", className: t, ...n }, r) => {
    const o = Fl({ size: e });
    return /* @__PURE__ */ _.jsx(
      "div",
      {
        ...n,
        ref: r,
        className: t ? `${t} ${o}` : o
      }
    );
  }
);
Vl.displayName = "Space";
var Hl = "_17w677g0", Bl = ye({ defaultClassName: "_17w677g7", variantClassNames: { size: { small: "_17w677g1", medium: "_17w677g2", large: "_17w677g3" }, variant: { default: "_17w677g4", hyper: "_17w677g5", volt: "_17w677g6" } }, defaultVariants: { size: "small", variant: "default" }, compoundVariants: [] });
const Wl = ({
  className: e,
  asChild: t,
  defaultChecked: n,
  checked: r,
  onCheckedChange: o,
  disabled: a,
  required: s,
  name: i,
  value: l,
  ...u
}) => /* @__PURE__ */ _.jsx(
  Ho,
  {
    ...u,
    className: k(e, Hl),
    defaultChecked: n,
    checked: r,
    onCheckedChange: o,
    disabled: a,
    required: s,
    name: i,
    value: l
  }
), go = F(
  (e, t) => {
    const {
      className: n,
      size: r = "small",
      variant: o = "default",
      asChild: a = !1,
      ...s
    } = e;
    return /* @__PURE__ */ _.jsx(
      Vo,
      {
        ...s,
        ref: t,
        asChild: a,
        className: k(n, Bl({ size: r, variant: o }))
      }
    );
  }
), xn = (e) => /* @__PURE__ */ _.jsx(Wl, { ...e });
xn.Toggle = go;
xn.displayName = "Switch";
xn.Toggle.displayName = "Switch.Toggle";
go.displayName = "Switch.Toggle";
var Xl = ye({ defaultClassName: "fpsfqv30", variantClassNames: { font: { system: "fpsfqv0", inter: "fpsfqv1", mono: "fpsfqv2" }, size: { xs: "fpsfqv3", sm: "fpsfqv4", md: "fpsfqv5", lg: "fpsfqv6", xl: "fpsfqv7", xxl: "fpsfqv8", "3xl": "fpsfqv9", "4xl": "fpsfqva", "5xl": "fpsfqvb", "6xl": "fpsfqvc", "7xl": "fpsfqvd", "8xl": "fpsfqve", "9xl": "fpsfqvf" }, weight: { superlite: "fpsfqvg", lite: "fpsfqvh", normal: "fpsfqvi", medium: "fpsfqvj", semibold: "fpsfqvk", bold: "fpsfqvl", heavy: "fpsfqvm", black: "fpsfqvn" }, color: { transparent: "fpsfqvo", current: "fpsfqvp", white: "fpsfqvq", black: "fpsfqvr", gray100: "fpsfqvs", gray200: "fpsfqvt", gray300: "fpsfqvu", pale100: "fpsfqvv", pale200: "fpsfqvw", pale300: "fpsfqvx", pale400: "fpsfqvy", pale500: "fpsfqvz", hyper0: "fpsfqv10", hyper1: "fpsfqv11", hyper2: "fpsfqv12", hyper3: "fpsfqv13", hyper4: "fpsfqv14", hyper5: "fpsfqv15", hyper6: "fpsfqv16", hyper7: "fpsfqv17", hyper8: "fpsfqv18", hyper9: "fpsfqv19", hyper10: "fpsfqv1a", hyper11: "fpsfqv1b", hyper12: "fpsfqv1c", hyper13: "fpsfqv1d", lemon0: "fpsfqv1e", lemon1: "fpsfqv1f", lemon2: "fpsfqv1g", lemon3: "fpsfqv1h", lemon4: "fpsfqv1i", lemon5: "fpsfqv1j", lemon6: "fpsfqv1k", lemon7: "fpsfqv1l", lemon8: "fpsfqv1m", lemon9: "fpsfqv1n", lemon10: "fpsfqv1o", lemon11: "fpsfqv1p", lemon12: "fpsfqv1q", lemon13: "fpsfqv1r", slate1: "fpsfqv1s", slate2: "fpsfqv1t", slate3: "fpsfqv1u", slate4: "fpsfqv1v", slate5: "fpsfqv1w", slate6: "fpsfqv1x", slate7: "fpsfqv1y", slate8: "fpsfqv1z", slate9: "fpsfqv20", slate10: "fpsfqv21", slate11: "fpsfqv22", slate12: "fpsfqv23", slate13: "fpsfqv24", sapphire0: "fpsfqv25", sapphire1: "fpsfqv26", sapphire2: "fpsfqv27", sapphire3: "fpsfqv28", sapphire4: "fpsfqv29", sapphire5: "fpsfqv2a", sapphire6: "fpsfqv2b", sapphire7: "fpsfqv2c", sapphire8: "fpsfqv2d", sapphire9: "fpsfqv2e", sapphire10: "fpsfqv2f", sapphire11: "fpsfqv2g", sapphire12: "fpsfqv2h", sapphire13: "fpsfqv2i", volt0: "fpsfqv2j", volt1: "fpsfqv2k", volt2: "fpsfqv2l", volt3: "fpsfqv2m", volt4: "fpsfqv2n", volt5: "fpsfqv2o", volt6: "fpsfqv2p", volt7: "fpsfqv2q", volt8: "fpsfqv2r", volt9: "fpsfqv2s", volt10: "fpsfqv2t", volt11: "fpsfqv2u", volt12: "fpsfqv2v", volt13: "fpsfqv2w" }, align: { left: "fpsfqv2x", center: "fpsfqv2y", right: "fpsfqv2z" } }, defaultVariants: { font: "system", size: "md", weight: "medium", color: "slate5", align: "left" }, compoundVariants: [] });
const Ul = B.forwardRef(
  ({
    children: e,
    className: t,
    font: n = "inter",
    size: r = "md",
    align: o = "left",
    color: a = "slate5",
    weight: s = "medium",
    ...i
  }, l) => /* @__PURE__ */ _.jsx(
    "p",
    {
      ref: l,
      className: k(t, Xl({ font: n, size: r, align: o, color: a, weight: s })),
      ...i,
      children: e
    }
  )
);
Ul.displayName = "Text";
var Kl = "fgg2xl1", Yl = "fgg2xl0";
const Gl = 500, Zl = 300, Jl = !1, Ql = ({ children: e, ...t }) => /* @__PURE__ */ _.jsx(
  Tt.Provider,
  {
    delayDuration: Gl,
    skipDelayDuration: Zl,
    disableHoverableContent: Jl,
    children: /* @__PURE__ */ _.jsx(Tt.Root, { ...t, children: e })
  }
), xo = B.forwardRef(
  ({
    children: e,
    className: t,
    onEscapeKeyDown: n,
    onPointerDownOutside: r,
    forceMount: o,
    side: a = "right",
    sideOffset: s = 10,
    align: i = "center",
    alignOffset: l = 0,
    avoidCollisions: u = !0,
    sticky: d = "always",
    hideWhenDetached: f = !1,
    //..
    ...m
  }, v) => /* @__PURE__ */ _.jsx(
    Tt.Content,
    {
      ...m,
      ref: v,
      "aria-label": "atelier-tip",
      side: a,
      sideOffset: s,
      align: i,
      alignOffset: l,
      avoidCollisions: u,
      sticky: d,
      hideWhenDetached: f,
      className: k(t, Kl),
      children: e
    }
  )
), bo = B.forwardRef(
  ({ children: e, ...t }, n) => /* @__PURE__ */ _.jsx(
    Tt.Trigger,
    {
      ...t,
      ref: n,
      className: Yl,
      children: e
    }
  )
), bn = (e) => /* @__PURE__ */ _.jsx(Ql, { ...e });
bn.Trigger = bo;
bn.Content = xo;
bn.displayName = "Tip";
bo.displayName = "TipTrigger";
xo.displayName = "TipContent";
export {
  Pl as ArrowDownIcon,
  ac as ArrowUpIcon,
  We as Avi,
  na as Button,
  aa as Canvas,
  ia as CanvasBlur,
  la as Chip,
  ua as Container,
  da as Flex,
  va as Heading,
  fn as Input,
  mo as KitContext,
  cc as KitProvider,
  ic as LogoIcon,
  ke as Menubar,
  Pa as Paragraph,
  Ta as PassLink,
  qa as Section,
  ae as Select,
  Rl as SmallArrowDownIcon,
  Tl as SmallArrowUpIcon,
  Vl as Space,
  xn as Switch,
  Ul as Text,
  bn as Tip,
  Ol as base,
  ql as element,
  Sl as kit,
  sc as resets,
  lc as useTheme
};
//# sourceMappingURL=index.js.map
